/*
 *
 * 802.1X related procedures
 *
 */ 

// update 8021.x menu onload
function updateIEEE8021x() 
{
	if (network_ieee8021x_enable == 1)
	{
		$("#ieee8021x_eap_peap").show();
		if (network_ieee8021x_eapmethod == "eap-tls")
		{
			$("#ieee8021x_eap_tls").show();
			$("#privatekey_password").show();
			$("#identity_tls").show();

			$("#ieee8021x_password").hide();
			$("#identity_peap").hide();
		}
		else
		{
			$("#ieee8021x_eap_tls").hide();
			$("#privatekey_password").hide();
			$("#identity_tls").hide();

			$("#ieee8021x_password").show();
			$("#identity_peap").show();
		}
	}
	else
	{
		$("#ieee8021x_eap_peap").hide();
		$("#ieee8021x_eap_tls").hide();
	}

	// update CA information size/date
	updateCAstatus();
}

function updateIEEE8021xcheck(inputName, eapmethod, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		$("#ieee8021x_eap_peap").slideDown("slow");
		updateEAPMethodselect(eapmethod);

		if (eapmethod.value == "eap-tls")
			$("#ieee8021x_eap_tls").slideDown("slow");
	}
	else
	{
		$("#ieee8021x_eap_peap").slideUp("slow");
		$("#ieee8021x_eap_tls").slideUp("slow");
	}
}

function updateEAPMethodselect(eapmethod)
{
	if (eapmethod.value == "eap-peap") 
	{
		$("#ieee8021x_eap_tls").slideUp("slow");
		$("#privatekey_password").hide();
		$("#ieee8021x_password").show();
		$("#identity_peap").show();
		$("#identity_tls").hide();
	}
	else if (eapmethod.value == "eap-tls")
	{
		$("#ieee8021x_eap_tls").slideDown("slow");
		$("#privatekey_password").show();
		$("#ieee8021x_password").hide();
		$("#identity_tls").show();
		$("#identity_peap").hide();
	}
}

// update actual ca related html content by input
function refreshCATimeAndSize (timeObj, time, sizeObj, size)
{
	timeObj.innerHTML = epoch_to_display_time(time);
	sizeObj.innerHTML = size + " " + translator("bytes");
}

function updateCAstatus() // update CA status onload
{
	var ca_time          = document.getElementById("ca_time");
	var ca_size          = document.getElementById("ca_size");
	var client_cert_time = document.getElementById("client_cert_time");
	var client_cert_size = document.getElementById("client_cert_size");
	var privatekey_time  = document.getElementById("privatekey_time");
	var privatekey_size  = document.getElementById("privatekey_size");

	var file_not_exist = "none"; // fgetstat will return 0 when file doesn't exist 

	// get acualt exist status 
	$.ajax({
			type: "GET",
			cache: false,
			url: "/cgi-bin/admin/getparam.cgi?network_ieee8021x_ca_exist&network_ieee8021x_certificate_exist&network_ieee8021x_privatekey_exist",
			async: false,
			success: function (returned_data) 
			{ eval(returned_data); }
			});

	// handle CA cert
	if (network_ieee8021x_ca_exist == "0")
	{
		ca_time.innerHTML = "";
		ca_size.innerHTML = translator("no_file");
		$("#ca_cert_remove_btn").attr("disabled", true);
	}
	else
	{
		refreshCATimeAndSize(
				ca_time, network_ieee8021x_ca_time, 
				ca_size, network_ieee8021x_ca_size);
		$("#ca_cert_remove_btn").attr("disabled", false);
	}

	// handle client cert on EAP-TLS
	if (network_ieee8021x_certificate_exist == "0")
	{
		client_cert_time.innerHTML = "";
		client_cert_size.innerHTML = translator("no_file");
		$("#client_cert_remove_btn").attr("disabled", true);
	}
	else
	{
		refreshCATimeAndSize(
				client_cert_time, network_ieee8021x_certificate_time,
				client_cert_size, network_ieee8021x_certificate_size);
		$("#client_cert_remove_btn").attr("disabled", false);
	}

	// handle client private key on EAP-TLS
	if (network_ieee8021x_privatekey_exist == "0")
	{
		privatekey_time.innerHTML = "";
		privatekey_size.innerHTML = translator("no_file");
		$("#privatekey_cert_remove_btn").attr("disabled", true);
	}
	else
	{
		refreshCATimeAndSize(
				privatekey_time, network_ieee8021x_privatekey_time,
				privatekey_size, network_ieee8021x_privatekey_size);
		$("#privatekey_cert_remove_btn").attr("disabled", false);
	}
}

function uploadIEEE8021xCAbyCriteria(uploadId, removebtnId, uploadBlockId, uploadURL, callbackOnSuccess)
{
	// check if input field is empty
	var uploadfile = document.getElementById(uploadId);
	if (checkPEMFile(uploadfile) != 0) 
	{
		alert(translator("invalid_pem_file"));
		return;
	}
	
	// upload file by ajax method
	$.ajaxFileUpload 
	({
		url: uploadURL,
		secureuri: false,
		fileElementId: uploadId,
		dataType: 'xml',
		success: function (data, status)
		{ 
            $("#" + removebtnId).attr("disabled", false);
			callbackOnSuccess();
		},
		error: function (data, status, e)
		{ 
			alert(translator("upload_fail"));
		}
	});

}

function updateClientTimeAndSize()
{
	$.get("/cgi-bin/admin/getparam.cgi?network_ieee8021x_certificate_time&network_ieee8021x_certificate_size",
		{},
		function (returned_data)
		{
			eval(returned_data);
			var client_cert_time = document.getElementById("client_cert_time");
			var client_cert_size = document.getElementById("client_cert_size");
			refreshCATimeAndSize(
				client_cert_time, network_ieee8021x_certificate_time,
				client_cert_size, network_ieee8021x_certificate_size);
			network_ieee8021x_certificate_exist = 1;
		}
	);
}


// CA/client certificate and privacy key time and date ajax update function
function updatePrivatekeyTimeAndSize()
{
	$.get("/cgi-bin/admin/getparam.cgi?network_ieee8021x_privatekey_time&network_ieee8021x_privatekey_size",
		{},
		function (returned_data)
		{
			eval(returned_data);
			var privatekey_time = document.getElementById("privatekey_time");
			var privatekey_size = document.getElementById("privatekey_size");
			refreshCATimeAndSize(
				privatekey_time, network_ieee8021x_privatekey_time,
				privatekey_size, network_ieee8021x_privatekey_size);
			network_ieee8021x_privatekey_exist = 1;
		}
	);
}

function updateCATimeAndSize ()
{
	$.get("/cgi-bin/admin/getparam.cgi?network_ieee8021x_ca_time&network_ieee8021x_ca_size",
		{},
		function (returned_data)
		{
			eval(returned_data);
			var ca_time = document.getElementById("ca_time");
			var ca_size = document.getElementById("ca_size");
			refreshCATimeAndSize(
				ca_time, network_ieee8021x_ca_time,
				ca_size, network_ieee8021x_ca_size);
			network_ieee8021x_ca_exist = 1;
		}
	);
}

function uploadIEEE8021xCA ()
{
	uploadIEEE8021xCAbyCriteria(
			"ca_cert_upload_id"                      , 
			"ca_cert_remove_btn"                     , 
			"ca_cert"                                , 
			"/cgi-bin/admin/upload_ieee8021x_ca.cgi" , 
			updateCATimeAndSize);
}

// CA/client and private key certificate upload procedures
function uploadIEEE8021xClient ()
{
	uploadIEEE8021xCAbyCriteria(
			"client_cert_upload_id"                         , 
			"client_cert_remove_btn"                        , 
			"client_cert"                                   , 
			"/cgi-bin/admin/upload_ieee8021x_client_ca.cgi" , 
			updateClientTimeAndSize);
}

function uploadIEEE8021xPrivate ()
{
	uploadIEEE8021xCAbyCriteria(
			"private_key_upload_id"                          , 
			"privatekey_cert_remove_btn"                     , 
			"private_key"                                    , 
			"/cgi-bin/admin/upload_ieee8021x_client_key.cgi" , 
			updatePrivatekeyTimeAndSize);
}


// CA/client and private key removal procedures
function removeCAbyCriteria(removeButton, removeURL, timeSpan, sizeSpan)
{
	$(removeButton).attr("disabled", true);
	$.get(
			removeURL, {}, 
			function (response) 
			{
				$(timeSpan).html('');
				$(sizeSpan).html(translator("no_file"));
			}
		 );

	// update ca status variable
	if (removeButton == "#ca_cert_remove_btn")
	{
		network_ieee8021x_ca_exist = 0;
	}
	else if (removeButton == "#client_cert_remove_btn")
	{
		network_ieee8021x_certificate_exist = 0;
	}
	else if (removeButton == "#privatekey_cert_remove_btn")
	{
		network_ieee8021x_privatekey_exist = 0;
	}

}

function removeCA()
{
	removeCAbyCriteria(
			'#ca_cert_remove_btn', 
			'/cgi-bin/admin/setparam.cgi?network_ieee8021x_ca_exist=0',
			'#ca_time',
			'#ca_size'
			);
}

function removeClientCert ()
{
	removeCAbyCriteria(
			'#client_cert_remove_btn',
			'/cgi-bin/admin/setparam.cgi?network_ieee8021x_certificate_exist=0',
			'#client_cert_time',
			'#client_cert_size'
			);
}

function removePrivateKey ()
{

	removeCAbyCriteria(
			'#privatekey_cert_remove_btn',
			'/cgi-bin/admin/setparam.cgi?network_ieee8021x_privatekey_exist=0',
			'#privatekey_time',
			'#privatekey_size'
			);
}


// check suffix correctness of .pem files
function checkPEMFile (uploadfile)
{
	return checkSuffix(uploadfile, "pem");
}

// function for processing ca time
function epoch_to_display_time (epoch)
{
	epoch = parseInt(epoch, 10);
	var pcTime = new Date();
	var system_time_zone = system_timezoneindex / 40;
	epoch = epoch + (system_time_zone * 60 * 60); // convert to
	epoch = epoch + pcTime.getTimezoneOffset() * 60;
	var time_obj = epoch_to_time(epoch);
	var formatted_time = get_date_string(time_obj) + " " + get_time_string(time_obj);

	return formatted_time;
}

function epoch_to_time (epoch)
{
	if (epoch < 10000000000)
	{
		epoch *= 1000;
	}

	var real_date = new Date();
	real_date.setTime(epoch);
	return real_date;
}

function auto_prepend_zero (digit)
{

	if (digit < 10)
	{
		digit = "0" + digit;
	}
	return digit;
}

function get_time_string (time_obj)
{
	var separator = ":";
	return auto_prepend_zero(time_obj.getHours()) + separator + auto_prepend_zero(time_obj.getMinutes());
}
function get_date_string (time_obj)
{
	var separator = "/";
	return time_obj.getFullYear() + separator + (time_obj.getMonth()+1) + separator + time_obj.getDate();
}


function checkIfCAExist ()
{
	var eapmethod = document.ieee8021x.network_ieee8021x_eapmethod.value;
	var ieee8021x_enable = document.ieee8021x.network_ieee8021x_enable.value;

	// skip ca checking if 802.1x is disabled
	if (ieee8021x_enable == "0") 
	{
		return 0;
	}

	if (eapmethod == "eap-peap")
	{ 
		if (network_ieee8021x_ca_exist == 0)
		{
			alert(translator("ca_cert_missing") + " " + translator("upload_first"));
			return -1;
		}
	}
	else if (eapmethod == "eap-tls")
	{
		if (network_ieee8021x_certificate_exist == 0)
		{
			alert(translator("client_cert_missing") + " " + translator("upload_first"));
			return -1;
		}
		else if (network_ieee8021x_privatekey_exist  == 0) 
		{
			alert(translator("client_private_missing") + " " + translator("upload_first"));
			return -1;
		}
	
	}
	return 0;
}

function checkPasswordVal()
{
	var passwordval;
	passwordval = document.ieee8021x.network_ieee8021x_password.value;
	if(checkDefaultPassword(passwordval) != 0)
	{
		document.ieee8021x.network_ieee8021x_password.disabled = true;
	}
	
	passwordval = document.ieee8021x.network_ieee8021x_privatekeypassword.value;
	if(checkDefaultPassword(passwordval) != 0)
	{
		document.ieee8021x.network_ieee8021x_privatekeypassword.disabled = true;
	}

	return 0;
}

function submitform_ieee8021x()
{
	if (checkvalue())
	{
		return -1;
	}
	if (checkIfCAExist()) 
	{
		return -1;
	}
	if(checkPasswordVal() != 0)
	{
		return -1;
	}
	
	$("#ca_cert_upload_id").attr("disabled", true);
	$("#client_cert_upload_id").attr("disabled", true);
	$("#private_key_upload_id").attr("disabled", true);
	document.getElementById("ieee8021x").submit();
	$("#ca_cert_upload_id").attr("disabled", false);
	$("#client_cert_upload_id").attr("disabled", false);
	$("#private_key_upload_id").attr("disabled", false);
	showNotification(30);
}

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
	if (network_ieee8021x_identity_peap != "")
	{
		document.ieee8021x.network_ieee8021x_password.value = getDefaultPassword();
	}
	if (network_ieee8021x_identity_tls != "")
	{
		document.ieee8021x.network_ieee8021x_privatekeypassword.value = getDefaultPassword();
	}
	// 802.1x
	updateIEEE8021x();
}

function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&system_timezoneindex&network", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("ieee8021x");
	
	loadlanguage();
	$('#notification').bgiframe();
}
