var giCH_Curr = 0;
var gbNoticed = false;
var gEnableextled;
var gEnableextledIndex = 0;
var gDNS = false;
var gbShowSensitivity = true;
var gbSensitivityNormalize = false;
	var TmpSensitivitySupportLevel;
	var TmpSensitivityStep;
var gSetExpousretoAutoMode = false;
var sensitivityStrings = ["low", "normal", "high"];
var fontPathVVTK       = "/usr/share/VVTK.ttf";
var fontPathCustomized = "/mnt/flash2/customized.ttf";
var gbSaved = false;
var bWDRPro = false;
	var bWDROnSIRHidden = false;
var bExpWin = false;
	var TmpExpWinMode;
	var bExpWinModeImpactSIRHidden = false;

//Called when the Web page is on loading.
function loadCurrentSetting()
{	
	var tmp = location.href.split("?");
    	var tmp2 = tmp[1].split("=");

	if (tmp2[0] == 'ch')
	{
		giCH_Curr = parseInt(tmp2[1], 10);
	}

	// capability group
	{
		var capabilityStr=
			"&capability_daynight_c"+giCH_Curr+"_support"+
			"&capability_daynight_c"+giCH_Curr+"_externalir"+
			"&capability_daynight_c"+giCH_Curr+"_extled_interface"+
			"&capability_daynight_c"+giCH_Curr+"_builtinir"+
			"&capability_daynight_c"+giCH_Curr+"_smartir"+
			"&capability_daynight_c"+giCH_Curr+"_ircutfilter"+
			"&capability_daynight_c"+giCH_Curr+"_lightsensor"+
			"&capability_daynight_c"+giCH_Curr+"_ircutsensitivity_type"+
			"&capability_daynight_c"+giCH_Curr+"_ircutsensitivity_supportlevel"+
			"&capability_daynight_c"+giCH_Curr+"_blackwhitemode"+
			"&capability_ndi"+"&capability_ptzenabled"+
			"&capability_image_c"+giCH_Curr;
	}
	
	// ircutcontrol group
	{
		var ircutcontrolStr=
			"&ircutcontrol_bwmode"+"&ircutcontrol_disableirled"+
			"&ircutcontrol_enableextled"+"&ircutcontrol_extledmode"+
			"&ircutcontrol_mode"+"&ircutcontrol_daymodebegintime"+"&ircutcontrol_daymodeendtime"+
			"&ircutcontrol_sensitivity"+"&ircutcontrol_sir";
	}

	// exposure group
	{
		var exposureStr="&videoin_c"+giCH_Curr+"_exposuremode";
	}

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&videoin_c"+giCH_Curr+capabilityStr+ircutcontrolStr+exposureStr+"&exposurewin_c"+giCH_Curr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();
}

function findWDRImpact()
{
	//Find WDR impact.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_wdrpro_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_wdrpro_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("sir:hidden:"))
			{
				bWDROnSIRHidden = true;
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findExpWinModeImpact()
{
	//Find Exposure window mode impact.
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_"+TmpExpWinMode+"mode_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_exposure_"+TmpExpWinMode+"mode_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("sir:hidden:"))
			{
				bExpWinModeImpactSIRHidden = true;
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

//Called when the Web page is loaded done.
//Start point of this code.
function receivedone()
{
	//WDR pro = 1
	//WDR pro & WDR proII = 2
	if (1 <= parseInt(eval("capability_image_c"+giCH_Curr+"_wdrpro_mode"), 10) 
	&& ((0 != parseInt(eval("videoin_c"+giCH_Curr+"_wdrpro_mode"))) || (0 != parseInt(eval("videoin_c"+giCH_Curr+"_profile_i0_wdrpro_mode")))))
	{
		bWDRPro = true;
		findWDRImpact();
	}
	
	//Exposure window.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_exposure_winmode"))
	{
		bExpWin = true;
		TmpExpWinMode = eval("exposurewin_c"+giCH_Curr+"_mode");
		findExpWinModeImpact();
		TmpExpWinMode = eval("exposurewin_c"+giCH_Curr+"_profile_i0_mode");
		findExpWinModeImpact();
	}
	
	// IR related features
	checkDayNightRelatedFeatures();

}


//Called when all objects in Web page is ready.
function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";

}

function saveGeneralSettingsDayNight()
{
	var XMLHttpRequestObject = null;
	var commitList = "";
	var tmp = "";

	gbSaved = true;

	$("#dayNightSettingsSaveButton").attr("disabled", true);

	if (window.XMLHttpRequest)
	{
		XMLHttpRequestObject = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{
		XMLHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	tmp = "videoin_c"+giCH_Curr+"_";

	commitList = "/cgi-bin/admin/setparam.cgi?"+"ircutcontrol_bwmode="+eval("ircutcontrol_bwmode");

	
	// append the part of DayNightSetting
	if (0 != eval("capability_daynight_c"+giCH_Curr+"_support"))
	{
		commitList = appendDNSCommitList(commitList);
	}

	// append the part of Speed Dome
	if (gSetExpousretoAutoMode)
	{
		commitList = commitList +"&"+"videoin_c"+giCH_Curr+"_exposuremode=auto";
	}
	
	XMLHttpRequestObject.open("GET", commitList);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	setTimeout('$("#dayNightSettingsSaveButton").attr("disabled", false)', 500);

}

function setIRCutBWMode(checked)
{
	if (false == checked)
	{
		eval("ircutcontrol_bwmode=0");
	}
	else
	{
		eval("ircutcontrol_bwmode=1");
	}
}

function IsMountedExtIRByDO()
{
	var ExtIROptSeletor = getExtIROptSelector();
        var bMountedExtIRByDO = true;

        if (null != ExtIROptSeletor)
        {
                if ("do" != (ExtIROptSeletor.options[ExtIROptSeletor.selectedIndex].value))
                {
                        bMountedExtIRByDO = false;
                }
        }

	return bMountedExtIRByDO;
}

function setExtIR(checked)
{
	var bMountedExtIRByDO = IsMountedExtIRByDO ();

	if ((false == gEnableextled) && (true == bMountedExtIRByDO))
	{
		if (!confirm(translator("turn_on_extir_warning_message")))
		{
			document.getElementById("externalir").checked = false;
			return;
		}
	}
	gEnableextled = checked;

	if (true == checked)
	{
		eval("ircutcontrol_enableextled=1");
	}
	else
	{
		eval("ircutcontrol_enableextled=0");
	}
}

function getExtIROptSelector()
{
	var ExtIROptions = null;
	try {
		ExtIROptions = document.getElementById('extir_opt_selector');
	}
	catch(e){
	}
	return ExtIROptions;
}

function setExtIRDevice()
{
	var ExtIROptSeletor = getExtIROptSelector();
	var bMountedExtIRByDO = IsMountedExtIRByDO ();

	if ((null != ExtIROptSeletor) &&(true == gEnableextled) && (true == bMountedExtIRByDO))
	{
		if (!confirm(translator("turn_on_extir_warning_message")))
		{
			ExtIROptSeletor.selectedIndex = gEnableextledIndex;
			return;
		}
	}
	gEnableextledIndex = ExtIROptSeletor.selectedIndex;
}

function checkSIRMode()
{
	var bMountedExtIRByDO = IsMountedExtIRByDO ();
	
	if (false == bMountedExtIRByDO)
	{
		return;
	}

	if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir")) 
	{
		if ((bWDRPro && bWDROnSIRHidden) || (bExpWin && bExpWinModeImpactSIRHidden))
		{
			$("#sirChild").slideUp("slow");
		}
		else
		{
			if (document.getElementById("irled_checkbox").checked || document.getElementById("externalir").checked)
			{
				$("#sirChild").slideDown("slow");
			}
			else
			{
				$("#sirChild").slideUp("slow");
			}
		}
	}
}

function setDisableBuiltInIR(checked)
{
	//set the inverse value;
	if (true == checked)
	{
		eval("ircutcontrol_disableirled=0");
	}
	else
	{
		eval("ircutcontrol_disableirled=1");
	}
}

function setSIR(checked)
{
	if (true == checked)
	{
		eval("ircutcontrol_sir=1");
	}
	else
	{
		eval("ircutcontrol_sir=0");
	}
}

function checkDayNightMode(mode)
{
	document.getElementById("setExpModetoAutoMessage").style.display = "none";
	// Kent@20110930, Auto ICR can not work under AE: Manual ONLY, for AE: auto under Auto ICR mode
	if (isSpeedDome(capability_ptzenabled) == 1)
	{
		if (mode == "auto")
		{
			if ("manual" == eval("videoin_c"+giCH_Curr+"_exposuremode"))
			{
				gSetExpousretoAutoMode = true;
				document.getElementById("setExpModetoAutoMessage").style.display = "block";
				$("setExpModetoAutoMessage").slideDown("slow");
			}
			else
			{
				gSetExpousretoAutoMode = false;
			}
		}
	}

	if (mode == "auto")
	{
		$("#scheduleModeChild").slideUp("slow");
		$("#autoModeChild").slideDown("slow");

		if (gDNS == true)
		{
			$("#autoModeChildMessage").slideDown("slow");
		}
	}
	else if (mode == "schedule")
	{
		$("#scheduleModeChild").slideDown("slow");
		$("#autoModeChild").slideUp("slow");
		
		if (gDNS == true)
		{
			$("#autoModeChildMessage").slideUp("slow");
		}
	}
	else
	{
		$("#scheduleModeChild").slideUp("slow");
		$("#autoModeChild").slideUp("slow");
		
		if (gDNS == true)
		{
			$("#autoModeChildMessage").slideUp("slow");
		}
	}
}

function setDayNightMode(mode)
{
	eval("ircutcontrol_mode='"+mode+"'");
}

function changeDayModeBeginTime(text)
{
	if (-1 == checkInString(text))
	{
		text.value = eval("ircutcontrol_daymodebegintime");
		return;
	}

	eval("ircutcontrol_daymodebegintime='"+text.value+"'");
}

function changeDayModeEndTime(text)
{
	if (-1 == checkInString(text))
	{
		text.value = eval("ircutcontrol_daymodeendtime");
		return;
	}

	eval("ircutcontrol_daymodeendtime='"+text.value+"'");
}

function setLightSensorSensitivity(level)
{
	eval("ircutcontrol_sensitivity='"+level+"'");
}

function setIRCutSensitivity(level)
{
	eval("ircutcontrol_sensitivity='"+level+"'");
	//setIRCutSensitivityPreview(level);
}

function setIRCutSensitivityPreview(value)
{
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "ircutcontrol_sensitivity=" + value,
		cache: false
	});
}

function generateExternalIRNaming(value)
{
        var szReturn = translator("null");
        switch(value)
        {
        case "do":
                szReturn = translator("digital_output");
                break;
        case "irring":
                szReturn = translator("ir_illuminator_ring");
                break;
        default:
                break;
        }
        return szReturn;
}

function generateExternalIRList()
{
	var bSupportExtIROptions = !ParamUndefinedOrZero("capability_daynight_c"+giCH_Curr+"_extled_interface");
	if (true == bSupportExtIROptions)
	{
		var opt = eval("capability_daynight_c"+giCH_Curr+"_extled_interface");
		var tmp = opt.split(",").sort();
		if (tmp.length > 1)
		{
			var useValue = getParamValueByName("ircutcontrol_extledmode");
			var useIndex = 0;
                        $(document.getElementById('externalir_section')).append(""
                        +' <select id="extir_opt_selector" style="padding:0px 0px 0px 2px" valign="top" class="position_av" onchange="setExtIRDevice(this.value)">'
                        +' </select>'
                        );
			for (var i = 0; i < tmp.length; i++)
			{
                                var newItem = document.createElement('option');
                                newItem.innerHTML = generateExternalIRNaming(tmp[i]);
                                newItem.value = tmp[i];
                                document.getElementById('extir_opt_selector').appendChild(newItem);
				// Assign the selected value by loading data.
				if (useValue == newItem.value)
				{
					document.getElementById('extir_opt_selector').selectedIndex = useIndex;
					gEnableextledIndex = useIndex;
				}
				useIndex ++;
			}
		}
	}
}
	
function checkDayNightRelatedFeatures()
{
	//BW Mode
	if (ircutcontrol_bwmode == '1')
	{
		document.getElementById("bwmode").checked = 1;
	}
	else
	{
		document.getElementById("bwmode").checked = 0;
	}

	if (ParamUndefined("capability_daynight_c"+giCH_Curr+"_blackwhitemode"))
	{
		document.getElementById("switchbw_section").style.display = "block";
	}
	else
	{
		if (1 == eval("capability_daynight_c"+giCH_Curr+"_blackwhitemode")) 
		{
			document.getElementById("switchbw_section").style.display = "block";
		}
	}
	
	//External IR
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_externalir"))
	{
		document.getElementById("externalir_section").style.display = "block";
		gEnableextled = (ircutcontrol_enableextled == '1' ? true : false);
		
		if (ircutcontrol_enableextled == '1')
		{
			document.getElementById("externalir").checked = 1;
		}
		else
		{
			document.getElementById("externalir").checked = 0;
		}
		
		generateExternalIRList();
	}

	//Built-in IR
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_builtinir")) 
	{
		document.getElementById("builtinir_section").style.display = "block";
		if (ircutcontrol_disableirled == '1')
		{
			document.getElementById("irled_checkbox").checked = 0;
		}
		else
		{
			document.getElementById("irled_checkbox").checked = 1;
		}
	}

	// Smart IR
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir")) 
	{
		if (ircutcontrol_sir == '1')
		{
			document.getElementById("sir").checked = 1;
		}
		else
		{
			document.getElementById("sir").checked = 0;
		}
		checkSIRMode();
	}

	// IRCut Filter
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_support")) 
	{
		if (eval("capability_ndi") == 0) 
		{
			$("#dayNightMode option[value='di']").remove();
		}

		$(document.getElementById("dayNightMode")).children().each(
			function()
			{
				if (eval("ircutcontrol_mode") == this.value)
				{	
					this.selected = true;
				}
			}
		);
		checkDayNightMode(eval("ircutcontrol_mode"));
		document.getElementById("daymodebegintime").value = eval("ircutcontrol_daymodebegintime");
		document.getElementById("daymodeendtime").value   = eval("ircutcontrol_daymodeendtime");
	}

	//whether to hide sensitivity block
	if(ParamUndefinedOrZero("capability_daynight_c"+giCH_Curr+"_ircutsensitivity_type"))
	{
		gbShowSensitivity = false;
		document.getElementById("autoModeChildMessage").style.display = "none";
	}

	// ICR sensitivity UI style: selection or Slider bar
	if ("normalize" == getParamValueByName("capability_daynight_c"+giCH_Curr+"_ircutsensitivity_type"))
	{
		gbSensitivityNormalize = true;

		TmpSensitivitySupportLevel = parseInt(eval("capability_daynight_c"+giCH_Curr+"_ircutsensitivity_supportlevel"));

		if (TmpSensitivitySupportLevel < 3)
		{
			TmpSensitivitySupportLevel = 2;
			TmpSensitivityStep = 99;
		}
		else
		{
			TmpSensitivityStep = Math.floor(100 / (TmpSensitivitySupportLevel - 1));
		}
	}
	
	// Light senor
	if ((1 == eval("capability_daynight_c"+giCH_Curr+"_lightsensor"))&&gbShowSensitivity) 
	{
		if (!gbSensitivityNormalize)
		{
			$(document.getElementById("lightSensorSensitivity")).children().each(
				function()
				{
					if (eval("ircutcontrol_sensitivity") == this.value)
					{	
						this.selected = true;
					}
				}
			);
			document.getElementById("lightSensorSensitivity_section").style.display = "block";
		}
		else
		{
			document.getElementById("ircutSensitivitySliderTitle").innerHTML = translator("light_sensor_sensitivity");
			document.getElementById("IRCutSensitivity_slider").style.display = "block";

			//This is kept for compatibility
			TmpSensitivityNor = eval("ircutcontrol_sensitivity");
			switch (TmpSensitivityNor)
			{
				case "low":
					TmpSensitivityNor = 1;
					break;
				case "normal":
					TmpSensitivityNor = 50;
					break;
				case "high":
					TmpSensitivityNor = 100;
					break;
				default:
					TmpSensitivityNor = parseInt(TmpSensitivityNor, 10);
					break;
			}

			var SensitivitySliderUI = mappingStrengthUI(TmpSensitivityNor, TmpSensitivitySupportLevel, TmpSensitivityStep);

			$("#IRCutSensitivityValue").html(""+TmpSensitivityNor+" %");
			$("#IRCutSensitivitySlider").slider(
			{
				min: 1,
				max: 100,
				step: TmpSensitivityStep,
				animate: true,
				value: SensitivitySliderUI,
				slide: function(event, ui)
				{
					if (ui.value > 100)
					{
						ui.value = 100;
					}
					$("#IRCutSensitivityValue").html(""+ui.value+" %");
				},
				change: function(event, ui)
				{
					TmpSensitivityNor = ui.value;
					/*
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "ircutcontrol_sensitivity="+TmpSensitivityNor,
						async: false,
						cache: false
					});
					*/
				}	
			});
		}
		document.getElementById("autoModeChildMessage").style.display = "none";
	}
	else if((0 == eval("capability_daynight_c"+giCH_Curr+"_lightsensor"))&&gbShowSensitivity)
	{
		gDNS = true;

		if (!gbSensitivityNormalize)
		{
			$(document.getElementById("ircutSensitivity")).children().each(
				function()
				{
					if (eval("ircutcontrol_sensitivity") == this.value)
					{	
						this.selected = true;
					}
				}
			);
			document.getElementById("IRCutSensitivity_section").style.display = "block";
		}
		else
		{
			document.getElementById("IRCutSensitivity_slider").style.display = "block";
			
			//This is kept for compatibility
			TmpSensitivityNor = eval("ircutcontrol_sensitivity");
			switch (TmpSensitivityNor)
			{
				case "low":
					TmpSensitivityNor = 1;
					break;
				case "normal":
					TmpSensitivityNor = 50;
					break;
				case "high":
					TmpSensitivityNor = 100;
					break;
				default:
					TmpSensitivityNor = parseInt(TmpSensitivityNor, 10);
					break;
			}
			
			var SensitivitySliderUI = mappingStrengthUI(TmpSensitivityNor, TmpSensitivitySupportLevel, TmpSensitivityStep);

			$("#IRCutSensitivityValue").html(""+TmpSensitivityNor+" %");
			$("#IRCutSensitivitySlider").slider(
			{
				min: 1,
				max: 100,
				step: TmpSensitivityStep,
				animate: true,
				value: SensitivitySliderUI,
				slide: function(event, ui)
				{
					if (ui.value > 100)
					{
						ui.value = 100;
					}
					$("#IRCutSensitivityValue").html(""+ui.value+" %");
				},
				change: function(event, ui)
				{
					TmpSensitivityNor = ui.value;
					/*
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "ircutcontrol_sensitivity="+TmpSensitivityNor,
						async: false,
						cache: false
					});
					*/
				}	
			});
		}

		document.getElementById("autoModeChildMessage").style.display = "block";

		if (eval("capability_daynight_c"+giCH_Curr+"_ircutfilter") == 0) 
		{
			document.getElementById("dayNightModeTitle").innerHTML = translator("day_night_filter");
			document.getElementById("ircutSensitivityTitle").innerHTML = translator("day_night_filter_sensitivity");
		}

		if (eval("ircutcontrol_mode") == "auto")
		{
			$("#autoModeChildMessage").slideDown("slow");
			
			$.ajax({
				type: "POST",
				url: "/cgi-bin/admin/setparam.cgi",
				data: "videoin_c0_profile_i0_enable=0",
				cache: false
			});
		}
		else
		{
			$("#autoModeChildMessage").slideUp("slow");
		}
	}
}

function setFontType(type)
{
	if (type == "fontvvtk")
	{
		eval("videoin_c"+giCH_Curr+"_textonvideo_fontpath='"+fontPathVVTK+"'");
		document.getElementById("fontvvtk").checked = true;
		document.getElementById("fontcustomized").checked = false;
	}
	else if (type == "fontcustomized")
	{
		eval("videoin_c"+giCH_Curr+"_textonvideo_fontpath='"+fontPathCustomized+"'");
		document.getElementById("fontvvtk").checked = false;
		document.getElementById("fontcustomized").checked = true;
	}
}
	
function appendDNSCommitList(commitList)
{
	//commitList = commitList +"&"+"ircutcontrol_bwmode="+eval("ircutcontrol_bwmode");
	commitList = commitList +"&"+"ircutcontrol_mode="+eval("ircutcontrol_mode");
	commitList = commitList +"&"+"ircutcontrol_daymodebegintime="+eval("ircutcontrol_daymodebegintime");
	commitList = commitList +"&"+"ircutcontrol_daymodeendtime="+eval("ircutcontrol_daymodeendtime");
	
	if (gbSensitivityNormalize&&gbShowSensitivity)
	{
		commitList = commitList +"&"+"ircutcontrol_sensitivity="+TmpSensitivityNor;
	}
	else if((!gbSensitivityNormalize)&&gbShowSensitivity)
	{
		commitList = commitList +"&"+"ircutcontrol_sensitivity="+eval("ircutcontrol_sensitivity");
	}

	if (1 == eval("capability_daynight_c"+giCH_Curr+"_externalir"))
	{
		commitList = commitList +"&"+"ircutcontrol_enableextled="+eval("ircutcontrol_enableextled");
	}
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_builtinir"))
	{
		commitList = commitList +"&"+"ircutcontrol_disableirled="+eval("ircutcontrol_disableirled");
	}
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir"))
	{
		commitList = commitList +"&"+"ircutcontrol_sir="+eval("ircutcontrol_sir");
	}
	
	if (gDNS == true)
	{
		if (eval("ircutcontrol_mode") == "auto")
		{
			commitList = commitList +"&"+"videoin_c0_profile_i0_enable=0";
		}
	}

	if(false == ParamUndefinedOrZero("capability_daynight_c"+giCH_Curr+"_extled_interface"))
	{
		var ExtIR = null;

		try { 
			ExtIR = document.getElementById('extir_opt_selector');
		}
		catch(e){
		}

		if (null != ExtIR)
		{
			commitList = commitList +"&"+"ircutcontrol_extledmode="+ExtIR.options[ExtIR.selectedIndex].value;
		}
	}

	return commitList;
}

function RestoreSliderSetting()
{
	var restoreParams ="";

	//This is kept for compatibility
	if (gbSensitivityNormalize&gbShowSensitivity)
	{
		TmpSensitivityNor = eval("ircutcontrol_sensitivity");
		switch (TmpSensitivityNor)
		{
			case "low":
			TmpSensitivityNor = 1;
			break;
			case "normal":
			TmpSensitivityNor = 50;
			break;
			case "high":
			TmpSensitivityNor = 100;
			break;
			default:
			TmpSensitivityNor = parseInt(TmpSensitivityNor, 10);
			break;
		}
		
		restoreParams = restoreParams + "ircutcontrol_sensitivity="+ TmpSensitivityNor + "&";
	}
		
	if (restoreParams != "")
	{
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/setparam.cgi",
			data: restoreParams,
			async: false,
			cache: false
		});
	}
}

function RestoreSetting()
{
	// Spec said: Day/Night settings do not support instant-preview, so that we could skip the restore setting.
	/*
	if (!gbSaved)
	{
		RestoreSliderSetting();
	}
	*/
	return;
}
