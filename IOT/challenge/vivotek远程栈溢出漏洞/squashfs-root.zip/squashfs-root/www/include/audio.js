//Global variable:
var giCH_Curr = 0;

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?audioin&system_info_language&system_info_customlanguage&capability", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("audio");

	if (g_mode == "0")
	{
		var hideOptions = new Array();
		hideOptions.push("aacChild", "gsmChild", "g711Child");
		jQuery.each(hideOptions, function(i) { 
			$("#" + hideOptions[i]).css("display","none");
		});
	}
		
	loadlanguage();
}

function receivedone()
{
    var bMicHardwareSwitch = capability_audio_michardwareswitch;
	var bInternalMic     = capability_audio_intmic;
	var bExternalMic     = capability_audio_extmic;
	showMicRegion(bMicHardwareSwitch, bInternalMic, bExternalMic);

	showCodecRegion();
	showaecRegion();
	
    if( lan >= 100 ) //custom language
       return -1;
    
}

function loadvaluedone()
{
	form = document.forms[0];
	
	$("#aacChild, #gsmChild, #g711Child").hide();

	checkAudioType();

	document.getElementById("content").style.visibility = "visible";
	
	var f = document.audiovideo;
	//internal_microphone_input_gain
	$("#internal_adjust_fix").html(f.audioin_c0_volume_internal.value + "%");
	$("#internal_adjust_slider_handle div.ui-slider-handle").attr("title", f.audioin_c0_volume_internal.value);
	$("#internal_adjust_slider_handle" ).slider({
		min: 0,
		max: 100,
		animate: true,
		value: f.audioin_c0_volume_internal.value,
		slide: function(event, ui)
		{
			$("#internal_adjust_fix").html(ui.value + "%");
		},
		change: function(event, ui)
		{
			$("#internal_adjust_slider_handle div.ui-slider-handle").attr("title", ui.value);
			f.audioin_c0_volume_internal.value = ui.value;
		}	
	});

	//external_microphone_input_gain
	$("#external_adjust_fix").html(f.audioin_c0_volume_external.value + "%");
	$("#external_adjust_slider_handle div.ui-slider-handle").attr("title", f.audioin_c0_volume_external.value);
	$("#external_adjust_slider_handle" ).slider({
		min: 0,
		max: 100,
		animate: true,
		value: f.audioin_c0_volume_external.value,
		slide: function(event, ui)
		{
			$("#external_adjust_fix").html(ui.value + "%");
		},
		change: function(event, ui)
		{
			$("#external_adjust_slider_handle div.ui-slider-handle").attr("title", ui.value);
			f.audioin_c0_volume_external.value = ui.value;
		}	
	});
}

function checkAudioType()
{
	form = document.forms[0];

	if (getCheckedValue(form.audioin_c0_s0_codectype) == "aac4")
	{
		$("#aacChild").slideDown("slow");
		$("#gsmChild").slideUp("slow");
		$("#g711Child").slideUp("slow");
	}
	else if (getCheckedValue(form.audioin_c0_s0_codectype) == "gamr")
	{
		$("#gsmChild").slideDown("slow");
		$("#aacChild").slideUp("slow");	
		$("#g711Child").slideUp("slow");	
	}
	else
	{
		$("#g711Child").slideDown("slow");
		$("#aacChild").slideUp("slow");	
		$("#gsmChild").slideUp("slow");	
	}
}


function proceed()
{
	var board = document.getElementById("progress_bar");
	count --;
	if (count < 0)
	{
		location.reload();
			
	}
	else
	{	
		board.value = board.value + "|";
		setTimeout("proceed()", intervel);
	}
}

function showProgressBar(barID, waitingTime)
{
	document.getElementById("notification").style.display = "block";
	document.getElementById(barID).style.display = "block";
	wait_time = waitingTime;
	count = 70;
	intervel = wait_time * 1000 / count;
	proceed();
}


function submitform()
{
	form = document.forms[0];

	if(checkvalue())
	{
		return -1;	
	}
	else
	{
		form.submit();
	}
	
	saveAudioSettings();
	if(!ParamUndefinedOrZero("capability_audio_aecswitch"))
	{	
		showProgressBar("waitingbar", 20);
	}	
}

function showMicRegion(bMicHardwareSwitch, bInternalMic, bExternalMic)
{
	//it only need to show the selected options on UI, if there is no "microphone source switch" on camera
	if (bInternalMic == true && bExternalMic == true && bMicHardwareSwitch == false)
	{
		$("#microphone_source").css("display","block");
	}

	//doesn't support internal mic, hide the region
	if (bInternalMic == false)
	{
		$("#internal_microphone_region").css("display","none");
		$("#audio_input").val("extmic");
	}
	
	//doesn't support external mic, hide the region
	if (bExternalMic == false)
	{
		$("#external_microphone_region").css("display","none");
		$("#audio_input").val("intmic");
	}
}

function showaecRegion()
{
	if(ParamUndefinedOrZero("capability_audio_aecswitch"))
	{
		document.getElementById("aec_checkbox").style.visibility = "hidden";
		document.getElementById("aec_span").style.visibility = "hidden";	
	}	
	else
	{
		document.getElementById("aec_checkbox").style.visibility = "visible";
		document.getElementById("aec_span").style.visibility = "visible";

	}	

}


function showCodecRegion()
{
	form = document.forms[0];
	var supportCodec = capability_audioin_codec.split(",");
	for (var i = 0; i < supportCodec.length; i++) 
	{
		switch (supportCodec[i])
		{
			case "aac4":
				$("#aacParent").css("display","block");
				form.audioin_c0_s0_aac4_bitrate.value = audioin_c0_s0_aac4_bitrate;
				break;
			case "gamr":
				$("#gamrParent").css("display","block");
				form.audioin_c0_s0_gamr_bitrate.value = audioin_c0_s0_gamr_bitrate;
				break;
			case "g711":
				$("#g711Parent").css("display","block");
				form.audioin_c0_s0_g711_mode.value = audioin_c0_s0_g711_mode;
				break;
			case "g726":
				$("#g726Parent").css("display","block");
				form.audioin_c0_s0_g726_bitrate.value = audioin_c0_s0_g726_bitrate;
				break;
		}
	}
}

function changeBitRate(s, codec, obj)
{
	eval("audioin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate='"+obj.value+"'");
}

function changeMode(s, codec, obj)
{
	eval("audioin_c"+giCH_Curr+"_s"+s+"_"+codec+"_mode='"+obj.value+"'");
}

function saveAudioSettings()
{
	var XMLHttpRequestObject = null;
	var commitList = "";
	var commonList = "";
	var aac4List = "";
	var gamrList = "";
	var g711List = "";
	var g726List = "";
	var tmp = "";

	for (iSave = 0; iSave < parseInt(capability_nmediastream, 10); iSave++)
	{
		if (window.XMLHttpRequest)
		{
			XMLHttpRequestObject = new XMLHttpRequest();
		}
		else if (window.ActiveXObject)
		{
			XMLHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
		}

		if (capability_videoin_codec.search("aac4") != -1)
		{
			tmp = "audioin_c"+giCH_Curr+"_s"+giCH_Curr+"_aac4_";
			aac4List = tmp+"bitrate="+eval(tmp+"bitrate")+"&";
		}
		
		if (capability_videoin_codec.search("gamr") != -1)
		{
			tmp = "audioin_c"+giCH_Curr+"_s"+giCH_Curr+"_gamr_";
			gamrList = tmp+"bitrate="+eval(tmp+"bitrate")+"&";
		}

		if (capability_videoin_codec.search("g711") != -1)
		{
			tmp = "audioin_c"+giCH_Curr+"_s"+giCH_Curr+"_g711_";
			g711List = tmp+"mode="+eval(tmp+"mode")+"&";
		}
		
		if (capability_videoin_codec.search("g726") != -1)
		{
			tmp = "audioin_c"+giCH_Curr+"_s"+giCH_Curr+"_g726_";
			g726List = tmp+"bitrate="+eval(tmp+"bitrate")+"&";
		}
		
		commitList = "/cgi-bin/admin/setparam.cgi?"+ commonList + aac4List + gamrList + g711List + g726List;

		XMLHttpRequestObject.open("GET", commitList);
		XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
		XMLHttpRequestObject.send(null);
	}
}
