

function loadCurrentSetting()
{	
	loadlanguage();
	parent.document.getElementById("privacybutton").height = document.body.scrollHeight;
	document.getElementById("content").style.visibility = "visible";
}

function NewButton()
{
	parent.document.getElementById("privacypage").contentDocument.getElementById("privacyNewButton").click();
}

function SaveButton()
{
	parent.document.getElementById("privacypage").contentDocument.getElementById("privacySaveButton").click();
}

