streamsource=getCookie("streamsource");
if(streamsource > (capability_nmediastream - 1))
{
    streamsource = 0;
    setCookie("streamsource", 0);
}
streamingbuffertime=getCookie("streamingbuffertime");
eval("VideoSize=videoin_c0_s"+streamsource+"_resolution");
eval("codectype=videoin_c0_s"+streamsource+"_codectype");
if(codectype=="mpeg4" || codectype=="h264")
  eval("AccessName=network_rtsp_s"+streamsource+"_accessname");
else
  eval("AccessName=network_http_s"+streamsource+"_accessname");

/* for switching between half-duplex & full-duplex */
var EDuplexMode = {"half": "1", "full": "2"};	// starts from 1 to avoid the situation of returning value 0 from getCookie when the cookie is not set
var COOKIE_DUPLEX_MODE = "duplexmode";
var DEFAULT_DUPLEX_MODE = EDuplexMode.half;

function setDuplexMode(eDuplexMode)
{
	setCookie(COOKIE_DUPLEX_MODE, eDuplexMode);
}

function getDuplexMode()
{
	var eDuplexMode = getCookie(COOKIE_DUPLEX_MODE);

	if (0 == eDuplexMode) 
	{
		setDuplexMode(DEFAULT_DUPLEX_MODE);

		return DEFAULT_DUPLEX_MODE;
	}
	
	return eDuplexMode;
}

/* RTSP plug-in defines */
var PLUGIN_ID = "WinLessPluginCtrl";
var PLUGIN_NAME = "VVTK_Plugin_Installer.exe";
var PLUGIN_VER = "1,1,0,24";
var CLASS_ID = "64865E5A-E8D7-44C1-89E1-99A84F6E56D0";
var FFTYPE = "application/x-streamctrl";
var FF_VER = "1.0.0.88";
var VNDPWRAPPER_VER = "";
var FF_XPI_DESCRIPTION = "Installer Management v" + FF_VER;


var X_OFFSET = 10;
var Y_OFFSET = 30;

var X_OFFSET_CTRL = X_OFFSET;
var Y_OFFSET_CTRL = Y_OFFSET + 36;
var X_OFFSET_MD = X_OFFSET + 220;
var Y_OFFSET_MD = Y_OFFSET;
var CSET_TYPE = 101;
var CSET_HEIGHT = 200;
var STRETCH = "false";
var PLUGIN_LANG="EN";

var ss_width_offset = 40;
var ss_height_offset = 90;
var Width, Height;
var BaseWidth = 320;
var BaseHeight = 240;

//This must be a ascending list, and match following "switch case" 
var VideoSizeAry = ["176x144", "320x240", "360x240", "640x480", "720x480", "800x600", "1280x720", "1280x960", "1280x1024", "1600x1200"];
function evalPluginSize()
{
	switch(VideoSize)
	{
		case "1600x1200":
			Width = 1600;
			Height = 1200;
			W = 1600;
			H = 1200;
			break;
		case "1280x1024":
			Width = 1280;
			Height = 1024;
			W = 1280;
			H = 1024;
			break;
		case "1280x720":
			Width = 1280;
			Height = 720;
			W = 1280;
			H = 720;
			break;
		case "1280x960":
			Width = 1280;
			Height = 960;
			W = 1280;
			H = 960;
			break;
		case "800x600":
			Width = 800;
			Height = 600;
			W = 800;
			H = 600;
			break;
		case "720x480":
			Width = 720;
			Height = 480;
			W = 720;
			H = 480;
			break;
		case "640x480":
			Width = 640;
			Height = 480;
			W = 640;
			H = 480;
			break;
		case "360x240":
			Width = 360;
			Height = 240;
			W = 360;
			H = 240;
			break;
		case "320x240":
			Width = 320;
			Height = 240;
			W = 320;
			H = 240;
			break;
		case "176x144":
			Width = 176;
			Height = 144;
			W = 176;
			H = 144;
			STRETCH = "false";
			break;

		case "D1":
			Width = 720;
			if (status_videomode_c0 == "pal")
				Height = 576;
			else if (status_videomode_c0 == "ntsc")
				Height = 480;
			W = Width;
			H = Height;
			STRETCH = "true";
			break;	
			case "4CIF":
				Width = 704;
			if (status_videomode_c0 == "pal")
				Height = 576;
			else if (status_videomode_c0 == "ntsc")
				Height = 480;
			W = Width;
			H = Height;
			STRETCH = "true";
			break;	
		case "CIF":
			Width = 352;
			if (status_videomode_c0 == "pal")
				Height = 288;
			else if (status_videomode_c0 == "ntsc")
				Height = 240;
			W = Width;
			H = Height;
			STRETCH = "true";
			break;	
		case "QCIF":
			Width = 176;
			if (status_videomode_c0 == "pal")
				Height = 144;
			else if (status_videomode_c0 == "ntsc")
				Height = 120;
			W = Width;
			H = Height;
			STRETCH = "true";
			break;
		default:
			W = Width = parseInt(VideoSize.split('x')[0]);
			H = Height = parseInt(VideoSize.split('x')[1]);
			/*Width = parseInt(VideoSize.split('x')[0]);
			Height = parseInt(VideoSize.split('x')[1]);
			for(index = 0; index < VideoSizeAry.length; index++)
			{
				var tmpWidth = parseInt(VideoSizeAry[index].split("x")[0]);
				var tmpHeight = parseInt(VideoSizeAry[index].split("x")[1]);
				if((Width <= tmpWidth) && (Height <= tmpHeight))
				{
					W = tmpWidth;
					H = tmpHeight;
					break;
				}
			}*/
			STRETCH = "false";
			break;
	}
	
	if ((0 != capability_videoin_c0_rotation) && (videoin_c0_rotate == 90 || videoin_c0_rotate == 270)) 
	{
		var WHTemp;
		WHTemp = W; 
		W = H;
		H = WHTemp;

		WHTemp = Width;
		Width = Height;
		Height = WHTemp;
		
		STRETCH = "true";
	}
		
}

function InstallPlugin()
{
	// Plugin is work on Win32/Windows platform only till now
	if (navigator.platform.match("Win") == null) return;

	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;

		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			xpi = plugin.xpi;
		}

		if(xpi) {
			window.InstallTrigger.install(xpi);

			// Kent, this should be added here to force return, or the following statement will let overwrite above iframe statement 
			return;
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');

			// Kent, this should be added here to force return, or the following statement will let overwrite above iframe statement 
			return;
		}
	}

	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}

	$('#InstallerArea').hide();

}
evalPluginSize();
