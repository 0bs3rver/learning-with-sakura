var XMLHttpRequestEventScriptFile;
	
function loadXMLDoc()
{
	var File_Index = "/setup/UserNum.xml";
	File_Index = File_Index.toString().replace("Num", index + 1);
		
	XMLHttpRequestEventScriptFile = null;
	if (window.XMLHttpRequest)
	{	// code for IE7, Firefox, Opera, etc.
		XMLHttpRequestEventScriptFile = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{	// code for IE6, IE5
		XMLHttpRequestEventScriptFile = new ActiveXObject("Microsoft.XMLHTTP");
	}
	if (XMLHttpRequestEventScriptFile != null)
	{
		XMLHttpRequestEventScriptFile.onreadystatechange = State_Change;
		XMLHttpRequestEventScriptFile.open("GET", File_Index, true);
		XMLHttpRequestEventScriptFile.setRequestHeader("If-Modified-Since","0");
		XMLHttpRequestEventScriptFile.send(null);
	}
	else
	{
		alert("Your browser does not support XMLHTTP.");
	}
}

function State_Change()
{
	if (XMLHttpRequestEventScriptFile.readyState == 4)
	{	// 4 = "loaded"
		if (XMLHttpRequestEventScriptFile.status == 200)
		{// 200 = "OK"
			// code for IE6, IE5
			document.getElementById('EventScriptEdit').innerText = XMLHttpRequestEventScriptFile.responseText;
			// code for IE7, Firefox, Opera, etc.
			document.getElementById('EventScriptEdit').textContent = XMLHttpRequestEventScriptFile.responseText;
		}
		else
		{
			alert("Problem retrieving XML data:" + XMLHttpRequestEventScriptFile.statusText);
		}
	}
}

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?event_customtaskfile", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title="Edit customized script file";
	loadlanguage();
	eval(location.search.toString().slice(1));
	//alert(location.search.toString().slice(1));
	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
	{
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	}
	
	loadXMLDoc();
}

function checkCustomScript()	
{
	var form = document.uploadEvent;
	window.open("", "uploadevent", "height=800, width=800, scrollbars=yes");
	form.submit();
	opener.location.reload();
	window.close();
}

function checkUploadFile()
{
	var form = document.UploadEventScript;
	
	if (form.UploadEventScriptFile.value == "") 
	{
		alert(translator("select_a_file_before_click_on_upload"));
		return -1;
  	}
  	
  	var suffix = form.UploadEventScriptFile.value.split(".");

	if (suffix[suffix.length-1] != 'xml')
	{
		alert(translator("the_file_must_have_a_xml_file_suffix"));
		return -1;
	}
	
	window.open("/setup/null.html", "uploadevent", "height=800, width=800, scrollbars=yes");
	form.target="uploadevent";
	form.submit();

	parent.location.reload();
	self.parent.tb_remove();
}
