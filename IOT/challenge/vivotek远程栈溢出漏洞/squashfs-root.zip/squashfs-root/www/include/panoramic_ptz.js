
function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&network&remotecamctrl&ivas_c0_objtrack", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	$('#InstallerArea').hide();
	document.title=translator("panoramic_ptz");
	
	if (document.getElementById("adv_panoramic_ptz") != null) 
	{
		$("div.tabs").css("display","block");
		$("#tabs-1").parent("div").attr("class","tab-content");
		tabsUI(0); // default
	}
	loadlanguage();
}

function loadvaluedone()
{
	eval("alarm=remotecamctrl_c0_client0_eventalarm");
	var triggerCnt = document.getElementsByName("manual_trigger_chkbox").length;
	for (var i = 0; i < triggerCnt; i++)
	{
		document.getElementsByName("manual_trigger_chkbox")[i].checked=alarm&(1<<i)?1:0;
	}
	// check mapping file status
	var mapfile_time = eval('remotecamctrl_c0_client0_createtime');
	if (mapfile_time == -1 || mapfile_time == '') //file is not exist
	{
		document.getElementById("mapping_table_status_string").innerHTML=translator("file_does_not_exist")+". "+translator("upload_mapping_table_by_ct");
	}
	else if (mapfile_time==1) //file version is not valid
	{
		document.getElementById("mapping_table_status_string").innerHTML=translator("version_not_match");
	}
	else
	{
		document.getElementById("mapping_table_status_string").innerHTML=translator("file_create_on")+" "+mapfile_time+" "+translator("already_exists");
	}
	// check objtrack enable
	var objtrack_enable = eval('ivas_c0_objtrack_enable');
	
	if (objtrack_enable == 1)
	{
		$("#trackingPageId").css("display","inline");
	}
	else
	{
		$("#trackingPageId").css("display","none");
	}
	
	updateObjTrackChkbox();
	document.location.href = "/setup/application/panoramic_ptz.html#tabs-1";
}

var have_submit = false;

function addElement(inputname)
{
	var newElement = document.createElement("input");

	newElement.type = "hidden";
	newElement.name = inputname;
	newElement.value = "1";
	
	var targetForm = document.getElementById("DefaultButton");
	var parentNode = targetForm.parentNode;
	var newChild = parentNode.insertBefore(newElement, targetForm);	
}

function upload_finish()
{
	var myIFrame = document.getElementById('upload_target');
	var content = myIFrame.contentWindow.document.body.innerHTML;
	if (content.length > 0)
	{
		eval(content);
		if (eval('upload_result') == 0)// upload success
		{
			if (eval('ip').length == 0 || eval('port').length == 0 || eval('username').length == 0)
			{
				document.location.href = "/setup/application/panoramic_ptz.html#tabs-2";
			}
			else
			{
				if (confirm(translator("upload_aux_cam_info")) == true)
				{
					document.getElementById('remotecamctrl_c0_client0_ip').value = eval('ip');
					document.getElementById('remotecamctrl_c0_client0_port').value = eval('port');
					document.getElementById('remotecamctrl_c0_client0_account').value = eval('username');
					document.getElementById('remotecamctrl_c0_client0_passwd').value = eval('passwd');	
					saveRemoteCamInfo();
					$.ajax({
								type: "GET",
								url: "/cgi-bin/admin/setparam.cgi",
								data: "remotecamctrl_c0_enable=1",
								cache: false
							});
					document.location.href = "/setup/application/panoramic_ptz.html#tabs-1";
				}
				else
				{
					document.location.href = "/setup/application/panoramic_ptz.html#tabs-2";
				}
			}
		}
		else if (eval('upload_result') == 1)  //upload fail
		{
			var msg = eval('upload_msg');
			alert(translator(msg));
			document.location.href = "/setup/application/panoramic_ptz.html#tabs-2";
		}
		else if (eval('export_result') == 1) //export fail
		{
			var msg = eval('export_msg');
			alert(translator(msg));
			document.location.href = "/setup/application/panoramic_ptz.html#tabs-2";
		}
		document.location.reload();
	}
}

function checkUploadMapFile()
{
	
	var form = document.uploadMapFile;
	
	if (have_submit) 
		return -1;
	
	if (form.uploadMap.value == "") 
	{
    	alert(translator("select_a_file_before_click_on_upload"));
    	return -1;
  	}
	have_submit = true;
	form.submit();
	//diable upload button
	$("#uploadMap").attr ( "disabled" , true );
	$("#upload_button").attr ( "disabled" , true );
}

function submitform(a, b)
{
    updatecheck(a, b);
    updateObjTrackChkbox();
    document.forms[0].submit();
}

function updateObjTrackChkbox()
{
	// enable / disable track_chkbox
	if (document.getElementById("remotecam_enable_chkbox").checked)
	{
		$("#autotrack_enable_chkbox").removeAttr ( "disabled" );
		$("#autotrack_enable_str").removeAttr ( "disabled" );
	}
	else
	{
		$("#autotrack_enable_chkbox").attr ( "disabled" , true ); 
		$("#autotrack_enable_str").attr ( "disabled" , true );
	}
	// show / hide track_page
	if (document.getElementById("autotrack_enable_chkbox").checked)
	{
		$("#trackingPageId").css("display","inline");
	}
	else
	{
		$("#trackingPageId").css("display","none");
	}
}

function checkUserAndPassword(theUserCtrl)
{
	var aUser = theUserCtrl.value;
	if (aUser.length != 0)
	{
		for (i = 0; i < aUser.length; i++)
		{
			c = aUser.charAt(i);
			if (!( (c>='@' && c<='Z') || (c>='a' && c<='z') || (c>='0' && c<='9') || c=="!" ||
				c=="$" || c=="%" || c=="-" || c=="." || c=="^" || c=="_" || c=="~"))
			{
				alert(translator("you_have_used_invalid_characters_passwd"));
				theUserCtrl.focus();
				theUserCtrl.select();
				return -1;
			}
		}
	}
	return 0;
}
function checkPort(thisObj)
{
	switch(thisObj.name)
	{
		case "remotecamctrl_c0_client0_port":
			defaultPort=80;
			message="http_port_must_be_80_or_from_1025_to_65535";
			break;
	}
	if (thisObj.value == defaultPort)
		return 0;
	if ((thisObj.value > 1024) && (thisObj.value <= 65535))
		return 0;
	alert(translator(message));
	thisObj.select();
	thisObj.focus();
	return -1;
}
function testClientInfo()
{
	var camInfo = document.remoteCamInfo;
	//check empty
	if(CheckEmptyString(camInfo.remotecamctrl_c0_client0_ip) == -1) 
	{
		return -1
	}
	if(CheckEmptyString(camInfo.remotecamctrl_c0_client0_port) == -1) 
	{
		return -1
	}
	//ip
	if (checkIPaddr(camInfo.remotecamctrl_c0_client0_ip) == -1)
	{
		return -1;
	}
	//port 
	if (checkPort(camInfo.remotecamctrl_c0_client0_port) == -1)
	{
		return -1;
	}
	//account
	if (checkUserAndPassword(camInfo.remotecamctrl_c0_client0_account) != 0)
	{
		return -1;
	}
	//passwd
    if (checkUserAndPassword(camInfo.remotecamctrl_c0_client0_passwd) != 0)
	{
		return -1;
	}
	return 0;
}
function saveRemoteCamInfo()
{
	if (document.getElementById("remotecam_enable_chkbox").checked)
	{
		if (testClientInfo() < 0)
			return -1;
	}	
	var triggerCnt = document.getElementsByName("manual_trigger_chkbox").length;
	var trigger_value = 0;
	for (var i=0; i<triggerCnt; i++)
	{
		trigger_value = (document.getElementsByName("manual_trigger_chkbox")[i].checked==true) ? trigger_value+(1 << i) : trigger_value;
	}
	document.getElementById("eventalarm_index").value=trigger_value;
	var camInfo = document.remoteCamInfo;
	camInfo.submit();
}

function testpptz()
{
	form0=document.remoteCamInfo;
	form1=document.formTestPPTZ;
	if(testClientInfo() < 0)
	{
		return -1;
	}
	else
	{
		
		form1.type.value="http";
		var ip = document.getElementById("remotecamctrl_c0_client0_ip").value;
		var port = document.getElementById("remotecamctrl_c0_client0_port").value;
		var cgi = "/cgi-bin/admin/getparam.cgi?capability_remotecamctrl_slave";
		form1.url.value="http://"+ip+":"+port+cgi;
		form1.username.value=document.getElementById("remotecamctrl_c0_client0_account").value;
		form1.passwd.value=document.getElementById("remotecamctrl_c0_client0_passwd").value;
		
		window.open("", "testserver", "height=100,width=400");
		form1.target="testserver";
		document.formTestPPTZ.submit();
	}
}

