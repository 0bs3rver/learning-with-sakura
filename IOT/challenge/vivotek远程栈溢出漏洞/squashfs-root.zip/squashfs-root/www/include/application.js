media_index=1;
function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?event&server&media&recording&system_info_language&system_info_customlanguage", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);	
	document.title=translator("event_settings");

	loadlanguage();
}
function receivedone()
{
	var haveEvent = false;
	var haveServer = false;
	var haveMedia = false;
	var server_using = new Array(0, 0, 0, 0, 0);
	var media_using = new Array(0, 0, 0, 0, 0);
	var customevent_using = new Array(0, 0, 0);
	form=document.forms[0];
	
	for(j=0;j<5;j++)
	{
		if(eval("(recording_i0_name!=\"\"&&recording_i0_dest==j)||(recording_i1_name!=\"\"&&recording_i1_dest==j)")==1)
			server_using[j]++;
	}	
	
	if(event_i0_name=="")
		document.getElementById("event_i0").style.display="none";
	else
	{
		haveEvent = true;
		for(j=0;j<5;j++)
		{
			if(eval("event_i0_action_server_i"+j+"_enable")==1)
				server_using[j]++;
			eval("use_media=event_i0_action_server_i"+j+"_media");
			if(use_media!="")
				media_using[use_media]++;
		}
		if(event_i0_action_cf_media!="")
			media_using[event_i0_action_cf_media]++;
		if(event_i0_trigger=="vi")
			event_i0_trigger="manual";
	}
	if(event_i1_name=="")
		document.getElementById("event_i1").style.display="none";
	else
	{
		haveEvent = true;
		for(j=0;j<5;j++)
		{
			if(eval("event_i1_action_server_i"+j+"_enable")==1)
				server_using[j]++;
			eval("use_media=event_i1_action_server_i"+j+"_media");
			if(use_media!="")
				media_using[use_media]++;
		}
		if(event_i1_action_cf_media!="")
			media_using[event_i1_action_cf_media]++;
		if(event_i1_trigger=="vi")
			event_i1_trigger="manual";
	}
	if(event_i2_name=="")
		document.getElementById("event_i2").style.display="none";
	else
	{
		haveEvent = true;
		for(j=0;j<5;j++)
		{
			if(eval("event_i2_action_server_i"+j+"_enable")==1)
				server_using[j]++;
			eval("use_media=event_i2_action_server_i"+j+"_media");
			if(use_media!="")
				media_using[use_media]++;
		}
		if(event_i2_action_cf_media!="")
			media_using[event_i2_action_cf_media]++;
		if(event_i2_trigger=="vi")
			event_i2_trigger="manual";
	}
	
	if(server_i0_name=="")
		document.getElementById("server_i0").style.display="none";
	else
	{
		haveServer = true;
		if(server_i0_type=="email")
			server_i0_place=server_i0_email_address;
		else if(server_i0_type=="ftp")
			server_i0_place=server_i0_ftp_address;
		else if(server_i0_type=="http")
			server_i0_place=server_i0_http_url;
		else if(server_i0_type=="ns")
			server_i0_place=server_i0_ns_location;
		if(server_using[0]!=0)
		{
			$("#server_i0 input").attr("disabled", "disabled");
		}		
	}
	if(server_i1_name=="")
		document.getElementById("server_i1").style.display="none";
	else
	{
		haveServer = true;
		if(server_i1_type=="email")
			server_i1_place=server_i1_email_address;
		else if(server_i1_type=="ftp")
			server_i1_place=server_i1_ftp_address;
		else if(server_i1_type=="http")
			server_i1_place=server_i1_http_url;
		else if(server_i1_type=="ns")
			server_i1_place=server_i1_ns_location;
		if(server_using[1]!=0)
		{
			$("#server_i1 input").attr("disabled", "disabled");
		}
	}
	if(server_i2_name=="")
		document.getElementById("server_i2").style.display="none";
	else
	{
		haveServer = true;
		if(server_i2_type=="email")
			server_i2_place=server_i2_email_address;
		else if(server_i2_type=="ftp")
			server_i2_place=server_i2_ftp_address;
		else if(server_i2_type=="http")
			server_i2_place=server_i2_http_url;
		else if(server_i2_type=="ns")
			server_i2_place=server_i2_ns_location;
		if(server_using[2]!=0)
		{
			$("#server_i2 input").attr("disabled", "disabled");
		}
	}
	if(server_i3_name=="")
		document.getElementById("server_i3").style.display="none";
	else
	{
		haveServer = true;
		if(server_i3_type=="email")
			server_i3_place=server_i3_email_address;
		else if(server_i3_type=="ftp")
			server_i3_place=server_i3_ftp_address;
		else if(server_i3_type=="http")
			server_i3_place=server_i3_http_url;
		else if(server_i3_type=="ns")
			server_i3_place=server_i3_ns_location;
		if(server_using[3]!=0)
		{
			$("#server_i3 input").attr("disabled", "disabled");
		}
	}
	if(server_i4_name=="")
		document.getElementById("server_i4").style.display="none";
	else
	{
		haveServer = true;
		if(server_i4_type=="email")
			server_i4_place=server_i4_email_address;
		else if(server_i4_type=="ftp")
			server_i4_place=server_i4_ftp_address;
		else if(server_i4_type=="http")
			server_i4_place=server_i4_http_url;
		else if(server_i4_type=="ns")
			server_i4_place=server_i4_ns_location;
		if(server_using[4]!=0)
		{
			$("#server_i4 input").attr("disabled", "disabled");
		}
	}
	
	if(media_i0_name=="")
		document.getElementById("media_i0").style.display="none";
	else
	{
		haveMedia = true;
		if(media_using[0]!=0)
		{
			$("#media_i0 input").attr("disabled", "disabled");
		}
	}

	if(media_i1_name=="")
		document.getElementById("media_i1").style.display="none";
	else
	{
		haveMedia = true;
		if(media_using[1]!=0)
		{
			$("#media_i1 input").attr("disabled", "disabled");
		}		
	}

	if(media_i2_name=="")
		document.getElementById("media_i2").style.display="none";
	else
	{
		haveMedia = true;
		if(media_using[2]!=0)
		{
			$("#media_i2 input").attr("disabled", "disabled");
		}		
	}

	if(media_i3_name=="")
		document.getElementById("media_i3").style.display="none";
	else
	{
		haveMedia = true;
		if(media_using[3]!=0)
		{
			$("#media_i3 input").attr("disabled", "disabled");
		}		
	}

	if(media_i4_name=="")
		document.getElementById("media_i4").style.display="none";
	else
	{
		haveMedia = true;
		if(media_using[4]!=0)
		{
			$("#media_i4 input").attr("disabled", "disabled");
		}		
	}
	
	// custom event script
	if(event_customtaskfile_i0_name=="")
		document.getElementById("custom_i0").style.display="none";
	else if(customevent_using[0]!=0)
	{
		$("#custom_i0 input").attr("disabled", "disabled");
	}
	if(event_customtaskfile_i1_name=="")
		document.getElementById("custom_i1").style.display="none";
	else if(customevent_using[1]!=0)
	{
		$("#custom_i1 input").attr("disabled", "disabled");
	}
	if(event_customtaskfile_i2_name=="")
		document.getElementById("custom_i2").style.display="none";
	else if(customevent_using[2]!=0)
	{
		$("#custom_i0 input").attr("disabled", "disabled");
	}
	document.getElementById("content").style.visibility = "visible";
	
	initPage(haveEvent, haveServer, haveMedia);
	
	/* fill the alt info for all thickbox input button */
	var thickHeight
	
	if( typeof( window.innerWidth ) == 'number' ) 
	{
		//Non-IE
		thickHeight = window.innerHeight - 100;
	} 
	else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) 
	{
		//IE 6+ in 'standards compliant mode'
		thickHeight = document.documentElement.clientHeight - 100;
	} 
	else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) 
	{
		//IE 4 compatible
		thickHeight = document.body.clientHeight - 100;
	}
	
	if (thickHeight > 550)
		thickHeight = 550;
		
	var thick_box_param = "TB_=savedValues&TB_iframe=true&height=" + thickHeight+ "&width=700&modal=true";
	if(event_i0_name=="")
	{
		$("#eventSettings input.thickbox").attr("alt", "event.html?index=0" + thick_box_param);
	}	
	else if(event_i1_name=="")
	{	
		$("#eventSettings input.thickbox").attr("alt", "event.html?index=1" + thick_box_param);
	}
	else if(event_i2_name=="")
	{
		$("#eventSettings input.thickbox").attr("alt", "event.html?index=2" + thick_box_param);
	}
	else
	{
		// Unbind ThickBox click
		$("#eventSettings input.thickbox").unbind("click");
		$("#eventSettings input.thickbox").click(function(){
			alert(translator("no_more_list_for_event_to_enter"));
			return false;
		});	
	}
	
	thick_box_param = "TB_=savedValues&TB_iframe=true&height=450&width=500&modal=true";
	if(server_i0_name=="")
	{
		$("#serverSettings input.thickbox").attr("alt", "server.html?index=0" + thick_box_param);
	}
	else if(server_i1_name=="")
	{
		$("#serverSettings input.thickbox").attr("alt", "server.html?index=1" + thick_box_param);
	}
	else if(server_i2_name=="")
	{
		$("#serverSettings input.thickbox").attr("alt", "server.html?index=2" + thick_box_param);
	}
	else if(server_i3_name=="")
	{
		$("#serverSettings input.thickbox").attr("alt", "server.html?index=3" + thick_box_param);
	}
	else if(server_i4_name=="")
	{
		$("#serverSettings input.thickbox").attr("alt", "server.html?index=4" + thick_box_param);
	}
	else
	{
		// Unbind ThickBox click
		$("#serverSettings input.thickbox").unbind("click");
		$("#serverSettings input.thickbox").click(function(){
			alert(translator("no_more_list_for_server_to_enter"));
			return false;
		});	
	}
	
	thick_box_param = "TB_=savedValues&TB_iframe=true&height=390&width=500&modal=true";
	if(media_i0_name=="")
	{
		$("#mediaSettings input.thickbox").attr("alt", "media.html?index=0" + thick_box_param);
	}
	else if(media_i1_name=="")
	{
		$("#mediaSettings input.thickbox").attr("alt", "media.html?index=1" + thick_box_param);
	}
	else if(media_i2_name=="")
	{
		$("#mediaSettings input.thickbox").attr("alt", "media.html?index=2" + thick_box_param);
	}
	else if(media_i3_name=="")
	{
		$("#mediaSettings input.thickbox").attr("alt", "media.html?index=3" + thick_box_param);
	}
	else if(media_i4_name=="")
	{
		$("#mediaSettings input.thickbox").attr("alt", "media.html?index=4" + thick_box_param);
	}
	else
	{
		// Unbind ThickBox click
		$("#mediaSettings input.thickbox").unbind("click");
		$("#mediaSettings input.thickbox").click(function(){
			alert(translator("no_more_list_for_media_to_enter"));
			return false;
		});	
	}

	if ((event_customtaskfile_i0_name!="") && (event_customtaskfile_i1_name!="") && (event_customtaskfile_i2_name!=""))
	{
		// Unbind ThickBox click
		$("#customSettings input.thickbox").unbind("click");
		$("#customSettings input.thickbox").click(function(){
			alert(translator("no_more_list_for_event_to_enter"));
			return false;
		});	
	}
}

function initPage(haveEvent, haveServer, haveMedia)
{
	var hideArray = new Array();
	
	if (!haveServer)
		hideArray.push("serverSettings");

	if (!haveMedia)
		hideArray.push("mediaSettings");
	
	jQuery.each(hideArray, function(i) { 
		$("#" + hideArray[i]).css("display","none");
	});    
   
	//show event note
	if (haveServer && haveMedia)
		$("#event_note").css("display", "none");
	else if (!haveServer && haveMedia)
	{
		$("#media_link ").css("display", "none");
		$("#str_and ").css("display", "none")
	}
	else if (haveServer && !haveMedia)
	{
		$("#server_link ").css("display", "none");
		$("#str_and ").css("display", "none");
	}
}

function submitform()
{
	if(!checkvalue())
	{
		return -1;
	}
	else
		document.forms[0].submit();
}

function addevent()
{
	if(event_i0_name=="")
		openurl("/setup/application/event.html?index=0", "yes");
	else if(event_i1_name=="")
		openurl("/setup/application/event.html?index=1", "yes");
	else if(event_i2_name=="")
		openurl("/setup/application/event.html?index=2", "yes");
	else
		alert(translator("no_more_list_for_event_to_enter"));
}

function delevent(idx)
{
	form=document.forms[0];
		
	params  = "event_i" + idx + "_name=" + "&";
	params += "event_i" + idx + "_enable=0" + "&";
	params += "event_i" + idx + "_priority=1" + "&";
	params += "event_i" + idx + "_delay=10" + "&";
	params += "event_i" + idx + "_trigger=boot" + "&";
	params += "event_i" + idx + "_di=1" + "&";
	params += "event_i" + idx + "_vi=0" + "&";
	params += "event_i" + idx + "_mdwin=0" + "&";
	params += "event_i" + idx + "_mdwin0=0" + "&";
	params += "event_i" + idx + "_vadp=0" + "&";
	params += "event_i" + idx + "_inter=1" + "&";
	params += "event_i" + idx + "_weekday=127" + "&";
	params += "event_i" + idx + "_begintime=00:00" + "&";
	params += "event_i" + idx + "_endtime=24:00" + "&";
	params += "event_i" + idx + "_lowlightcondition=1" + "&";
	params += "event_i" + idx + "_action_do_i0_enable=0" + "&";
	params += "event_i" + idx + "_action_do_i0_duration=1" + "&";
	params += "event_i" + idx + "_action_do_i1_enable=0" + "&";
	params += "event_i" + idx + "_action_do_i1_duration=1" + "&";
	params += "event_i" + idx + "_action_cf_enable=0" + "&";
	params += "event_i" + idx + "_action_cf_folder=" + "&";
	params += "event_i" + idx + "_action_cf_media=" + "&";
	//params += "event_i" + idx + "_action_cf_datefolder=0" + "&";
	params += "event_i" + idx + "_action_cf_backup=0" + "&";
	params += "event_i" + idx + "_action_server_i0_enable=0" + "&";
	params += "event_i" + idx + "_action_server_i0_media=" + "&";
	params += "event_i" + idx + "_action_server_i0_datefolder=0" + "&";
	params += "event_i" + idx + "_action_server_i1_enable=0" + "&";
	params += "event_i" + idx + "_action_server_i1_media=" + "&";
	params += "event_i" + idx + "_action_server_i1_datefolder=0" + "&";
	params += "event_i" + idx + "_action_server_i2_enable=0" + "&";
	params += "event_i" + idx + "_action_server_i2_media=" + "&";
	params += "event_i" + idx + "_action_server_i2_datefolder=0" + "&";
	params += "event_i" + idx + "_action_server_i3_enable=0" + "&";
	params += "event_i" + idx + "_action_server_i3_media=" + "&";
	params += "event_i" + idx + "_action_server_i3_datefolder=0" + "&";
	params += "event_i" + idx + "_action_server_i4_enable=0" + "&";
	params += "event_i" + idx + "_action_server_i4_media=" + "&";
	params += "event_i" + idx + "_action_server_i4_datefolder=0" + "&";

	location.replace("/cgi-bin/admin/setparam.cgi?" + params + "return=/setup/event/application.html");
}

function delserver(idx)
{
	form=document.forms[0];
    	
    	params  = "server_i" + idx + "_name=" + "&";
    	params += "server_i" + idx + "_type=email" + "&";
    	params += "server_i" + idx + "_http_url=http://" + "&";
    	params += "server_i" + idx + "_http_username=" + "&";
    	params += "server_i" + idx + "_http_passwd=" + "&";
    	params += "server_i" + idx + "_ftp_address=" + "&";
    	params += "server_i" + idx + "_ftp_username=" + "&";
    	params += "server_i" + idx + "_ftp_passwd=" + "&";
    	params += "server_i" + idx + "_ftp_port=21" + "&";
    	params += "server_i" + idx + "_ftp_passive=1" + "&";
    	params += "server_i" + idx + "_ftp_location=" + "&";
    	params += "server_i" + idx + "_email_address=" + "&";
    	params += "server_i" + idx + "_email_username=" + "&";
    	params += "server_i" + idx + "_email_passwd=" + "&";
    	params += "server_i" + idx + "_email_senderemail=" + "&";
    	params += "server_i" + idx + "_email_recipientemail=" + "&";
    	params += "server_i" + idx + "_email_sslmode=0" + "&";
    	params += "server_i" + idx + "_email_port=25" + "&";
    	params += "server_i" + idx + "_ns_location=" + "&";
    	params += "server_i" + idx + "_ns_username=" + "&";
    	params += "server_i" + idx + "_ns_passwd=" + "&";
    	params += "server_i" + idx + "_ns_workgroup=" + "&";
    	
    	location.replace("/cgi-bin/admin/setparam.cgi?" + params + "return=/setup/event/application.html");
}

function delmedia(idx)
{
	form=document.forms[0];
    	
    	params  = "media_i" + idx + "_name=" + "&";
    	params += "media_i" + idx + "_type=snapshot" + "&";
    	params += "media_i" + idx + "_snapshot_source=0" + "&";
    	params += "media_i" + idx + "_snapshot_prefix=" + "&";
    	params += "media_i" + idx + "_snapshot_datesuffix=0" + "&";
    	params += "media_i" + idx + "_snapshot_preevent=1" + "&";
    	params += "media_i" + idx + "_snapshot_postevent=1" + "&";
    	params += "media_i" + idx + "_videoclip_source=0" + "&";
    	params += "media_i" + idx + "_videoclip_prefix=" + "&";
    	params += "media_i" + idx + "_videoclip_preevent=0" + "&";
    	params += "media_i" + idx + "_videoclip_maxduration=5" + "&";
    	params += "media_i" + idx + "_videoclip_maxsize=500" + "&";
    	
	location.replace("/cgi-bin/admin/setparam.cgi?" + params + "return=/setup/event/application.html");
}

function openHelp(url)
{
	var subWindow = window.open(url, "","width=550, height=300, scrollbars=yes, status=yes,resizable=no");
	subWindow.focus();
}

function switchEvent(param)
{	
	var newValue;

	document.getElementById("event_index_enable").name = param;
	if (document.getElementById(param + "_value").firstChild.nodeValue == "OFF")
	{	
		newValue = 1;
	}
	else
	{
		newValue = 0;
	}
	document.getElementById("event_index_enable").value = newValue;
	document.event.submit();
	document.getElementById(param + "_value").firstChild.nodeValue = (newValue == 1? "ON" : "OFF");
}

function delcustomscript(idx)
{
	form=document.forms[0];

    	params  = "event_customtaskfile_i" + idx + "_name=" + "&";
    	
	location.replace("/cgi-bin/admin/eventscript.cgi?" + params + "return=/setup/event/application.html");
}
