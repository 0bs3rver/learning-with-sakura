function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?https&system_info_language&system_info_customlanguage&network&capability_nmediastream", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	
	document.title=translator("https");
	loadlanguage();	
	$('#notification').bgiframe();	
}

function receivedone()
{
	if (https_enable == '1' && https_policy == '1')
		$("input:[name=https_policy_input]").eq(1).attr("checked", "true");
	else
		$("input:[name=https_policy_input]").eq(0).attr("checked", "true");
	
	switch(https_status)
	{
	case '-2':
		$("#status-val").html("<b style='color:red'>" + translator("invalid_public_key") + "</b>");
		$("#certificate-setting").hide();
		$("#certificate-result").show();
		document.getElementById("property").style.visibility="hidden";
		break;
	case '-1':
		$("#status-val").html("<b style='color:red'>" + translator("waiting_for_certificated") + "</b>");
		openurl('certificate_request.html');
		$("#certificate-setting").hide();
		$("#certificate-result, #upload-file").show();
		document.getElementById("property").style.visibility="hidden";
		break;
	case '0':
		$("#status-val").html("<b style='color:#666'>" + translator("not_installed") + "</b>");
		$("#certificate-setting").show();
		$("#certificate-result").hide();
		break;
	case '1':
		$("#status-val").html("<b style='color:#0186d1'>" + translator("active") + "</b>");
		$("#certificate-setting").hide();
		$("#certificate-result").show();
		document.getElementById("property").style.visibility="visible";
		$("#save_btn").show();
		break;
	}
	$("#original_https_enable_input")[0].value = https_enable;
	$("#https_enable_input")[0].value = https_enable;
	
	var str_method;
	if (https_method == "install")
	{
		str_method = translator("create_certificate_request_and_install");
	}
	else
	{
		str_method = translator("create_self_signed_certificate");
	}
	
	$("#certificate-result span").eq(3).html(str_method);

	switchCertificateMethod(https_method);
	
}

function loadvaluedone()
{
	var hideArray = new Array();
	var httpsMethod = $("select:[name=https_method]").val();

	if ($("#https_enable_input")[0].value != 1)
	{
		hideArray.push("httpsPort");
		hideArray.push("httpsMode");
		hideArray.push("certificateInfo");
	}
	/*
	if (httpsMethod == "auto")
	{	
		hideArray.push("certificate-setting");
	}
	else 
	{
		hideArray.push("certificate-result");
	}
	*/
	
   jQuery.each(hideArray, function(i) { 
     $("#" + hideArray[i]).css("display","none");
   });
			
	/*
	checkcertificatemethod();
	if (https_enable == 1)
	{
		document.getElementById("auto_self_signed").disabled = true;
		document.getElementById("manual_self_signed").disabled = true;
		document.getElementById("install_certificate").disabled = true;		
	}
	*/
	document.getElementById("content").style.visibility = "visible";
	if (https_enable == 1)
	{
		$("#httpsPort, #httpsMode, #certificateInfo").slideDown();
		$("#enable_https_input").attr("checked", "true");
	}
	else
	{
		document.getElementById("enable_https_input").checked = false;
	}
}

function checkhttpspolicy(a,b)
{
	updatecheck(a,b);
	if ($("#https_enable_input")[0].value == 1)
	{
		$("#httpsPort, #httpsMode, #certificateInfo").slideDown();
	}
	else {
		$("input[name=https_policy_input]")[0].checked = true;
		$("#httpsPort, #httpsMode, #certificateInfo").slideUp();
	}
}

function submitform()
{
	//enable
	var original_enable = $("#original_https_enable_input").val();
	var enable = $("#https_enable_input").val()
	//policy
	var policy;
	if ($("input:[name=https_policy_input]").eq(0).attr("checked") == true)
		policy = 0;
	else
		policy = 1;
	//status
	var status = https_status;
	//method
	var method = https_method;
	
	var httpsport = document.httpsPortForm.network_https_port.value;
	var network_rtcp_videoport = parseInt(network_rtp_videoport) + 1;
	var network_rtcp_audioport = parseInt(network_rtp_audioport) + 1;
	var videoport;
	var audioport;
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		videoport = eval('parseInt(network_rtsp_s'+i+'_multicast_videoport) + 1');
		audioport = eval('parseInt(network_rtsp_s'+i+'_multicast_audioport) + 1');
		eval('var network_rtsp_s'+i+'_multicast_rtcp_videoport = '+videoport);
		eval('var network_rtsp_s'+i+'_multicast_rtcp_audioport = '+audioport);
	}
	var port = new Array(network_http_port,                  //0
						 network_http_alternateport,         //1
						 httpsport,				 //2
						 network_sip_port,                   //3
						 network_ftp_port,                   //4
						 network_rtsp_port,                  //5
						 network_rtp_videoport,              //6
						 network_rtcp_videoport.toString(),    //7
						 network_rtp_audioport,              //8
						 network_rtcp_audioport.toString()             //9
					 );
	// Dynamic push audio and video port into port array 
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		port.push(eval('network_rtsp_s'+i+'_multicast_videoport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_rtcp_videoport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_audioport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_rtcp_audioport'));
	}

	if(checkvalue())
	{
		return -1;
	}
	
	// Check port conflict: https_port	
	if(CheckEmptyString(port[2]) == -1)
	{
		return -1
	}

	for (var j = 0; j < port.length; j++)
	{
		if (j == 2)
		{
			continue;
		}
		if (port[2] == port[j])
		{
			document.httpsPortForm.network_https_port.select();
			document.httpsPortForm.network_https_port.focus();
			alert(translator("https_port_can_not_be_the_same_as_other_port"));
			return -1;
		}
	}

	if (original_enable == 0)
	{
		if (https_status == '-1')
		{
			alert(translator("please_upload_a_valid_certificate"));
			return;
		}
		else if (https_status != '1')
		{
			alert(translator("please_create_a_valid_certificate_first"));
			return;
		}
		
		$.get(	"/cgi-bin/admin/setparam.cgi?"+
				"https_enable=" + enable +
				"&https_policy=" + policy +
				"&https_status=" + status +
				"&https_method=" + method +
				"&network_https_port=" + httpsport,
				function(){
		          var  $hostname = window.document.location.hostname;
		          var  $port = httpsport;
		          var  $new_target = "https://" +  $hostname + ":"  + $port ;
		          location.replace($new_target);
					
				}
		);
	}
	else
	{
		if (enable == 0)
		{
			var r = confirm(translator("do_you_want_to_stop_https_service"));
			if (r == true)
			{
				document.getElementById("return").disabled = false;
				$.get(	"/cgi-bin/admin/setparam.cgi?" + 
						"https_enable="  + enable +
						"&https_policy=" + policy +
						"&https_status=" + status +
						"&https_method=" + method +
						"&network_https_port=" + httpsport
				);
				
				if (location.protocol == "https:")
				{
					if (https_policy == "0")
					{
						var  $hostname = window.document.location.hostname;
					    var  $port = network_http_port;
					    var  $new_target = "http://" +  $hostname + ":"  + $port ;
					    location.replace($new_target);
					}
					else
						showProgressBar("disableBar", 10, true);
				}
			}
		}
		else
		{
			$.get(	"/cgi-bin/admin/setparam.cgi?" + 
					"https_enable="  + enable +
					"&https_policy=" + policy +
					"&https_status=" + status +
					"&https_method=" + method +
					"&network_https_port=" + httpsport,
					function()
					{
						if (policy == 1 || network_https_port != httpsport)
						{
							var  $hostname = window.document.location.hostname;
					    	var  $port = httpsport;
					    	var  $new_target = "https://" +  $hostname + ":"  + $port ;
					    	location.replace($new_target);
						}
						else
							location.reload();
								
					}
			);
		}
	}
}

function checkcertificatemethod()
{
	if (document.getElementById("auto_self_signed").checked)
	{
		document.getElementById("enable_https").disabled = false;
	}
	else if (document.getElementById("manual_self_signed").checked)
	{
		if (document.informationForm.https_status.value != 1) {
			document.httpsForm.https_enable.value = 0;
			document.getElementById("enable_https").checked = false;
			document.getElementById("enable_https").disabled = true;
			document.httpsForm.https_policy[0].checked = true;
			$("#httpsChild").slideUp("slow");
		}
	}
	else //install_certificate
	{
		if (document.informationForm.https_status.value != 1) {
			document.httpsForm.https_enable.value = 0;
			document.getElementById("enable_https").checked = false;
			document.getElementById("enable_https").disabled = true;
			document.httpsForm.https_policy[0].checked = true;
			$("#httpsChild").slideUp("slow");
		}
	}
}

function checkRequest()
{
	/*
	if (document.informationForm.https_status.value != -1 &&
		document.informationForm.https_status.value != -2)
	{
		alert(translator("certificate_request_has_to_exist_before_signed_certificate_can_be_uploaded"));
	}
	*/
}

function checkUpload()
{
	if (document.getElementById("select_certificate_file").value != "")
	{
		document.getElementById("upload_certificate_file").disabled = false;
	}
	else
	{
		document.getElementById("upload_certificate_file").disabled = true;
	}
}

function checkCountrycode(input)
{
    var filter=/[a-zA-Z][a-zA-Z]/;
    if (!filter.test(input.value))
    {
        alert(translator("please_enter_the_correct_country_code"));
        return -1;
    }
    return 0;
}

function createCertificate()
{
	var form = $("form:[name=certificate-detail-form]")[0]
	
	if(checkvalue())
	{
		return -1;
	}
	if (checkCountrycode(form.https_countryname))
	{
		return -1;
	}
	
	https_method = form.https_method.value
	https_countryname = form.https_countryname.value;
	https_stateorprovincename = form.https_stateorprovincename.value;
	https_localityname = form.https_localityname.value
	https_organizationname = form.https_organizationname.value
	https_unit = form.https_unit.value
	https_commonname = form.https_commonname.value
	https_validdays = form.https_validdays.value
	
	//determint the https_status
	if (https_status != 1)
	{
		if (form.https_method.value == "install")
		{
			$("input:[name=https_status]")[0].value = "-1";
			https_status = $("input:[name=https_status]")[0].value;
		}
		else
		{
			$("input:[name=https_status]")[0].value = "-3";
			https_status = "1";
		}
	}
	
	
	form.submit();
	/*
	$("#notification").show();
	wait_time = 20;
	count = 70;
	intervel = wait_time * 1000 / count;
	proceed();
	*/
	showProgressBar("certificateBar", 120, false);
}

function removeCertificate()
{
	var r = confirm(translator("are_you_sure_you_want_to_delete_the_certificate"));
	if (r == true)
	{
		$.get("/cgi-bin/admin/setparam.cgi?https_enable=0&https_status=0&https_policy=0", function(){
			if (location.protocol == "https:")
			{
				if (https_policy == "0")
				{
					var  $hostname = window.document.location.hostname;
		        	var  $port = network_http_port;
		        	var  $new_target = "http://" +  $hostname + ":"  + $port ;
		        	location.replace($new_target);
				}
				else
					showProgressBar("disableBar", 10, true);
			}
			else
				location.replace(location.href.replace(/http:\/\//, "http://"));
		});	
	}
}

function showProgressBar(barID, waitingTime, redirectFlag)
{
	document.getElementById("notification").style.display = "block";
	document.getElementById(barID).style.display = "block";
	wait_time = waitingTime;
	count = 70;
	intervel = wait_time * 1000 / count;
	proceed(redirectFlag);
}

function proceed(redirectFlag)
{
	var board = document.getElementById("progress_bar");
	count --;
	if (count < 0)
	{
		if (redirectFlag)
		{
			var  $hostname = window.document.location.hostname;
		    var  $port = network_http_port;
		    var  $new_target = "http://" +  $hostname + ":"  + $port ;
		    location.replace($new_target);
		}
		else
		{
			//location.reload();
			$("#certificate-result").show();
			$("#certificate-setting, #notification").hide();
	
			switch(https_status)
			{
			case '-2':
				$("#status-val").html("<b style='color:red'>" + translator("invalid_public_key") + "</b>");
				document.getElementById("property").style.visibility="hidden";
				break;
			case '-1':
				$("#status-val").html("<b style='color:red'>" + translator("waiting_for_certificated") + "</b>");
				$("#upload-file").show();
				document.getElementById("property").style.visibility="hidden";
				openurl('certificate_request.html');
				break;
			case '0':
				$("#status-val").html("<b style='color:#666'>" + translator("not_installed") + "</b>");
				break;
			case '1':
				$("#status-val").html("<b style='color:#0186d1'>" + translator("active") + "</b>");
				$("#save_btn").show();
				document.getElementById("property").style.visibility="visible";
				break;
			}		
			
			var str_method;
			if (https_method == "install")
				str_method = translator("create_certificate_request_and_install")
			else
				str_method = translator("create_self_signed_certificate")	
			$("#certificate-result span").eq(3).html(str_method);
			$("#certificate-result span").eq(5).html(https_countryname);
			$("#certificate-result span").eq(7).html(https_stateorprovincename);
			$("#certificate-result span").eq(9).html(https_localityname);
			$("#certificate-result span").eq(11).html(https_organizationname);
			$("#certificate-result span").eq(13).html(https_unit);
			$("#certificate-result span").eq(15).html(https_commonname);
			
		}
	}
	else
	{
		if (https_method == "install")
		{
			$.ajax({
        			url: "/setup/publickey.req",
        			cache: false,
        			async: true,
        			success: function(html){
						if (html)
						{
							setTimeout("count=0;", 5000);
						}
        			}
			});
		}
		else if (https_method == "manual")
		{
            $.ajax({
                    url: "/setup/publickey.cert",
                    cache: false,
                    async: true,
                    success: function(html){
                        if (html)
                        {
                                setTimeout("count=0;", 5000);
                        }
                    }
            });
		}
		board.value = board.value + "|";
		setTimeout("proceed(" + redirectFlag + ")", intervel);
	}
}

function switchCertificateMethod(value)
{
	if (value == "install"){
		$("#validity").slideUp("slow");
		document.getElementsByName("https_validdays")[0].disabled=true;
	}
	else{
		$("#validity").slideDown("slow");
		document.getElementsByName("https_validdays")[0].disabled=false;
	}
}
