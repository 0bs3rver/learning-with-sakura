function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?uart&capability", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	if (window.XMLHttpRequest)
		receiveparam();
	document.title=translator("custom_command");
	loadlanguage();
	eval(location.search.toString().slice(1));
	showcustomctrl();
}

function close_window() {
    window.close();
}

function checkInString(instr)
{
	for (i = 0; i < instr.value.length; i++)
    {
        c = instr.value.charAt(i);
        if (c == '"' || c == '\'' || c == '<' || c == '>' || c == '/' || c == ':' || c == '*' || c == '.' || c == '?' || c == '|' || c == '\\' || c == '&')
        {
          alert(translator("you_have_used_invalid_characters_lg"));
          instr.focus();
          return -1;
        }
    }

   return 0;
}

function checkInValue(instr){
	for (i = 0; i < instr.value.length; i++){
        c = instr.value.charAt(i);
        if (!((c>='a' && c<='f') || (c>='A' && c<='F') || (c>='0' && c<='9') || (c == ';') || (c == ',')))
        {
          alert(translator("please_input_a_valid_value"));
          instr.focus();
          return -1;
        }
    }

   return 0;
}

function checkCmdName()
{
	for (k = 0; k < 5; k++)
	{
		checkStringSize(document.getElementById(k));
	}
	
    for (i = 0; i < 4; i++)
    {
    	j = (i + 1) % 5;
    	if (document.getElementById(i).value)
    	{
    		if (document.getElementById(i).value == document.getElementById(j).value)
    		{
    	    	alert(translator("custom_command_name_can_not_be_the_same"));
    	    	return -1;
    		}
    	}
    }
}
function submitform1()
{	
	if (checkCmdName())
	{
		return -1;
	}
	document.forms[0].submit();
}


function showcustomctrl()
{
	if (CustomDriver == true)
	{
		document.getElementById("control_settings").style.display="block";
	}
}
