var rmPx_reg = /[^\d]+/img;
var rmSpace_reg = /\s+/g;
var cell_size = 8;
var cell_total;
var aryNum;
var bitwise;
var bIsWinMSIE = checkIsWinMSIE();

var giCH_Curr = 0;
var giTargetStream = parseInt(capability_nmediastream,10) - 1;
var gImgW = 320;
var gImgH = 240;
var Width, Height;
var bRotate = false;

function swap(var1, var2)
{
	return "var temp_" + var1 + " = " + var1 + ";\n" +
			var1 + " = " + var2 + ";\n" +
			var2 + " = temp_" + var1 + ";" ;
}

/* copy from common.js */
function checkIsWinMSIE()
{
	// This function will check if IE browser 
	
	var rtn = false;
	if (navigator.appName == "Microsoft Internet Explorer" && navigator.platform.match("Win"))
	{
		// Before IE11 ~
		if (navigator.userAgent.match("MSIE") !== null)
		{
			rtn = true;
		}
	}
	else if (navigator.appName == "Netscape" && navigator.platform.match("Win"))
	{	
		// New IE (IE11)
		if (navigator.userAgent.match("Trident") !== null)
		{
			rtn = true;
		}
	}

	return rtn;
}

function checkRotate()
{
	if( eval("capability_videoin_c" + giCH_Curr + "_rotation") == 1 )
	{
		if( eval("videoin_c" + giCH_Curr + "_rotate") == 90 || eval("videoin_c" + giCH_Curr + "_rotate") == 270 )
		{
			bRotate = true;
		}
	}
}

function initCell()
{
	var i, j, idx;
	
	var cell_style = "<style>.CELL_style { position: absolute; border: 5px #ccc solid; }</style>";
	parent.$("html > head").append(cell_style );
	
	eval("VideoSize=videoin_c"+ giCH_Curr + "_s" + giTargetStream + "_resolution");
	Width = VideoSize.split("x")[0];
	Height = VideoSize.split("x")[1];
	
	gImgH = gImgW * Height / Width;
	
	checkRotate();
	
	if(bRotate)
	{
		eval(swap('gImgH', 'gImgW'));
	}
	
	var w_cellnum = Math.floor(gImgW / cell_size);
	var h_cellnum = Math.floor(gImgH / cell_size);	

	parent.$(".CELL_style").remove();
	cell_total = w_cellnum * h_cellnum;
	
	parent.$("#imagecoverBlock").prepend("" + '<div id="CellBlock"></div>');
	
	idx = 0;
	for (j = 0; j < h_cellnum; j++)
	{
		for (i = 0; i < w_cellnum; i++)
		{
			parent.$("#CellBlock").append("" +
				'<div id="cellWindow'+ idx +'" class="CELL_style">' +
				'</div>');

			parent.$('#cellWindow' + idx).css({
				"border-width": 0 +'px',
				width: (cell_size) +'px',
				height: (cell_size) +'px',
				top:  (cell_size * j) +'px',
				left:  (cell_size * i) +'px',
				display: "none"
			});

			parent.$('#cellWindow' + idx).css("opacity","0.3");
			parent.$('#cellWindow' + idx).css("backgroundColor","#C0C000");

			idx++;
		}
	}

	// Initial bitwise map
	aryNum = (cell_total >> 5) + 1;		// calculate 32bit once for javascript limitation
	bitwise = new Array(aryNum);
}

function getMotionStream(motionstream)
{
	var i;
	var streamData = motionstream.replace(rmSpace_reg, "");
	
	for (i = 0; i < aryNum; i++)
	{
		bitwise[i] = parseInt(streamData.substr(8 * i, 8), 16);
	}
}

function showCell()
{
	var i, j, k;

	i = 0;
	j = 0;
	k = 0;
	while (i < cell_total)
	{
		if ((1 << j) & bitwise[k])
		{
			parent.$('#cellWindow' + i).show();
		}
		else
		{
			parent.$('#cellWindow' + i).hide();
		}
		i++;
		j = i % 32;
		if (j === 0) k++;
	}
}

function loadCurrentSetting() 
{
	initCell();
	
	if (bIsWinMSIE) 
	{
		IEComet("/cgi-bin/admin/motionstream.cgi?ua=iesux&interval=100", motionCallbackFn);
	}
	else
	{
		AjaxComet("/cgi-bin/admin/motionstream.cgi?interval=100");
	}
}

function IEComet(url, callback) 
{
	transferDoc = new ActiveXObject("htmlfile");
	transferDoc.open();
	transferDoc.write( "<html><div><iframe src=\"" + url + "\"></iframe></div><\/html>");
	transferDoc.close();
	transferDoc.parentWindow.callback = callback;
	setInterval( function () {}, 10000); // this eliminates the DOM usage limit inside the iframe 
}

function AjaxComet(url) 
{
	//var request = $.get(url);
	var request = new XMLHttpRequest();
	var pos = 0;
	//request._onreadystatechange = request.onreadystatechange; // save original handler
	request.onreadystatechange = function () {
		//request._onreadystatechange();                        // execute original handler
		if (request.readyState == 3) {
			var text = request.responseText; 
			//console.log("pos: "+ pos + "," + text.substring(pos));
			motionCallbackFn(text.substring(pos));
			pos = text.length;
		}
	};
	request.open("GET", url, true);
	request.send();	
}

function callback(data) 
{
	return motionCallbackFn(data);
}

function motionCallbackFn(motionstream) 
{	
	getMotionStream(motionstream);
	showCell();
}

