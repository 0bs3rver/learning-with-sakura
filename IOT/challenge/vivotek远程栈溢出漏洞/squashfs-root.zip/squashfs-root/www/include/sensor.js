/* Exposure level mapping is
 * 0 ->  "-2.0"
 * 1 ->  "-1.7"
 * 2 ->  "-1.3"
 * 3 ->  "-1.0"
 * 4 ->  "-0.7"
 * 5 ->  "-0.3"
 * 6 ->  "0"
 * 7 ->  "+0.3"
 * 8 ->  "+0.7"
 * 9 ->  "+1.0"
 * 10 -> "+1.3"
 * 11 -> "+1.7"
 * 12 -> "+2.0"
 *
 * It is used in UI and cgi 
 * e.g. aExposureLevelEVTbl and capability_image_c0_wdrpro_affect=exposurelevel:fixed:xxx,exposurelevel:ranged:xxx 
 */
var aExposureLevelEVTbl = [[0, "-2.0"], [1, "-1.7"], [2, "-1.3"], [3, "-1.0"], [4, "-0.7"], [5, "-0.3"],
    			   [6, "0"], [7, "+0.3"], [8, "+0.7"], [9, "+1.0"], [10, "+1.3"], [11, "+1.7"], [12, "+2.0"]]

var aExposureTimeTbl = new Array();
var DEFAULT_EXPLV = 6; // default exposure level value for WDR on/off
var gMaxPageHeight = 300; //px

var giCH_Curr = 0;
var giMode = 0;
var bExpMode = false;
var bExpModeType = false;
	var aExposureSupportMode;
	var TmpExposureMode;
	var preExpMode;
	var eRangeType;
	var bAEImpactExposurewinBlcHidden = false;
	var bAEImpactExposurewinHidden = false;
	var bAEImpactDefogDisabled = false;
	var bAEImpactWDRProDisabled = false;
	var bAEImpactLevelHidden = false;
	var bAEImpactAutoICRNotSupport = false;
	var bAEImpactDefaultGainValue = false;
	var giDefaultGainFixValue;
var bExpWin = false;
	var TmpExpWinMode;
	var bWDROnExposurewinFixedAuto = false;
	var bWDROnExposurewinBlcDisabled = false;
	var bWDROnExposurewinBlcHidden = false;
	var bWDROnExposurewinHlcHidden = false;
	var bExpWinModeImpactSIRHidden = false;
var bExpLevel = false;
	var bWDROnLevelHidden = false;
	var bWDROnLevelFixed = false;
	var bWDROnLevelRanged = false;
	var gWDROnLevelRangeMin = false;
	var gWDROnLevelRangeMax = false;
	var gWDROnLevelFixValue;
	var TmpExpLevel;
	var bIsEVTable = false;
	var bIsWDROnLevelSingleFixValue = false;
var bExposureMode = false;
    var bWDROnExposuremodeFixedAuto = false;
var eIrisType;
	var TmpPirisPosition;
	var TmpPirisMode;
	var TmpIrisMode;
	var bWDROnIrismodeHidden = false;
var bAESpeedAdjust = false;
    var bWDROnAESpeedUnchanged = false;
    var bWDROnAESpeedDisabled = false;
	var TmpAESpeedMode;
	var TmpAESpeedLevel;
	var TmpAESpeedSensitivity;
var bSceneModeEnable = false;
	var bSceneModeOnMinexposureHidden = false;
	var bSceneModeOnMingainHidden = false;
	var bSceneModeOnFlickerlessHidden = false;
	var bSceneModeOnFlickerlessUnchanged = false;
	var bSceneModeOnWdrproUnchanged = false;
	var bSceneModeOnDefaultMaxexposure = false;
	var bSceneModeOnDefaultMaxgain = false;
	var TmpSceneMode;

var bWDRCOnContrastUnchanged = false;
var bWDREnhanced = false;
	var bWDROnWDRCEnabled = false;
	var bWDROnWDRCEnabledOnlyOnce = false;
	var bWDROnWDRCEnabledAlways = false;
	var gWDROnWDRCEnabledValue;
	var bWDROnWDRCUnchanged = false;
var bWDRCStr = false;
	var TmpWDRCMode;
	var TmpWDRCMode_odd;
	var TmpWDRCStr;
	var TmpWDRCSupportLevel;
	var TmpWDRCStep;
var bWDRPro = false;
	var giWDRProMode;
var bWDRStr = false;
	var TmpWDRMode;
	var TmpWDRStr;
	var TmpWDRSupportLevel;
	var TmpWDRStep;

var bPAL50 = false;
var bExpTimeMax = false;
var bExpTimeMin = false;
	var bWDROnExpTimeHidden = false;
	var gExpTimeLevel;
	var gExpTimeMaxValue;
	var TmpExpTimeMax;
	var gExpTimeMinValue;
	var TmpExpTimeMin;

var bGainMin = false;
var bGainMax = false;
	var bWDROnGainHidden = false;
	var gGainMaxValue;
	var gGainMinValue;
	var TmpGainMin;
	var TmpGainMax;

var bFlickerless = false;
	var TmpFlickerless;
	var bFlickerlessOnExposureRange = false;
	var bWDROnFlickerlessUnchanged = false;
	var gFlickerlessOnExposureRangeMax;
	var gFlickerlessOnExposureRangeMin = 120; // default value, minimum exposure time 1/120 removes the rolling band 

var bDayNight = false;
	var TmpBWmode;
	var TmpEnableextled;
	var TmpDisableirled;
	var TmpSir;
	var TmpIrcutcontrolMode;
	var TmpDaymodebegintime;
	var TmpDaymodeendtime;
	var TmpIrcutcontrolsen;
	var gEnableextled;

var bICRMode = false;
	var TmpICRMode;
	var bForceICRtoDayMode = false;

var bDefog = false;
    var	bDefogOnWDRProUnchanged = false;
    var	bDefogOnWDRProDisabled= false;
    var	bDefogOnWDRCUnchanged = false;
	
var TmpProfileEnable;
var TmpPolicy;
var TmpBeginTime;
var TmpEndTime;

var gbIsSmartSensor = false;
	var aIrisTbl;
var giProfileIdx;
var gstrProfile;
var bExitProfile = false;

var TmpNormalLightEnable;
var bExitNormalLight = false;

function setProfileIndex()
{
	giProfileIdx = Number(getCookie("sensorprofileindex"));
	
	if (giProfileIdx == 0)
	{
		gstrProfile = "";
	}
	else
	{
		gstrProfile = "_profile_i0";
	}
}

function checkSensorType()
{
	if (getParamValueByName("capability_image_c"+giCH_Curr+"_sensortype") == "smartsensor")
	{
		gbIsSmartSensor = true;
		checkSmartSensorRelatedFeature();
	}
}

function checkSmartSensorRelatedFeature()
{
	//Iris table
	aIrisTbl = eval("capability_image_c"+giCH_Curr+"_smartsensor_iristotalrange").split(",");
}

function updateProfileCheck(checked)
{
	document.getElementById("enableprofile").checked = checked;
	if (checked)
	{
		TmpProfileEnable = 1;
		$("#profileDayMode, #profileNightMode, #profileSchedule, #profileScheduleContent1, #profileScheduleContent2").attr("disabled",false);
		$("#enableOpt").show(500);
	}
	else
	{
		TmpProfileEnable = 0;
		$("#profileDayMode, #profileNightMode, #profileSchedule, #profileScheduleContent1, #profileScheduleContent2").attr("disabled",true);
		$("#enableOpt").hide(500);
	}
	
	//$("#enableOpt").slideToggle()
}

function updateProfileScheduleTime(obj)
{
	if (obj.id == "profileScheduleBeginTime")
	{
		TmpBeginTime = obj.value;
	}
	else
	{
		TmpEndTime = obj.value;
	}
}

function checkProfileMode(obj)
{
	if (obj.id == "profileDayMode")
	{
		TmpPolicy = "day";
		//document.getElementById("profileDayMode").checked = true;
		document.getElementById("profileNightMode").checked = false;
		document.getElementById("profileSchedule").checked = false;
		$("#profileScheduleChild").css("display","none");
	}
	else if (obj.id == "profileNightMode")
	{
		TmpPolicy = "night";
		//document.getElementById("profileDayMode").checked = false;
		document.getElementById("profileNightMode").checked = true;
		document.getElementById("profileSchedule").checked = false;
		$("#profileScheduleChild").css("display","none");
	}
	else
	{
		TmpPolicy = "schedule";
		//document.getElementById("profileDayMode").checked = false;
		document.getElementById("profileNightMode").checked = false;
		document.getElementById("profileSchedule").checked = true;
		$("#profileScheduleChild").css("display","inline");
	}
}	

function enterProfileMode()
{
	params = "videoin_c0_profile_i0_enable=1&" +
			 "videoin_c0_profile_i0_policy=schedule&" + 
			 "videoin_c0_profile_i0_begintime=00:00&" + 
			 "videoin_c0_profile_i0_endtime=23:59"

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: params, 
		cache: false
	});

}

//load data when enter normallight page
function enterNormalLightMode()
{
	params = "videoin_c0_profile_i0_enable=0" 
	
 	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: params, 
		cache: false
	});

}


/*
function exitProfileMode()
{
	params = "videoin_c"+giCH_Curr+"_profile_i0_enable=" + eval("videoin_c"+giCH_Curr+"_profile_i0_enable") + "&" +
			"videoin_c"+giCH_Curr+"_profile_i0_policy=" + eval("videoin_c"+giCH_Curr+"_profile_i0_policy") + "&" +
			"videoin_c"+giCH_Curr+"_profile_i0_begintime=" + eval("videoin_c"+giCH_Curr+"_profile_i0_begintime") + "&" +
			"videoin_c"+giCH_Curr+"_profile_i0_endtime=" + eval("videoin_c"+giCH_Curr+"_profile_i0_endtime") + "&";

	$.ajax({
		type: "GET",
		url: "/cgi-bin/admin/setparam.cgi",
		data: params, 
		async: false,
		cache: false
	});
}
*/

//Called when the Web page is on loading.
function loadCurrentSetting()
{
	var tmp = location.href.split("?");
	var tmp2 = tmp[1].split("=");

	setProfileIndex();
	
	if (tmp2[0] == 'ch')
	{
		giCH_Curr = parseInt(tmp2[1], 10);
	}

	// exposure page related params
	{
		var params="capability_videoin_type&status_videomode_c"+giCH_Curr+"&capability_image_c"+giCH_Curr+"&capability_videoin_c"+giCH_Curr+
					"&videoin_c"+giCH_Curr+"&exposurewin_c"+giCH_Curr;
	}

	// day&night related capability group
	{
		var daynightcapabilityStr="&capability_daynight_c"+giCH_Curr+"_support&capability_daynight_c"+giCH_Curr+"_externalir"+"&capability_daynight_c"+giCH_Curr+"_builtinir"+
		                          "&capability_daynight_c"+giCH_Curr+"_smartir"+"&capability_daynight_c"+giCH_Curr+"_ircutfilter"+"&capability_daynight_c"+giCH_Curr+"_lightsensor";
	}
	
	// ircutcontrol group
	{
		var ircutcontrolStr="&ircutcontrol_bwmode"+"&ircutcontrol_enableextled"+"&ircutcontrol_disableirled"+
				            "&ircutcontrol_mode"+"&ircutcontrol_daymodebegintime"+"&ircutcontrol_daymodeendtime"+
							"&ircutcontrol_sensitivity"+"&ircutcontrol_sir";
	}

	// the group from image page
	{
		var otherStr="&image_c"+giCH_Curr+gstrProfile+"_scene"+"&image_c"+giCH_Curr+gstrProfile+"_defog";
	}
	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?" + params + daynightcapabilityStr + ircutcontrolStr + otherStr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();
}

function findDefogImpact()
{
	if ("-" != eval("capability_image_c"+giCH_Curr+"_defog_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_defog_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("wdrpro:unchanged:"))
			{
				bDefogOnWDRProUnchanged = true;
			}
			else if ( -1 != tmp[i].search("wdrpro:disabled:"))
			{
				bDefogOnWDRProDisabled = true;
			}
			else if ( -1 != tmp[i].search("wdrc:unchanged:"))
			{
				bDefogOnWDRCUnchanged = true;
			}
		}
	}
	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findAEImpact()
{
	//reset
	bAEImpactExposurewinBlcHidden = false;
	bAEImpactExposurewinHidden = false;
	bAEImpactDefogDisabled = false;
	bAEImpactWDRProDisabled = false;
	bAEImpactLevelHidden = false;
	bAEImpactAutoICRNotSupport = false;
	bAEImpactDefaultGainValue = false;
	
	//Find AE impact.
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_"+TmpExposureMode+"mode_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_exposure_"+TmpExposureMode+"mode_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("exposurewin.mode.blc:hidden:"))
			{
				bAEImpactExposurewinBlcHidden = true;
			}
			else if (-1 != tmp[i].search("exposurewin.mode:hidden:"))
			{
				bAEImpactExposurewinHidden = true;
			}
			else if (-1 != tmp[i].search("defog:disabled:"))
			{
				bAEImpactDefogDisabled = true;
			}
			else if (-1 != tmp[i].search("wdrpro:disabled:"))
			{
				bAEImpactWDRProDisabled = true;
			}
			else if (-1 != tmp[i].search("exposurelevel:hidden:"))
			{
				bAEImpactLevelHidden = true;
			}
			else if (-1 != tmp[i].search("icrmode.auto:notsupport:"))
			{
				bAEImpactAutoICRNotSupport = true;
			}
			else if (-1 != tmp[i].search(/defaultgain:fixed:\d+/))
			{
				bAEImpactDefaultGainValue = true;
				section = tmp[i].split(":")
				giDefaultGainFixValue = parseInt(section[2]);
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findWDRImpact()
{
	//Find WDR impact.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_wdrpro_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_wdrpro_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("exposurewin.mode:fixed:auto"))
			{
				bWDROnExposurewinFixedAuto = true;
			}
			else if (-1 != tmp[i].search("exposurewin.mode.blc:disabled:"))
			{
				bWDROnExposurewinBlcDisabled = true;
			}
			else if (-1 != tmp[i].search("exposurewin.mode.blc:hidden:"))
			{
				bWDROnExposurewinBlcHidden = true;
			}
			else if (-1 != tmp[i].search("exposurewin.mode.hlc:hidden:"))
			{
				bWDROnExposurewinHlcHidden = true;
			}
			else if (-1 != tmp[i].search("exposurelevel:hidden:"))
			{
				bWDROnLevelHidden = true;
			}
			else if (-1 != tmp[i].search(/exposurelevel:fixed:\d+/))
			{
				bWDROnLevelFixed = true;
				section = tmp[i].split(":")
				gWDROnLevelFixValue = section[2];

				if (1 != gWDROnLevelFixValue.search("/"))
				{
					bIsWDROnLevelSingleFixValue = true;
				}
			}
			else if (-1 != tmp[i].search(/exposurelevel:ranged:\d+-\d+/))
			{
				bWDROnLevelRanged = true;
				section = tmp[i].split(":")
				RangeValue = section[2].match(/(\d+)-(\d+)/); //extract range value
				gWDROnLevelRangeMin = parseInt(RangeValue[1]);
				gWDROnLevelRangeMax = parseInt(RangeValue[2]);
			}
			else if (-1 != tmp[i].search("exposuremode:fixed:auto"))
			{
				bWDROnExposuremodeFixedAuto = true;
			}
			else if (-1 != tmp[i].search("exposuretime:hidden:"))
			{
				bWDROnExpTimeHidden = true;
			}
			else if (-1 != tmp[i].search("gaincontrol:hidden:"))
			{
				bWDROnGainHidden = true;
			}
			else if (-1 != tmp[i].search("aespeed:disabled:"))
			{
				bWDROnAESpeedDisabled = true;
			}
			else if (-1 != tmp[i].search("aespeed:unchanged:"))
			{
				bWDROnAESpeedUnchanged = true;
			}
			else if (-1 != tmp[i].search("irismode:hidden:"))
			{
				bWDROnIrismodeHidden = true;
			}
			else if (-1 != tmp[i].search("flickerless:unchanged:"))
			{
				bWDROnFlickerlessUnchanged = true;
			}
			else if (-1 != tmp[i].search("wdrc:enabled:"))
			{
				bWDROnWDRCEnabled = true;

				section = tmp[i].split(":")
				gWDROnWDRCEnabledValue = section[2];
				if(gWDROnWDRCEnabledValue == "onlyonce")
				{
					bWDROnWDRCEnabledOnlyOnce = true;
					bWDROnWDRCEnabled = false;
				}	
				else if(gWDROnWDRCEnabledValue == "always")
				{
					bWDROnWDRCEnabledAlways = true;
					bWDROnWDRCEnabled = false;
				}	

			}
			else if (-1 != tmp[i].search("wdrc:unchanged:"))
			{
				bWDROnWDRCUnchanged = true;
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findWDRCImpact()
{
	//Find WDRC impact.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_wdrc_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_wdrc_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("contrast:unchanged:"))
			{
				bWDRCOnContrastUnchanged = true;
			}
		}
	}
	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findFlickerlessImpact()
{
	if ("-" != eval("capability_image_c"+giCH_Curr+"_flickerlessaffect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_flickerlessaffect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search(/minexposure.lowerbound:fixed:\d+/))
			{
				bFlickerlessOnExposureRange = true;
				section = tmp[i].split(":")
				gFlickerlessOnExposureRangeMin = section[2];

				if (bPAL50)
				{
					gFlickerlessOnExposureRangeMin = doPAL50Transfer(gFlickerlessOnExposureRangeMin);
				}
			}

		}
	}
}

function findSceneModeImpact() 
{
	TmpSceneMode = eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode");
	
	if ("-" != eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("minexposure:hidden:"))
			{
				bSceneModeOnMinexposureHidden = true;
			}
			else if ( -1 != tmp[i].search("mingain:hidden:"))
			{
				bSceneModeOnMingainHidden = true;
			}
			else if ( -1 != tmp[i].search("flickerless:hidden:"))
			{
				bSceneModeOnFlickerlessHidden = true;
			}
			else if ( -1 != tmp[i].search("flickerless:unchanged:"))
			{
				bSceneModeOnFlickerlessUnchanged = true;
			}
			else if ( -1 != tmp[i].search("wdrpro:unchanged:"))
			{
				bSceneModeOnWdrproUnchanged = true;
			}
		}
	}
	
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxexposure"))
	{
		bSceneModeOnDefaultMaxexposure = true;
	}
	
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxgain"))
	{
		bSceneModeOnDefaultMaxgain = true;
	}
}

function findExpWinModeImpact()
{
	//reset
	bExpWinModeImpactSIRHidden = false;
	
	//Find Exposure window mode impact.
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_"+TmpExpWinMode+"mode_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_exposure_"+TmpExpWinMode+"mode_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("sir:hidden:"))
			{
				bExpWinModeImpactSIRHidden = true;
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

//Called when the Web page is loaded done.
//Start point of this code.
function receivedone()
{
	var iTmp, iTmp2;
	var tmp, tmp2;

	// check sensor type: "smart sensor" or "raw sensor"
	checkSensorType();
	
	/* Check ircutcontrol mode if show message */
	if (eval("capability_daynight_c"+giCH_Curr+"_support") == "1"
			&& eval("capability_daynight_c"+giCH_Curr+"_lightsensor") == "0"
			&& eval("ircutcontrol_mode") == "auto")
	{
		$("#autoModeChildMessage").slideDown("slow");
	}
	else
	{
		$("#autoModeChildMessage").slideUp("slow");
	}

	//Scene mode
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_scenemode_support"), 10) &&  1 == parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_scene_enable")))
	{
		bSceneModeEnable = true;
		findSceneModeImpact();
	}
	
	//Defog
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_defog_mode"), 10) &&  1 == parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_defog_mode")))
	{
		bDefog = true;
		findDefogImpact();
	}

	//Exposure.
	if (1 == eval("capability_image_c"+giCH_Curr+"_exposure_mode"))
	{
		bExpMode = true;

		getCMOSfrq();
		getExpTimeTotalRange();

		//Exposure window.
		if ("-" != eval("capability_image_c"+giCH_Curr+"_exposure_winmode"))
		{
			bExpWin = true;
			document.getElementById("expWinControl").style.display = "block";
			//document.getElementById("expWinButton").style.display = "none";
			//
			// include/exclude window buttons are in another iframe
			$("#expwinbutton", window.parent.document).hide();

			if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("auto") != -1)
			{
				document.getElementById("expWinModeAuto").style.display = "inline";
				document.getElementById("expWinModeAutoName").style.display = "inline";
				if ("auto" == eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode"))
				{
					document.getElementById("expWinModeAuto").checked = true;
				}
			}

			if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("custom") != -1)
			{
				document.getElementById("expWinModeCustom").style.display = "inline";
				document.getElementById("expWinModeCustomName").style.display = "inline";
				if ("custom" == eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode"))
				{
					document.getElementById("expWinModeCustom").checked = true;
					showCustomWinType();
				}
			}

			if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("blc") != -1)
			{
				document.getElementById("expWinModeBlc").style.display = "inline";
				document.getElementById("expWinModeBlcName").style.display = "inline";
				if ("blc" == eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode"))
				{
					document.getElementById("expWinModeBlc").checked = true;
				}
			}

			if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("hlc") != -1)
			{
				document.getElementById("expWinModeHlc").style.display = "inline";
				document.getElementById("expWinModeHlcName").style.display = "inline";
				if ("hlc" == eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode"))
				{
					document.getElementById("expWinModeHlc").checked = true;
					if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_hlcmode_supportwindow"))
					{
						showCustomWinType();
					}
				}
			}
		}

		//Exposure level
		if ("-" != eval("capability_image_c"+giCH_Curr+"_exposure_levelrange"))
		{
			bExpLevel = true;
			document.getElementById("exposurelevelControl").style.display = "block";
			TmpExpLevel = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_exposurelevel"), 10);

			//Generate exposure level options.
			$(document.getElementById("exposurelevelSelect")).removeOption(/./);
			if ("0,12" == eval("capability_image_c"+giCH_Curr+"_exposure_levelrange"))
			{
				bIsEVTable = true;
				for (i = (aExposureLevelEVTbl.length - 1); i >= 0 ; i--)
				{
					if (aExposureLevelEVTbl[i][0] == TmpExpLevel)
					{
						$(document.getElementById("exposurelevelSelect")).addOption(aExposureLevelEVTbl[i][0], aExposureLevelEVTbl[i][1], true);
					}
					else
					{
						$(document.getElementById("exposurelevelSelect")).addOption(aExposureLevelEVTbl[i][0], aExposureLevelEVTbl[i][1], false);
					}
				}
			}
			else
			{
				bIsEVTable = false;
				iTmp = eval("capability_image_c"+giCH_Curr+"_exposure_levelrange").split(",")[1];
				for (i = iTmp; i >= 0; i--)
				{
					if (i == TmpExpLevel)
					{
						$(document.getElementById("exposurelevelSelect")).addOption(i, i, true);
					}
					else
					{
						$(document.getElementById("exposurelevelSelect")).addOption(i, i, false);
					}
				}
			}
		}

		//Exposure mode
		if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_modetype"))
		{
			document.getElementById("exposureModeParent").style.display = "block";
		}
		else
		{
			if ("-" != eval("capability_image_c"+giCH_Curr+"_exposure_modetype"))
			{
				bExpModeType = true;
				document.getElementById("exposureModeParent").style.display = "block";
				//Generate exposure mode options.
				$(document.getElementById("exposure_mode")).removeOption(/./);
				aExposureSupportMode = eval("capability_image_c"+giCH_Curr+"_exposure_modetype").split(",").sort();
				
				//Sort by alphabetical order (A ~ Z), and manual is last.
				var idx = -1;
				for (idx = 0; i < aExposureSupportMode.length; idx++)
				{
					if (aExposureSupportMode[idx]=="manual")
					{
						aExposureSupportMode.splice(idx, 1);
						aExposureSupportMode.push("manual");
						break;
					}
				}

				for (i = 0; i < aExposureSupportMode.length; i++)
				{
					$(document.getElementById("exposure_mode")).addOption(aExposureSupportMode[i], translator(aExposureSupportMode[i]), true);
				}
			}
		}

		//Range type
		if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_rangetype"))
		{
			eRangeType = "TWOVALUE";
		}
		else
		{
			if ("twovalues" == eval("capability_image_c"+giCH_Curr+"_exposure_rangetype"))
			{
				eRangeType = "TWOVALUE";
			}
			else if ("onevalue" == eval("capability_image_c"+giCH_Curr+"_exposure_rangetype"))
			{
				eRangeType = "ONEVALUE";
			}
		}


		//Iris Type
		if ("piris" == eval("capability_image_c"+giCH_Curr+"_iristype"))
		{
			eIrisType = "PIRIS";
			//document.getElementById("exposureModeParent").style.display = "block";
		}
		else if ("dciris" == eval("capability_image_c"+giCH_Curr+"_iristype"))
		{
			eIrisType = "DCIRIS";
			//document.getElementById("exposureModeParent").style.display = "block";
		}
		else
		{
			eIrisType = "FIXIRIS";

			//Flickerless
			if (1 == eval("capability_image_c"+giCH_Curr+"_flickerless"))
			{
				bFlickerless = true;
				document.getElementById("exposureModeParent").style.display = "none";
				document.getElementById("flickerlessControl").style.display = "block";
				findFlickerlessImpact();
			}
		}

		//Exposure time
		if ("-" != eval("capability_image_c"+giCH_Curr+"_exposure_maxrange"))
		{
			bExpTimeMax = true;
			gExpTimeMaxValue = eval("capability_image_c"+giCH_Curr+"_exposure_maxrange").split(",")[1];
			gExpTimeMinValue = eval("capability_image_c"+giCH_Curr+"_exposure_maxrange").split(",")[0];
		}

		if ("-" != eval("capability_image_c"+giCH_Curr+"_exposure_minrange"))
		{
			// this scene affect do not have "minexposure:hidden:" or scene mode is not enable or support
			if(!bSceneModeOnMinexposureHidden)
			{
				bExpTimeMin = true;
				
				//calculate widest range
				expTimeMinRangeUpBound = eval("capability_image_c"+giCH_Curr+"_exposure_minrange").split(",")[0];
				expTimeMinRangeLowBound = eval("capability_image_c"+giCH_Curr+"_exposure_minrange").split(",")[1];
				if (parseInt(gExpTimeMinValue, 10) > parseInt(expTimeMinRangeUpBound, 10))
				{
					gExpTimeMinValue = expTimeMinRangeUpBound;
				}
				if (parseInt(gExpTimeMaxValue, 10) < parseInt(expTimeMinRangeLowBound, 10))
				{
					gExpTimeMaxValue = expTimeMinRangeLowBound;
				}
			}
		}
		
		if (bExpTimeMax && bExpTimeMin)
		{
			document.getElementById("exptimename").innerHTML = translator("exposure_time");
			document.getElementById("exposureTimeControl").style.display = "block";
		}
		else if (bExpTimeMax)
		{
			document.getElementById("exptimename").innerHTML = translator("maximum_exposure_time");
			document.getElementById("exposureTimeControl").style.display = "block";
		}

		if (bExpTimeMax || bExpTimeMin)
		{
			iTmp = 0;
			for (i = 0; i < aExposureTimeTbl.length; i++)
			{
				if (aExposureTimeTbl[i][0] >= gExpTimeMinValue && aExposureTimeTbl[i][0] <= gExpTimeMaxValue)
				{
					aExposureTimeTbl[i][1] = iTmp;
					iTmp = parseInt(iTmp, 10) + 1;
				}
			}
			gExpTimeLevel = iTmp;

		}


		//Gain
		if ("-" != eval("capability_image_c"+giCH_Curr+"_agc_maxgain"))
		{
			bGainMax = true;
			gGainMaxValue = eval("capability_image_c"+giCH_Curr+"_agc_maxgain").split(",")[1];
			gGainMinValue = eval("capability_image_c"+giCH_Curr+"_agc_maxgain").split(",")[0];
		}

		if ("-" != eval("capability_image_c"+giCH_Curr+"_agc_mingain"))
		{
			// this scene affect do not have "mingain:hidden:" or scene mode is not enable or support
			if (!bSceneModeOnMingainHidden)
			{
				gGainMinValue = eval("capability_image_c"+giCH_Curr+"_agc_mingain").split(",")[0];
				bGainMin = true;
			}
		}

		if (bGainMax && bGainMin)
		{
			document.getElementById("gainName").innerHTML = translator("gain_control");
			document.getElementById("gainControl").style.display = "block";
		}
		else if (bGainMax)
		{
			document.getElementById("gainName").innerHTML = translator("maximum_gain_control");
			document.getElementById("gainControl").style.display = "block";
		}
	}

	//AE speed adjustment
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_aespeed"), 10))
	{
		bAESpeedAdjust = true;
		document.getElementById("aespeedControl").style.display = "block";

		if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_aespeedsupportsensitivity"))
		{
			document.getElementById("sensitivity_adjustment").style.display = "none";
		}
	}

	//WDR pro = 1
	//WDR pro & WDR proII = 2
	if (1 <= (giWDRProMode = parseInt(eval("capability_image_c"+giCH_Curr+"_wdrpro_mode"), 10)))
	{
		bWDRPro = true;

		if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_wdrpro_description"))
		{
			document.getElementById("wdrenableTitle").innerHTML = translator("enable") + " " + eval("capability_image_c"+giCH_Curr+"_wdrpro_description");
		}
		else
		{
			switch(giWDRProMode)
			{
				case 1:
					document.getElementById("wdrenableTitle").innerHTML = translator("enable_wdr_pro");
					break;
				case 2:
					document.getElementById("wdrenableTitle").innerHTML = translator("enable_wdr_pro_ii");
					break;
			}
		}
		
		document.getElementById("wdrTitle").innerHTML = translator("wdr");
		document.getElementById("wdrControl").style.display = "block";
		document.getElementById("wdrpro_content").style.display = "block";
		document.getElementById("wdrpro_strength").innerHTML = translator("strength");
		if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_wdrpro_strength"), 10))
		{
			bWDRStr = true;
		}

		TmpWDRSupportLevel = 0;

		iTmp = eval("capability_image_c"+giCH_Curr+"_wdrpro_supportlevel").split(",");

		for (i = 0; i < iTmp.length; i++)
		{
			/* String * Value = Value */
			TmpWDRSupportLevel = TmpWDRSupportLevel*1 + iTmp[i]*1;
		}

		if (TmpWDRSupportLevel < 3)
		{
			TmpWDRSupportLevel = 2;
			TmpWDRStep = 99;
		}
		else
		{
			TmpWDRStep = Math.floor(100 / (TmpWDRSupportLevel - 1));
		}

		findWDRImpact();

	}

	//WDR enhance
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_wdrc_mode"), 10))
	{
		bWDREnhanced = true;
		
		if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_wdrc_description"))
		{
			document.getElementById("wdrcenableTitle").innerHTML = translator("enable") + " " + eval("capability_image_c"+giCH_Curr+"_wdrc_description");
		}
		else
		{
			document.getElementById("wdrcenableTitle").innerHTML = translator("enable_wdr_enhanced");	
		}
		
		document.getElementById("wdrTitle").innerHTML = translator("wdr");
		document.getElementById("wdrControl").style.display = "block";
		document.getElementById("wdrc_content").style.display = "block";
		document.getElementById("wdrc_strength").innerHTML = translator("strength");
		bWDRCStr = true;

		TmpWDRCSupportLevel = eval("capability_image_c"+giCH_Curr+"_wdrc_supportlevel");

		if (TmpWDRCSupportLevel < 3)
		{
			TmpWDRCSupportLevel = 2;
			TmpWDRCStep = 99;
		}
		else
		{
			TmpWDRCStep = Math.floor(100 / (TmpWDRCSupportLevel - 1));
		}

		findWDRCImpact();
	}

	//If day and night is determined by DNS (not light sensor),
	//we put day night settings in exposure page to avoid hunting
	/*if (1 == parseInt(eval("capability_daynight_c"+giCH_Curr+"_support"), 10) && 0 == parseInt(eval("capability_daynight_c"+giCH_Curr+"_lightsensor"), 10) && giProfileIdx == 0)
	{
		bDayNight = true;
		document.getElementById("daynightControl").style.display = "block";
	}*/
   
   	if (1 == parseInt(eval("capability_daynight_c"+giCH_Curr+"_support"), 10) && 1 == parseInt(eval("capability_daynight_c"+giCH_Curr+"_ircutfilter"), 10))
	{
		bICRMode = true;
		TmpICRMode = eval("ircutcontrol_mode");
	}

	RestoreSettingUI();

	if (true == bIsWinMSIE)
	{
		if (document.body.scrollHeight + 18 > gMaxPageHeight)
		{
			parent.document.getElementById("exposurepage").height = gMaxPageHeight;
		}
		else
		{
			parent.document.getElementById("exposurepage").height = document.body.scrollHeight + 18;
		}
	}
	else
	{
		if (document.body.scrollHeight > gMaxPageHeight)
		{
			parent.document.getElementById("exposurepage").height = gMaxPageHeight;
		}
		else
		{
			parent.document.getElementById("exposurepage").height = document.body.scrollHeight;
		}
	}

	// In firefox, it has the chance that document.body.scrollHeight return 0
	// if so, we assign height with gMaxPageHeight
	if (parent.document.getElementById("exposurepage").height == 0)
	{
		parent.document.getElementById("exposurepage").height = gMaxPageHeight;
	}

}

//Called when all objects in Web page is ready.
function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
}

function doPAL50Transfer(input)
{
	var exptimeList_PAL50  = eval("capability_image_c"+giCH_Curr+"_exposure_pal_totalrange").split(",");
	var exptimeList_NTSC60 = eval("capability_image_c"+giCH_Curr+"_exposure_ntsc_totalrange").split(",");
	var indexOfPAL50  = jQuery.inArray("" + input, exptimeList_PAL50);
	var indexOfNTSC60 = jQuery.inArray("" + input, exptimeList_NTSC60);

	if (indexOfPAL50 >= 0)
	{
		return input;
	}
	
	if (indexOfNTSC60 >= 0)
	{
		if (exptimeList_PAL50.length == exptimeList_NTSC60.length)
		{
			// do one-to-one mapping
			return exptimeList_PAL50[indexOfNTSC60];
		}
		else
		{
			// find the nearest item
			var nearerVal = exptimeList_PAL50[0];
			for (var key in exptimeList_PAL50)
			{
				nearerVal = (Math.abs(input - exptimeList_PAL50[key]) < Math.abs(input - nearerVal))? exptimeList_PAL50[key] : nearerVal;
			}
    			return nearerVal;
		}
	}

	return input;
}

function doNTSC60Transfer(input)
{
	var exptimeList_PAL50  = eval("capability_image_c"+giCH_Curr+"_exposure_pal_totalrange").split(",");
	var exptimeList_NTSC60 = eval("capability_image_c"+giCH_Curr+"_exposure_ntsc_totalrange").split(",");
	var indexOfPAL50  = jQuery.inArray("" + input, exptimeList_PAL50);
	var indexOfNTSC60 = jQuery.inArray("" + input, exptimeList_NTSC60);

	if (indexOfNTSC60 >= 0)
	{
		return input;
	}
	
	if (indexOfPAL50 >= 0)
	{
		if (exptimeList_NTSC60.length == exptimeList_PAL50.length)
		{
			// do one-to-one mapping
			return exptimeList_NTSC60[indexOfPAL50];
		}
		else
		{
			// find the nearest value
			var nearerVal = exptimeList_NTSC60[0];
			for (var key in exptimeList_NTSC60)
			{
				nearerVal = (Math.abs(input - exptimeList_NTSC60[key]) < Math.abs(input - nearerVal))? exptimeList_NTSC60[key] : nearerVal;
			}
    			return nearerVal;
		}
	}

	return input;
}

function checkExpTimeInPAL50Range(expTime)
{
	ExpTimeRange = eval("capability_image_c"+giCH_Curr+"_exposure_pal_totalrange").split(",");
	for (i = 0; i < ExpTimeRange.length; i++)
	{
		if (ExpTimeRange[i] == expTime)
		{
			return true;
		}
	}
	return false;
}

function checkExpTimeInNTSC60Range(expTime)
{
	ExpTimeRange = eval("capability_image_c"+giCH_Curr+"_exposure_ntsc_totalrange").split(",");
	for (i = 0; i < ExpTimeRange.length; i++)
	{
		if (ExpTimeRange[i] == expTime)
		{
			return true;
		}
	}
	return false;
}

function showCustomWinType()
{
	//if (parseInt(eval("capability_image_c"+giCH_Curr+"_exposure_winnum"), 10) > 1)
	/*
	{
		document.getElementById("expWinButton").style.display = "table-row";

		iTmp2 = -1;
		iTmp = parseInt(eval("capability_image_c"+giCH_Curr+"_exposure_winnum"), 10);
		for (i = 0; i < iTmp; i++)
		{
			if (0 == eval("exposurewin_c"+giCH_Curr+"_win_i"+i+"_enable"))
			{
				iTmp2 = i;
				break;
			}
		}

		if (-1 == iTmp2)
		{
			document.getElementById("addIncludeButton").disabled = true;
			document.getElementById("addExcludeButton").disabled = true;
		}

		if (-1 == eval("capability_image_c"+giCH_Curr+"_exposure_wintype").search("exclusive"))
		{
			document.getElementById("addExcludeButton").style.display = "none";;
		}
	}
	*/

	// include/exclude window buttons are in another iframe
	{
		$("#expwinbutton", window.parent.document).show();

		iTmp2 = -1;
		iTmp = parseInt(eval("capability_image_c"+giCH_Curr+"_exposure_winnum"), 10);
		for (i = 0; i < iTmp; i++)
		{
			if (0 == eval("exposurewin_c"+giCH_Curr+gstrProfile+"_win_i"+i+"_enable"))
			{
				iTmp2 = i;
				break;
			}
		}

		if (-1 == iTmp2)
		{
			$("#expwinbutton", window.parent.document).contents().find("#addIncludeButton").attr('disabled','disabled');
			$("#expwinbutton", window.parent.document).contents().find("#addExcludeButton").attr('disabled','disabled');
		}

		if (-1 == eval("capability_image_c"+giCH_Curr+"_exposure_wintype").search("exclusive"))
		{
			$("#expwinbutton", window.parent.document).contents().find("#addExcludeButton").css('display','none');
		}
	}
}

function changeExpWinMode(mode)
{
	TmpExpWinMode = mode;
	
	findExpWinModeImpact();
	
	if (false == switchExpWinModeUI_MsgCheck(mode))
	{
		if ("auto" == mode)
		{
			document.getElementById("expWinModeAuto").checked = false;
		}
		else if ("custom" == mode)
		{
			document.getElementById("expWinModeCustom").checked = false;
		}
		else if ("blc" == mode)
		{
			document.getElementById("expWinModeBlc").checked = false;
		}
		else if ("hlc" == mode)
		{
			document.getElementById("expWinModeHlc").checked = false;
		}
		return;
	}

	if ("auto" == mode)
	{
		document.getElementById("expWinModeAuto").checked = true;
		document.getElementById("expWinModeCustom").checked = false;
		document.getElementById("expWinModeBlc").checked = false;
		document.getElementById("expWinModeHlc").checked = false;
		//document.getElementById("expWinButton").style.display = "none";
		
		// include/exclude window buttons are in another iframe
		$("#expwinbutton", window.parent.document).hide();

		getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "auto";
	}
	else if ("custom" == mode)
	{
		document.getElementById("expWinModeAuto").checked = false;
		document.getElementById("expWinModeCustom").checked = true;
		document.getElementById("expWinModeBlc").checked = false;
		document.getElementById("expWinModeHlc").checked = false;
		
		showCustomWinType();

		getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "custom";
	}
	else if ("blc" == mode)
	{
		document.getElementById("expWinModeAuto").checked = false;
		document.getElementById("expWinModeCustom").checked = false;
		document.getElementById("expWinModeBlc").checked = true;
		document.getElementById("expWinModeHlc").checked = false;
		//document.getElementById("expWinButton").style.display = "none";
		
		// include/exclude window buttons are in another iframe
		$("#expwinbutton", window.parent.document).hide();

		getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "blc";
	}
	else if ("hlc" == mode)
	{
		document.getElementById("expWinModeAuto").checked = false;
		document.getElementById("expWinModeCustom").checked = false;
		document.getElementById("expWinModeBlc").checked = false;
		document.getElementById("expWinModeHlc").checked = true;
		//document.getElementById("expWinButton").style.display = "none";

		if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_hlcmode_supportwindow"))
		{
			showCustomWinType();
		}
		else
		{
			// include/exclude window buttons are in another iframe
			$("#expwinbutton", window.parent.document).hide();
		}

		getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "hlc";
	}

	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "exposurewin_c"+giCH_Curr+gstrProfile+"_mode="+TmpExpWinMode,
		async: false,
		cache: false
	});
}

function addIncludeWindow()
{
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "addIncludeWin";
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();
}

function addExcludeWindow()
{
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "addExcludeWin";
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();
}

function changeExpLevel(expLevel)
{
	TmpExpLevel = expLevel;

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_exposurelevel="+TmpExpLevel,
		async: false,
		cache: false
	});
}

function setFlickerless(checked)
{
	if (checked)
	{
		TmpFlickerless = 1;
	}
	else
	{
		TmpFlickerless = 0;
	}

	SwitchFlickerlessUI(checked);

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_flickerless="+TmpFlickerless,
		async: false,
		cache: false
	});
}

function SwitchFlickerlessUI(checked)
{
	if (false == checked)
	{
		TmpFlickerless = 0;

		if (bExpTimeMax && bExpTimeMin)
		{
			$("#exposureTimeSlider").slider('option', 'min', 0);
			$("#exposureTimeSlider").slider('option', 'max', gExpTimeLevel - 1);
			$("#exposureTimeSlider").slider('values', 0, getExpTimeSlideIdx(TmpExpTimeMin));
		}
		else if (bExpTimeMax)
		{
			//Only Max exposure time can be control
			//Reference from above.
			$("#exposureTimeSlider").slider('option', 'min', 0);
			$("#exposureTimeSlider").slider('option', 'max', gExpTimeLevel - 1);
			$("#exposureTimeSlider").slider('value',  getExpTimeSlideIdx(TmpExpTimeMax));
		}
	}
	else
	{
		var aTmpExpTimeMin;

		TmpFlickerless = 1;

		if (bExpTimeMax && bExpTimeMin)
		{
			if (parseInt(TmpExpTimeMin, 10) > gFlickerlessOnExposureRangeMin)
			{
				TmpExpTimeMin = gFlickerlessOnExposureRangeMin;
			}

			if (parseInt(TmpExpTimeMax, 10) > gFlickerlessOnExposureRangeMin)
			{
				TmpExpTimeMax = gFlickerlessOnExposureRangeMin;
			}

			$("#exposureTimeSlider").slider('option', 'min', getExpTimeSlideIdx(gFlickerlessOnExposureRangeMin));

			$("#exposureTimeSlider").slider('values', 1, getExpTimeSlideIdx(TmpExpTimeMax));
			$("#exposureTimeSlider").slider('values', 0, getExpTimeSlideIdx(TmpExpTimeMin));
			$("#exposureTimeValue").html("1/"+TmpExpTimeMin+" - 1/"+TmpExpTimeMax);

		}
		else if (bExpTimeMax)
		{
			//Only Max exposure time can be control
			//Reference from above.
			if (!bSceneModeOnFlickerlessHidden && !bSceneModeOnFlickerlessUnchanged)
			{
				if (parseInt(TmpExpTimeMax, 10) > gFlickerlessOnExposureRangeMin)
				{
					TmpExpTimeMax = gFlickerlessOnExposureRangeMin;
				}

				$("#exposureTimeSlider").slider('option', 'min', getExpTimeSlideIdx(gFlickerlessOnExposureRangeMin));
				$("#exposureTimeSlider").slider('value', getExpTimeSlideIdx(TmpExpTimeMax));
				$("#exposureTimeValue").html("1/"+TmpExpTimeMax);
			}
		}
	}

}

function getCMOSfrq()
{
	if (2 == parseInt(eval("capability_videoin_type"),10))
	{
		if (50 == parseInt(eval("videoin_c"+giCH_Curr+"_cmosfreq"),10))
		{
			bPAL50 = true;
		}
	}
	else
	{
		if ("pal" == eval("status_videomode_c"+giCH_Curr))
		{
			bPAL50 = true;
		}
	}
}

function getExpTimeTotalRange()
{
	var exptimeRange;
	var exptimeTotal;

	if (bPAL50)
	{
		exptimeTotal = eval("capability_image_c"+giCH_Curr+"_exposure_pal_totalrange").split(",").length;
		exptimeRange = eval("capability_image_c"+giCH_Curr+"_exposure_pal_totalrange"); 
	}
	else
	{
		exptimeTotal = eval("capability_image_c"+giCH_Curr+"_exposure_ntsc_totalrange").split(",").length;
		exptimeRange = eval("capability_image_c"+giCH_Curr+"_exposure_ntsc_totalrange"); 
	}

	for (i = 0; i < exptimeTotal; i++)
	{
		ExposureTime = eval("["+exptimeRange.split(",")[i]+",999]"); 
		aExposureTimeTbl.push(ExposureTime);
	}
}

function getExpTimeSlideIdx(expTime)
{
	//Future work: mixexposure/maxexposure can be set to any values in their available ranges.
		//This code can not handle that.

	for (i = 0; i < aExposureTimeTbl.length; i++)
	{
		if (expTime == aExposureTimeTbl[i][0])
		{
			return aExposureTimeTbl[i][1];
		}
	}
}

function getExpTimeSlideValue(slideIdx)
{
	for (i = 0; i < aExposureTimeTbl.length; i++)
	{
		if (slideIdx == aExposureTimeTbl[i][1])
		{
			return aExposureTimeTbl[i][0];
		}
	}
}

function RestoreSettingUI()
{
	if (giProfileIdx == 0)
	{
		TmpNormalLightEnable = parseInt(eval("videoin_c"+giCH_Curr+"_profile_i0_enable"));
		enterNormalLightMode();
	}
	
	if (giProfileIdx == 1)
	{
		$("#enableProfileContent").show();

		if ("0" == eval("capability_daynight_c"+giCH_Curr+"_support"))
		{
//            document.getElementById("profileDayMode").style.display = "none";
//            document.getElementById("profileDayModeStr").style.display = "none";
			document.getElementById("profileNightMode").style.display = "none";
			document.getElementById("profileNightModeStr").style.display = "none";
		}
		
		TmpProfileEnable = parseInt(eval("videoin_c"+giCH_Curr+"_profile_i0_enable"));
	    if(TmpProfileEnable == 0)
		{
			updateProfileCheck(false);
			//$("#enableOpt").hide(500);
		}
	    else
		{
			updateProfileCheck(true);
			//$("#enableOpt").show(500);
		}

		TmpPolicy = eval("videoin_c"+giCH_Curr+"_profile_i0_policy");
		if (TmpPolicy == "day")
		{
			//document.getElementById("profileDayMode").checked = true;
			document.getElementById("profileNightMode").checked = false;
			document.getElementById("profileSchedule").checked = false;
			$("#profileScheduleChild").css("display","none");
		}
		else if (TmpPolicy == "night")
		{
			//document.getElementById("profileDayMode").checked = false;
			document.getElementById("profileNightMode").checked = true;
			document.getElementById("profileSchedule").checked = false;
			$("#profileScheduleChild").css("display","none");
		}
		else if (TmpPolicy == "schedule")
		{
			//document.getElementById("profileDayMode").checked = false;
			document.getElementById("profileNightMode").checked = false;
			document.getElementById("profileSchedule").checked = true;
			$("#profileScheduleChild").css("display","inline");
		}

		TmpBeginTime = eval("videoin_c"+giCH_Curr+"_profile_i0_begintime");
		document.getElementById("profileScheduleBeginTime").value = TmpBeginTime;

		TmpEndTime = eval("videoin_c"+giCH_Curr+"_profile_i0_endtime");
		document.getElementById("profileScheduleEndTime").value = TmpEndTime;
		enterProfileMode();
	}

	if (bExpWin)
	{
		TmpExpWinMode = eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode");

		if ("auto" == TmpExpWinMode)
		{
			document.getElementById("expWinModeAuto").checked = true;
			document.getElementById("expWinModeCustom").checked = false;
			document.getElementById("expWinModeBlc").checked = false;
			document.getElementById("expWinModeHlc").checked = false;
		}
		else if ("custom" == TmpExpWinMode)
		{
			document.getElementById("expWinModeAuto").checked = false;
			document.getElementById("expWinModeCustom").checked = true;
			document.getElementById("expWinModeBlc").checked = false;
			document.getElementById("expWinModeHlc").checked = false;
		}
		else if ("blc" == TmpExpWinMode)
		{
			document.getElementById("expWinModeAuto").checked = false;
			document.getElementById("expWinModeCustom").checked = false;
			document.getElementById("expWinModeBlc").checked = true;
			document.getElementById("expWinModeHlc").checked = false;
		}
		else if ("hlc" == TmpExpWinMode)
		{
			document.getElementById("expWinModeAuto").checked = false;
			document.getElementById("expWinModeCustom").checked = false;
			document.getElementById("expWinModeBlc").checked = false;
			document.getElementById("expWinModeHlc").checked = true;
		}
	}

	if (bExpLevel)
	{
		TmpExpLevel = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_exposurelevel"), 10);

		$(document.getElementById("exposurelevelSelect")).children().each(
			function()
			{
				if (TmpExpLevel == this.value)
				{	
					this.selected = true;
				}
			}
		);
	}

	// ExposureMode
	if (gbIsSmartSensor)
	{
		if(eIrisType == "PIRIS")
		{
			$(".dciris").css("display", "none");
			$(".fixediris").css("display", "none");
			$(".piris").css("display", "none");
			$("#iris_adjustment").css("display", "block");
		}
		TmpExposureMode = eval("videoin_c"+giCH_Curr+gstrProfile+"_exposuremode");
		$("#exposure_mode").val(TmpExposureMode);
		switchAEMode($("#exposure_mode").val());
	}
	else
	{
		if(eIrisType == "PIRIS")
		{
			$(".dciris").css("display", "none");
			$(".fixediris").css("display", "none");

			if (eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_mode") == "-")
			{
				//smart sensor (SD sony moudle spec)
				$(".piris").css("display", "none");
				$("#iris_adjustment").css("display", "block");
			}
			else if (eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_mode") != "manual")
			{
				$("#exposure_mode").val("auto");
				$("#fake_videoin_c"+giCH_Curr+"_piris_mode").val(eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_mode"));
				switchAEMode($("#exposure_mode").val());
			}
			else
			{
				$("#exposure_mode").val("manual");
				switchAEMode($("#exposure_mode").val());
			}
		}
		else if(eIrisType == "DCIRIS")
		{
			$(".piris").css("display", "none");
			$(".fixediris").css("display", "none");

			$("#exposure_mode").get(0).options[1].text = translator("manual");
			if (eval("videoin_c"+giCH_Curr+gstrProfile+"_irismode") != "fixed")
			{
				$("#exposure_mode").val("auto");
				$("#fake_videoin_c"+giCH_Curr+"_irismode").val(eval("videoin_c"+giCH_Curr+gstrProfile+"_irismode"));
				switchAEMode($("#exposure_mode").val());
			}
			else
			{
				$("#exposure_mode").val("manual");
				switchAEMode($("#exposure_mode").val());
			}		
		}
		else // fixediris
		{
			$(".piris").css("display", "none");
			$(".dciris").css("display", "none");
			$("#exposureModeParent").css("display", "none");
			switchAEMode("manual");
		}
	}
	
	//PIRIS Position
	if (eIrisType == "PIRIS")
	{
		//PIRIS bar
		if (gbIsSmartSensor)
		{
			var uiVal;
			SmartSensorPirisValue = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_position"), 10);
			TmpPirisPosition = inversePirisPostion(SmartSensorPirisValue);

			$("#iris_value").html("" + aIrisTbl[TmpPirisPosition-1]);
			
			$("#irisAdjustSlider").slider(
			{
				min: 1,
				max: aIrisTbl.length,
				animate: true,
				value: TmpPirisPosition,
				slide: function(event, ui)
				{
					uiVal = parseInt(ui.value);
					$("#iris_value").html("" + aIrisTbl[uiVal-1]);
				},
				change: function(event, ui)
				{
					if (uiVal == aIrisTbl.length)
					{
						SmartSensorPirisValue = 100;
					}
					else
					{
						SmartSensorPirisValue = Math.round(uiVal * jsCount_float_div(100.00, aIrisTbl.length));
					}
					//$("#irisAdjustSlider div.ui-slider-handle").attr("title", TmpPirisPosition);

					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_piris_position="+SmartSensorPirisValue,
						async: false,
						cache: false
					});
				}
			});
		}
		else
		{
			TmpPirisPosition = inversePirisPostion(parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_position"), 10));
			$("#irisAdjustSlider").slider(
				{
					min: 1,
					max: 100,
					animate: true,
					value: TmpPirisPosition,
					change: function(event, ui)
					{
						TmpPirisPosition= ui.value;
						$("#irisAdjustSlider div.ui-slider-handle").attr("title", TmpPirisPosition);

						$.ajax({
							type: "POST",
							url: "/cgi-bin/admin/setparam.cgi",
							data: "videoin_c"+giCH_Curr+gstrProfile+"_piris_position="+inversePirisPostion(TmpPirisPosition),
							async: false,
							cache: false
						});
					}
				});
		}
		
		$("#irisAdjustSlider div.ui-slider-handle").attr("title", TmpPirisPosition);
	}
	

	//Exposure time
	//2 cases: Min&Max range, Max only.
	if (bExpTimeMax && bExpTimeMin && (!gbIsSmartSensor))
	{
		checkMinMaxExposure();
		
		TmpExpTimeMax = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure"), 10);
		TmpExpTimeMin = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_minexposure"), 10);
		if (bPAL50)
		{
			TmpExpTimeMax = doPAL50Transfer(TmpExpTimeMax);
			TmpExpTimeMin = doPAL50Transfer(TmpExpTimeMin);
		}
		else
		{
			TmpExpTimeMax = doNTSC60Transfer(TmpExpTimeMax);
			TmpExpTimeMin = doNTSC60Transfer(TmpExpTimeMin);
		}

		$("#exposureTimeValue").html("1/"+TmpExpTimeMin+" - 1/"+TmpExpTimeMax);
		$("#exposureTimeSlider").slider(
		{
			min: 0,
			max: gExpTimeLevel - 1,
			animate: true,
			range: true,
			values: [getExpTimeSlideIdx(TmpExpTimeMin), getExpTimeSlideIdx(TmpExpTimeMax)],
			slide: function(event, ui)
			{
				//only block expTimeMinRangeUpBound 
				expTimeMinRangeUpBound = eval("capability_image_c"+giCH_Curr+"_exposure_minrange").split(",")[0];
				bMinrangeIs60hz = checkExpTimeInNTSC60Range(expTimeMinRangeUpBound);
				bMinrangeIs50hz = checkExpTimeInPAL50Range(expTimeMinRangeUpBound);
				if (bMinrangeIs60hz && bPAL50)
				{
					expTimeMinRangeUpBound = doPAL50Transfer(expTimeMinRangeUpBound);
				}
				if (bMinrangeIs50hz && !bPAL50)
				{
					expTimeMinRangeUpBound = doNTSC60Transfer(expTimeMinRangeUpBound);
				}
				
				if ( getExpTimeSlideIdx(expTimeMinRangeUpBound) < ui.values[0] )
				{
					$(this).slider("values", 0, getExpTimeSlideIdx(expTimeMinRangeUpBound));
					return false;
				}
				
				$("#exposureTimeValue").html("1/"+getExpTimeSlideValue(ui.values[0])+" - 1/"+getExpTimeSlideValue(ui.values[1]));
			},
			change: function(event, ui)
			{
				TmpExpTimeMin = getExpTimeSlideValue(ui.values[0]);
				TmpExpTimeMax = getExpTimeSlideValue(ui.values[1]);

				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "videoin_c"+giCH_Curr+gstrProfile+"_minexposure="+TmpExpTimeMin+"&videoin_c"+giCH_Curr+gstrProfile+"_maxexposure="+TmpExpTimeMax,
					async: false,
					cache: false
				});
			}
		});

		$("#exposureTimeSlider .ui-slider-handle").eq(0).css("background", "transparent url(/pic/slidericon_left.png)");
		$("#exposureTimeSlider .ui-slider-handle").eq(1).css("background", "transparent url(/pic/slidericon_right.png)");
	}
	else if (bExpTimeMax)
	{
		if (eRangeType == "ONEVALUE")
		{
			TmpExpTimeMax = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_shuttervalue"), 10);
		}	
		else if (eRangeType == "TWOVALUE")
		{
			TmpExpTimeMax = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure"), 10);
		}

		if (bPAL50)
		{
			TmpExpTimeMax = doPAL50Transfer(TmpExpTimeMax);
		}
		else
		{
			TmpExpTimeMax = doNTSC60Transfer(TmpExpTimeMax);
		}

		$("#exposureTimeValue").html("1/"+TmpExpTimeMax);
		$("#exposureTimeSlider").slider(
		{
			min: 0,
			max: gExpTimeLevel - 1,
			animate: true,
			value: getExpTimeSlideIdx(TmpExpTimeMax),
			slide: function(event, ui)
			{
				$("#exposureTimeValue").html("1/"+getExpTimeSlideValue(ui.value));
			},
			change: function(event, ui)
			{
				TmpExpTimeMax = getExpTimeSlideValue(ui.value);
				
				if (eRangeType == "ONEVALUE")
				{
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_shuttervalue="+TmpExpTimeMax,
						async: false,
						cache: false
					});
				}
				else if (eRangeType == "TWOVALUE")
				{
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_maxexposure="+TmpExpTimeMax,
						async: false,
						cache: false
					});
				}
			}
		});
	}

	if (bFlickerless)
	{
		TmpFlickerless = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_flickerless"), 10);


		if (1 == TmpFlickerless)
		{
			document.getElementById("flickerlessInput").checked = true;
			SwitchFlickerlessUI(true);
		}
		else
		{
			document.getElementById("flickerlessInput").checked = false;
			SwitchFlickerlessUI(false);
		}

	}


	//Gain contgrol
	//2 cases: Min&Max gain, Max gain only.
	if (bGainMax && bGainMin && (!gbIsSmartSensor))
	{
		checkMinMaxGain();
		
		TmpGainMax = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain"), 10);
		TmpGainMin = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_mingain"), 10);

		$("#gainValue").html(""+TmpGainMin+" - "+TmpGainMax+" %");
		$("#gainSlider").slider(
		{
			min: gGainMinValue,
			max: gGainMaxValue,
			animate: true,
			range: true,
			values: [TmpGainMin, TmpGainMax],
			slide: function(event, ui)
			{
				$("#gainValue").html(""+ui.values[0]+" - "+ui.values[1]+" %");
			},
			change: function(event, ui)
			{
				TmpGainMin = ui.values[0];
				TmpGainMax = ui.values[1];

				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "videoin_c"+giCH_Curr+gstrProfile+"_mingain="+TmpGainMin+"&videoin_c"+giCH_Curr+gstrProfile+"_maxgain="+TmpGainMax,
					async: false,
					cache: false
				});
			}
		});

		$("#gainSlider .ui-slider-handle").eq(0).css("background", "transparent url(/pic/slidericon_left.png)");
		$("#gainSlider .ui-slider-handle").eq(1).css("background", "transparent url(/pic/slidericon_right.png)");
	}
	else if (bGainMax)
	{
		if (eRangeType == "ONEVALUE")
		{
			TmpGainMax = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_gainvalue"), 10);
		}
		else if (eRangeType == "TWOVALUE")
		{
			TmpGainMax = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain"), 10);
		}

		$("#gainValue").html(""+TmpGainMax+" %");
		$("#gainSlider").slider(
		{
			min: gGainMinValue,
			max: gGainMaxValue,
			animate: true,
			value: TmpGainMax,
			slide: function(event, ui)
			{
				$("#gainValue").html(""+ui.value+" %");
			},
			change: function(event, ui)
			{
				TmpGainMax = ui.value;

				if (eRangeType == "ONEVALUE")
				{
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_gainvalue="+TmpGainMax,
						async: false,
						cache: false
					});
				}
				else if (eRangeType == "TWOVALUE")
				{
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_maxgain="+TmpGainMax,
						async: false,
						cache: false
					});
				}
			}
		});
	}

	if (bAESpeedAdjust)
	{
		TmpAESpeedMode = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_mode"), 10);
		if (TmpAESpeedMode == 1)
		{
			document.getElementById("aespeed_enable").checked = true;
			$("#tr_aespeed_speedlevel").show();
			$("#tr_aespeed_sensitivity").show();
		}
		else
		{
			document.getElementById("aespeed_enable").checked = false;
			$("#tr_aespeed_speedlevel").hide();
			$("#tr_aespeed_sensitivity").hide();
		}

		//speedlevel adjustment
		TmpAESpeedLevel = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_speedlevel"), 10);

		$("#speedlevel_adjust_slider_handle" ).slider({
			min: 20,
			max: 100,
			step: 20,
			animate: true,
			value: TmpAESpeedLevel,
			slide: function(event, ui)
			{
				//$("#speedlevel_adjust_fix").html(ui.value);
			},
			change: function(event, ui)
			{
				TmpAESpeedLevel = ui.value;

				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "videoin_c"+giCH_Curr+gstrProfile+"_aespeed_speedlevel="+TmpAESpeedLevel,
					async: false,
					cache: false
				});
			}	
		});
		
		//sensitivity adjustment
		if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_aespeedsupportsensitivity"))
		{
			TmpAESpeedSensitivity = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_sensitivity"), 10);

			$("#sensitivity_adjust_slider_handle" ).slider({
				min: 20,
				max: 100,
				step: 20,
				animate: true,
				value: TmpAESpeedSensitivity,
				slide: function(event, ui)
				{
					//$("#sensitivity_adjust_fix").html(ui.value);
				},
				change: function(event, ui)
				{
					TmpAESpeedSensitivity = ui.value;

					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_aespeed_sensitivity="+TmpAESpeedSensitivity,
						async: false,
						cache: false
					});
				}	
			});
		}
	}

	//Generate WDR/WDRC elements before switching UI and setting value.
	if (bWDRPro && bWDRStr)
	{
		// WDR:wait for the spec
		$("#wdrpro_adjust_slider_handle" ).slider({
			min: 1,
			max: 100,
			step: TmpWDRStep,
			animate: true,
			slide: function(event, ui)
			{
				//$("#speedlevel_adjust_fix").html(ui.value);
			},
			change: function(event, ui)
			{
				TmpWDRStr = ui.value;
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_strength="+TmpWDRStr,
					async: false,
					cache: false
				});
			}
		});
	}
	if (bWDREnhanced && bWDRCStr)
	{
		// WDR:wait for the spec
		$("#wdrc_adjust_slider_handle" ).slider({
			min: 1,
			max: 100,
			step: TmpWDRCStep,
			animate: true,
			slide: function(event, ui)
			{
				//$("#speedlevel_adjust_fix").html(ui.value);
			},
			change: function(event, ui)
			{
				TmpWDRCStr = ui.value;
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrc_strength="+TmpWDRCStr,
					async: false,
					cache: false
				});
			}	
		});
	}

	//WDR Pro
	if (bWDRPro)
	{
		TmpWDRMode = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_mode"), 10);
		if (1 == TmpWDRMode)
		{
			document.getElementById("wdr_enable").checked = true;
			if (true == bWDRStr)
			{
				//document.getElementById("wdrc_strengthControl").style.display = "block";
				document.getElementById("wdrpro_strength_slider").style.display = "block";
			}
			else
			{
				//document.getElementById("wdrc_strengthControl").style.display = "none";
				document.getElementById("wdrpro_strength_slider").style.display = "none";
			}

			switchWDRUI(true, false);
		}
		else
		{
			document.getElementById("wdr_enable").checked = false;
			//document.getElementById("wdrc_strengthControl").style.display = "none";
			document.getElementById("wdrpro_strength_slider").style.display = "none";

			switchWDRUI(false, false);
		}


		if (bWDRStr)
		{
			TmpWDRStr = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_strength"), 10);
			
			var WDRStrUI = mappingStrengthUI(TmpWDRStr, TmpWDRSupportLevel, TmpWDRStep);

			$(document.getElementById("wdr_strengthSelect")).children().each(
				function()
				{
					if (this.value == TmpWDRStr)
					{	
						this.selected = true;
					}
				}
			);

			$('#wdrpro_adjust_slider_handle').slider('value', WDRStrUI);
		}
	}

	//WDR enhanced
	if (bWDREnhanced)
	{
		TmpWDRCMode = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode"), 10);
		if (2 == TmpWDRCMode)
		{
			TmpWDRCMode_odd = true;
		}
		else
		{
			TmpWDRCMode_odd = false;
		}

		if (1 == TmpWDRCMode || 2 == TmpWDRCMode)
		{
			document.getElementById("wdrc_enable").checked = true;
			document.getElementById("wdrc_sensitivity").style.display = "none";
			//document.getElementById("wdrc_strengthControl").style.display = "block";
			document.getElementById("wdrc_strength_slider").style.display = "block";

			$(document.getElementById("wdrc_sensitivitySelect")).children().each(
				function()
				{
					if (this.value == TmpWDRCMode)
					{	
						this.selected = true;
					}
				}
			);
		}
		else
		{
			document.getElementById("wdrc_enable").checked = false;
			document.getElementById("wdrc_sensitivity").style.display = "none";
			//document.getElementById("wdrc_strengthControl").style.display = "none";
			document.getElementById("wdrc_strength_slider").style.display = "none";
		}

		if (bWDRCOnContrastUnchanged)
		{
			if (0 == TmpWDRCMode)
			{
				//warning messages
				//waiting for the spec
			}
			else
			{
				//warning messages
				//waiting for the spec
			}
		}

		if (bWDRCStr)
		{
			TmpWDRCStr = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_strength"), 10);

			WDRCStrUI = mappingStrengthUI(TmpWDRCStr, TmpWDRCSupportLevel, TmpWDRCStep);

			$(document.getElementById("wdrc_strengthSelect")).children().each(
				function()
				{
					if (this.value == TmpWDRStr)
					{	
						this.selected = true;
					}
				}
			);

			$('#wdrc_adjust_slider_handle').slider('value', WDRCStrUI);
		}
		
		if (bDefog)
		{
			if (bDefogOnWDRCUnchanged)
			{
				$("#wdrc_enable").attr('disabled','disabled');
				$("#wdrc_adjust_slider_handle").slider("disable");
			}
		}
		else
		{
			if (bDefogOnWDRCUnchanged)
			{
				$("#wdrc_enable").removeAttr('disabled');
				$("#wdrc_adjust_slider_handle").slider("enable");
			}
		}
	}
	
	if (bDayNight)
	{
		checkDayNightRelatedFeatures();
	}

	/*--------------------------------------------------------------*/
	// Warning!!
	// Check your spec if the affect of your functionality priority is higher than Scene mode.
	// Scene mode affect has higher priority than WDR pro and Flickerless.
	/*-------------------Start scene mode affect--------------------*/
	if (bSceneModeOnWdrproUnchanged)
	{
		document.getElementById("wdrpro_content").disabled = "disabled";
		document.getElementById("wdr_strengthSelect").disabled = "disabled";
		document.getElementById("wdrpro_adjust_slider_handle").disabled = "disabled";
	}
	
	if (bSceneModeOnFlickerlessHidden)
	{
		document.getElementById("flickerlessControl").style.display = "none";
	}
	
	if(bSceneModeOnFlickerlessUnchanged)
	{
		document.getElementById("flickerlessControl").disabled = "disabled";
	}
	/*------------------End scene mode affect-----------------------*/
}

function swtichExposureLevelRange(WDR, resetexplevel)
{
	$(document.getElementById("exposurelevelSelect")).removeOption(/./);
	var s = $("select[id=exposurelevelSelect]");

	if (WDR == 'WDROn')
	{
		if (bIsEVTable == true)
		{
			if (bWDROnLevelFixed == true)
			{
				var iTmp = gWDROnLevelFixValue.split("/");

				iTmp.sort(function(a,b){return a-b});

				for (i = (iTmp.length - 1); i >= 0; i--)
				{
					$(document.getElementById("exposurelevelSelect")).addOption(aExposureLevelEVTbl[iTmp[i]][0], aExposureLevelEVTbl[iTmp[i]][1], false);
				}
			}
			else if (bWDROnLevelRanged == true)
			{
				for (i = gWDROnLevelRangeMax; i >= gWDROnLevelRangeMin; i--)
				{
					$(document.getElementById("exposurelevelSelect")).addOption(aExposureLevelEVTbl[i][0], aExposureLevelEVTbl[i][1], false);
				}
			}
		}
		else
		{
			for (i = gWDROnLevelRangeMax; i >= gWDROnLevelRangeMin; i--)
			{
				$(document.getElementById("exposurelevelSelect")).addOption(i, i, false);
			}
		}
	}
	else
	{
		if (bIsEVTable == true)
		{
			for (i = (aExposureLevelEVTbl.length - 1); i >= 0; i--)
			{
				$(document.getElementById("exposurelevelSelect")).addOption(aExposureLevelEVTbl[i][0], aExposureLevelEVTbl[i][1], false);
			}
		}
		else
		{
			iTmp = eval("capability_image_c"+giCH_Curr+"_exposure_levelrange").split(",")[1];
			for (i = iTmp; i >= 0; i--)
			{
				$(document.getElementById("exposurelevelSelect")).addOption(i, i, false);
			}
		}
	}

	if (resetexplevel)
	{
		if (bIsWDROnLevelSingleFixValue == true)
		{
			s.val(TmpExpLevel).trigger("change");
		}
		else
		{
			s.val(DEFAULT_EXPLV).trigger("change");
		}
	}
	else
	{
		s.val(TmpExpLevel);
	}
}

function switchAESPEEDMode(AESPEEDOn)
{
	if (true == AESPEEDOn) 
	{
		TmpAESpeedMode = 1;
		$("#tr_aespeed_speedlevel").show();
		$("#tr_aespeed_sensitivity").show();
	}
	else
	{
		TmpAESpeedMode = 0;
		$("#tr_aespeed_speedlevel").hide();
		$("#tr_aespeed_sensitivity").hide();
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_aespeed_mode=" + TmpAESpeedMode,
		async: false,
		cache: false
	});

}

function changeWDRCMode(checked)
{
	if (false == checked)
	{
		TmpWDRCMode = 0;

		if (bWDRCOnContrastUnchanged)
		{
			//warning messages
			//waiting for the spec
		}

		document.getElementById("wdrc_sensitivity").style.display = "none";
		//document.getElementById("wdrc_strengthControl").style.display = "none";
		document.getElementById("wdrc_strength_slider").style.display = "none";
	}
	else
	{
		if (bWDREnhanced && TmpWDRCMode_odd == true)
		{
			TmpWDRCMode = 2;
		}
		else
		{
			TmpWDRCMode = 1;
		}

		if (bWDRCOnContrastUnchanged)
		{
			//warning messages
			//waiting for the spec
		}

		document.getElementById("wdrc_sensitivity").style.display = "none";
		//document.getElementById("wdrc_strengthControl").style.display = "block";
		document.getElementById("wdrc_strength_slider").style.display = "block";
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode="+TmpWDRCMode,
		cache: false
	});
}

function changeWDRCSensitivity(mode)
{
	TmpWDRCMode = mode;

	if (2 == parseInt(TmpWDRCMode, 10))
	{
		TmpWDRCMode_odd = true;
	}
	else
	{
		TmpWDRMode_odd = false;
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode="+TmpWDRCMode,
		cache: false
	});
}

function setWDRCStr(str)
{
	TmpWDRCStr = str;
	
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrc_strength="+TmpWDRCStr,
		cache: false
	});
}

function changeWDRMode(WDROn)
{
	if (false == switchWDRUI_MsgCheck(WDROn))
	{
		if (true == WDROn)
		{
			document.getElementById("wdr_enable").checked = false;
		}
		else
		{
			document.getElementById("wdr_enable").checked = true;
		}
		return;
	}
	
	if (WDROn)
	{
		TmpWDRMode = 1;
		
		if (bWDROnWDRCEnabled || bWDROnWDRCEnabledOnlyOnce || bWDROnWDRCEnabledAlways)
		{
			$("#wdrc_enable").attr("checked",true).triggerHandler("click");
		}
	}
	else
	{
		TmpWDRMode = 0;
		
		if (bWDROnWDRCEnabledOnlyOnce)
		{
			$("#wdrc_enable").attr("checked",false).triggerHandler("click");		
		}
		if (bWDROnWDRCEnabledAlways)
		{
			$("#wdrc_enable").attr("checked",true).triggerHandler("click");	
		}
	}

	// the 2nd true is for setting exposure level to 0
	/* when wdr switch to enable need to resetexplevel,
	 * wdr switch to disable then keep old explevel,
	 * so switchWDRUI 2nd parameter will control by WDROn */
	switchWDRUI(WDROn, WDROn);

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_mode="+TmpWDRMode,
		async: false,
		cache: false
	});
}

function switchWDRUI(WDROn, resetexplevel)
{
	if (WDROn)
	{
		TmpWDRMode = 1;

		if (true == bWDRStr)
		{
			//document.getElementById("wdrc_strengthControl").style.display = "block";
			document.getElementById("wdrpro_strength_slider").style.display = "block";
		}

		if (bWDROnExposurewinFixedAuto && bExpWin)
		{
			TmpExpWinMode = "auto"; 
			if ($("input[class=expWin]:checked").attr('id') != "expWinModeAuto") 
			{
				$("input[class=expWin][id=expWinModeAuto]").attr("checked","true").trigger("click");
			}
			document.getElementById("expWinModeAuto").disabled = "disabled";
			document.getElementById("expWinModeCustom").disabled = "disabled";
			document.getElementById("expWinModeBlc").disabled = "disabled";
			document.getElementById("expWinModeHlc").disabled = "disabled";
		}

		if (bWDROnExposurewinBlcDisabled && bExpWin)
		{
			if ($("input[class=expWin]:checked").attr('id') == "expWinModeBlc")
			{
				TmpExpWinMode = "auto"; 
				$("input[class=expWin][id=expWinModeAuto]").attr("checked","true").trigger("click");
			}
			document.getElementById("expWinModeBlc").disabled = "disabled";
		}

		if (bWDROnExposurewinBlcHidden && bExpWin)
		{
			if (false == bAEImpactExposurewinBlcHidden) //WDR and AE mode both own the blc affect rule.
			{
				if (true == document.getElementById("expWinModeBlc").checked)
				{
					changeExpWinMode('auto');
				}
				document.getElementById("expWinModeBlc").style.display = "none";
				document.getElementById("expWinModeBlcName").style.display = "none";
			}
		}
		
		if (bWDROnExposurewinHlcHidden && bExpWin)
		{
			if (true == document.getElementById("expWinModeHlc").checked)
			{
				changeExpWinMode('auto');
			}
			document.getElementById("expWinModeHlc").style.display = "none";
			document.getElementById("expWinModeHlcName").style.display = "none";
		}	

		if (bWDROnLevelHidden && bExpLevel)
		{
			document.getElementById("exposurelevelControl").style.display = "none";
		}

		if (bWDROnLevelFixed && bExpLevel)
		{
			$(document.getElementById("exposurelevelSelect")).children().each(
				function()
				{
					if (gWDROnLevelFixValue == this.value)
					{	
						this.selected = true;
					}
				}
			);
			//TmpExpLevel = gWDROnLevelFixValue;
			
			if (bIsWDROnLevelSingleFixValue == true)
			{
				document.getElementById("exposurelevelSelect").disabled = "disabled";
				TmpExpLevel = gWDROnLevelFixValue;
			}
			else
			{
				document.getElementById("exposurelevelSelect").disabled = "";
			}
		}

		if ((bWDROnLevelRanged || bWDROnLevelFixed) && bExpLevel)
		{
			swtichExposureLevelRange('WDROn', resetexplevel);
		}

		if (bWDROnIrismodeHidden)
		{
			if ("dciris" == eval("capability_image_c"+giCH_Curr+"_iristype"))
			{
				$(".dciris").css("display", "none");
			}
		}

		if (bWDROnFlickerlessUnchanged)
		{
			document.getElementById("flickerlessInput").disabled = "disabled";
		}

		if (bWDROnExpTimeHidden && !bSceneModeOnDefaultMaxexposure )
		{
			document.getElementById("exposureTimeControl").style.display = "none";
		}

		if (bWDROnGainHidden && !bSceneModeOnDefaultMaxgain)
		{
			document.getElementById("gainControl").style.display = "none";
		}

		if (bWDROnExposuremodeFixedAuto)
		{
			if ($("#exposure_mode").val() != "auto")
			{
				$("#exposure_mode").val("auto").trigger("change");
			}
			$("#exposure_mode").attr("disabled", "true");
		}

		if (bWDROnAESpeedDisabled)
		{
			if ($("#aespeed_enable").is(":checked"))
			{
				$("#aespeed_enable").attr("checked",false).triggerHandler("click");
				//document.getElementById("aespeed_enable").checked = false;
				//switchAESPEEDMode(false);
			}
			$("#aespeed_enable").attr('disabled','disabled');
			//document.getElementById("aespeed_enable").disabled = "disabled";
		}

		if (bWDROnAESpeedUnchanged)
		{
			$("#aespeed_enable").attr('disabled','disabled');
			$("#speedlevel_adjust_slider_handle").slider("disable");
			$("#sensitivity_adjust_slider_handle").slider("disable");
		}
		
		if (bWDROnWDRCEnabled || bWDROnWDRCEnabledOnlyOnce || bWDROnWDRCEnabledAlways)
		{
			if ($("#wdrc_enable").is(":checked") == false)
			{
				if (bDefogOnWDRCUnchanged && bDefog)
				{
					$("#wdrc_enable").attr('disabled','disabled');
					$("#wdrc_adjust_slider_handle").slider("disable");
				}
				else
				{
					$("#wdrc_adjust_slider_handle").slider("enable");
				}
			}
		}

		if (bWDROnWDRCUnchanged)
		{
			$("#wdrc_enable").attr('disabled','disabled');
			$("#wdrc_adjust_slider_handle").slider("disable");
		}
	}
	else
	{
		TmpWDRMode = 0;

		if (true == bWDRStr)
		{
			//document.getElementById("wdrc_strengthControl").style.display = "none";
			document.getElementById("wdrpro_strength_slider").style.display = "none";
		}

		if (bWDROnLevelHidden && bExpLevel)
		{
			document.getElementById("exposurelevelControl").style.display = "block";
		}

		if (bWDROnLevelFixed && bExpLevel)
		{
			document.getElementById("exposurelevelSelect").disabled = "";
		}

		if (bWDROnExposurewinFixedAuto && bExpWin)
		{
			document.getElementById("expWinModeAuto").disabled = "";
			document.getElementById("expWinModeCustom").disabled = "";
			document.getElementById("expWinModeBlc").disabled = "";
			document.getElementById("expWinModeHlc").disabled = "";
		}

		if (bWDROnExposurewinBlcDisabled && bExpWin)
		{
			document.getElementById("expWinModeBlc").disabled = "";
		}

		if (bWDROnExposurewinBlcHidden && bExpWin)
		{
			if (false == bAEImpactExposurewinBlcHidden) //WDR and AE mode both own the blc affect rule.
			{
				document.getElementById("expWinModeBlc").style.display = "inline";
				document.getElementById("expWinModeBlcName").style.display = "inline";
			}
		}
		
		if (bWDROnExposurewinHlcHidden && bExpWin)
		{
			document.getElementById("expWinModeHlc").style.display = "inline";
			document.getElementById("expWinModeHlcName").style.display = "inline";
		}

		if ((bWDROnLevelRanged || bWDROnLevelFixed) && bExpLevel)
		{
			swtichExposureLevelRange('WDROff', resetexplevel);
		}

		if (bWDROnIrismodeHidden)
		{
			if ("dciris" == eval("capability_image_c"+giCH_Curr+"_iristype"))
			{
				$(".dciris").css("display", "block");
			}
		}

		if (bWDROnFlickerlessUnchanged)
		{
			document.getElementById("flickerlessInput").disabled = "";
		}

		if (bWDROnExpTimeHidden)
		{
			document.getElementById("exposureTimeControl").style.display = "block";
		}

		if (bWDROnGainHidden)
		{
			document.getElementById("gainControl").style.display = "block";
		}

		if (bWDROnLevelFixed && bExpLevel)
		{
			$(document.getElementById("exposurelevelSelect")).children().each(
				function()
				{
					if (TmpExpLevel == this.value)
					{	
						this.selected = true;
					}
				}
			);
		}

		if (bWDROnExposuremodeFixedAuto)
		{
			$("#exposure_mode").removeAttr("disabled");
		}

		if (bWDROnAESpeedDisabled)
		{
			$("#aespeed_enable").removeAttr('disabled');
		}

		if (bWDROnAESpeedUnchanged)
		{
			$("#aespeed_enable").removeAttr('disabled');
			$("#speedlevel_adjust_slider_handle").slider("enable");
			$("#sensitivity_adjust_slider_handle").slider("enable");
		}
	
		if (bWDROnWDRCUnchanged)
		{
			if (bDefogOnWDRCUnchanged && bDefog)
			{
				if (bAEImpactDefogDisabled)
				{
					$("#wdrc_enable").removeAttr('disabled');
					$("#wdrc_adjust_slider_handle").slider("enable");
				}
				else
				{
					$("#wdrc_enable").attr('disabled','disabled');
					$("#wdrc_adjust_slider_handle").slider("disable");
				}
			}
			else
			{
				$("#wdrc_enable").removeAttr('disabled');
				$("#wdrc_adjust_slider_handle").slider("enable");
			}
		}
	}
}


function setWDRStr(str)
{
	TmpWDRStr = str;
	
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_strength="+TmpWDRStr,
		async: false,
		cache: false
	});
}


function RestoreSettingAPI()
{
	var restoreParams ="";
	
	if (giProfileIdx == 0 && bExitNormalLight)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+"_profile_i0_enable=" + eval("videoin_c"+giCH_Curr+"_profile_i0_enable") + "&";
	}
	
	if (giProfileIdx == 1 && bExitProfile)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+"_profile_i0_enable=" + eval("videoin_c"+giCH_Curr+"_profile_i0_enable") + "&";
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+"_profile_i0_policy=" + eval("videoin_c"+giCH_Curr+"_profile_i0_policy") + "&";
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+"_profile_i0_begintime=" + eval("videoin_c"+giCH_Curr+"_profile_i0_begintime") + "&";
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+"_profile_i0_endtime=" + eval("videoin_c"+giCH_Curr+"_profile_i0_endtime") + "&";
	}

	if (bExpMode)
	{
		if (bExpWin)
		{
			restoreParams = restoreParams +"exposurewin_c"+giCH_Curr+gstrProfile+"_mode="+eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode") +"&";
		}
		
		if (bExpModeType)
		{
			restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_exposuremode="+eval("videoin_c"+giCH_Curr+gstrProfile+"_exposuremode")+"&";
		}

		if (bAEImpactDefogDisabled)
		{
			restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_defog_mode="+eval("image_c"+giCH_Curr+gstrProfile+"_defog_mode")+"&";
		}
		
		if (bForceICRtoDayMode)
		{
			restoreParams = restoreParams + "ircutcontrol_mode="+eval("ircutcontrol_mode")+"&";
		}
	}

	if (bExpLevel)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_exposurelevel="+eval("videoin_c"+giCH_Curr+gstrProfile+"_exposurelevel")+"&";
	}

	if (bFlickerless)
	{
		restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_flickerless="+eval("videoin_c"+giCH_Curr+gstrProfile+"_flickerless")+"&";
	}

	if (eRangeType == "TWOVALUE")
	{
		if (bExpTimeMax)
		{
			restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_maxexposure="+eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure")+"&";
		}

		if (bExpTimeMin)
		{
			restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_minexposure="+eval("videoin_c"+giCH_Curr+gstrProfile+"_minexposure")+"&";
		}

		if (bGainMax)
		{
			restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_maxgain="+eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain")+"&";
		}

		if (bGainMin)
		{
			restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_mingain="+eval("videoin_c"+giCH_Curr+gstrProfile+"_mingain")+"&";
		}
	}
	else if (eRangeType == "ONEVALUE")
	{
		restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_shuttervalue="+eval("videoin_c"+giCH_Curr+gstrProfile+"_shuttervalue")+"&";
		restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_gainvalue="+eval("videoin_c"+giCH_Curr+gstrProfile+"_gainvalue")+"&";
	}

	if (bAESpeedAdjust)
	{
		restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_aespeed_mode="+eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_mode")+"&";
		restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_aespeed_speedlevel="+eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_speedlevel")+"&";
		if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_aespeedsupportsensitivity"))
		{
			restoreParams = restoreParams +"videoin_c"+giCH_Curr+gstrProfile+"_aespeed_sensitivity="+eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_sensitivity")+"&";
		}
	}

	if (bWDRPro == true)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_mode="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_mode") + "&";
	}

	if (bWDRStr)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_strength="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_strength") + "&";
	}

	if (bWDREnhanced == true)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode") + "&";
	}
	
	if (bWDRCStr)
	{
		restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_wdrc_strength="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_strength") + "&";
	}

	// if the value of "videoin_c0_piris_mode" parameter is "-"
	if (gbIsSmartSensor)
	{
		if (eIrisType == "PIRIS")
		{
			restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_piris_position="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_position") + "&";
		}
	}
	else
	{
		if (eIrisType == "PIRIS")
		{
			restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_piris_mode="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_mode") + "&";
			restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_piris_position="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_position") + "&";
		}
		else if(eIrisType =="DCIRIS")
		{
			restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_irismode="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_irismode") + "&";
		}
	}

	if (bDayNight)
	{
		restoreParams = restoreParams + "ircutcontrol_mode="+ eval("ircutcontrol_mode") + "&";
		restoreParams = restoreParams + "ircutcontrol_daymodebegintime="+ eval("ircutcontrol_daymodebegintime") + "&";
		restoreParams = restoreParams + "ircutcontrol_daymodeendtime="+ eval("ircutcontrol_daymodeendtime") + "&";
		restoreParams = restoreParams + "ircutcontrol_bwmode="+ eval("ircutcontrol_bwmode") + "&";
		restoreParams = restoreParams + "ircutcontrol_sensitivity="+ eval("ircutcontrol_sensitivity") + "&";
		if (1 == eval("capability_daynight_c"+giCH_Curr+"_externalir"))
		{
			restoreParams = restoreParams + "ircutcontrol_enableextled="+ eval("ircutcontrol_enableextled") + "&";
		}
		if (1 == eval("capability_daynight_c"+giCH_Curr+"_builtinir"))
		{
			restoreParams = restoreParams + "ircutcontrol_disableirled="+ eval("ircutcontrol_disableirled") + "&";
		}
		if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir"))
		{
			restoreParams = restoreParams + "ircutcontrol_sir="+ eval("ircutcontrol_sir") + "&";
		}
	}


	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: restoreParams,
		async: false,
		cache: false
	});

}

function SaveButton()
{
	if(checkvalue())
	{
		return -1;
	}
	
	if (giProfileIdx == 0)
	{
		eval("videoin_c"+giCH_Curr+"_profile_i0_enable='"+TmpNormalLightEnable+"'");
	}
	
	
	if (giProfileIdx == 1)
	{
		eval("videoin_c"+giCH_Curr+"_profile_i0_enable='"+TmpProfileEnable+"'");
		eval("videoin_c"+giCH_Curr+"_profile_i0_policy='"+TmpPolicy+"'");
		eval("videoin_c"+giCH_Curr+"_profile_i0_begintime='"+TmpBeginTime+"'");
		eval("videoin_c"+giCH_Curr+"_profile_i0_endtime='"+TmpEndTime+"'");
	}

	if (bExpMode)
	{
		if (bExpWin)
		{
			eval("exposurewin_c"+giCH_Curr+gstrProfile+"_mode='"+TmpExpWinMode+"'")
		}

		if (bExpModeType)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_exposuremode='"+TmpExposureMode+"'");
		}
		
		if (bAEImpactDefogDisabled)
		{
			eval("image_c"+giCH_Curr+gstrProfile+"_defog_mode='0'");
		}

		if (bForceICRtoDayMode)
		{
			eval("ircutcontrol_mode='day'");
		}
	}

	if (bExpLevel)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_exposurelevel='"+TmpExpLevel+"'");
	}

	if (bFlickerless)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_flickerless='"+TmpFlickerless+"'");
	}

	if (eRangeType == "TWOVALUE")
	{
		if (bExpTimeMax)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure='"+TmpExpTimeMax+"'");
		}

		if (bExpTimeMin)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_minexposure='"+TmpExpTimeMin+"'");
		}

		if (bGainMax)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain='"+TmpGainMax+"'");
		}

		if (bGainMin)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_mingain='"+TmpGainMin+"'");
		}
	}
	else if (eRangeType == "ONEVALUE")
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_shuttervalue='"+TmpExpTimeMax+"'");
		eval("videoin_c"+giCH_Curr+gstrProfile+"_gainvalue='"+TmpGainMax+"'");
	}

	if (bAESpeedAdjust)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_mode='"+TmpAESpeedMode+"'");
		eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_speedlevel='"+TmpAESpeedLevel+"'");
		if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_aespeedsupportsensitivity"))
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_aespeed_sensitivity='"+TmpAESpeedSensitivity+"'");
		}
	}

	if (bWDRPro == true)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_mode='"+TmpWDRMode+"'");
	}

	if (bWDRStr)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_strength='"+TmpWDRStr+"'");
	}

	if (bWDREnhanced == true)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode='"+TmpWDRCMode+"'");
	}

	if (bWDRCStr)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_strength='"+TmpWDRCStr+"'");
	}

	// if the value of "videoin_c0_piris_mode" parameter is "-"
	if (gbIsSmartSensor)
	{
		if (eIrisType == "PIRIS") 
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_position='"+SmartSensorPirisValue+"'");
		}
	}
	else
	{
		if (eIrisType == "PIRIS") 
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_position='"+inversePirisPostion(TmpPirisPosition)+"'");
			eval("videoin_c"+giCH_Curr+gstrProfile+"_piris_mode='"+TmpPirisMode+"'");
		}
		else if (eIrisType == "DCIRIS")
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_irismode='"+TmpIrisMode+"'");
		}
		else //fixediris
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_irismode='manual'");
		}
	}

	if (bDayNight)
	{
		eval("ircutcontrol_mode='"+TmpIrcutcontrolMode+"'");
		eval("ircutcontrol_bwmode='"+TmpBWmode+"'");
		eval("ircutcontrol_daymodebegintime='"+TmpDaymodebegintime+"'");
		eval("ircutcontrol_daymodeendtime='"+TmpDaymodeendtime+"'");
		eval("ircutcontrol_sensitivity='"+TmpIrcutcontrolsen+"'");

		if (1 == eval("capability_daynight_c"+giCH_Curr+"_externalir"))
		{
			eval("ircutcontrol_enableextled='"+TmpEnableextled+"'");
		}
		if (1 == eval("capability_daynight_c"+giCH_Curr+"_builtinir"))
		{
			eval("ircutcontrol_disableirled='"+TmpDisableirled+"'");
		}
		if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir"))
		{
			eval("ircutcontrol_sir='"+TmpSir+"'");
		}
	}

	RestoreSettingAPI();

	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "save";
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();
}

function RestoreButton()
{
	RestoreSettingUI();
	RestoreSettingAPI();

	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "restore";
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();

	changeExpWinMode(TmpExpWinMode);
}

function RestoreSetting()
{
	bExitNormalLight = true;
	bExitProfile = true;
	RestoreSettingAPI();
}

function ExposureWinAffectByWDR()
{

}

function inversePirisPostion(value)
{
	if (gbIsSmartSensor)
	{
		var unitstep = jsCount_float_div(100, aIrisTbl.length);
		for (i = 1; i <= aIrisTbl.length; i++)
		{
			if (value <= Math.round(jsCount_float_mul(unitstep, i)))
			{
				return i;
			}
			else if (i == aIrisTbl.length)
			{
				return (aIrisTbl.length);
			}
		}
	}
	else
	{
    		return (100 - value + 1);
	}
}

function switchAEMode(value)
{
	var data_str;
	TmpExposureMode = value;
	
	findAEImpact();

	if (gbIsSmartSensor)
	{
		// Jiunchen@20140122, EV_Series, The Defog / WDR only support exposure auto mode.
		if (preExpMode == "auto" && value != "auto")
		{
			if (bAEImpactDefogDisabled && bAEImpactWDRProDisabled)
			{
				if (bAEImpactAutoICRNotSupport)
				{
					if (value == "manual" && bICRMode)
					{
						if ("auto" == TmpICRMode)
						{
							if(!confirm(translator("icr_is_auto_mode_and_switch_to_exposure_non_auto_mode_warning_message")))
							{
								$("#exposure_mode").val("auto").change();
								return;
							}
							else
							{
								bForceICRtoDayMode = true;
							}
						}
						else
						{
							if(!confirm(translator("switch_to_exposure_non_auto_mode_warning_message")))
							{
								$("#exposure_mode").val("auto").change();
								return;
							}

						}
					}
				}
				else
				{
					if(!confirm(translator("switch_to_exposure_non_auto_mode_warning_message")))
					{
						$("#exposure_mode").val("auto").change();
						return;
					}
				}
			}
		}
		else if (preExpMode != "manual" && value == "manual")
		{
			if (bAEImpactAutoICRNotSupport)
			{
				if (bICRMode && ("auto" == TmpICRMode))
				{
					if(!confirm(translator("switch_icr_mode_to_daymode_warning_message")))
					{
						return;
					}
					else
					{
						bForceICRtoDayMode = true;
					}
				}
			}
		}
		preExpMode = value;
	}
	
	switch(value) 
	{
		case 'auto':
		case 'shutterpriority':
		case 'qualitypriority':
			if (gbIsSmartSensor)
			{
				$("#auto-mode").slideDown(function(){
					$(window.parent.document.getElementsByName("sensor")).height(parseInt($("body").height()) + 18);
				});
				$("#manual-mode").slideDown();
				$("#iris_adjustment").css("display", "none");
				$('#auto-mode').css("zoom", "1"); 
			}
			else
			{
				$("#auto-mode").slideDown(function(){
					$(window.parent.document.getElementsByName("sensor")).height(parseInt($("body").height()) + 18);
				});
				$("#manual-mode").hide();
				$('#auto-mode').css("zoom", "1"); 
				// indoor, outdoor should not set these parameters, imgproc library will handle by itself
			}
			break;

		case 'irispriority':
		case 'manual':
			if (gbIsSmartSensor)
			{
				$("#auto-mode").hide();
				$("#manual-mode").slideDown();
				$("#iris_adjustment").css("display", "block");
				$(window.parent.document.getElementsByName("sensor")).height(parseInt($("body").height()) + 208);
				$('#manual-mode').css("zoom", "1"); 
			}
			else
			{
				$("#auto-mode").hide();
				$("#manual-mode").slideDown();
				$(window.parent.document.getElementsByName("sensor")).height(parseInt($("body").height()) + 208);
				$('#manual-mode').css("zoom", "1"); 
			}
			break;
	}	

	if (bAEImpactDefaultGainValue)
	{
		$("#gainSlider").slider("value", giDefaultGainFixValue);
		$("#gainValue").html(""+ giDefaultGainFixValue +" %");
	}

	if (eRangeType == "ONEVALUE")
	{
		setNameofShutterandGainSilder(value);
	}
	
	//AE impact
	if (bAEImpactExposurewinBlcHidden && bExpWin)
	{
		if (true == document.getElementById("expWinModeBlc").checked)
		{
			changeExpWinMode('auto');
		}		
		document.getElementById("expWinModeBlc").style.display = "none";
		document.getElementById("expWinModeBlcName").style.display = "none";
	}
	else if (!bAEImpactExposurewinBlcHidden && bExpWin)
	{
		document.getElementById("expWinModeBlc").style.display = "inline";
		document.getElementById("expWinModeBlcName").style.display = "inline";
	}

	if (bAEImpactExposurewinHidden && bExpWin)
	{
		changeExpWinMode('auto');
		document.getElementById("expWinControl").style.display = "none";
	}
	else if (!bAEImpactExposurewinHidden && bExpWin)
	{
		document.getElementById("expWinControl").style.display = "block";
	}
	
	if (bAEImpactWDRProDisabled)
	{
		if ($("#wdr_enable").is(":checked"))
		{
			$("#wdr_enable").attr("checked",false).triggerHandler("click");
		}
		$("#wdr_enable").attr('disabled','disabled');
	}
	else
	{
		$("#wdr_enable").removeAttr('disabled');
	}

	if (bAEImpactLevelHidden && bExpLevel)
	{
		document.getElementById("exposurelevelControl").style.display = "none";
	}
	else if (!bAEImpactLevelHidden && bExpLevel)
	{
		document.getElementById("exposurelevelControl").style.display = "block";
	}


	if (!gbIsSmartSensor)
	{
		if (eIrisType == "PIRIS")
		{
			if( $("#exposure_mode").val() == "manual" )
			TmpPirisMode = "manual";
			else
			TmpPirisMode = $("#fake_videoin_c"+giCH_Curr+"_piris_mode").val();
			data_str = "videoin_c"+giCH_Curr+gstrProfile+"_piris_mode=" + TmpPirisMode;
		}
		else if(eIrisType == "DCIRIS") // DCIRIS
		{
			if( $("#exposure_mode").val() == "manual" )
			TmpIrisMode = "fixed";
			else
			TmpIrisMode = $("#fake_videoin_c"+giCH_Curr+"_irismode").val();
			data_str = "videoin_c"+giCH_Curr+gstrProfile+"_irismode=" + TmpIrisMode;
		}	
		else
		{
			data_str = "videoin_c"+giCH_Curr+gstrProfile+"_irismode=manual";
		}
		/*
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/setparam.cgi",
			data: data_str,
			async: false,
			cache: false
		});
		*/
	}
	else
	{
        	switch(value)
        	{
                	case 'auto':
				data_str = "videoin_c"+giCH_Curr+gstrProfile+"_exposuremode=auto";
				break;	
                	case 'shutterpriority':
				data_str = "videoin_c"+giCH_Curr+gstrProfile+"_exposuremode=shutterpriority";
				break;
                	case 'irispriority':
				data_str = "videoin_c"+giCH_Curr+gstrProfile+"_exposuremode=irispriority";
				break;
				case 'qualitypriority':
					data_str = "videoin_c"+giCH_Curr+gstrProfile+"_exposuremode=qualitypriority";
					break;
                	case 'manual':
				data_str = "videoin_c"+giCH_Curr+gstrProfile+"_exposuremode=manual";
				break;
        	}
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: data_str,
		async: false,
		cache: false
	});
}

function irisModePreview(value)
{
	var data_str;
	
	if(eIrisType == "PIRIS")
	{
		TmpPirisMode = ($("#exposure_mode").val() == "auto" ? value : "manual");
		data_str = "videoin_c"+giCH_Curr+gstrProfile+"_piris_mode=" + TmpPirisMode;
	}
	else // DCIRIS
	{
		TmpIrisMode = ($("#exposure_mode").val() == "auto" ? value : "fixed");
		data_str = "videoin_c"+giCH_Curr+gstrProfile+"_irismode=" + TmpIrisMode;
	}
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: data_str,
		async: false,
		cache: false
	});
}

function setIRCutBWMode(checked)
{
	if (false == checked)
	{
		TmpBWmode = 0;
	}
	else
	{
		TmpBWmode = 1;
	}
}

function setExtIR(checked)
{
	if (false == gEnableextled)
	{
		if (!confirm(translator("turn_on_extir_warning_message")))
		{
			document.getElementById("externalir").checked = false;
			return;
		}
	}
	gEnableextled = checked;

	if (true == checked)
	{
		TmpEnableextled = 1;
	}
	else
	{
		TmpEnableextled = 0;
	}
}

function checkSIRMode()
{
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir")) 
	{
		if (document.getElementById("irled_checkbox").checked || document.getElementById("externalir").checked)
		{
			$("#sirChild").slideDown("slow");
		}
		else
		{
			$("#sirChild").slideUp("slow");
		}
	}
}

function setDisableBuiltInIR(checked)
{
	//set the inverse value;
	if (true == checked)
	{
		TmpDisableirled = 0;
	}
	else
	{
		TmpDisableirled = 1;
	}
}

function setSIR(checked)
{
	if (true == checked)
	{
		TmpSir = 1;
	}
	else
	{
		TmpSir = 0;
	}
}

function checkDayNightMode(mode)
{
	if (mode == "auto")
	{
		$("#scheduleModeChild").slideUp("slow");
		$("#autoModeChild").slideDown("slow");
	}
	else if (mode == "schedule")
	{
		$("#scheduleModeChild").slideDown("slow");
		$("#autoModeChild").slideUp("slow");
	}
	else
	{
		$("#scheduleModeChild").slideUp("slow");
		$("#autoModeChild").slideUp("slow");
	}
}

function setDayNightMode(mode)
{
	TmpIrcutcontrolMode = mode;
}

function changeDayModeBeginTime(text)
{
	if (-1 == checkInString(text))
	{
		text.value = eval("ircutcontrol_daymodebegintime");
		return;
	}

	TmpDaymodebegintime = text.value;
}

function changeDayModeEndTime(text)
{
	if (-1 == checkInString(text))
	{
		text.value = eval("ircutcontrol_daymodeendtime");
		return;
	}

	TmpDaymodeendtime = text.value;
}

function setLightSensorSensitivity(level)
{
	TmpIrcutcontrolsen = level;
	setIRCutSensitivityPreview(level);
}

function setIRCutSensitivity(level)
{
	TmpIrcutcontrolsen = level;
	setIRCutSensitivityPreview(level);
}

function setIRCutSensitivityPreview(value)
{
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "ircutcontrol_sensitivity=" + value,
		async: false,
		cache: false
	});
}
	
function checkDayNightRelatedFeatures()
{
	//BW Mode
	TmpBWmode = eval("ircutcontrol_bwmode");
	if (ircutcontrol_bwmode == '1')
	{
		document.getElementById("bwmode").checked = 1;
	}
	else
	{
		document.getElementById("bwmode").checked = 0;
	}
	
	//External IR
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_externalir"))
	{
		document.getElementById("externalir_section").style.display = "block";

		gEnableextled = (ircutcontrol_enableextled == '1' ? true : false);
		TmpEnableextled = eval("ircutcontrol_enableextled");
		if (ircutcontrol_enableextled == '1')
		{
			document.getElementById("externalir").checked = 1;
		}
		else
		{
			document.getElementById("externalir").checked = 0;
		}
	}

	//Built-in IR
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_builtinir")) 
	{
		document.getElementById("builtinir_section").style.display = "block";

		TmpDisableirled = eval("ircutcontrol_disableirled");
		if (ircutcontrol_disableirled == '1')
		{
			document.getElementById("irled_checkbox").checked = 0;
		}
		else
		{
			document.getElementById("irled_checkbox").checked = 1;
		}
	}

	// Smart IR
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_smartir")) 
	{
		TmpSir = eval("ircutcontrol_sir");
		if (ircutcontrol_sir == '1')
		{
			document.getElementById("sir").checked = 1;
		}
		else
		{
			document.getElementById("sir").checked = 0;
		}
		checkSIRMode();
	}

	// IRCut Filter
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_ircutfilter")) 
	{
		TmpIrcutcontrolMode = eval("ircutcontrol_mode");
		$(document.getElementById("dayNightMode")).children().each(
			function()
			{
				if (eval("ircutcontrol_mode") == this.value)
				{	
					this.selected = true;
				}
			}
		);
		checkDayNightMode(eval("ircutcontrol_mode"));
		document.getElementById("daymodebegintime").value = eval("ircutcontrol_daymodebegintime");
		document.getElementById("daymodeendtime").value   = eval("ircutcontrol_daymodeendtime");
	}

	// Light senor
	if (1 == eval("capability_daynight_c"+giCH_Curr+"_lightsensor")) 
	{
		TmpIrcutcontrolsen = eval("ircutcontrol_sensitivity");
		$(document.getElementById("lightSensorSensitivity")).children().each(
			function()
			{
				if (eval("ircutcontrol_sensitivity") == this.value)
				{	
					this.selected = true;
				}
			}
		);
		document.getElementById("lightSensorSensitivity_section").style.display = "block";
	}
	else
	{
		TmpIrcutcontrolsen = eval("ircutcontrol_sensitivity");
		$(document.getElementById("ircutSensitivity")).children().each(
			function()
			{
				if (eval("ircutcontrol_sensitivity") == this.value)
				{	
					this.selected = true;
				}
			}
		);
		document.getElementById("IRCutSensitivity_section").style.display = "block";
	}
}

function checkMinMaxExposure()
{
	var maxvalue = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure"), 10);
	var minvalue = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_minexposure"), 10);
	if (maxvalue > minvalue) //exposure time is inverse number
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_minexposure='"+maxvalue+"'");
		
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/setparam.cgi",
			data: "videoin_c"+giCH_Curr+gstrProfile+"_minexposure=" + maxvalue,
			async: false,
			cache: false
		});
	}
}

function checkMinMaxGain()
{
	var maxvalue = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain"), 10);
	var minvalue = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_mingain"), 10);
	if (maxvalue < minvalue)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_mingain='"+maxvalue+"'");
		
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/setparam.cgi",
			data: "videoin_c"+giCH_Curr+gstrProfile+"_mingain=" + maxvalue,
			async: false,
			cache: false
		});
	}
}

function setNameofShutterandGainSilder(mode)
{
	// Maximum or Fixed
	exposuremode = eval("capability_image_c"+giCH_Curr+"_exposure_modetype").split(",");
	shuttertype = eval("capability_image_c"+giCH_Curr+"_exposure_shuttervaluetype").split(",");
	gaintype = eval("capability_image_c"+giCH_Curr+"_exposure_gainvaluetype").split(",");

	for (i = 0; i < exposuremode.length; i++)
	{
		if (exposuremode[i] == mode)
		{
			if (shuttertype[i] != "-")
			{
				$("#exposureTimeControl").slideDown();
				if (shuttertype[i] == "maximum")
				{
					$("#exptimename").text(translator("maximum_exposure_time"));
				}
				else if (shuttertype[i] == "fixed")
				{
					$("#exptimename").text(translator("fix_exposure_time"));
				}
			}
			else
			{
				$("#exposureTimeControl").hide();
			}


			if (gaintype[i] != "-")
			{
				$("#gainControl").slideDown();
				if (gaintype[i] == "maximum")
				{
					$("#gainName").text(translator("maximum_gain_control"));
				}
				else if (gaintype[i] == "fixed")
				{
					$("#gainName").text(translator("fix_gain_control"));
				}
			}
			else
			{
				$("#gainControl").hide();
			}
		}

	}
}

function switchWDRUI_MsgCheck(WDROn)
{
	if (WDROn)
	{
		if(bWDROnExposurewinHlcHidden)
		{
			if(!confirm("HLC and Smart IR will be disabled. Do you want to continue?"))
			{
				return false;
			}
		}
	}
	return true;
}

function switchExpWinModeUI_MsgCheck(mode)
{
	if ("hlc" == mode)
	{
		if(bExpWinModeImpactSIRHidden)
		{
			if(!confirm("Smart IR will be disabled. Do you want to continue?"))
			{
				return false;
			}
		}
	}
	return true;
}
