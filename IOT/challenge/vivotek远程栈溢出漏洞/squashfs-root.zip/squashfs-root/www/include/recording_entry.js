eval(location.search.toString().slice(1));
added=0;
function loadCurrentSetting()
{
	bSaved = false;
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?recording&server&capability_supportsd&capability_nmediastream", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("recording_entry");
	loadlanguage();
	
	var lan=getCookie("lan");
	var Russian_index=9;
	
       //Russian languages's special case
       if (lan==Russian_index)
       {
               $("#step_destination").css("width", "120px");
               $("#step_destination").css("padding-bottom", "7px");
               $("#step_destination").css("padding-top", "10px");
       }


	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	var input=document.getElementsByTagName("select");
	for (var i = 0; i < input.length; i++)
		input[i].name=input[i].name.toString().replace("index", "i"+index);	
}

function receivedone()
{
	eval("weekday=recording_i"+index+"_weekday");
	document.getElementsByName("day")[0].checked=weekday&64?1:0;
	document.getElementsByName("day")[1].checked=weekday&32?1:0;
	document.getElementsByName("day")[2].checked=weekday&16?1:0;
	document.getElementsByName("day")[3].checked=weekday&8?1:0;
	document.getElementsByName("day")[4].checked=weekday&4?1:0;
	document.getElementsByName("day")[5].checked=weekday&2?1:0;
	document.getElementsByName("day")[6].checked=weekday&1?1:0;
	
	eval("triggerType=recording_i"+index+"_trigger");
	checkTriggerType(triggerType);
	selectsd();
	generateRecordingIndexSource(capability_nmediastream);
}
function loadvaluedone()
{
	if(document.getElementById("begintime").value=="00:00" && document.getElementById("endtime").value=="24:00")
	{
		document.getElementsByName("method")[0].checked=1;
		document.getElementById("begintime").disabled="disabled";
		document.getElementById("endtime").disabled="disabled";
	}
	else
		document.getElementsByName("method")[1].checked=1;
	
	if(document.getElementsByTagName("input")[0].value=="")
	{
		document.forms[0].reset();	
		added=1;
	}
	
	var recordingName = eval('recording_i'+index+'_name');
	
	if (recordingName != "")
	{
		document.getElementById("recordingName").disabled=true;
	}
	selectsd();

	document.getElementById("reserve").value = eval('recording_i' + index + '_reserveamount');
	document.getElementById("maxduration").value = Math.round(eval('recording_i' + index + '_maxduration')/60);
	document.getElementById("maxsize").value = eval('recording_i' + index + '_maxsize');
	
	if (eval('recording_i'+index+'_limitsize') == 0)
	{
		document.getElementById("freeall").checked=1;
	}


	if($('#checkbox_adaptive_recording').attr('checked') == true)
	{
		$('#adaptive_preevent').slideDown();
		$('#adaptive_postevent').slideDown();
	}else{
		$('#adaptive_preevent').slideUp();
		$('#adaptive_postevent').slideUp();
	}
	
//	selectsd();

	if ( capability_supportsd == "0" )
	{
		document.getElementById("networkfail").style.display = "none";
		
		document.getElementById("dest_list").options[0].text = "-----None-----"
		document.getElementById("dest_list").options[0].value = ""
		//$('#dest_list').removeOption(["cf"]); //remove -----None-----
	}
	
	//60 fps mode, modified by Leslie
	if (capability_nmediastream == "1")
	{
		$(document.getElementById("recording_index_source")).removeOption("1");
	}
}

function selectsd()
{
	if(document.getElementById("dest_list").selectedIndex==0)
	{
		document.getElementById("nssettings").style.display="none";
	}
	else
	{
		document.getElementById("nssettings").style.display="block";
	}
}


function checkname()
{
	if (CheckEmptyString(document.getElementsByTagName("input")[0]) == -1)
	{
		return -1;
	}
	if((document.getElementsByTagName("input")[0].value==recording_i0_name ||
		document.getElementsByTagName("input")[0].value==recording_i1_name) && added==1)
	{
		alert(translator("the_name_has_already_existed"));
		return -1;
	}
	else
		return 0;
}

function submitform()
{
	if ( document.getElementById("dest_list").value == "" )
	{
		alert(translator("destination_is_nothing"));
		return -1;
	}
		
	document.getElementById("weekday").value=document.getElementsByName("day")[0].checked*64+document.getElementsByName("day")[1].checked*32+document.getElementsByName("day")[2].checked*16+document.getElementsByName("day")[3].checked*8+document.getElementsByName("day")[4].checked*4+document.getElementsByName("day")[5].checked*2+document.getElementsByName("day")[6].checked;
	
	document.getElementById("begintime").disabled="";
	document.getElementById("endtime").disabled="";
		
	if(checkvalue())
	{
		return -1;
	}
	else
	{
		if(document.getElementById("dest_list").length==0)
		{
			alert(translator("destination_is_nothing"));
			return -1;
		}
		
		if(checkname())
			return -1;
		
		if (CheckEmptyString(document.getElementById("begintime")) ||
			CheckEmptyString(document.getElementById("endtime")))
		{
			return -1;
		}
		/*
		if ((document.forms[0].cyclic_checkbox.checked) && ((checkLeastNum(document.getElementById("reserve"), 15))))
		{
			return -1;
		}*/

		if(document.getElementById("dest_list").selectedIndex!=0)
		{
			if (verifySize())
			{
				return -1;
			}
		}
		
		document.getElementById("maxduration").value = parseInt(document.getElementById("maxduration").value)*60;
//		document.getElementById("maxsize").value = parseInt(document.getElementById("maxsize").value)*1;
		
		bSaved = true;
		document.forms[0].submit();
		
		document.getElementById("maxduration").value = parseInt(document.getElementById("maxduration").value)/60;
//		document.getElementById("maxsize").value = parseInt(document.getElementById("maxsize").value)/1024;
	}
}

var MINIMUM_RECORDING_FILE_SIZE = 50; //MB
function verifySize()
{
	var ret = 0;
	$.ajax({
		url: "/cgi-bin/admin/get_nas_freespace.cgi",
		async: false,
		cache: false,
		success: function(data){

			if(parseInt(data) == -1)
			{
				alert(translator("connected_to_nas_failed"));
				ret = -1;
				return;
			}

			if($("input[name$='_reserveamount']").val() > parseInt(data) - MINIMUM_RECORDING_FILE_SIZE)
			{
				alert(translator("the_capacity_of_des_is_too_small")+ "\n" + translator("it_should_be_greater_than") + " " + (MINIMUM_RECORDING_FILE_SIZE+parseInt($("input[name$='_reserveamount']").val())) + " Mbytes.");
				document.getElementById("reserve").focus();
				document.getElementById("reserve").select();
				ret = -1;
				return;
			}
		}
	});

	if(ret == 0)
		return 0;
	else
		return -1;
}

function checkLeastNum(thisObj, down)
{
	if ((thisObj.value >= down) && parseInt(thisObj.value)==parseFloat(thisObj.value))
		return 0;
	alert(translator("please_input_a_valid_value") + "\n >= " + down + " Mbytes");
	thisObj.select();
	thisObj.focus();
	return -1;
}

function changemethod()
{
	if(document.getElementsByName("method")[0].checked==1)
	{
		document.getElementById("begintime").disabled="disabled";
		document.getElementById("endtime").disabled="disabled";
		document.getElementById("begintime").value="00:00";
		document.getElementById("endtime").value="24:00";
	}
	else
	{
		document.getElementById("begintime").disabled="";
		document.getElementById("endtime").disabled="";
	}
}

function openapplication()
{
        //openurl("/setup/event/application.html");
	window.open("/setup/event/application.html", "","width=1024, height=768, scrollbars=yes, status=yes");
}

function showNAS()
{
	list = document.getElementById("dest_list");

	for (i = 0; i < 5; i++)
	{
		if(eval("server_i" + i + "_name") != "" && eval("server_i" + i + "_type") == "ns")
		{
			list.options[++list.length - 1].text = eval("server_i" + i + "_name");
			list.options[list.length - 1].value = i;
			//show or hide add server btn
			$("#action-menu").parent().parent().css("display", "none");
		}
	}
}

function hideNAS()
{
	list = document.getElementById("dest_list");

	if (document.getElementById("dest_list").options[1] != null)
	{
		document.getElementById("dest_list").options[1] = null;
	}
	selectsd();
}

function checkTriggerType(obj)
{
	if (obj == "schedule")
	{
		//document.getElementById("scheduleSetting").style.display="block";
		$("#scheduleSetting").slideDown();
		$("#action-menu").show();
		showNAS();
	}
	else
	{
		//document.getElementById("scheduleSetting").style.display="none";
		$("#scheduleSetting").slideUp();
		$("#action-menu").hide();
		hideNAS();
	}
}

function checkAdaptiveRecording (obj) {

	if (obj.checked)
	{
		alert(translator("adaptive_recording_will_only_be_active_by_event"));
	}
	updatecheckById('adaptive_enable', obj);
	if($(obj).attr('checked') == true)
	{
		$('#adaptive_preevent').slideDown();
		$('#adaptive_postevent').slideDown();
	}else{
		$('#adaptive_preevent').slideUp();
		$('#adaptive_postevent').slideUp();
		$("#adaptive_help").slideUp();
	}
} 
	
function generateRecordingIndexSource(capability_nmediastream)
{
	for (var i = 0; i < capability_nmediastream; i++) 
	{
		var symbolIndex = i + 1;
		var symbolName= "stream" + symbolIndex;
		if (i == 0)
		{
			$(document.getElementById("recording_index_source")).append(""
			+'<option value="'+ i +'" selected="selected" title="symbol">' + translator(symbolName) +'</option>'
			);
		}
		else
		{
			$(document.getElementById("recording_index_source")).append(""
			+'<option value="' + i + '" title="symbol">' + translator(symbolName) + '</option>'
			);
		}
	}
}
