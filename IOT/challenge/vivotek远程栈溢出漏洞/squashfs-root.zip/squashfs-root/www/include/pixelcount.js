var PC_WINDOW_NUMBER = 3;

var g_PCW_width = new Array(PC_WINDOW_NUMBER) ;
var g_PCW_height = new Array(PC_WINDOW_NUMBER) ;
var g_PCW_left = new Array(PC_WINDOW_NUMBER) ;
var g_PCW_top = new Array(PC_WINDOW_NUMBER) ;

var g_mode = "Auto"
var g_auto_pc_rect = new Array(PC_WINDOW_NUMBER);
var g_100_pc_rect = new Array(PC_WINDOW_NUMBER);
var g_50_pc_rect = new Array(PC_WINDOW_NUMBER);
var g_25_pc_rect = new Array(PC_WINDOW_NUMBER);

for(var i = 0; i < PC_WINDOW_NUMBER; i++)
{
	g_auto_pc_rect[i] = new Array(4);
	g_100_pc_rect[i] = new Array(4);
	g_50_pc_rect[i] = new Array(4);
	g_25_pc_rect[i] = new Array(4);
}

var	ori_PCWindowWidth = 320;
var	ori_PCWindowHeight = 240;

var streamsource = 2;


$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

function updatePixelNum(pc_num,w,h)
{	
	if ($("#PCWindow" + pc_num).css("display") != "none")
	{
		s0_resolution_x = videoin_c0_s0_resolution.split('x')[0];
		s0_resolution_y = videoin_c0_s0_resolution.split('x')[1];
		s0_pix_x = Math.round(w*s0_resolution_x/($("#"+PLUGIN_ID).width()-X_OFFSET));
		s0_pix_y = Math.round(h*s0_resolution_y/($("#"+PLUGIN_ID).height()-Y_OFFSET));		
		$('#window'+pc_num+'_stream0_pixelnum').html(s0_pix_x+"x"+s0_pix_y);

		s1_resolution_x = videoin_c0_s1_resolution.split('x')[0];
		s1_resolution_y = videoin_c0_s1_resolution.split('x')[1];
		s1_pix_x = Math.round(w*s1_resolution_x/($("#"+PLUGIN_ID).width()-X_OFFSET));
		s1_pix_y = Math.round(h*s1_resolution_y/($("#"+PLUGIN_ID).height()-Y_OFFSET));		
		$('#window'+pc_num+'_stream1_pixelnum').html(s1_pix_x+"x"+s1_pix_y);

		s2_resolution_x = videoin_c0_s2_resolution.split('x')[0];
		s2_resolution_y = videoin_c0_s2_resolution.split('x')[1];
		s2_pix_x = Math.round(w*s2_resolution_x/($("#"+PLUGIN_ID).width()-X_OFFSET));
		s2_pix_y = Math.round(h*s2_resolution_y/($("#"+PLUGIN_ID).height()-Y_OFFSET));
		$('#window'+pc_num+'_stream2_pixelnum').html(s2_pix_x+"x"+s2_pix_y);
	}
}

function getFirstFreeWindow()
{
	for (i = 0; i < PC_WINDOW_NUMBER; i++) 
	{
		if ($("#PCWindow" + i).css("display") == "none")
			return i;
	}
	return -1;
}

function getPCWCandidate()
{
	for (i = 0; i < PC_WINDOW_NUMBER; i++) 
	{
		if ($("#PCWindow" + i).css("display") != "none")
		{
			return i;
		}
	}
	return -1;
}

function addWindow()
{
	var freeWindowIndex = getFirstFreeWindow();

	if (freeWindowIndex == -1)
		return -1;
	else
	{
		PC_Window_selected = freeWindowIndex;

		$('#PCWindow'+ freeWindowIndex).css({
			"width"	: 100 +"px",
			"height": 100 +(2+18) +"px",
			"left"	: 40 +"px",
			"top"	: 40 +"px",
			"opacity": "0.9"
		}).show().mousedown();

		PCWinLenTransfer(freeWindowIndex, 100, 100);
		PCWinPosTransfer(freeWindowIndex, 40, 40);

		$('#PCWindow'+ freeWindowIndex).show();
		$('#PCWindow'+ freeWindowIndex).css("background-color", "transparent");
		$('#PCWindow'+ freeWindowIndex).find(".PCW_drag").css("backgroundColor","#555555");
		
		updatePixelNum(freeWindowIndex,100,100);
		$('#window'+freeWindowIndex+"_pixelcount").show();
	}
	
	if(getFirstFreeWindow() == -1)
	{
		$('#add_btn').attr("disabled", true);
	}

	$('#warning_message_for_do').hide();
}

var g_aspectRatio = 1;
function switchView(obj, param, bForce)
{
	var bOverSize = false;
	
	// 1: 100%, 2: Best-fit, 3: 50%, 4: 25%
	// +------------------------------+
	// | $(window).height();          |
	// | $(window).width();           |
	// | $(document).height();        |
	// | $(document).wdith();         |
	// +------------------------------+


	// Reset default state, except "4:3" btn
	$(".viewstyle:gt(0)").attr("disabled", false).each(function(){
		posObj = $(this).css("backgroundPosition").split(" ");
		$(this).css("backgroundPosition", posObj[0] + " 0px");
	});
	// set selected button state
	var posObj = $(obj).css("backgroundPosition").split(" ");
	$(obj).css("backgroundPosition", posObj[0] + " -36px").attr("disabled", true);


	Log("$(window).height()=" + $(window).height()       +
		", $(window).width()=" + $(window).width()       +
		", $(document).height()=" + $(document).height() +
		", $(document).wdith()=" + $(document).width());

	//Video Server, use D1, 4CIF.. as VideoSize param, so we need to do some modification here.
	if (system_info_firmwareversion.match(/VS/) != null)
	{
		var VideoSizeW = Width;
		var VideoSizeH = Height;
	}
	else
	{
		var VideoSizeW = VideoSize.split('x')[0];
		var VideoSizeH = VideoSize.split('x')[1];
	}

	var bStretch = true;

	// default value: 100%
	var tmpHeight = Height + Y_OFFSET;
	var tmpWidth = Width + X_OFFSET;

	// Mainly used for Video Server 4:3 mode! Other models don't need this!
	// **********************************************************************
	var evalByAspectRatio = function(destVar, srcVar1, srcVar2)
	{
		if (destVar.match(/tmpWidth/) != null)
		{
			if (g_aspectRatio == 1)
				tmpWidth = srcVar1 + X_OFFSET;
			else
				tmpWidth = srcVar2 * g_aspectRatio + X_OFFSET;
		}
		else
		{
			if (g_aspectRatio == 1)
				tmpHeight = srcVar1 + Y_OFFSET;
			else
				tmpHeight = srcVar2 / g_aspectRatio + Y_OFFSET;
		}
	};
	// **********************************************************************
	var pc_rect;
	
	switch(param)
	{
		case 'Auto':
			tmpWidth = 550;
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");

			g_mode = 'Auto';
			pc_rect = g_auto_pc_rect;
			break;
		case '100':
			g_vsRatio = 1;
			tmpWidth = Width + X_OFFSET;
			if (tmpWidth > 550)
			{
				tmpWidth = 550;
				bOverSize = true;
			}
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");

			g_mode = '100';
			pc_rect = g_100_pc_rect;
			break;
		case '50':
			g_vsRatio = 1/2;
			tmpWidth = Width/2 + X_OFFSET;
			if (tmpWidth > 550)
			{
				tmpWidth = 550;
				bOverSize = true;
			}
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");

			g_mode = '50';
			pc_rect = g_50_pc_rect;
			break;
		case '25':
			g_vsRatio = 1/4;
			tmpWidth = Width/4+ X_OFFSET;
			evalByAspectRatio("tmpHeight", Height/4, Width/4);
			$(window).unbind("resize");

			g_mode = '25';
			pc_rect = g_25_pc_rect;
			break;
		default:
			alert('Do nothing now');
			break;
	}
	
	//change all pc win

	for (i = 0; i < PC_WINDOW_NUMBER; i++)
	{
		$('#PCWindow' + i).css({
			width: 	Math.round(pc_rect[i][0])+ 'px',
			height: Math.round(pc_rect[i][1] + (2+18) )+ 'px',
			left:  	Math.round(pc_rect[i][2])+'px',
			top:  	Math.round(pc_rect[i][3])+'px'		
		});
	}

	
	if(bIsWinMSIE)
		$("#"+PLUGIN_ID)[0].Stretch = bStretch;

	if (param == "100")
	{
		if (bOverSize == true)
		{
			  $("#"+PLUGIN_ID).attr("height", parseInt(Height)+Y_OFFSET).height(parseInt(Height)+Y_OFFSET);
			  $("#"+PLUGIN_ID).attr("width", parseInt(Width)+X_OFFSET).width(parseInt(Width)+X_OFFSET);
		}
		else
		{
			  $("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
			  $("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
		}
	}
	else if (param == "50")
	{	
		if (bOverSize == true)
		{
			  $("#"+PLUGIN_ID).attr("height", Height/2 + Y_OFFSET).height(Height/2 + Y_OFFSET);
			  $("#"+PLUGIN_ID).attr("width", Width/2 + X_OFFSET).width(Width/2 + X_OFFSET);		  
		}
		else
		{
			  $("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
			  $("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
		}	
	}
	else
	{
		$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
		$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
	}
	
	$("#PCWinContainer").height($("#"+PLUGIN_ID).height()-6).width($("#"+PLUGIN_ID).width()-6);

	if (bOverSize == false)
		$("#showimageBlock").height(tmpHeight).width(tmpWidth).css("overflow","hidden");
	else	
		$("#showimageBlock").height(tmpHeight).width(tmpWidth).css("overflow","auto");

	document.getElementById("PCWinContainer").style.left = document.getElementById('WinLessPluginCtrl').getBoundingClientRect().left - 6;
}

function PCWinLenTransfer(pc_num, w, h)
{
	switch(g_mode)
	{
	case 'Auto':
		g_auto_pc_rect[pc_num][0] = w;
		g_auto_pc_rect[pc_num][1] = h;
		break;
	case '100':
		g_100_pc_rect[pc_num][0] = w;
		g_100_pc_rect[pc_num][1] = h;
		break;
	case '50':
		g_50_pc_rect[pc_num][0] = w;
		g_50_pc_rect[pc_num][1] = h;
		break;
	case '25':
		g_25_pc_rect[pc_num][0] = w;
		g_25_pc_rect[pc_num][1] = h;
		break;
	default:
		//alert('Do nothing now');
		break;
	}
	
	//alert($("#showimageBlock").width()+"x"+$("#showimageBlock").height());
	//alert($("#"+PLUGIN_ID).width()+"x"+$("#"+PLUGIN_ID).height());
	
	if (g_auto_pc_rect.length != 0 && g_mode != "Auto")
	{
		g_auto_pc_rect[pc_num][0] = w * ($("#showimageBlock").width()-X_OFFSET) / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_auto_pc_rect[pc_num][1] = h * ($("#showimageBlock").height()-Y_OFFSET) / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
	if (g_100_pc_rect.length != 0 && g_mode != "100")
	{
		g_100_pc_rect[pc_num][0] = w * Width / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_100_pc_rect[pc_num][1] = h * Height / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
	if (g_50_pc_rect.length != 0 && g_mode != "50")
	{
		g_50_pc_rect[pc_num][0] = w * (Width / 2) / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_50_pc_rect[pc_num][1] = h * (Height / 2) / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
	if (g_25_pc_rect.length != 0 && g_mode != "25")
	{
		g_25_pc_rect[pc_num][0] = w * (Width / 4) / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_25_pc_rect[pc_num][1] = h * (Height / 4) / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
}

function PCWinPosTransfer(pc_num, l, t)
{
	switch(g_mode)
	{
	case 'Auto':
		g_auto_pc_rect[pc_num][2] = l;
		g_auto_pc_rect[pc_num][3] = t;
		break;
	case '100':
		g_100_pc_rect[pc_num][2] = l;
		g_100_pc_rect[pc_num][3] = t;
		break;
	case '50':
		g_50_pc_rect[pc_num][2] = l;
		g_50_pc_rect[pc_num][3] = t;
		break;
	case '25':
		g_25_pc_rect[pc_num][2] = l;
		g_25_pc_rect[pc_num][3] = t;
		break;
	default:
		//alert('Do nothing now');
		break;
	}
	
	if (g_auto_pc_rect.length != 0 && g_mode != "Auto")
	{
		g_auto_pc_rect[pc_num][2] = l * ($("#showimageBlock").width()-X_OFFSET) / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_auto_pc_rect[pc_num][3] = t * ($("#showimageBlock").height()-Y_OFFSET) / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
	if (g_100_pc_rect.length != 0 && g_mode != "100")
	{
		g_100_pc_rect[pc_num][2] = l * Width / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_100_pc_rect[pc_num][3] = t * Height / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
	if (g_50_pc_rect.length != 0 && g_mode != "50")
	{
		g_50_pc_rect[pc_num][2] = l * (Width / 2) / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_50_pc_rect[pc_num][3] = t * (Height / 2) / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
	if (g_25_pc_rect.length != 0 && g_mode != "25")
	{
		g_25_pc_rect[pc_num][2] = l * (Width / 4) / ($("#"+PLUGIN_ID).width()-X_OFFSET);
		g_25_pc_rect[pc_num][3] = t * (Height / 4) / ($("#"+PLUGIN_ID).height()-Y_OFFSET);
	}
}

function winless_loadCurrentSetting()
{
	loadlanguage();
	showimage_innerHTML('9', 'showimageBlock', false, true, false);
	$("#showimageBlock").append("<div id='PCWinContainer'></div>");
	
	//defauil plug-in border size
	tmpHeight=434;
	tmpWidth=550;
	$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
	$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);

	if (bIsWinMSIE || ffversion >= 3)
	{
		//openChannel()
		$("#StreamContainer").addClass("StreamContainerStyle");

		/*
		 * create temporay EP window div block.
		 */
		var window_string = translator("window") + " ";
		for (i = 0; i < PC_WINDOW_NUMBER; i++)
		{
			$("#PCWinContainer").append(""
				+ '<div id="PCWindow' + i + '" class="PCW_style">'
				+ '<div class="PCW_drag">'
				+ '<span title="" class="PCW_title">' + (i+1) + '</span>'
				+ '<a class="ui-dialog-titlebar-close" href="#"><span>X</span></a>'
				+ '</div>'
				+ '</div>');
		}

		/*
		 * initial Window by jQueryUI, enable resizable and draggable
		 */
		$('.PCW_style').resizable({
			//bug of jquery: http://bugs.jqueryui.com/ticket/4489, not fix it, so just remove the containment and check the boundary in callback function
			//containment: "#PCWinContainer",  // use it will cause resize width fail in 100% mode.
			handles: 'all',
			autoHide: true,
			minWidth: 25,
			minHeight: 45,
			resize: function(e, ui)
			{
				var self = $(this).data("resizable");
				
				// containment is not valid, so check boundary here:
				if(self.position.top < 3) self.position.top = 3;
				if(self.position.left < 3) self.position.left = 3;
				
				WinHeight = parseInt($("#PCWindow" + PC_Window_selected).css("height"));
				WinWidth = parseInt($("#PCWindow" + PC_Window_selected).css("width"));

				if (self.position.left + WinWidth+4 > $("#"+PLUGIN_ID).width() - 3){
					self.position.left = $("#"+PLUGIN_ID).width() - 3 - (WinWidth+4);
				}

				if (self.position.top + WinHeight+4 >  $("#"+PLUGIN_ID).height() -3){
					self.position.top = $("#"+PLUGIN_ID).height() - 3 - (WinHeight+4);
				}
				
				realHeight = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("height")) - 20);
				realWidth = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("width")));

				updatePixelNum(PC_Window_selected,realWidth,realHeight);				
			},
			stop: function(e, ui)
			{
				var self = $(this).data("resizable");

				realHeight = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("height")) - 20);
				realWidth = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("width")));
				realTop = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("top")));
				realLeft = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("left")));

				//change pc win info for all mode
				PCWinLenTransfer(PC_Window_selected, realWidth, realHeight);
				PCWinPosTransfer(PC_Window_selected, realLeft, realTop);
				updatePixelNum(PC_Window_selected,realWidth,realHeight);
			}
		})
		.draggable({
			cursor: 'move',
			handle: 'div',
			containment: "#PCWinContainer",
			drag: function(e, ui)
			{
				var self = $(this).data("draggable");
				// reopen it, it seems that the param of  containment is invalid to check the boundary. when change mode to 100%, you can drag window outside the boundary.
				if(self.position.top < 3) self.position.top = 3;
				if(self.position.left < 3) self.position.left = 3;
				
				WinHeight = parseInt($("#PCWindow" + PC_Window_selected).css("height"));
				WinWidth = parseInt($("#PCWindow" + PC_Window_selected).css("width"));

				if (self.position.left + WinWidth+4 > $("#"+PLUGIN_ID).width() - 3){
					self.position.left = $("#"+PLUGIN_ID).width() - 3 - (WinWidth+4);
				}

				if (self.position.top + WinHeight+4 >  $("#"+PLUGIN_ID).height() -3){
					self.position.top = $("#"+PLUGIN_ID).height() - 3 - (WinHeight+4);
				}
				
			},
			stop: function()
			{
				var self = $(this).data("draggable");
		
				realHeight = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("height")) - 20);
				realWidth = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("width")));
				realTop = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("top")));
				realLeft = Math.round(parseInt($("#PCWindow" + PC_Window_selected).css("left")));

				//change pc win info for all mode
				PCWinLenTransfer(PC_Window_selected, realWidth, realHeight);
				PCWinPosTransfer(PC_Window_selected, realLeft, realTop);

			}
		}).css("display","none");
	}
}
	
function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?videoin&system_date&system_time&capability_nmediastream", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	//document.title = translator("Pixel counter");
	document.title = "Pixel counter";
	loadlanguage();
	
	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};
/*	
	//updata 
	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;
			
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];
		
		if(!type || compare(type.description, plugin.description)) {
			xpi = plugin.xpi;
		}
	
		if(xpi) {
			if( window.InstallTrigger == undefined) // It means this page is include in other page
				parent.window.InstallTrigger.install(xpi);
			else
			window.InstallTrigger.install(xpi);
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');
		}																					   //
	}
	
	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}
*/
	$('#InstallerArea').hide();

	winless_loadCurrentSetting();
	
	if(typeof(RtspVapgCtrl) != "undefined")
		SetPluginString(RtspVapgCtrl);
	reDrawPlugin();
}

function disableItem(obj, checkbox)
{
	if (checkbox.checked == true)
	{
		obj.disabled = true;
	}
	else
	{
		obj.disabled = false;
	}
}

function receivedone()
{
	//winless_receivedone();
}

function winless_loadvaluedone()
{

	if (bIsWinMSIE || ffversion >= 3)
	{

		$('.PCW_style').mousedown(function(e){
			var index = $(this).attr("id").charAt(8);
			PC_Window_selected = index;

			// when PC Window onfocus, change the color of the title and border
			$(this).siblings().find(".PCW_drag").css("border-bottom-color","#ccc"); //set all PCW to default color
			$(this).siblings(":not('#PCWindow11,#PCWindow21,#PCWindow31, #Canvas_temp, #Canvas_real, #Canvas_highlight')").css("borderColor","#ccc"); //set all PCW border to default color
			$(this).siblings(".PCW_style").css("z-index",1);
			$(this).css("z-index",100);
			$(this).find(".PCW_title").css("font-weight","bolder");
		});

		// PC window clsoe action
		$('.ui-dialog-titlebar-close').click(function(){
			PC_Window_selected = $(this).parent().parent().attr("id").charAt(8);
			$(this).parent().parent().hide();
			$('#window'+PC_Window_selected+"_pixelcount").hide();
			
			$('#add_btn').attr("disabled", false);

			
			if(getPCWCandidate() == -1)
				$('#warning_message_for_do').show();

			/*
			PC_Window_selected = getPCWCandidate();
			if (EP_Window_selected != -1)
			{
				$('#PCWindow'+ PC_Window_selected).mousedown();  //force this window to be foucs after the curent one is closed	
			}
			else
			{
				PC_Window_selected = -1;
			}
			*/
		})

		
		//Initial windows
		
		for (i = 0; i < PC_WINDOW_NUMBER; i++)
		{
			g_auto_pc_rect[i][0] = 200;
			g_auto_pc_rect[i][1] = 200;
			g_auto_pc_rect[i][2] = 50;
			g_auto_pc_rect[i][3] = 50;
		}
		/*
		//set the 1st exist PCW to be focused
		PC_Window_selected = getPCWCandidate();
		if(PC_Window_selected != '-1')  //PC Window exists.
		{
			$('#PCWindow'+ PC_Window_selected).mousedown();
		}
		*/
		switchView($("button.viewstyle:[title*='Auto-Fit']")[0], "Auto", true);
	
		for (i = 0; i < PC_WINDOW_NUMBER; i++)
		{
			PCWinLenTransfer(i, 200, 200);
			PCWinPosTransfer(i, 50, 50);
		}
	}
}

function loadvaluedone()
{
	winless_loadvaluedone();
	//showmode();
}


function updateCheckbox(obj)
{
	var checkboxID = (obj.value == "auto") ? 0 : 1;
	obj[checkboxID].checked = true;
}
