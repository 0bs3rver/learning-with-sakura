function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?ipfilter", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	loadlanguage();
	//index
	eval(location.search.toString().slice(1));

	document.title="Add list";
	var input = document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
		input[i].name = input[i].name.toString().replace("index", "i" + index);
	var input = document.getElementsByTagName("select");
	for (var i = 0; i < input.length; i++)
		input[i].name = input[i].name.toString().replace("index", "i" + index);	
}

function showFilter()
{
	Netform = document.forms[0];
	for(i = 0; i < Netform.add_filter.length; i++)
	{
		document.getElementById(Netform.add_filter.options[i].value).style.display = "none";
	}
	document.getElementById(Netform.add_filter.options[Netform.add_filter.selectedIndex].value).style.display = "block";
}

function checkRangev4(start, end)
{
	var filter = /\d+\.\d+\.\d+\.\d+/;
	start.value = start.value.match(filter)[0];
	startsubip = start.value.split(".");
	end.value = end.value.match(filter)[0];
	endsubip = end.value.split(".");
	for (i = 0; i < startsubip.length; i ++)
	{
		if (parseInt(startsubip[i]) < parseInt(endsubip[i]))
		{
			return 0;
		}
		else if (parseInt(startsubip[i]) > parseInt(endsubip[i]))
		{
			alert(translator("please_enter_a_valid_ip_address"));
			end.focus();
			end.select();
			return -1;
		}
	}	
	// start == end case
	alert(translator("please_enter_a_valid_ip_address"));
	end.focus();
	end.select();
	return -1;
}

function checkSameRule(ipaddrStr, ipType)
{
	for (iCnt = 0; iCnt < 10; iCnt++)
	{
		(ipType == "ipv4") ? existRule = eval("ipfilter_ipv4list_i" + iCnt) : existRule = eval("ipfilter_ipv6list_i" + iCnt);

		if (ipaddrStr == existRule)
		{
			alert("Input rule is same with existed rule");
			return -1;
		}
	}
	return 0;
}

function submitv4()
{
	var ipaddrStr = "";
	if (Netform.add_filter.selectedIndex == 0)
	{
		if (checkIPaddr(document.add4List.singlev4_ip))
			return;
		ipaddrStr = document.add4List.singlev4_ip.value;
	}
	else if (Netform.add_filter.selectedIndex == 1)
	{
		if (checkIPaddr(document.add4List.networkv4_name))
			return;
		if (checkNumRange(document.add4List.networkv4_mask,32,0))
			return;
		ipaddrStr = document.add4List.networkv4_name.value + "/" + document.add4List.networkv4_mask.value;
	}
	else
	{
		if (checkIPaddr(document.add4List.rangev4_start))
			return;
		if (checkIPaddr(document.add4List.rangev4_end))
			return;
		if (checkRangev4(document.add4List.rangev4_start, document.add4List.rangev4_end))
			return;
		ipaddrStr = document.add4List.rangev4_start.value + "-" + document.add4List.rangev4_end.value;
	}

	if (checkSameRule(ipaddrStr, "ipv4"))
	{
		return -1;
	}

	var msg = "/cgi-bin/admin/ipfilter.cgi?method=addv4&ip=" + ipaddrStr + "&index=" + index;
	XMLHttpRequestObject.open("GET", msg, false);
	XMLHttpRequestObject.send(null);

	opener.location.reload();
	window.close();
}

function submitv6()
{
	var ipaddrStr = "";
	if (Netform.add_filter.selectedIndex == 0)
	{
		if (checkIPtable6(document.add6List.singlev6_ip))
			return;
		//rule = document.add6List.singlev6_ip.value;
		ipaddrStr = document.add6List.singlev6_ip.value;
	}
	else
	{
		if (checkIPtable6(document.add6List.networkv6_name))
			return;
		if (checkNumRange(document.add6List.networkv6_mask, 128, 0))
			return;
		//rule = document.add6List.networkv6_name.value + "/" + document.add6List.networkv6_mask.value;
		ipaddrStr = document.add6List.networkv6_name.value + "/" + document.add6List.networkv6_mask.value;
	}

	if (checkSameRule(ipaddrStr, "ipv6"))
	{
		return -1;
	}

	var msg = "/cgi-bin/admin/ipfilter.cgi?method=addv6&ip=" + ipaddrStr + "&index=" + index;
	XMLHttpRequestObject.open("GET", msg, false);
	XMLHttpRequestObject.send(null);

	opener.location.reload();
	window.close();
}
