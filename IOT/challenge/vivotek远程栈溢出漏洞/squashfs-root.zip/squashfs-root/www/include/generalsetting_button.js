
var blockSeconds = 20;

function loadCurrentSetting()
{	
	giCH_Curr = Number(getCookie("channelsource"));

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?capability_daynight_c"+giCH_Curr+"_support&capability_daynight_c"+giCH_Curr+"_lightsensor&videoin_c"+giCH_Curr+"_cmosfreq&capability_image_c"+giCH_Curr+"_sensortype", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();
	parent.document.getElementById("generalpage_button").height = document.body.scrollHeight;
	document.getElementById("content").style.visibility = "visible";
}

function SaveButton()
{
	var conf_cmosfreq = videoin_c0_cmosfreq;
	var form_cmosfreq = (true == parent.$("#generalpage_video")[0].contentWindow.$("#cmosfreq60").attr('checked'))? 60:50;

	if ((getParamValueByName("capability_image_c"+giCH_Curr+"_sensortype") == "smartsensor") && (conf_cmosfreq != form_cmosfreq))
	{
		if(!confirm(translator("cmosfreq_switch_warning_message2")))
		{
			parent.location.reload();
		}
		else
		{
			parent.$("#generalpage_video")[0].contentWindow.$("#videoSettingsSaveButton").click();
			parent.blockUI();
			setTimeout("$.unblockUI(); parent.location.reload();", blockSeconds*1000);
		}
	}
	else
	{
		parent.$("#generalpage_video")[0].contentWindow.$("#videoSettingsSaveButton").click();
	}

	if (parseInt(eval("capability_daynight_c"+giCH_Curr+"_support"), 10) == 1)
	{
		parent.$("#generalpage_daynight")[0].contentWindow.$("#dayNightSettingsSaveButton").click();
	}
}

