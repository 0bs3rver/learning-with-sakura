
var MAX_NAME_LENGTH	= 40;
var MAX_PRESET_COUNT	= 256;
var MAX_PATROL_COUNT	= 128;
var MAX_TOUR_COUNT	= 20;
var MAX_TOUR_TIMEMSEC	= 600000;
var MAX_URL_LENGTH	= 2000;

var g_viewportWidth;
var g_viewportHeight;

var g_tourIndex		= -1;
var g_tourSetMode	= "";
var g_tourSetType	= "";

var g_bRecEnabled	= false;
var g_bPlayEnabled	= false;
var g_bPauseEnabled	= false;

var g_recordingTimer	= null;
var g_recordingTimeup	= MAX_TOUR_TIMEMSEC;

var g_lastMove = 0;

// Workaround for IE8
Date.now = Date.now || function() { return +new Date; };

var giCH_Curr = 0;
function loadCurrentSetting()
{
	g_tourSetMode   = getParamFromURL("opmode");
	g_tourSetType	= getParamFromURL("method");
        g_tourIndex     = getParamFromURL("target");

	InstallPlugin();
	var cgiGetParams = 
		"capability_ptz_panspeedlv&capability_ptz_tiltspeedlv&" + 
		"camctrl_c"+giCH_Curr+"_panspeed&camctrl_c"+giCH_Curr+"_tiltspeed&camctrl_c"+giCH_Curr+"_zoomspeed&" + 
		"camctrl_c"+giCH_Curr+"_autospeed&camctrl_c"+giCH_Curr+"_focusspeed&" + 
		"camctrl_c"+giCH_Curr+"_preset&camctrl_c"+giCH_Curr+"_tour_i"+g_tourIndex+"&" + 
		"camctrl_c"+giCH_Curr+"_motortype"+
		"&capability_camctrl_c_"+giCH_Curr+"_focusmode";

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?" + cgiGetParams, false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();

	ShowPresetSelction("builtin");
	initSDPtzPannel(); 
	
	konami(function(){
		$("#auto-ctrl").toggle();
	});
    
    	CheckControlMode();

}

function receivedone()
{
        document.add.addpos_temp.value = "";
        form=document.cameractrl;
}

function loadvaluedone()
{
	// add mode
	if (g_tourSetMode == "add")
	{
		//document.getElementById("selectPage").style.display = "block";
		document.getElementsByName("tourType")[0].checked = (g_tourSetType == 0)? true : false;
		document.getElementsByName("tourType")[1].checked = (g_tourSetType == 0)? false : true;
		nextStep(false);
	}
	// modify mode
	else
	{
		g_tourSetType = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_type");
		document.getElementsByName("tourType")[0].checked = (g_tourSetType == 0)? true : false;
		document.getElementsByName("tourType")[1].checked = (g_tourSetType == 0)? false : true;
		nextStep(true);
	}

	// different motor device solution will own different capability, the value cannot be changed at will. 
	if (getParamValueByName("camctrl_c"+giCH_Curr+"_motortype") == "02")
	{
		g_recordingTimeup = 120000;	// 2 minute 
	}
	else if (getParamValueByName("camctrl_c"+giCH_Curr+"_motortype") == "04")
	{
		//g_recordingTimeup = 60000;	// 1 minute
		g_recordingTimeup = 120000;	// 2 minute, C4 HW change. 
	}
	else
	{
		g_recordingTimeup = MAX_TOUR_TIMEMSEC;
	}
}

function switchTourSpeed(obj)
{
	//var newParams = "camctrl_c0_tour_i" + g_tourIndex + "_speed=" + obj.value + "&";
	//$.get("/cgi-bin/admin/setparam.cgi?" + newParams + "return=/setup/ptz/cameracontrol.html");
}

function CheckEmptyPatrolName(input)
{
        if(input.value == "")
        {
                alert(translator("patrol_name_cannot_be_empty"));
                input.focus();
                input.select();
                return -1;
        }
        return 0;
}

function checkPresetName()
{
        if (CheckEmptyPatrolName(document.add.addpos_temp) == -1)
        {
                return false;
        }

        if (checkInSpace(document.add.addpos_temp))
        {
                return false;
        }

        if (checkInString(document.add.addpos_temp))
        {
            return false;
        }

        if (document.add.addpos_temp.value.match(',') != null)
        {
            alert(translator("you_have_used_invalid_characters_comma"));
            return false;
        }

        if (document.spdfm.presetLocs.length > MAX_PRESET_COUNT)
        {
                alert(translator("no_more_than_256_locations"));
                return false;
        }

        if (CountLength(document.add.addpos_temp.value) > MAX_NAME_LENGTH)
        {
                alert(translator("the_length_is_over_40_characters"));
                return false;
        }

        for (var i = 0; i < document.spdfm.presetLocs.length; i++)
        {
                if (document.add.addpos_temp.value == document.spdfm.presetLocs.options[i].text)
                {
                        alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
                        return false;
                }
        }

	return true;
}

function checkTourName()
{
        if (CheckEmptyPatrolName(document.newtour.tourname_temp) == -1)
        {
                return false;
        }

        if (checkInSpace(document.newtour.tourname_temp))
        {
                return false;
        }

        if (checkInString(document.newtour.tourname_temp))
        {
            return false;
        }

        if (document.newtour.tourname_temp.value.match(',') != null)
        {
            alert(translator("you_have_used_invalid_characters_comma"));
            return false;
        }

        if (CountLength(document.newtour.tourname_temp.value) > MAX_NAME_LENGTH)
        {
                alert(translator("the_length_is_over_40_characters"));
                return false;
        }

	var iTourIdx = 0;
	var tmpName = "";
        for (iTourIdx = 0; iTourIdx < MAX_TOUR_COUNT; iTourIdx++)
        {
		if (iTourIdx == g_tourIndex)
		{
			continue;
		}
		
		tmpName = "";
		$.ajax({
			url: "/cgi-bin/admin/getparam.cgi?camctrl_c"+giCH_Curr+"_tour_i" + iTourIdx + "_name",
			type: "GET",
			cache: false,
			async: false,
			success: function (result) {
                 		tmpName = eval(result);
			},
			error: function() {
                                return false;
                        }
		});

                if ( tmpName == document.newtour.tourname_temp.value)
                {
                        alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
                        return false;
                }
        }

        return true;
}

function AddPresetLoc()
{
    if (checkPresetName() == false)
    {
		return false;
	}
  
	document.add.addpos.value = document.add.addpos_temp.value;
	var presetURL = "/cgi-bin/camctrl/camctrl.cgi?name=" + encodeURIComponent(document.add.addpos.value) + "&focussetting=fixcurrent&cam=getsetpreset";
	document.add.Submit2.disabled=true;

	// adding preset location by AJAX
	$.ajax({
		url: presetURL,
		type: "GET",
       		cache: false,
		async: false,
		beforeSend: function () {
			$("#ajaxLoadIcon").show();
		},
		error: function (xhr) {
			document.add.addpos_temp.value = "";
			document.add.Submit2.disabled = false;
			return false; 
		},
		success: function (response) {
			var addIndex = MAX_PRESET_COUNT;
			if (response != null)
			{
				addIndex = eval(response);
			}
			$(".sel_gotoPreset").addOption($(".sel_gotoPreset option:last").val() + 1, document.add.addpos.value , false);
			var strTemp = genPresetFocusSelectionToTable("fixcurrent");
			$("#table-preset tbody").append("<tr id='newpreset" + addIndex + "'><td><input type='checkbox'/></td><td class='presetname' style='cursor: default;' title='" + document.add.addpos.value + "'>" + document.add.addpos.value + "</td><td class='presetindex' style='display:none;'>" + addIndex + "</td><td><select style='width:132px;' id='addPresetFocus_" + addIndex + "' name='addpreset_focus_" + addIndex + "' onchange='changePresetFocus(this)'>" + strTemp + "</td><td>&nbsp;</td></tr>");

			document.add.addpos_temp.value = "";

			if ($("#table-preset tbody > tr").size() < MAX_PRESET_COUNT)
			{
				document.add.Submit2.disabled = false;
			}
			else
			{
				document.add.Submit2.disabled = true;
			}

			$("#addPresetInput").blur();
			$("#ajaxLoadIcon").fadeOut(1000);
			presetSclBarDetect();
			return true;
		}
	});
}

function presetSclBarDetect() 
{
	if($("#table-preset").height() >= 130)
	{
		$("#btn_adjPresetTbl").show();
	}
	else
	{
		($(".tablescroll_wrapper:eq(0)").hasScrollbar()) ? $("#btn_adjPresetTbl").show() : $("#btn_adjPresetTbl").hide();
	}
}

function patrolSclBarDetect() 
{
	if($("#table-patrol").height() >= 130)
	{
		$("#btn_adjPatrolTbl").show();
	}
	else
	{
		($(".tablescroll_wrapper:eq(1)").hasScrollbar()) ? $("#btn_adjPatrolTbl").show() : $("#btn_adjPatrolTbl").hide();
	}
}

function initPrestAndPatrolBlk()
{
	// Init "add preset location"
    	$('label.pre').labelOver('overlay').show();

    	// Preset - Select All or Clear
    	$("#chk_SelAllPreset").click(function() {
        	$(this).attr("checked") ? $("#table-preset :checkbox").attr("checked", true) : $("#table-preset :checkbox").attr("checked", false);
    	}).attr("checked", false);

    	// Patrol - Select All or Clear
    	$("#chk_SelAllPatrol").click(function() {
        	$(this).attr("checked") ? $("#table-patrol :checkbox").attr("checked", true) : $("#table-patrol :checkbox").attr("checked", false);
    	}).attr("checked", false);;

    	// Generate Preset table 
    	var presetItemStr = "";
    	for (i = 0; i < MAX_PRESET_COUNT; i ++)
    	{
       		var presetName = eval("camctrl_c"+giCH_Curr+"_preset_i" + i + "_name");
       		var presetFocusSetting = eval("camctrl_c"+giCH_Curr+"_preset_i" + i + "_focussetting");
       		if (presetName != "")
       		{
				if (presetFocusSetting == "") 
				{
					presetFocusSetting = "fixcurrent";
				}
				var strTemp = genPresetFocusSelectionToTable(presetFocusSetting);
				presetItemStr += "<tr id='newpreset" + i + "'><td><input type='checkbox'/></td><td class='presetname' style='cursor: default;' title='" + presetName + "'>" + presetName + "</td><td class='presetindex' style='display:none;'>" + i + "</td><td>" + "<select style='width:132px;' id='addPresetFocus_" + i + "' name='addpreset_focus_" + i + "' onchange='changePresetFocus(this)'>" + strTemp + "</td><td>&nbsp;</td></tr>";
       	 		}
    		}
		$("#table-preset tbody").empty();
    	$("#table-preset tbody").append(presetItemStr);
	 
    	//Avoid draggin operation on this field.
    	$("#table-preset td:odd").live("mousedown", function(){
        	return false;
    	});

	if ($("#table-preset tbody > tr").size() < MAX_PRESET_COUNT)
	{
		document.add.Submit2.disabled = false;
	}
	else
	{
		document.add.Submit2.disabled = true;
	}	

    	// Generate Patrol table
    	var patrolItemStr = "";
	var patrolName = "";
	var patrolIndexList = new Array();
	var patrolDwellList = new Array();
	var tourName = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_name");
	if (tourName != "")
	{
		patrolIndexList = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_checklist").split(',');
		patrolDwellList = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_dwelltime").split(',');
		var iBoundIndex = (patrolIndexList.length <= patrolDwellList.length)? patrolIndexList.length : patrolDwellList.length;
		for(i = 0; i < iBoundIndex; i++)
		{
			if (patrolIndexList[i] != "")
			{
				patrolName = eval("camctrl_c"+giCH_Curr+"_preset_i" + patrolIndexList[i] + "_name");
				patrolItemStr += "<tr><td><input type='checkbox'/></td><td title='"+ patrolName +"'>" + patrolName + "</td><td><input type='text' style='width:100px;' value='" + patrolDwellList[i] + "' maxlength='3'/></td><td class='patrolindex' style='display:none;'>" + patrolIndexList[i] + "</td><td>&nbsp;</td></tr>";
			}
		}
	}
	$("#table-patrol tbody").empty();
    	$("#table-patrol tbody").append(patrolItemStr);

    	// Make Patrol locations Drag & Drop
    	$("#table-patrol").tableDnD({ onDragClass: "myDragClass" });
    	if (bIsWinMSIE) $("#table-patrol :checkbox").css("cursor", "default");

    	$("#table-patrol tr").live('click', function(){
        	$(this).siblings().attr("selected", 0).css("background", "#fff");
        	$(this).attr("selected", 1).css("background", "#ccc");
    	});

    	// Finetune the layout
    	$("#table-patrol :text").css("padding", "0 3px");
//	wrapperPatrolW = $("#wrapper-patrol").width() - 2;
//	wrapperPresetW = $("#wrapper-preset").width() - 2;
//alert( $("#wrapper-preset").width() + "," + $("#wrapper-patrol").width() + "," + $("#tourPresetPage").width());
//	$("div.tablescroll_wrapper:eq(1)").css("width", wrapperPatrolW);
//	$("div.tablescroll_wrapper:eq(0)").css("width", wrapperPresetW);
}

// Preset Locations to be deleted!
var g_delPresetCount = 0;
var g_delPresetGroupCnt = 0;
var g_delGotoOptions = new Array();
var g_delPresetLocSeq = new Array();
g_delPresetLocSeq[g_delPresetGroupCnt] = new Array();

function initURLCmdBuff()
{
	g_delPresetCount = 0;
	g_delPresetGroupCnt = 0;
	g_delGotoOptions = new Array();
	g_delPresetLocSeq = new Array();
	g_delPresetLocSeq[g_delPresetGroupCnt] = new Array();
}

function delPresetLocs()
{
	$("#table-preset :checked").parent().next().each(function(){
        	tmpPresetName = $(this).attr("title");
		g_delGotoOptions[g_delPresetCount] = tmpPresetName;

		if (encodeURIComponent(g_delPresetLocSeq[g_delPresetGroupCnt] + tmpPresetName).length > MAX_URL_LENGTH)
		{
			g_delPresetGroupCnt ++;
			g_delPresetLocSeq[g_delPresetGroupCnt] = new Array();
		}

		g_delPresetLocSeq[g_delPresetGroupCnt].push(tmpPresetName);
        	g_delPresetCount ++;

		$("#table-patrol tr td[title!='']").each(function(){
            		if (tmpPresetName == $(this).attr("title")) 
			{
                		$(this).parent().remove();
            		}
        	});
    	});

    	$("#table-preset :checked").parent().parent().remove();
    	$("#btn_adjPresetTbl").click().click(); //force click twice to auto adjust #table-patrol
    	$("#chk_SelAllPreset").attr("checked", false);

    	presetSclBarDetect();
    	patrolSclBarDetect();
}

function delPatrolLocs()
{
    	$("#table-patrol :checked").parent().parent().remove();
    	$("#btn_adjPatrolTbl").click().click(); //force click twice to auto adjust #table-patrol
    	$("#chk_SelAllPatrol").attr("checked", false);
    	patrolSclBarDetect();
}

function AddToPatrol()
{
	if ( (MAX_PATROL_COUNT - $("#table-patrol tr").length) < $("#table-preset :checked").length )
    	{
		alert(translator("no_more_than_128_locations"));
        	return;
    	}

    	var patrolItemStr = "";
    	$("#table-preset :checked").each(function(i, obj){
        	// Insert to Patrol table
        	var patrolName = $(obj).parent().siblings(".presetname").text();
		var patrolIndex = $(obj).parent().siblings(".presetindex").text();
        	//Set default dwell time to 5
        	var patrolDwell = 5; 
        	patrolItemStr += "<tr><td><input type='checkbox'/></td><td title='" + patrolName +"'>" + patrolName + "</td><td><input style='padding: 0 3px; width: 100px;' type='text' value='" + patrolDwell + "' maxlength='3'/></td><td class='patrolindex' style='display:none;'>" + patrolIndex + "</td><td>&nbsp;</td></tr>";
    	});

    	$("#table-patrol tbody").append(patrolItemStr);
    
    	//Make new item Drag & Drop 
    	$("#table-patrol").tableDnD({ onDragClass: "myDragClass" });
    	if (bIsWinMSIE) $("#table-patrol :checkbox").css("cursor", "default");

	patrolSclBarDetect();
}

function MoveUp()
{
    var Index = $("#table-patrol tr").index($("#table-patrol tr[selected='1']"));
    if ( -1 == Index) return;

    if ( Index == $("#table-patrol tr").index($("#table-patrol tr:first")) ) return;  // At first place
    $("#table-patrol tr[selected='1']").insertBefore($("#table-patrol tr:eq("+ (Index-1) +")"));
}

function MoveDown()
{
    var Index = $("#table-patrol tr").index($("#table-patrol tr[selected='1']"));
    if ( -1 == Index ) return;

    if ( Index == $("#table-patrol tr").index($("#table-patrol tr:last")) ) return;  // At last place
    $("#table-patrol tr[selected='1']").insertAfter($("#table-patrol tr:eq("+ (Index + 1) +")"));
}

function adjustPatrolTbl(obj)
{
    var currentH = $("div.tablescroll_wrapper:eq(1)").css("height");

    if ("130px" == currentH) 
    {
        if($("#table-patrol").height() <= 130) return;
        $("div.tablescroll_wrapper:eq(1)").css("height", "auto");
        $(obj).val(translator("less"));
    }
    else
    {
        $("div.tablescroll_wrapper:eq(1)").css("height", "130px");
        $(obj).val(translator("more"));
    }
    obj.blur();
}

function adjustPresetTbl(obj)
{
    var currentH = $("div.tablescroll_wrapper:eq(0)").css("height");

    if ("130px" == currentH) 
    {
        if($("#table-preset").height() <= 130) return;
        $("div.tablescroll_wrapper:eq(0)").css("height", "auto");
        $(obj).val(translator("less"));
    }
    else
    {
        $("div.tablescroll_wrapper:eq(0)").css("height", "130px");
        $(obj).val(translator("more"));
    }
    obj.blur();
}

function SubmitResetRecord()
{
        var object_record = document.getElementById("btn_record");
        var object_play = document.getElementById("btn_play");
        var object_stop = document.getElementById("btn_stop");
	if (true == g_bRecEnabled)
	{
		object_record.style.backgroundPosition = "-192px 0px";
		object_play.disabled = false;
		object_play.style.backgroundPosition = "-64px 0px";
		
		$.get("/cgi-bin/camctrl/camctrl.cgi?recorded=" + g_tourIndex);
		g_bRecEnabled   = false;
		g_bPlayEnabled  = false;
		g_bPauseEnabled = false;

                if (null != g_recordingTimer)
                {
                        clearTimeout(g_recordingTimer);
                }
	}

	tourStopFunction(false);
}

function SubmitAll()
{
	var bValid = true;
    	var patrolSeqParam = "";
	var tourPresetIndexList = "";
	var tourDwellingList = "";

	$("#ajaxLoadIcon2").show();

	// We allow to delete preset positions without new a named patrol
	// If the user does not delete any preset position, they have to input the name to save the patrol setting.
	if ( "" == g_delPresetLocSeq)
	{
		if (checkTourName() == false)
		{
			$("#ajaxLoadIcon2").fadeOut(1000);
			return false;
		}
	}

	var bValid = true;
    	$("#table-patrol tr").each(function(idx, obj){
        	if (checkNumRange($(this).find(":text")[0], 999, 0) == -1)
        	{
            		bValid = false;
			return false; //break the loop
        	}
		if (true == bValid)
		{
			tourPresetIndexList += $(obj).find(".patrolindex").text() + ",";
			tourDwellingList += $(this).find(":text").val() + ",";
		}
    	});
	if (false == bValid)
	{
		$("#ajaxLoadIcon2").fadeOut(1000);
		return false;
	}

	patrolSeqParam += "camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_name=" + encodeURIComponent($("#tourNameInput").val());
	patrolSeqParam += "&camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_speed=" + $("#tourSpeed select").val();
	patrolSeqParam += "&camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_type=" + g_tourSetType;

	if (1 == g_tourSetType)
	{
		patrolSeqParam += "&camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_checklist=" + escape(tourPresetIndexList);
		patrolSeqParam += "&camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_dwelltime=" + escape(tourDwellingList);
    	}
	else
	{
		if ($("#tourDwellInput").val() < 1 || $("#tourDwellInput").val() > 999)
		{
        		alert(translator("please_input_a_valid_value") + "[" + 1 + " ~ " + 999 + "]");
        		$("#tourDwellInput").select();
        		$("#tourDwellInput").focus();
			$("#ajaxLoadIcon2").fadeOut(1000);
            		return false;
		}
		
		// Stop the recording/playing function directly when user want to save current setting.
                SubmitResetRecord();

		patrolSeqParam += "&camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_dwelltime=" + $("#tourDwellInput").val();
	}

	var delpreset_func = function(delPresetLocSeq) {
  	      $.ajax({
			url: "/cgi-bin/operator/preset.cgi",
           	 	type: "GET",
           	 	dataType: "script",
                        cache: false,
            		async: true,
           	 	data: "delpos=" + encodeURIComponent(delPresetLocSeq.join(',')),
            		success: function() {
                		if(getWaitFlag_func())
                		{
                        		isDeletePreset --;
					cleanWaitFlag_func();
                		}
                		if (0 == isDeletePreset)
				{
                        		//Update patrol info after deleting preset list.
					setparam_func();
				}
			},
            		error: function() {
            		
			}
        	});
	}

	var redirect_func = function() {
		var newParams = "camctrl_c"+giCH_Curr+"_preset&camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex;
       		$.ajax({
           		url: "/cgi-bin/admin/getparam.cgi",
                    	type: "GET",
                	dataType: "script",
                	cache: false,
              		async: false,
                     	data: newParams,
                	success: function(result) {
                   		eval(result);
				if (1 == eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_type"))
				{
                          		initPrestAndPatrolBlk();
				}
           		}
		});		
	}

	var setparam_func = function() {
		var sendData = patrolSeqParam;
		$.ajax({
				url: "/cgi-bin/admin/setparam.cgi",
				type: "GET",
				dataType: "script",
                        	cache: false,
				async: false,
				data: sendData,
				success: function() {
					if(getWaitFlag_func())
                			{
                        			isDeletePreset --;
						cleanWaitFlag_func();
                			}
					if (isDeletePreset < 0)
					{
						for (i = 0; i < g_delPresetCount; i++)
						{					
                					$('.sel_gotoPreset option').each(function() {
                        					if ($(this).text() == g_delGotoOptions[i])
                        					{
                                					$(this).remove();
                        					}
                					})
						}

						redirect_func();
						initURLCmdBuff();
						$("#ajaxLoadIcon2").fadeOut(1000);
						$.unblockUI();
					}
				},
				error: function() {
					initURLCmdBuff();
					$("#ajaxLoadIcon2").fadeOut(1000);
					$.unblockUI();
				}
		});
	}
	
	var getWaitFlag_func = function() {
		if (waitflag)
		{
			setTimeout("setFlag_func()", 1000);
		}
		else
		{	
			waitflag = 1;
			return 1;
		}
	}
	
	var cleanWaitFlag_func = function() {
                waitflag = 0;
        }

	/*
     	 * Note: We should set preset.cgi first, then setparam.cgi?camctrl_xxx
     	 *       Because setparam.cgi?camctrl_c0_patrl_xxx will send SIGUSR1 to ptzctrl,
     	 *       ptzctrl will reconfig patrol information. 
    	 *
     	 *       If we setparam.cgi?camctrl_xxx first, then ptzctrl reconfig still in progress, 
     	 *       thus PTHIS->szPatrolName is not update to date, 
     	 *       so it would cause ptzctrl->PTZCTRL_DeletePatrol() miss removing non-exist loations. 
     	 */

    	var isDeletePreset = 0; // >=1 Update all value of PTZ, 0: Only update patrol and misc settings
    	var waitflag = 0;

	// Stop current patrol before changing preset and patrol list.
	CamControl('auto', 'stop');

    	// Delete preset and related patrol locations. 
    	if ( "" != g_delPresetLocSeq)
    	{
		if(getWaitFlag_func())
        	{
        		isDeletePreset += (g_delPresetGroupCnt + 1);
			cleanWaitFlag_func();
        	}

		//blockUI();
	        $.blockUI({ message: $('#notification'), css: {border: '0px', left: '5%', width: '90%'}});
        	showRemovePresetNotification(g_delPresetCount);
	
		for(var i = 0; i <= g_delPresetGroupCnt; i++)
		{
			delpreset_func(g_delPresetLocSeq[i]);
		}
    	}
    	else
    	{
       		//Setting patrol locations and misc settings!
       		setparam_func();
    	}

	if ($("#table-preset tbody > tr").size() < MAX_PRESET_COUNT)
	{
		document.add.Submit2.disabled = false;
	}
	else
	{
		document.add.Submit2.disabled = true;
	}

	return true;
}

jQuery.fn.labelOver = function(overClass) {
    return this.each(function(){
        var label = jQuery(this);
        var f = label.attr('for');
        if (f) {
            var input = jQuery('#' + f);
            
            this.hide = function() {
                label.css({ textIndent: -10000 });
                $(this).nextAll(":button").css("visibility", "visible");
            };
            
            this.show = function() {
                if (input.val() == '') {
                    label.css({ textIndent: 0 });
                    $(this).nextAll(":button").css("visibility", "hidden");
                } 
            };

            // handlers
            input.focus(this.hide);
            input.blur(this.show);
            label.addClass(overClass).click(function(){ input.focus(); });
            
            if (input.val() != '') this.hide(); 
        }
    });
};

jQuery.fn.hasScrollbar = function() {
    var scrollHeight = this.get(0).scrollHeight - 2; //2px for Top & Bottom border width

    //safari's scrollHeight includes padding
    if ($.browser.safari)
        scrollHeight -= parseInt(this.css('padding-top')) + parseInt(this.css('padding-bottom'));

    if (this.height() < scrollHeight)
        return true;
    else
        return false;
};

function KeyPress(evt)
{
    	var code = window.event?evt.keyCode:evt.which;
	if (code == 13)
        {
        return false;
        }
}

function getParamFromURL(paramName)
{
	return decodeURIComponent((new RegExp('[?|&]' + paramName + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null
}

function includeClear(targetFile)
{
        var includeList = document.getElementsByTagName("script");
        var iLastIndex = includeList.length;
        var bClearAll = (targetFile)?false:true;

        for (iLastIndex; iLastIndex >= 0; iLastIndex--)
        {
                if (includeList[iLastIndex]
                    && includeList[iLastIndex].getAttribute("src") != null
                    && ((bClearAll)?bClearAll:(includeList[iLastIndex].getAttribute("src").indexOf(targetFile) != -1)))
                {
                        includeList[iLastIndex].parentNode.removeChild(includeList[iLastIndex]);
                }
        }
}

function nextStep(bFromModify)
{
	if (document.getElementsByName("tourType")[0].checked)
	{
		document.getElementById('confSubpageTitle').innerText = translator("add_a_recorded_patrol");

		g_tourSetType = 0;
		// Show tourRecordPage
		document.getElementById("tourRecordPage").style.display = "block";
		// Show setting forms
		document.getElementById("tourInterval").style.display = "block";
		// Show tour record/play button
		initTourRecordBtn();
		// Show the previous setting if it comes from modify mode.
		if (true == bFromModify)
		{
			document.getElementById("tourNameInput").value = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_name");
			document.getElementById("tourDwellInput").value = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_dwelltime");
		}
		else
		{
			$('label.preTour').labelOver('overlay').show();
		}
	}   
	else
	{
		document.getElementById('confSubpageTitle').innerText = translator("add_a_preset_patrol");

		g_tourSetType = 1;
		// Show tourPresetPage
		document.getElementById("tourPresetPage").style.display = "block";
		// Show setting forms
		document.getElementById("tourSpeed").style.display = "block";
		// Dynamically adjust "left" value because of multilingual issue
		initPrestAndPatrolBlk();
        	// Show More/Less button if ScrollBar appears.
        	presetSclBarDetect();
        	patrolSclBarDetect();
        	$("label.overlay").css("left", $("#presetNameID").width() + 15);
		// Show the previous setting if it comes from modify mode.
		if (true == bFromModify)
		{
			document.getElementById("tourNameInput").value = eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_name");
			$("#tourSpeed select").val(eval("camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_speed"));
		}
		else
		{
			$('label.preTour').labelOver('overlay').show();
		}
	}

	document.getElementById("selectPage").style.display = "none";
	document.getElementById("tourNewName").style.display = "block";
	document.getElementById("tourSubmit").style.display = "block";
	document.getElementById("tourPannel").style.display = "block";
	// showimage should always apear after showing html page
	showimage_innerHTML('13', 'showimageBlock', false, true, true, 0);
}

function initTourRecordBtn()
{
	// Set up the handler
        var tourBtnObj = document.getElementById("tourRecordBtn-bar").getElementsByTagName("button");
        for (i = 0; i < tourBtnObj.length; i++)
        {
                addEventSimple(tourBtnObj[i], 'mouseover', tourRecordBtnHandler);
                addEventSimple(tourBtnObj[i], 'mouseout', tourRecordBtnHandler);
                addEventSimple(tourBtnObj[i], 'mousedown', tourRecordBtnHandler);
                addEventSimple(tourBtnObj[i], 'mouseup', tourRecordBtnHandler);
        }

	// Reset the button state
	document.getElementById("btn_record").disabled = false;
	document.getElementById("btn_record").style.backgroundPosition = "-192px 0px";
	if (g_tourSetMode == "add")
	{
		document.getElementById("btn_play").disabled = true;
		document.getElementById("btn_play").style.backgroundPosition = "-64px -72px";
		document.getElementById("btn_stop").disabled = true;
		document.getElementById("btn_stop").style.backgroundPosition = "-128px -72px";
		g_bRecEnabled	= false;
		g_bPlayEnabled	= false;
		g_bPauseEnabled	= false;
	}
	else
	{
		document.getElementById("btn_play").disabled = false;
		document.getElementById("btn_play").style.backgroundPosition = "-64px 0px";
		document.getElementById("btn_stop").disabled = true;
		document.getElementById("btn_stop").style.backgroundPosition = "-128px -72px";
		g_bRecEnabled	= false;
		g_bPlayEnabled	= false;
		g_bPauseEnabled	= false;
	}
}

function tourRecordBtnHandler(event)
{
        var object = event.srcElement?event.srcElement:event.target;

	if (object.clientWidth != object.offsetWidth || object.disabled == true)
                return;

	X = parseInt(object.style.backgroundPosition.split(" ")[0]).toString(10);
	if (event.type == "mousedown")
	{
		object.style.backgroundPosition = X + "px " + -2 * object.offsetHeight + "px";
		if (document.all)
			object.hideFocus = true;
		else
			return;
	}
	else if (event.type == "mouseover" || event.type == "mouseup")
	{
		object.style.backgroundPosition = X + "px " + -object.offsetHeight + "px";
	}
	else//(e=="mouseout")
	{
		object.style.backgroundPosition = X + "px " + "0px";
	}
}

function tourRecordTimeout()
{
	// 1. Stop recording ptzctrl
	tourRecordFunction();
	// 2. Send the notification
	if (g_recordingTimeup == 120000)
	{
		msg = translator("timeout_2min_recorded_patrol_msg");
	}
	else if (g_recordingTimeup == 60000)
	{
		msg = translator("timeout_1min_recorded_patrol_msg");
	}
	else
	{
		msg = translator("timeout_10min_recorded_patrol_msg");
	}
	alert(msg);
}

function tourRecordFunction()
{
	var object_record = document.getElementById("btn_record");
	var object_play = document.getElementById("btn_play");
	var object_stop = document.getElementById("btn_stop");
	if (true == g_bRecEnabled)
	{
		object_record.style.backgroundPosition = "-192px 0px";
		object_play.disabled = false;
		object_play.style.backgroundPosition = "-64px 0px";

		$.get("/cgi-bin/camctrl/camctrl.cgi?recorded=" + g_tourIndex);
		g_bRecEnabled	= false;
		g_bPlayEnabled	= false;
		g_bPauseEnabled	= false;

		if (null != g_recordingTimer)
		{
			clearTimeout(g_recordingTimer);
		}

		dwelltime = "camctrl_c"+giCH_Curr+"_tour_i" + g_tourIndex + "_dwelltime=" + $("#tourDwellInput").val();
		$.get("/cgi-bin/admin/setparam.cgi?"+dwelltime);
	}
	else
	{
		if (false == document.getElementById("btn_play").disabled)
		{
			msg = translator("overwrite_recorded_patrol_msg");
			if(!confirm(msg))
			{
				return;
			}
		}

		object_record.style.backgroundPosition = "-256px 0px";
		object_play.disabled = true;
		object_play.style.backgroundPosition = "-64px -72px";
		object_stop.disabled = true;
		object_stop.style.backgroundPosition = "-128px -72px";

		$.get("/cgi-bin/camctrl/camctrl.cgi?recording=" + g_tourIndex);
		g_bRecEnabled	= true;
		g_bPlayEnabled	= false;
		g_bPauseEnabled	= false;

		g_recordingTimer = setTimeout('tourRecordTimeout()', g_recordingTimeup);
	}
}

function tourPlayFunction()
{
        var object_record = document.getElementById("btn_record");
        var object_play = document.getElementById("btn_play");
        var object_stop = document.getElementById("btn_stop");
    	if (true == g_bPlayEnabled)
    	{
        	object_play.style.backgroundPosition = "-64px 0px";
                object_stop.disabled = true;
                object_stop.style.backgroundPosition = "-128px -72px";
		object_record.disabled = false;
		object_record.style.backgroundPosition = "-192px 0px";

		$.get("/cgi-bin/camctrl/camctrl.cgi?tour=pause" + g_tourIndex);
        	g_bRecEnabled	= false;
		g_bPlayEnabled	= false;
		g_bPauseEnabled	= true;
    	}
    	else
    	{
        	object_play.style.backgroundPosition = "0px 0px";
                object_stop.disabled = false;
                object_stop.style.backgroundPosition = "-128px 0px";
		object_record.disabled = true;
		object_record.style.backgroundPosition = "-192px -72px";
		if (true == g_bPauseEnabled)
		{
			$.get("/cgi-bin/camctrl/camctrl.cgi?tour=review");
		}
		else
		{
			$.get("/cgi-bin/camctrl/camctrl.cgi?tour=preview" + g_tourIndex);
		}
        	g_bRecEnabled	= false;
		g_bPlayEnabled	= true;
		g_bPauseEnabled	= false;
    	}
}

function tourStopFunction(bDirectCtrl)
{
	if (true == g_bPlayEnabled)
        {
        	var object_record = document.getElementById("btn_record");
        	var object_play = document.getElementById("btn_play");
        	var object_stop = document.getElementById("btn_stop");

		object_record.disabled = false;
		object_record.style.backgroundPosition = "-192px 0px";        
		object_play.disabled = false;
		object_play.style.backgroundPosition = "-64px 0px";
		object_stop.disabled = true;
		object_stop.style.backgroundPosition = "-128px -72px";
		if (false == bDirectCtrl)
		{
			$.get("/cgi-bin/camctrl/camctrl.cgi?auto=stop");
		}
		g_bRecEnabled	= false;
		g_bPlayEnabled	= false;
		g_bPauseEnabled	= false;
	}
}

function positionCallback(x, y)
{
	x = parseInt(x, 10);
	y = parseInt(y, 10);
	var z = Math.abs(x);
	if(((Date.now() - g_lastMove) > 100) || (x == 0 && y == 0)) {
		if(Math.abs(y) > Math.abs(x))
		{
			z = Math.abs(y)
		}
		$.ajax({url:"/cgi-bin/camctrl/camctrl.cgi?vx="+x+"&vy="+(-y)+"&vs="+z,async:true});
		g_lastMove = Date.now();
	}
}

function JoystickInit()
{
	//for joystick ctrl and drawing line
	$('#joystickDiv').joystick({"width":522, "height":298, "pathColor":"#45E678", "virtualPositionEasing":"easeOutCirc", "virtualPositionMaxXValue":capability_ptz_panspeedlv*0.7, "virtualPositionMaxYValue":capability_ptz_tiltspeedlv*0.7}, positionCallback);

	//for zoom in/out by mouse wheel
	$('#joystickDiv').bind('mousewheel DOMMouseScroll', function(e) {
		var scrollTo = null;

		e.preventDefault();
		if (e.type == 'mousewheel') {
			scrollTo = (e.originalEvent.wheelDelta * -1);
		}
		else if (e.type == 'DOMMouseScroll') {
			scrollTo = 40 * e.originalEvent.detail;
		}

		if (scrollTo > 0)
		{
		$.ajax({url:"/cgi-bin/camctrl/camctrl.cgi?zoom=wide&zs="+scrollTo,async:true});
		}
		else if (scrollTo < 0)
		{
		$.ajax({url:"/cgi-bin/camctrl/camctrl.cgi?zoom=tele&zs="+Math.abs(scrollTo),async:true});
		}
	});

}

function CheckControlMode()
{
	JoystickInit();

	//when select another option
	$("#ptzControlMode").change(function() {
		if (this.value == "joystick")
		{
			$('#joystickDiv').show();
			document.getElementById(PLUGIN_ID).ClickEventHandler=0;
		}
		else
		{
			$('#joystickDiv').hide();
			document.getElementById(PLUGIN_ID).ClickEventHandler=3;
		}
	});

	$(document).ready(function() {
		$("#ptzControlMode").change();
	});
}

var tidSubmitPresetPre = null;
var waitSlideLatency = 500;
function SubmitPreset(selObj)
{
        if (tidSubmitPresetPre != null) {
		clearTimeout(tidSubmitPresetPre);
	}
        tidSubmitPresetPre = setTimeout(function() {
		var CGICmd='/cgi-bin/camctrl/recall.cgi?recall=' + encodeURIComponent($(selObj).selectedOptions().text());
                $.ajaxSetup({ cache: false, async: true});
                $.get(CGICmd)
                Log("Send: %s",CGICmd);
	}, waitSlideLatency);
}

function getFocusSettingNaming(value)
{
	var szReturn = translator("null");
	switch(value)
	{
		case "sync":
			szReturn = translator("apply_focus_mode");
			break;
		case "fixcurrent":
			szReturn = translator("fix_current_focus");
			break;
		default:
			break;
	}
	return szReturn;
}

function genPresetFocusSelectionToTable(selectedValue)
{
	var arrItem = ["sync", "fixcurrent"];
	var strBuffer = "";
	for (var i = 0; i < arrItem.length; i++)
	{
		var optionName = getFocusSettingNaming(arrItem[i]);
		if (arrItem[i] == selectedValue) 
		{
			strBuffer = strBuffer + "<option selected value='" + arrItem[i] + "'>" + optionName + "</option>"
		}
		else
		{
			strBuffer = strBuffer + "<option value='" + arrItem[i] + "'>" + optionName + "</option>"
		}
	}

	return strBuffer;
}

function changePresetFocus(obj)
{
	var tmpIndex = obj.id.split("_");
	var strName = "";
	var strData1 = "camctrl_c" + giCH_Curr + "_preset_i" + tmpIndex[1] + "_name";
	var strData2 = "";

	var getNewPresetName = function() {
		$.ajax({
			url: "/cgi-bin/admin/getparam.cgi",
			cache: false,
			async: false,
			type: "POST",
			dataType: "script",
			data: strData1,
				success: function(result) {
					strName = eval(result);
				},
				error: function() {
					// Do nothing
				}
		});
	}

	var setPresetFocusOption = function() {
		$.ajax({
			url: "/cgi-bin/camctrl/camctrl.cgi",
			cache: false,
			async: false,
			type: "POST",
			dataType: "script",
			data: strData2,
				success: function(result) {
					eval(result);
				},
				error: function() {
					// Do nothing
				}
		});
	}

	getNewPresetName();

	sleep(500);
	strData2 = "name="+ strName + "&focussetting=" + obj.value + "&cam=getsetpreset";
	setPresetFocusOption();
}
