var giCH_Curr = 0;
var giTab_Curr = 0;
var giTargetStream;
var stack_bottomright = {"dir1": "up", "dir2": "left", "firstpos1": 15, "firstpos2": 15};
var giTabHeight = 400;
var Width, Height;
var gImgW = 320;
var gImgH = 240;
var bRotate = false;

function checkRotate()
{
	if( eval("capability_videoin_c" + giCH_Curr + "_rotation") == 1 )
	{
		if( eval("videoin_c" + giCH_Curr + "_rotate") == 90 || eval("videoin_c" + giCH_Curr + "_rotate") == 270 )
		{
			bRotate = true;
		}
	}
}

function submitform(a, b, iChanIndex)
{
    updatecheck(a, b);

    if (b.checked)
		eval("motion_c"+iChanIndex+"_enable=1");
    else
		eval("motion_c"+iChanIndex+"_enable=0");

	/* Enable motion detection notify message
	var avMLLangStr = "Enable motion detection completed";
	$.pnotify({
		pnotify_title: 'Motion Detection',
		pnotify_text: avMLLangStr,
		pnotify_notice_icon: 'ui-vadp-icon ui-vadp-icon-signal',
		pnotify_opacity: .8,
		pnotify_addclass: "stack-bottomright",
		pnotify_history: false,
		pnotify_stack: stack_bottomright
	});
	*/
	
    document.forms[0].submit();
}

function loadCurrentSetting()
{	
	var loadStr="&motion_c"+giCH_Curr+"_enable&videoin_c"+giCH_Curr+"&capability_videoin_c"+giCH_Curr+"_rotation";

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&capability_nmediastream"+loadStr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("motion_detection");

	$("div.tabs").css("display","block");
	
	loadlanguage();
}

function receivedone()
{
	giTargetStream = FullviewStreamIndex();
	eval("VideoSize=videoin_c"+ giCH_Curr + "_s" + giTargetStream + "_resolution");
	Width = VideoSize.split("x")[0];
	Height = VideoSize.split("x")[1];
	
	gImgH = gImgW * Height / Width;
	
	checkRotate();
	
	if(bRotate)
	{
		eval(swap('gImgH', 'gImgW'));
	}
	
	giTabHeight = giTabHeight + (gImgH - 240);
	
	setCookie("motionprofileindex", 0);
	$('#tab0').append("<iframe id='motion_tab' src='/setup/application/motion_tab.html' width='100%' height='" + giTabHeight + "px' scrolling=no frameborder=0></iframe>");
	tabsUI(0);
}

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
}

function changeTab(idx)
{
	if (giTab_Curr == parseInt(idx, 10))
	{
		return;
	}

	giTab_Curr = parseInt(idx, 10);
	
	$('.tab-content iframe').attr("src", "");
	$('.tab-content iframe').remove();

	setCookie("motionprofileindex", idx);
	$('#tab'+idx).append("<iframe id='motion_tab' src='/setup/application/motion_tab.html' width='100%' height='" + giTabHeight + "px' scrolling=no frameborder=0></iframe>");
}