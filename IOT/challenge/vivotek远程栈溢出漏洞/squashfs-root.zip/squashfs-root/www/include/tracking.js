
var channelsource = 0;
var streamsource = 2; //update by getLastStreamSource()
var WinLessPluginCtrl;
eval(location.search.toString().slice(1));  //channelsource=X

// for iva analytics
var enumShapeId = {
	"minObjRect" : 0,
	"ROI" : 1 };
	
//minObject, roi-field
var arRectColor = ['rgba(0,255,0,1)', 'rgba(255,0,0,0.2)'];

// for tracking
var gSensitivity_low = 30;
var gSensitivity_medium = 60;
var gSensitivity_high = 80;
var gSensitivity_min = 0;
var gSensitivity_max = 100;
var gSensitivity_default = 30;
var gMinObjWdRatio = 1.56;
var gMinObjHtRatio = 1.56;

//---object size: limit value setting base on 320x240
var gRatio = 10000;
var gProcImgWidth;
var gProcImgHeight;

// shapes UI
var gShapesArray = null;
var gFieldPoints = null;

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

function getLastStreamSource()
{
	eval("streamnum=capability_nmediastream");
	streamsource = parseInt(streamnum)-1;
	
	eval("codectype=videoin_c0_s" + streamsource + "_codectype");

	if (codectype == "mjpeg")
		eval("AccessName=network_http_s" + streamsource + "_accessname");
	else //(codectype == "mpeg4") || (codectype == "h264")
		eval("AccessName=network_rtsp_s" + streamsource + "_accessname");
}

function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?privacymask&videoin&network&status_videomode&capability&ivas", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	
	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};
	
	// get valid stream source
	getLastStreamSource();
		
	//updata 
	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;
			
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];
		
		if(!type || compare(type.description, plugin.description)) {
			xpi = plugin.xpi;
		}
	
		if(xpi) {
			window.InstallTrigger.install(xpi);
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');
		}
	}
	
	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}

	$('#InstallerArea').hide();
	document.title=translator("tracking");
	loadlanguage();
    //$("#test").dialog({height: 350, width: 600});  //showimage_in('1');
	showimage_innerHTML('8', 'showimageBlock', false, true, false, 0);
	
	var heightOverWidth;

	if(Width == Height) //fisheye
		heightOverWidth = 1;
	else //1080p, resize to 4:3
		heightOverWidth = 3/4;
		
	resizeView(heightOverWidth);
	
    if (bIsWinMSIE || ffversion >= 3)
	{		
        //openChannel()
        $("#StreamContainer").addClass("StreamContainerStyle");
        
		WinLessPluginCtrl = document.getElementById(PLUGIN_ID);
		setTimeout("WinLessPluginCtrl.PlayMute = true", 1);
		
    }
    parent.$("#ajax-loader").show(); 
   
    //draw object size rectangle
	gShapesArray = new ShapesArray('canvas2', getSelectedRect, true);

}
function loadCurrentSettingsss()
{
	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};

	$('#InstallerArea').hide();

	document.title=translator("tracking");
	loadlanguage();
    //$("#test").dialog({height: 350, width: 600});  //showimage_in('1');
	showimage_innerHTML('8', 'showimageBlock', false, true, false, 0);
	
	var heightOverWidth;

	if(Width == Height) //fisheye
		heightOverWidth = 1;
	else //1080p, resize to 4:3
		heightOverWidth = 3/4;
		
	resizeView(heightOverWidth);

	if (bIsWinMSIE)
	{
		  $("#imagecoverBlock").css("background-color","#FFFFFF");
		  $("#imagecoverBlock").css("opacity","0.01");
	}

	//$(document).keydown(function(event){return noNumbers(event)}); //Click on Image for Keyboard.
    if (bIsWinMSIE || ffversion >= 3)
	{
        //openChannel()
        $("#StreamContainer").addClass("StreamContainerStyle");
        $('#imagecoverBlock').css('width', $("#StreamContainer").width()- X_OFFSET + "px");
		$('#imagecoverBlock').css('height', $("#StreamContainer").height() - Y_OFFSET + "px");

		receivedone();
		loadvalue();
	
    }
    gShapesArray = new ShapesArray('canvas2', getSelectedRect, true);
}

var time_shift = 0;
function receivedone()
{
    if (bIsWinMSIE || ffversion >= 3)
    {    	
    	$("#slider_sensitivity").slider({
            min: gSensitivity_min,
            max: gSensitivity_max,
            animate: true,
            range: "min",
            slide: function(event, ui)
            {
                document.getElementById('IVA_sensitivity_value').value = ui.value;
            },
            change: function(event, ui)
            {
                document.getElementById('IVA_sensitivity_value').value = ui.value;
            }							
        });
        
        $("#JSPlugin").show();
    }	
}

function parseStringToPoints(strPoints)
{
	var tmpFieldPoint = new Array();
	var atVal = strPoints.split(',');
	if (atVal.length < 6)
	{
		alert("get_invalid_roi");
		return;
	}
	var x, y;
	for (var i = 0; i < atVal.length; i+=2)
	{
		x = parseInt(atVal[i]);
		y = parseInt(atVal[i+1]);
		var pt = new jsPoint(x, y);
		tmpFieldPoint.push(pt);
	}
	return getRatioToImgSize(tmpFieldPoint, gProcImgWidth, gProcImgHeight, gRatio);
	
}

function loadvaluedone()
{	
    var iIndex;
    
    if (bIsWinMSIE || ffversion >= 3)
    {
        //sensitivity  
		var sensitivity_val = getParamToRatio(eval('ivas_c0_objtrack_sensitivity'), gRatio, gSensitivity_max);
		$('#slider_sensitivity').slider('option', 'value', eval('sensitivity_val'));
		document.getElementById('IVA_sensitivity_value').value = sensitivity_val;
		updateSensitivityLevel(sensitivity_val);
		
		updateMinObjSize();
		
		//for UI draw field region
		gFieldPoints = parseStringToPoints(eval('ivas_c0_objtrack_win_i0_polygon'));
		addField(gFieldPoints);
    }
}

function getSelectedRect(baseshape, wd, ht)
{
	switch (baseshape.id)
	{
		case enumShapeId.minObjRect:
			document.getElementById('IVA_minobjwidth_id').value = getPixelToPercentRatio(wd, gProcImgWidth); 
			document.getElementById('IVA_minobjheight_id').value = getPixelToPercentRatio(ht, gProcImgHeight);
			break;
		case enumShapeId.maxObjRect:
			document.getElementById('IVA_maxobjwidth_id').value = getPixelToPercentRatio(wd, gProcImgWidth);
			document.getElementById('IVA_maxobjheight_id').value = getPixelToPercentRatio(ht, gProcImgHeight);
			break;
		case enumShapeId.ROI:
			break;
	}
}

function submitform(a, b)
{
    updatecheck(a, b);
    document.forms[0].submit();
}

function enterObjSize(obj, e)
{
	// look for window.event in case event isn't passed in 
    if (typeof e == 'undefined' && window.event) { e = window.event; } 
    if (e.keyCode == 13) 
    { 
		blurWin(obj);
    } 
}

function checkObjSize(obj, min, max)
{
	if (checkFloatNumChar(obj) < 0)
	{
		obj.value = min;
	}
	else
	{
		var objval = parseFloat(obj.value);
		if (objval == "" || objval < min)
		{
			obj.value = min;
		}
		else if(objval > max)
		{
			obj.value = max;
		}
	}
}
function blurWin(obj)
{
	checkObjSize(document.getElementById('IVA_minobjwidth_id'), gMinObjWdRatio, 100);
	checkObjSize(document.getElementById('IVA_minobjheight_id'), gMinObjHtRatio, 100);	
	var objwd = parseFloat(document.getElementById('IVA_minobjwidth_id').value);
	var objht = parseFloat(document.getElementById('IVA_minobjheight_id').value);
	
	var wdPixel = getParamToPixel(objwd, gProcImgWidth, 100);
	var htPixel = getParamToPixel(objht, gProcImgHeight, 100);
	
	gShapesArray.updateRectSizeById(0, wdPixel, htPixel);
}

function updateSensitivityLevel(value)
{
	if (value == gSensitivity_low)
	{
		changeSensitivityLevel("low", gSensitivity_low);
	}
	else if (value == gSensitivity_medium)
	{
		changeSensitivityLevel("medium", gSensitivity_medium);
	}
	else if (value == gSensitivity_high)
	{
		changeSensitivityLevel("high", gSensitivity_high);
	}
	else
	{
		value = parseInt(document.getElementById('IVA_sensitivity_value').value);
		changeSensitivityLevel("customize", value);
	}
}

function rectToPointArr(x, y, w, h)
{
	var arPts = new Array();
	arPts.push(new jsPoint(x, y));
	arPts.push(new jsPoint(x + w, y + h));
	return arPts;
}

function updateMinObjSize()
{
	var minObjSize = eval('ivas_c0_objtrack_objsize');
	var atVal = minObjSize.split(',');
	if (atVal.length != 2)
	{
		alert("get invalid min object size");
		return;
	}
	//min object size
    var minObjWdPixel = getParamToPixel(parseInt(atVal[0]), gProcImgWidth, gRatio);
    var minObjHtPixel = getParamToPixel(parseInt(atVal[1]), gProcImgHeight, gRatio);
    
    document.getElementById('IVA_minobjwidth_id').value = getPixelToPercentRatio(minObjWdPixel, gProcImgWidth); 
    document.getElementById('IVA_minobjheight_id').value = getPixelToPercentRatio(minObjHtPixel, gProcImgHeight);
    
    var ptArr = rectToPointArr((gProcImgWidth-minObjWdPixel)/2, (gProcImgHeight-minObjHtPixel)/2, minObjWdPixel, minObjHtPixel);
    var isFillRect = false;
	gShapesArray.add(enumShapeId.minObjRect, eShapeType.Rectangle, arRectColor[enumShapeId.minObjRect], ptArr, isFillRect);
}

function changeSensitivityLevelClick(level)
{
	switch (level)
	{
		case "customize":
			changeSensitivityLevel("customize", gSensitivity_default);
			break;
		case "low":
			changeSensitivityLevel("low", gSensitivity_low);
			break;
		case "medium":
			changeSensitivityLevel("medium", gSensitivity_medium);
			break;
		case "high":
			changeSensitivityLevel("high", gSensitivity_high);
			break;
	}
}

function changeSensitivityLevel(level, value)
{
	$('#IVA_sensitivity_value').css("display", "none");
	$('#slider_sensitivity').css("display", "none");
	var sensitivity_val = value;
	switch (level)
	{
		case "customize":
			$('#IVA_sensitivity_value').css("display", "inline");
			$('#slider_sensitivity').css("display", "block");
			document.getElementById('sensitivity-level').value = "customize";
			break;
		case "low":
			document.getElementById('sensitivity-level').value = "low";
			break;
		case "medium":
		document.getElementById('sensitivity-level').value = "medium";
			break;
		case "high":
			document.getElementById('sensitivity-level').value = "high";
			break;
	}
	eval('ivas_c0_objtrack_sensitivity='+sensitivity_val);		
	$('#slider_sensitivity').slider('option', 'value', sensitivity_val);
	document.getElementById('IVA_sensitivity_value').value = sensitivity_val;
}

function checkFloatNumChar(chkValue)
{
	for (i = 0; i < chkValue.value.length; i++)
	{
		c = chkValue.value.charAt(i);
	
		if (c == '.')
		{
			//not do anything
		}
		else if (i == 0 && c == '-')
		{
			//not do anything
		}
		else if (!(c>='0' && c<='9'))
		{
			chkValue.select();
			chkValue.focus();
			return -1;
		}
	}
	return 0;
}


function blurSensitivityValue()
{
	if (checkFloatNumChar(document.getElementById('IVA_sensitivity_value')) >= 0)
	{
    	var sensitivity_val = parseInt(document.getElementById('IVA_sensitivity_value').value);
    	document.getElementById('IVA_sensitivity_value').value = (sensitivity_val < gSensitivity_min)?gSensitivity_min:document.getElementById('IVA_sensitivity_value').value;
    	document.getElementById('IVA_sensitivity_value').value = (sensitivity_val > gSensitivity_max)?gSensitivity_max:document.getElementById('IVA_sensitivity_value').value;
    }
    else
    {
    	document.getElementById('IVA_sensitivity_value').value = gSensitivity_default;
    }
    eval('ivas_c0_objtrack_sensitivity='+document.getElementById('IVA_sensitivity_value').value);		
    $('#slider_sensitivity').slider('option', 'value', eval('ivas_c0_objtrack_sensitivity'));
}

function updateSensitivityValue(e)
{
	// look for window.event in case event isn't passed in 
    if (typeof e == 'undefined' && window.event) { e = window.event; } 
    if (e.keyCode == 13) 
    { 
    	blurSensitivityValue();
    } 
}

function addField(points)
{
	gShapesArray.add(enumShapeId.ROI, eShapeType.Field, arRectColor[enumShapeId.ROI], points, null);
	document.getElementById('btnAddField').disabled = true;
	document.getElementById('btnRemoveField').disabled = false;
}

function removeField()
{
	gShapesArray.remove(eShapeType.Field, enumShapeId.ROI);
	document.getElementById('btnAddField').disabled = false;
	document.getElementById('btnRemoveField').disabled = true;
}

function saveParams()
{
	var minobjwd = parseFloat(document.getElementById('IVA_minobjwidth_id').value);
	var minobjht = parseFloat(document.getElementById('IVA_minobjheight_id').value);
	
	var points = gShapesArray.getShapePointsById(eShapeType.Field, enumShapeId.ROI);
	if (points==null || points.length == 0) // user doesn't define roi
	{
		alert(translator("none_roi"));
		return;
	}
	
	minobjwd = getParamToRatio(document.getElementById('IVA_minobjwidth_id').value, 100, gRatio);
	minobjht = getParamToRatio(document.getElementById('IVA_minobjheight_id').value, 100, gRatio);
	var sensitivity = getParamToRatio(document.getElementById('IVA_sensitivity_value').value, 100, gRatio);
	var strPolygon = getImgSizeToRatioString(points, gProcImgWidth, gProcImgHeight, gRatio);
	
    var params = "";
    
    params += 
    	"ivas_c0_objtrack_sensitivity=" + sensitivity +"&"+
    	"ivas_c0_objtrack_objsize=" + minobjwd +"," + minobjht+"&"+
    	"ivas_c0_objtrack_win_i0_polygon="+strPolygon;

    $.ajax({
        type: "POST",
        cache: false,
        url: "/cgi-bin/admin/setparam.cgi",
        data: params,
        success: function(){
            //alert(translator("save_completed"));
        },
        error: function(){
            //alert(translator("save_failed"));
        }
    });
}

function getImgSizeToRatioString(srcPointList, imageWidth, imageHeight, gRatio)
{
	var strPoints="";
	var x, y;
	for (var i = 0; i < srcPointList.length; i++)
	{
		x = parseInt((srcPointList[i].x * gRatio) / imageWidth);
		y = parseInt((srcPointList[i].y * gRatio) / imageHeight);
		if (strPoints != "")
		{
			strPoints += ",";
		}
		strPoints += x+","+y;
	}
	return strPoints;
}

function getRatioToImgSize(srcPointList, imageWidth, imageHeight, gRatio)
{
	var pointlist = null;
	if (srcPointList != null && srcPointList != "")
	{
		pointlist = new Array();
		for (var i = 0; i < srcPointList.length; i++)
		{
			var pt = new jsPoint(0,0);
			pt.x = parseInt((srcPointList[i].x * imageWidth) / gRatio);
			pt.y = parseInt((srcPointList[i].y * imageHeight) / gRatio);
			pointlist.push(pt);
		}
	}
	return pointlist;
}

function getParamToRatio(param, srcRatio, dstRatio)
{
	return parseInt((parseFloat(param)*dstRatio)/srcRatio);
}

function getPixelToPercentRatio(pixel, imgsize)
{
	return parseFloat(pixel * 100 / imgsize).toFixed(2);
}

function getParamToPixel(param, imgsize, ratio)
{
	var pixel = parseFloat((parseFloat(param) * imgsize)/ratio);
	return pixel;
}

function resizeView(heightOverWidth)
{
	var bStretch = true;
	var procImgWidth = 320;
	var procImgHeight = 320;
	
	tmpWidth = procImgWidth + X_OFFSET;
	tmpHeight = procImgHeight*heightOverWidth + Y_OFFSET;

	g_iStreamWidth = tmpWidth;
	g_iStreamHeight = tmpHeight;

	if(bIsWinMSIE)
		$("#"+PLUGIN_ID)[0].Stretch = bStretch;

	$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
	$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
	$("#showimageBlock").height(tmpHeight).width(tmpWidth).css("overflow","auto");
	
	var canvas = document.getElementById("canvas2");
	gProcImgWidth = canvas.width = tmpWidth - 8;
    gProcImgHeight = canvas.height = tmpHeight - 28;
}
