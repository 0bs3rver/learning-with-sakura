function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&network&capability_protocol_sip", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("streaming_protocols");
	loadlanguage();
}

var i;
var orig_http;
var orig_http_alternate;
var orig_rtsp;
var orig_rtp_video;
var orig_rtp_audio;
//var orig_rtsp_s[n]_video;
for(i=0; i < parseInt(capability_nmediastream,10); i++)
{
	eval('var orig_rtsp_s'+i+'_video');
	eval('var orig_rtsp_s'+i+'_metadata');
	eval('var orig_rtsp_s'+i+'_audio');
}

function receivedone()
{
	GenerateAccessStream();
	JudgeAudioPortExist();
	JudgeTwoWayAudioPortExist();
}
function loadvaluedone()
{
	var hideArray = new Array();
	//  hideArray.push("multicastStream[n]Child");
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		hideArray.push("multicastStream"+eval(i+1)+"Child");
	}

   jQuery.each(hideArray, function(i) { 
     $("#" + hideArray[i]).css("display","none");
   });	
	
	updateparam();

	document.getElementById("content").style.visibility = "visible";

	orig_http = network_http_port;
	orig_http_alternate = network_http_alternateport;
	orig_rtsp = network_rtsp_port;
	orig_rtp_video = network_rtp_videoport;
	orig_rtp_metadata = network_rtp_metadataport;
	orig_rtp_audio = network_rtp_audioport;

	//  orig_rtsp_s[n]_video = network_rtsp_s[n]_multicast_videoport;
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		eval('orig_rtsp_s'+i+'_video = '+eval('network_rtsp_s'+i+'_multicast_videoport'));
		eval('orig_rtsp_s'+i+'_metadata = '+eval('network_rtsp_s'+i+'_multicast_metadataport'));
		eval('orig_rtsp_s'+i+'_audio = '+eval('network_rtsp_s'+i+'_multicast_audioport'));
	}
}

function updateparam()
{
	var netForm = document.streaming_protocol;
	netForm.network_rtcp_videoport.value=parseInt(netForm.network_rtp_videoport.value, 10)+1;
	netForm.network_rtcp_metadataport.value=parseInt(netForm.network_rtp_metadataport.value, 10)+1;
	//if(!ParamUndefinedOrZero("capability_naudioin"))
	{
		netForm.network_rtcp_audioport.value=parseInt(netForm.network_rtp_audioport.value, 10)+1;
	}
	
	//  netForm.network_rtsp_s[n]_multicast_rtcp_videoport.value=parseInt(netForm.network_rtsp_s[n]_multicast_videoport.value, 10)+1;
	//  netForm.network_rtsp_s[n]_multicast_rtcp_audioport.value=parseInt(netForm.network_rtsp_s[n]_multicast_audioport.value, 10)+1;
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		eval('netForm.network_rtsp_s'+i+'_multicast_rtcp_videoport.value = parseInt(netForm.network_rtsp_s'+i+'_multicast_videoport.value, 10)+1');
		eval('netForm.network_rtsp_s'+i+'_multicast_rtcp_metadataport.value = parseInt(netForm.network_rtsp_s'+i+'_multicast_metadataport.value, 10)+1');
		if(!ParamUndefinedOrZero("capability_naudioin"))
		{
			eval('netForm.network_rtsp_s'+i+'_multicast_rtcp_audioport.value = parseInt(netForm.network_rtsp_s'+i+'_multicast_audioport.value, 10)+1');
		}
	}
}

function submitform()
{
	var netForm = document.streaming_protocol;
	var setPortValue = 0;
	
	var https_port = document.createElement("input");
	//var sip_port   = document.createElement("input");
	var ftp_port   = document.createElement("input");
	
	https_port.type = "text";
	//sip_port.type 	= "text";
	ftp_port.type 	= "text";
	
	https_port.value = network_https_port;
	//sip_port.value 	 = network_sip_port;
	ftp_port.value 	 = network_ftp_port;
	
	
	var port = new Array(netForm.network_http_port,                  //0
						 netForm.network_http_alternateport,         //1
						 https_port,				 				 //2
						 netForm.network_sip_port,                  //3
						 ftp_port,                   				 //4
						 netForm.network_rtsp_port,                  //5
						 netForm.network_rtp_videoport,              //6
						 netForm.network_rtcp_videoport,             //7
						 netForm.network_rtp_metadataport,           //8
						 netForm.network_rtcp_metadataport           //9
//						 netForm.network_rtp_audioport,              //8
//						 netForm.network_rtcp_audioport              //9
//                       netForm.network_rtsp_s[n]_multicast_videoport,      //10
					  );					  
	if(!ParamUndefinedOrZero("capability_naudioin")) 
	{
		 port.push(netForm.network_rtp_audioport);  //10
		 port.push(netForm.network_rtcp_audioport); //11
	}
	for(i=0; i < parseInt(capability_nmediastream,10); i++) //10 and so on
	{
		port.push(eval('netForm.network_rtsp_s'+i+'_multicast_videoport'));
		port.push(eval('netForm.network_rtsp_s'+i+'_multicast_rtcp_videoport'));
		port.push(eval('netForm.network_rtsp_s'+i+'_multicast_metadataport'));
		port.push(eval('netForm.network_rtsp_s'+i+'_multicast_rtcp_metadataport'));
		if(!ParamUndefinedOrZero("capability_naudioin"))
		{
			port.push(eval('netForm.network_rtsp_s'+i+'_multicast_audioport'));
			port.push(eval('netForm.network_rtsp_s'+i+'_multicast_rtcp_audioport'));
		}
	}

//    var multicastip = new Array(netForm.network_rtsp_s[n]_multicast_ipaddress,
//						 s4_multicast_ipaddress
//                                           );
	var multicastip = new Array();
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		multicastip.push(eval('netForm.network_rtsp_s'+i+'_multicast_ipaddress'));
	}


	if(checkvalue())
	{
		return -1;
	}
	else
	{
//        if ((CheckEmptyString(netForm.network_http_s[n]_accessname) == -1) ||
//            (CheckEmptyString(netForm.network_rtsp_s[n]_accessname) == -1) ||
//            (CheckEmptyString(netForm.network_rtsp_s[n]_multicast_ipaddress) == -1) ||
//            (CheckEmptyString(netForm.network_rtsp_s[n]_multicast_ttl) == -1) ||
//        )
//        {
//            return -1;
//        }
		for(i=0; i < parseInt(capability_nmediastream,10); i++)
		{
			if((eval('CheckEmptyString(netForm.network_http_s'+i+'_accessname) == -1')) ||
			  (eval('CheckEmptyString(netForm.network_rtsp_s'+i+'_accessname) == -1')) ||
			  (eval('CheckEmptyString(netForm.network_rtsp_s'+i+'_multicast_ipaddress) == -1')) ||
			  (eval('CheckEmptyString(netForm.network_rtsp_s'+i+'_multicast_ttl) == -1'))
			  )
			  {
			  	return -1;
			  }
		}
		// check http and rtsp access name
		if (checkAccessName(netForm))
		{
			return -1;
		}
		if(!ParamUndefinedOrZero("capability_naudioin"))
		{
			if(checkPortEven(netForm.network_rtp_audioport, translator("invalid_port_number_rtp_audio_port_must_be_a_even_number")))
				return -1;
		}
		if(checkPortEven(netForm.network_rtp_videoport, translator("invalid_port_number_rtp_video_port_must_be_a_even_number")))
			return -1;
		if(checkPortEven(netForm.network_rtp_metadataport, translator("invalid_port_number_rtp_metadata_port_must_be_a_even_number")))
			return -1;
//        if(checkPortEven(netForm.network_rtsp_s0_multicast_videoport, translator("invalid_port_number_multicast_stream[n+1]_video_port_must_be_a_even_number")))
//            return -1;
//        if(checkPortEven(netForm.network_rtsp_s[n]_multicast_audioport, translator("invalid_port_number_multicast_stream[n+1]_audio_port_must_be_a_even_number")))
		for(i=0; i < parseInt(capability_nmediastream,10); i++)
		{
			if(eval('checkPortEven(netForm.network_rtsp_s'+i+'_multicast_videoport, translator("invalid_port_number_multicast_stream'+eval(i+1)+'_video_port_must_be_a_even_number"))'))
			{
				return -1;
			}
			if(eval('checkPortEven(netForm.network_rtsp_s'+i+'_multicast_metadataport, translator("invalid_port_number_multicast_stream'+eval(i+1)+'_metadata_port_must_be_a_even_number"))'))
			{
				return -1;
			}
			if(!ParamUndefinedOrZero("capability_naudioin"))
			{
				if(eval('checkPortEven(netForm.network_rtsp_s'+i+'_multicast_audioport, translator("invalid_port_number_multicast_stream'+eval(i+1)+'_audio_port_must_be_a_even_number"))'))
				{
					return -1;
				}
			}
		}
		for (var i = 0; i < port.length-1; i++)
		{
			// Ignore https, ftp, anystream
			if (i == 2 || i == 4 || (i >= 35 && i <= 40))
			{
				continue;
			}

			if(CheckEmptyString(port[i]) == -1)
			{
				return -1
			}
			for(var j=0; j < port.length; j++)
			{
				if (i == j)
				{
					continue;
				}

				if(port[i].value==port[j].value)
				{
					//Sometimes we could not focus successfully on the DOM due to different Tab.
					var tab1 = $(port[i]).parents(".tab-page").attr("id");
					var tab2 = $(port[j]).parents(".tab-page").attr("id");
					if (tab1 != tab2)
					{
						$("a[href=#" + tab1 +"]").click();
					port[i].select();
					port[i].focus();
					}

					switch (i){
					case 0:
						alert(translator("http_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 1:
						alert(translator("secondary_http_port_can_not_be_the_same_as_other_port"));
						return -1;
					/*
					case 2:
						alert(translator("https_port_can_not_be_the_same_as_other_port"));
						return -1;
					*/
					case 3:
						alert(translator("two_way_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					/*
					case 4:
						alert(translator("ftp_port_can_not_be_the_same_as_other_port"));
						return -1;
					*/
					case 5:
						alert(translator("rtsp_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 6:
						alert(translator("rtp_video_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 8:
						alert(translator("rtp_metadata_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 10:
						alert(translator("rtp_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 12:
						alert(translator("rtsp_s0_multicast_video_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 14:
						alert(translator("rtsp_s0_multicast_metadata_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 16:
						alert(translator("rtsp_s0_multicast_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 18:
						alert(translator("rtsp_s1_multicast_video_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 20:
						alert(translator("rtsp_s1_multicast_metadata_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 22:
						alert(translator("rtsp_s1_multicast_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 24:
						alert(translator("rtsp_s2_multicast_video_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 26:
						alert(translator("rtsp_s2_multicast_metadata_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 28:
						alert(translator("rtsp_s2_multicast_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 30:
						alert(translator("rtsp_s3_multicast_video_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 32:
						alert(translator("rtsp_s3_multicast_metadata_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 34:
						alert(translator("rtsp_s3_multicast_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					/*
					case 26:
						alert(translator("rtsp_s4_multicast_video_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 28:
						alert(translator("rtsp_s4_multicast_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					*/
					default:
						alert(translator("invalid_port_number"));						
					}
				}
			}
		}

		for (var o=0; o < multicastip.length-1; o++)
		{
			for (var p=o+1; p < multicastip.length; p++)
			{
				if (multicastip[o].value==multicastip[p].value)
				{
					alert(translator("please_use_different_address_for_multicast_stream"));
					multicastip[o].focus();
					multicastip[o].select();
					return -1;
				}
			}
		}
		
		// Check SIP port confliction
		if (checkSipPort(netForm.network_sip_port))
		{
			netForm.network_sip_port.select();
			netForm.network_sip_port.focus();
			return -1;
		}
			
		// stop related process before set port value
		if ((netForm.network_http_port.value != orig_http) || (netForm.network_http_alternateport.value != orig_http_alternate))
		{
			eval(setPortValue = setPortValue + 1);
		}
		if ((netForm.network_http_alternateport.value != orig_http_alternate))
		{
			eval(setPortValue = setPortValue + 2);
		}
		if 	((netForm.network_rtsp_port.value != orig_rtsp) || (netForm.network_rtp_videoport.value != orig_rtp_video) || (netForm.network_rtp_metadataport.value != orig_rtp_metadata) || (netForm.network_rtp_audioport.value != orig_rtp_audio))
		{
			eval(setPortValue = setPortValue + 8);
		}
		netForm.network_preprocess.value = setPortValue;
		
		orig_http = netForm.network_http_port.value;
		orig_http_alternate = netForm.network_http_alternateport.value;
		orig_rtsp = netForm.network_rtsp_port.value;
		orig_rtp_video = netForm.network_rtp_videoport.value;
		orig_rtp_metadata = netForm.network_rtp_metadataport.value;
		orig_rtp_audio = netForm.network_rtp_audioport.value;
//      orig_rtsp_s[n]_video = netForm.network_rtsp_s[n]_multicast_videoport.value;
		for(i=0; i < parseInt(capability_nmediastream,10); i++)
		{
			eval('orig_rtsp_s'+i+'_video = netForm.network_rtsp_s'+i+'_multicast_videoport.value');
			eval('orig_rtsp_s'+i+'_metadata = netForm.network_rtsp_s'+i+'_multicast_metadataport.value');
			eval('orig_rtsp_s'+i+'_audio = netForm.network_rtsp_s'+i+'_multicast_audioport.value');
		}

		document.streaming_protocol.submit();
	}
}

function checkSipPort(SipPort)
{
	val=SipPort.value;
	if (val == 10000)
	{
		// 10000: DRM
		alert(translator("invalid_port_number") + "(10000)");
		return -1;
	}
	else
	{
		// 8888~8895: RTSP Multicast
		for(j=0; j < 8; j++)
		{
			var k = 8888+j;
			if (val == k)
			{
				alert(translator("invalid_port_number") + "(8888~8895)");
				return -1;
			}
		}
	}
    return 0;
}

function checkAccessName(netForm)
{
//    var input = new Array(netForm.network_http_s[n]_accessname,
//                          netForm.network_rtsp_s[n]_accessname,
//                      )
 	var input = new Array();	
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		input.push(eval('netForm.network_http_s'+i+'_accessname'));
	}
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		input.push(eval('netForm.network_rtsp_s'+i+'_accessname'));
	}
	Http_reserve=jQuery.inArray( netForm.network_http_s2_accessname, input );
	Rtsp_reserve=jQuery.inArray( netForm.network_rtsp_s2_accessname, input );
	
	for (var j=0; j < input.length-1; j++)
	{
		for (var k=input.length-1; k > j; k--)
		{
			if (input[j].value==input[k].value)
			{
				if ( (k == Rtsp_reserve) || (k == Http_reserve) )
				{
					alert(translator("access_name_is_reserved "));
				}
				else
				{
					alert(translator("access_name_for_stream1_can_not_be_the_same_as_other_access_name"));
				}
				input[j].focus();
				input[j].select();
				return -1;
			}
		}
	}
	
	for (var i=0; i < input.length; i++) 
	{
		if (!/^[0-9a-zA-Z_\-\.]+$/.test(input[i].value))
		{
			alert(translator("accessname_can_only_contains_numeric_alpha"));
			input[i].focus();
			input[i].select();
			return -1;
		}
	}
	return 0;
}

function checkPortEven(thisObj, message)
{
	if(thisObj.value=="")
		return 0;
	if ((parseInt(thisObj.value, 10)%2) != 0)
	{
		alert(message);
		return -1;
	}
	return 0;
}

function GenerateAccessStream()
{
	for (iStream = 0; iStream < parseInt(capability_nmediastream, 10) ; iStream++)
	{
		$(document.getElementById("http_streaming")).append(""
		+'<dt id="http_access_name_stream'+eval(iStream+1)+'">'
		+'	<span title="symbol">'+translator("access_name_for_stream"+eval(iStream+1))+'</span>:'
		+'	<input name="network_http_s'+iStream+'_accessname" type="text" class="position" title="param,string,space" size="16" maxlength="32"/>'
		+'</dt>');
	}
	
	for (iStream = 0; iStream < parseInt(capability_nmediastream, 10) ; iStream++)
	{
		$(document.getElementById("rtsp_authentication")).append(""
		+'<dt id="rtsp_access_name_stream'+eval(iStream+1)+'">'
		+'	<span title="symbol">'+translator("access_name_for_stream"+eval(iStream+1))+'</span>:'
		+'	<input name="network_rtsp_s'+iStream+'_accessname" type="text" class="position" title="param,string,space" size="16" maxlength="32"/>'
		+'</dt>');
	}
	
	for (iStream = 0; iStream < parseInt(capability_nmediastream, 10) ; iStream++)
	{
		$(document.getElementById("rtsp_streaming")).append(""
		+'<dt id="multicastStream'+eval(iStream+1)+'Parent" class="pointer" onclick="switchBlock(\'multicastStream'+eval(iStream+1)+'Child\', \'multicastStream'+eval(iStream+1)+'Icon\');">'
		+'  <image id="multicastStream'+eval(iStream+1)+'Icon" src="/pic/rightArrow.gif"/><span title="symbol">'+translator("multicast_settings_for_stream"+eval(iStream+1))+'</span>'
		+'</dt>'
		+'<dt id="multicastStream'+eval(iStream+1)+'Child" style="overflow:hidden;">'
		+'  <table class="dl_dt">'
		+'	<tr>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_alwaysmulticast" type="hidden" title="param"/>'
		+'		<input type="checkbox" onchange="updatecheck(this.form.network_rtsp_s'+iStream+'_multicast_alwaysmulticast, this)"/>'
		+'		<span title="symbol">'+translator("always_multicast")+'</span>'
		+'	  </td>'
		+'	  <td></td>'
		+'	</tr>'
		+'	<tr>'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_group_address")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_ipaddress" type="text" title="param,multicastipaddr" size="16" maxlength="15"/>'
		+'	  </td>'
		+'	</tr>'
		+'	<tr>'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_video_port")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_videoport" type="text" title="param,port" onblur="updateparam()" size="5" maxlength="5"/>'
		+'	  </td>'
		+'	</tr>'
		+'	<tr>'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_rtcp_video_port")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_rtcp_videoport" type="text" disabled="disabled" size="5" maxlength="5"/>'
		+'	  </td>'
		+'	</tr>'	
		+'	<tr>'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_metadata_port")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_metadataport" type="text" title="param,port" onblur="updateparam()" size="5" maxlength="5"/>'
		+'	  </td>'
		+'	</tr>'
		+'	<tr>'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_rtcp_metadata_port")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_rtcp_metadataport" type="text" disabled="disabled" size="5" maxlength="5"/>'
		+'	  </td>'
		+'	</tr>'
		+'	<tr id="multicast_rtp_s'+iStream+'_audio_port">'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_audio_port")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_audioport" type="text" title="param,port" onblur="updateparam()" size="5" maxlength="5"/>'
		+'	  </td>'
		+'	</tr>'
		+'	<tr id="multicast_rtcp_s'+iStream+'_audio_port">'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_rtcp_audio_port")+'</span>:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_rtcp_audioport" type="text" disabled="disabled" size="5" maxlength="5"/>'
		+'	  </td>'
		+'	</tr>'
		+'	<tr>'
		+'	  <td>'
		+'		<span title="symbol">'+translator("multicast_ttl")+'</span>'
		+'		[1~255]:'
		+'	  </td>'
		+'	  <td>'
		+'		<input name="network_rtsp_s'+iStream+'_multicast_ttl" type="text" title="param,num,255,1" size="3" maxlength="3"/>'
		+'	  </td>'
		+'	</tr>'
		+'  </table>'
		+'  </dt>');
	}
}

function JudgeAudioPortExist()
{
	if(ParamUndefinedOrZero("capability_naudioin"))
	{
		$("#network_rtp_audio_port").hide();
		$("#network_rtcp_audio_port").hide();
		for (iStream = 0; iStream < parseInt(capability_nmediastream, 10) ; iStream++)
		{
			eval('$("#multicast_rtp_s'+iStream+'_audio_port").hide()');
			eval('$("#multicast_rtcp_s'+iStream+'_audio_port").hide()');
		}
	}
}

function JudgeTwoWayAudioPortExist()
{
	if(ParamUndefinedOrZero("capability_protocol_sip"))
	{
		document.getElementById("tab_sip").style.display = "none";
	}
}
