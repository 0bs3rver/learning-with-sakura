var MAX_TOUR_COUNT = 20;
var MAX_RECORD_COUNT = 10;

var g_viewportWidth;
var g_viewportHeight;
var g_popwindowWidth;
var g_popwindowHeight;

var g_tourStatus = -1;	// The status will update the id of the enabled setting.
var g_tourNumber = 0;	// The number will update the amount of current setting.
var g_recordNumber = 0;	// The number will update the amount of recorded setting.
var g_recordLimit = MAX_RECORD_COUNT; // To identify the maximum number of recording tour.

var giCH_Curr = 0;
function loadCurrentSetting()
{
	InstallPlugin();

	var cgiGetParamsByChannel = 
		"videoin_c"+giCH_Curr+"_zoomratiodisplay&image_c"+giCH_Curr+"_freeze&"+
		"camctrl_c"+giCH_Curr+"_tour&camctrl_c"+giCH_Curr+"_preset&camctrl_c"+giCH_Curr+"_autospeed&"+
		"camctrl_c"+giCH_Curr+"_panspeed&camctrl_c"+giCH_Curr+"_tiltspeed&"+
		"camctrl_c"+giCH_Curr+"_zoomspeed&camctrl_c"+giCH_Curr+"_focusspeed&"+
		"camctrl_c"+giCH_Curr+"_defaulthome&camctrl_c"+giCH_Curr+"_idleaction&"+
		"camctrl_c"+giCH_Curr+"_digitalzoom&camctrl_c"+giCH_Curr+"_zoomenhance&"+"camctrl_c"+giCH_Curr+"_focusmode&"+
		"capability_eptz&capability_npreset&capability_image_c"+giCH_Curr+"_freeze&"+
		"capability_camctrl_c"+giCH_Curr+"_focusmode&"+
		"camctrl_c"+giCH_Curr+"_motortype&"+
		"capability_peripheral_c"+giCH_Curr+"_washer_support&"+
		"capability_peripheral_c"+giCH_Curr+"_washer_mode&";
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?network_http_port&network&" + cgiGetParamsByChannel, false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	document.title=translator("camera_control");
	loadlanguage();

	var sform = document.patrolform;
	var spdform = document.spdfm;

	document.title=translator("camera_control");

	// windowless plugin
	showimage_innerHTML('12', 'showimageBlock', false, true, true, 0);

	initSDPtzPannel();

	$("select[name=ptz_panel_selector]").val(webptzmode);

	konami(function(){
		$("#auto-ctrl").toggle();
	});

	//initial inner value
	g_viewportWidth = $(window.top).width();
	g_viewportHeight = $(window.top).height();
	top.document.body.onresize = function()
	{
		g_viewportWidth = $(window.top).width();
		g_viewportHeight = $(window.top).height();

		if(top.$('#TB_iframeContent').length)
		{
			popwindowRenewSize();
			setTour(true, false, -1);
		}
	};

	// Generate Tour List
	genTourListTable();

	// Generate Goto Preset List
	genGotoPresetList();

	// Generate misc function items
	genDynamicMiscFunction();

	// Normalize the selector width
	var ptzpannelsel = document.getElementById("ptz_opt_selector");
	var autofocussel = document.getElementById("autofocus_opt_selector");
	ptzpannelsel.style.width = autofocussel.style.width;
}

function loadvaluedone()
{
	if (camctrl_c0_digitalzoom == 1)
	{
		$("#zoomenhance").attr("disabled", true);
	}
	else if ((false == ParamUndefinedOrZero("capability_eptz")) && (camctrl_c0_zoomenhance == 1))
	{
		$("#digitalzoom").attr("disabled", true);
	}

        // different motor device solution will own different capability, the value cannot be changed at will.
        if (getParamValueByName("camctrl_c"+giCH_Curr+"_motortype") == "02")
        {
		g_recordLimit = 4;
        }
        else if (getParamValueByName("camctrl_c"+giCH_Curr+"_motortype") == "04")
        {
                //g_recordLimit = 3;
		g_recordLimit = 4; // C4 HW change.
        }
        else
        {
		g_recordLimit = MAX_RECORD_COUNT;
        }
}

function checkKeyCode(ev)
{
	var keycode;

	if (!ev)
		/* for IE */
		keycode = window.event.keyCode;
	else
		/* for Firefox */
		keycode = ev.keyCode;

	if (keycode != 13)
		return true;
	else
		return false;
}

function SelectPos()
{
	var sform = document.patrolform
		var sel = sform.preloc.selectedIndex
		if(sform.preloc.selectedIndex==-1)
			return;
	if (sform.selloc.options.length >= 40)
	{
		alert(translator("no_more_than_40_locations"));
		return;
	}
	sform.selloc.options[sform.selloc.options.length] = new Option(sform.preloc.options[sel].text, sform.preloc.options[sel].value, false, false);
	sform.selloc.selectedIndex = sform.selloc.options.length-1;
	sform.seldwelling.options[sform.seldwelling.options.length] = new Option("10", sform.preloc.options[sel].value, false, false);
	sform.seldwelling.selectedIndex = sform.seldwelling.options.length-1;
	sform.dwelling.value = 10;
}

function RemovePos()
{
	var sform = document.patrolform
		var sel = sform.selloc.selectedIndex
		if(sel==-1)
			return;
	if (sform.selloc.options.length == 0)
		return;
	sform.selloc.options[sel] = null
		sform.seldwelling.options[sel] = null
		if (sel < sform.selloc.options.length){
			sform.selloc.selectedIndex = sel
				sform.seldwelling.selectedIndex = sel
		}
		else{
			sform.selloc.selectedIndex = sform.selloc.options.length-1
				sform.seldwelling.selectedIndex = sform.selloc.options.length-1
		}
	if(sform.seldwelling.selectedIndex>=0){
		sform.dwelling.value = sform.seldwelling.options[sform.seldwelling.selectedIndex].text
	}
	else{
		sform.dwelling.value = ""
	}
}

function UpwardPos()
{
	var tmpText
		var tmpValue
		var sform = document.patrolform
		var sel = sform.selloc.selectedIndex
		if(sel==-1)
			return;
	if (sel > 0)
	{
		tmpText = sform.selloc.options[sel].text
			sform.selloc.options[sel].text = sform.selloc.options[sel-1].text
			sform.selloc.options[sel-1].text = tmpText

			tmpText = sform.seldwelling.options[sel].text
			sform.seldwelling.options[sel].text = sform.seldwelling.options[sel-1].text
			sform.seldwelling.options[sel-1].text = tmpText

			tmpValue = sform.selloc.options[sel].value
			sform.selloc.options[sel].value = sform.selloc.options[sel-1].value
			sform.selloc.options[sel-1].value = tmpValue

			tmpValue = sform.seldwelling.options[sel].value
			sform.seldwelling.options[sel].value = sform.seldwelling.options[sel-1].value
			sform.seldwelling.options[sel-1].value = tmpValue

			sform.selloc.selectedIndex = sel-1
			sform.seldwelling.selectedIndex = sel-1
	}
	if(sform.seldwelling.selectedIndex>=0){
		sform.dwelling.value = sform.seldwelling.options[sform.seldwelling.selectedIndex].text
	}
	else{
		sform.dwelling.value = ""
	}
}

function DownwardPos()
{
	var tmpText
		var tmpValue
		var sform = document.patrolform
		var sel = sform.selloc.selectedIndex
		if(sel==-1)
			return;
	if (sel < sform.selloc.options.length-1)
	{
		tmpText = sform.selloc.options[sel].text
			sform.selloc.options[sel].text = sform.selloc.options[sel+1].text
			sform.selloc.options[sel+1].text = tmpText

			tmpText = sform.seldwelling.options[sel].text
			sform.seldwelling.options[sel].text = sform.seldwelling.options[sel+1].text
			sform.seldwelling.options[sel+1].text = tmpText

			tmpValue = sform.selloc.options[sel].value
			sform.selloc.options[sel].value = sform.selloc.options[sel+1].value
			sform.selloc.options[sel+1].value = tmpValue

			tmpValue = sform.seldwelling.options[sel].value
			sform.seldwelling.options[sel].value = sform.seldwelling.options[sel+1].value
			sform.seldwelling.options[sel+1].value = tmpValue

			sform.selloc.selectedIndex = sel+1
			sform.seldwelling.selectedIndex = sel+1
	}
	if(sform.seldwelling.selectedIndex>=0){
		sform.dwelling.value = sform.seldwelling.options[sform.seldwelling.selectedIndex].text
	}
	else{
		sform.dwelling.value = ""
	}
}

function UpdateSel()
{
	var sform = document.patrolform;
	var sel = sform.selloc.selectedIndex;

	if(sel==-1)
		return;
	sform.seldwelling.selectedIndex = sel;
	sform.dwelling.value = eval(sform.seldwelling.options[sel].text);
}

function KeyPress(evt)
{
	var code = window.event?evt.keyCode:evt.which;
	if (code == 13)
	{
		return false;
	}
}

function switchPTZPanel(value)
{
	if(value == 'mechanical') //mechanical
	{
		if(typeof(WinLessPluginCtrl) != "undefined") $("#" + PLUGIN_ID).attr("PtzURL","/cgi-bin/camctrl/camctrl.cgi");
		$("#eptz_panel").hide();
		$("#select_stream_panel").hide();
		$("#camctrl_panel").show();
	}
	else if(value == 'digital') //digital
	{
		showimage_innerHTML('4', 'showimageBlock', false, false, true, 0);
		setTimeout("addPluginEvent(document.getElementById(PLUGIN_ID), 'VNDPWrapperReady', PTZWinlessReady)", 500);
		$("#eptz_panel").show();
		$("#select_stream_panel").show();
		$("#camctrl_panel").hide();
	}

	if(value != getCookie("activatedmode"))
	{
		setCookie("activatedmode", value);
	}
}

function PTZWinlessReady()
{
	if(typeof(WinLessPluginCtrl) != "undefined")
		$("#" + PLUGIN_ID).attr("PtzURL","/cgi-bin/camctrl/eCamCtrl.cgi")
}

function getNewTourIndex()
{
	var iTourIdx = 0;
	for (iTourIdx = 0; iTourIdx < MAX_TOUR_COUNT; iTourIdx++)
	{
		var tourName = eval("camctrl_c0_tour_i" + iTourIdx + "_name");
		if (tourName == "")
		{
			break;
		}
	}
	return iTourIdx;
}

function getAutofocusNaming(value)
{
	var szReturn = translator("null");
	switch(value)
	{
	case "auto":
		szReturn = translator("auto");
		break;
	case "spotlight":
		szReturn = translator("spotlight_avoidance");
		break;
	case "onetimeauto":
		szReturn = translator("onetime_autofocus");
		break;
	case "manual":
		szReturn = translator("manual");
		break;
	default:
		break;
	}
	return szReturn;
}

function getWasherNaming(value)
{
	var szReturn = translator("null");
	switch(value)
	{
		case "wiper":
			szReturn = translator("wiper");
			break;
		case "washer":
			szReturn = translator("washer");
			break;
		default:
			break;
	}
	return szReturn;
}

function popwindowRenewSize()
{
	g_popwindowWidth = 750;
	if (g_viewportWidth < (g_popwindowWidth - 30))
	{
		g_popwindowWidth = g_viewportWidth * 0.5 + 30;
	}
	g_popwindowHeight = g_viewportHeight * 0.8;
}

function setTour(bInit, bCreate, iMethod)
{
	// iMethod? 0: recorded patrol, 1: preseted patrol
	popwindowRenewSize();
	if (false == bInit)
	{
		var thick_box_param = "";
		if (true == bCreate)
		{
			var iTourIdx = getNewTourIndex();
			if (iTourIdx >=  MAX_TOUR_COUNT)
			{
				alert(translator("no_more_than_20_locations"));
				return;
			}
			thick_box_param += "opmode=add";
			thick_box_param += "&target=" + iTourIdx ;
			thick_box_param += "&method=" + iMethod;
		}
		else
		{
			thick_box_param += "opmode=modify";
			thick_box_param += "&target=0";
			thick_box_param += "&method=" + iMethod;
		}

		if (0 == iMethod)
		{
			g_popwindowHeight = g_popwindowHeight * 0.7;
			thick_box_param += "&TB_iframe=true&width="+g_popwindowWidth+"&height="+g_popwindowHeight+"&modal=true&TB_iniframe=true";
			top.$('#TB_window').css("width", null);
			top.$('#TB_window').css("margin-top", -(g_popwindowHeight/2));
			top.$('#TB_window').css("margin-left", -(g_popwindowWidth/2));

			// To reduce the video latency while setting patrol by stop the non-focusing streaming.
			document.getElementById(PLUGIN_ID).RtspStop();
			document.getElementById(PLUGIN_ID).Disconnect();

			$("#newRecordButton").attr("alt", "new_a_tour.html?" + thick_box_param);
		}
		else
		{
			thick_box_param += "&TB_iframe=true&width="+g_popwindowWidth+"&height="+g_popwindowHeight+"&modal=true&TB_iniframe=true";
			top.$('#TB_window').css("width", null);
			top.$('#TB_window').css("margin-top", -(g_popwindowHeight/2));
			top.$('#TB_window').css("margin-left", -(g_popwindowWidth/2));
			$("#newPresetButton").attr("alt", "new_a_tour.html?" + thick_box_param);
		}
		includeClear();
	}
	else
	{
		top.$('#TB_iframeContent').css("width", g_popwindowWidth+"px");
		top.$('#TB_iframeContent').css("height", g_popwindowHeight+"px");
		top.$('#TB_window').css("width", null);
		top.$('#TB_window').css("margin-top", -(g_popwindowHeight/2));
		top.$('#TB_window').css("margin-left", -(g_popwindowWidth/2));
	}
}

function includeClear(targetFile)
{
	var includeList = document.getElementsByTagName("script");
	var iLastIndex = includeList.length;
	var bClearAll = (targetFile)? false : true;

	for (iLastIndex; iLastIndex >= 0; iLastIndex--)
	{
		if (includeList[iLastIndex]
				&& includeList[iLastIndex].getAttribute("src") != null
				&& ((bClearAll)?bClearAll:(includeList[iLastIndex].getAttribute("src").indexOf(targetFile) != -1)))
		{
			includeList[iLastIndex].parentNode.removeChild(includeList[iLastIndex]);
		}
	}
}

function switchTour(tourID)
{
	if (tourID < MAX_TOUR_COUNT)
	{
		if (tourID == g_tourStatus)
		{
			// Turn the desired tour from ON to OFF
			g_tourStatus = -1;
			newParams = "camctrl_c0_tour_index=" + g_tourStatus + "&";
			document.getElementById("tour_enable_value_i" + tourID).firstChild.nodeValue = "OFF";
			document.getElementById("tour_delete_btn_i" + tourID).disabled = false;
		}
		else
		{
			// Turn the desired tour from OFF to ON
			g_tourStatus = tourID;
			newParams = "camctrl_c0_tour_index=" + g_tourStatus  + "&";
			document.getElementById("tour_enable_value_i" + tourID).firstChild.nodeValue = "ON";
			document.getElementById("tour_delete_btn_i" + tourID).disabled = true;
			// Turn the other tours to OFF
			for(iIndex = 0; iIndex < MAX_TOUR_COUNT; iIndex++)
			{
				if (tourID != iIndex)
				{
					if (document.getElementById("tour_enable_value_i" + iIndex) != null)
					{
						document.getElementById("tour_enable_value_i" + iIndex).firstChild.nodeValue = "OFF";
					}
					if (document.getElementById("tour_delete_btn_i" + iIndex) != null)
					{
						document.getElementById("tour_delete_btn_i" + iIndex).disabled = false;
					}
				}
			}
		}
		
		CamControl('auto', 'stop'); // Stop current patrol before switching to another patrol.
		$.get("/cgi-bin/admin/setparam.cgi?" + newParams + "return=/setup/ptz/cameracontrol_speeddome.html");
	}
}

function switchTourSpeed(obj, tourID)
{
	newParams = "camctrl_c0_tour_i" + tourID + "_speed=" + obj.value + "&";
	//$.get("/cgi-bin/admin/setparam.cgi?" + newParams + "return=/setup/ptz/cameracontrol_speeddome.html");
}

function deleteTour(obj, tourID)
{
	var msg = translator("delete_a_patrol_msg");
	if(confirm(msg))
	{
		newParams  = "camctrl_c0_tour_i" + tourID + "_name=" + "&";
		newParams += "camctrl_c0_tour_i" + tourID + "_speed=" + "&";
		newParams += "camctrl_c0_tour_i" + tourID + "_type=" + "&";
		newParams += "camctrl_c0_tour_i" + tourID + "_checklist=" + "&";
		newParams += "camctrl_c0_tour_i" + tourID + "_dwelltime=" + "&";
		$.ajax({
			url: "/cgi-bin/admin/setparam.cgi",
			type: "POST",
			dataType: "script",
			async: false,
			data: newParams,
			beforeSend: function () {
				var rowIndex = obj.parentNode.parentNode.rowIndex;
				var tourTable = document.getElementById("table-tour");
				tourTable.deleteRow(rowIndex);
			},
			success: function() {
				window.location="/setup/ptz/cameracontrol_speeddome.html";
			},
			error: function() {
			}
		});
	}
}

function genGotoPresetList()
{
	var npreset = eval("capability_npreset");
	for (i = 0; i < npreset; i ++)
	{
		var presetName = eval("camctrl_c0_preset_i" + i + "_name");
		if (presetName != "")
		{
			$(".sel_gotoPreset").addOption($(".sel_gotoPreset option:last").val() + 1, presetName, false);
		}
	}
}

function genTourListTable()
{
	var tourItemStr = "";

	g_tourStatus = eval("camctrl_c0_tour_index");
	popwindowRenewSize();
	for (i = 0; i < MAX_TOUR_COUNT; i++)
	{
		var tourName = eval("camctrl_c0_tour_i" + i + "_name");
		var tourSpeed = eval("camctrl_c0_tour_i" + i + "_speed");
		var tourMode = eval("camctrl_c0_tour_i" + i + "_type");

		if (tourName != "")
		{
			tourItemStr += "<tr class='center' id='tour_i" + i + "'>";

			// Name
			tourItemStr += "<td><a href=\"new_a_tour.html?opmode=modify&target=" + i;
			tourItemStr += "&TB_=savedValues&TB_iframe=true&height=" + g_popwindowHeight + "&width=" + g_popwindowWidth + "&modal=true\" class=\"thickbox\" id=\"modifyTourLink\" onclick=\"includeClear()\">";
			tourItemStr += tourName + "</a></td>";

			// ON/OFF status
			if (g_tourStatus == i)
			{
				tourItemStr += "<td><a href='javascript:void(0)' onclick='switchTour(" + i + ")'><span id='tour_enable_value_i" + i + "'>ON</span></a></td>";
			}
			else
			{
				tourItemStr += "<td><a href='javascript:void(0)' onclick='switchTour(" + i + ")'><span id='tour_enable_value_i" + i + "'>OFF</span></a></td>";
			}

			// Mode
			if (tourMode == 0)
			{
				tourItemStr += "<td><span>" + translator("recorded_mode") + "</span></td>";
				g_recordNumber += 1;
			}
			else
			{
				tourItemStr += "<td><span>" + translator("preset_mode") + "</span></td>";
			}

			// Delete
			if (g_tourStatus == i)
			{
				tourItemStr += "<td><input id='tour_delete_btn_i" + i + "' onclick='deleteTour(this, " + i + ")' type='button' value=\"" + translator("delete") + "\" disabled=\"true\" /></td>";
			}
			else
			{
				tourItemStr += "<td><input id='tour_delete_btn_i" + i + "' onclick='deleteTour(this, " + i + ")' type='button' value=\"" + translator("delete") + "\" /></td>";
			}
			tourItemStr += "</tr>";
		}
	}
	$("#table-tour tbody").append(tourItemStr);

	g_tourNumber = $("#table-tour tr").length;
	if (g_tourNumber >= MAX_TOUR_COUNT)
	{
		$("#newRecordButton").attr("disabled", true);
		$("#newPresetButton").attr("disabled", true);
	}

	if (g_recordNumber >= g_recordLimit)
	{
		$("#newRecordButton").attr("disabled", true);
	}

	// Some component is generated dynamically, so we have to rebind thickbox event.
	rebindThickBoxEvents();
}

function removeThickBoxEvents()
{
	$('.thickbox').each(function(i) {
		$(this).unbind('click');
	});
}

function rebindThickBoxEvents()
{
	removeThickBoxEvents();
	tb_init('a.thickbox, area.thickbox, input.thickbox');
}

function receivedone()
{
	document.getElementById("content").style.visibility = "visible";
	form=document.cameractrl;
}

function CheckInputText(InputText)
{
	if (!checkNumberString(InputText))
	{
		InputText.focus();
		return;
	}
	if (parseInt(InputText.value) > 255 || parseInt(InputText.value) < 0)
	{
		alert(translator("please_input_a_value_between_0_and_255"));
		InputText.focus();
		return;
	}
}

function checkNumberString(instr){
	for (i = 0; i < instr.value.length; i++){
		c = instr.value.charAt(i);

		if (!(c>='0' && c<='9'))
		{
			alert(translator("please_input_a_valid_value"));
			return 0;
		}
	}

	return 1;
}

function DisableMode()
{
	document.getElementById("ptz_camera").style.display = "none";
	document.getElementById("port_settings").style.display = "none";
	document.getElementById("buttons").style.display = "none";
}

function EnableMode(mode)
{
	if (mode == 1)
	{
		document.getElementById("ptz_camera").style.display = "block";
		document.getElementById("port_settings").style.display = "block";
		document.getElementById("buttons").style.display = "block";

	}
	else if (mode == 2)
	{
		document.getElementById("ptz_camera").style.display = "none";
		document.getElementById("port_settings").style.display = "block";
		document.getElementById("buttons").style.display = "none";
	}
}

function openurl_wider(urladdr, h, w)
{
	var subWindow = window.open(urladdr, "","height="+h+",width="+w+",scrollbars=yes, status=yes");
	subWindow.focus();
}

function SubmitAll()
{
	var blockSeconds = 0;

	if (checkNumRange($("input[name=camctrl_c0_idleaction_interval]")[0], 999, 1))
	{
		return false;
	}

	var bSupportWasherCtrlOptions = !ParamUndefinedOrZero("capability_peripheral_c"+giCH_Curr+"_washer_support");
	if (true == bSupportWasherCtrlOptions) 
	{
		if (checkNumRange($("input[name=peripheral_c0_camclean_washer_dwelltime]")[0], 999, 15))
		{
			return false;
		}
		
		var sel = miscform.washer_opt_selector.selectedIndex;
		
		setWasherMode(miscform.washer_opt_selector.options[sel].value);
		setWasherDwelltime(miscform.peripheral_c0_camclean_washer_dwelltime.value);
	}

	var getAutofocusOptSelector = function () {
		var AutofocusOptions = null;
		try {
			AutofocusOptions = document.getElementById('autofocus_opt_selector');
		}
		catch(e){
		}
		return AutofocusOptions;
	}

	var setparam_func = function() {
		var sendData = $(document.miscform).serialize();
		$.ajax({
			url: "/cgi-bin/admin/setparam.cgi",
			type: "GET",
			dataType: "script",
			async: true,
			data: sendData,
			complete: function() {
			},
			success: function() {
				if (blockSeconds > 0)
				{
					setTimeout("$.unblockUI(); location.reload();", blockSeconds*1000);
				}
				else
				{
					window.location="/setup/ptz/cameracontrol_speeddome.html";
				}
			},
			error: function() {
			}
		});
	}

	var AutofocusSelector = getAutofocusOptSelector ();
	if (null != AutofocusSelector)
	{
		var userValue = AutofocusSelector.options[AutofocusSelector.selectedIndex].value;
		var loadValue = getParamValueByName("camctrl_c"+giCH_Curr+"_focusmode");
		if ((userValue != loadValue))
		{
			if ("spotlight" == userValue || "spotlight" == loadValue)
			{
				blockSeconds = 20;
				blockUI();
			}
		}
	}

	setparam_func();
}

function zoom_switch(obj)
{
	if ( obj.checked == true )
	{
		if ( obj.name == "zoomenhance" )
		{
			$("#digitalzoom").attr("disabled", true);
		}
		else if ( obj.name == "digitalzoom" )
		{
			$("#zoomenhance").attr("disabled", true);
		}
	}
	else if ( obj.checked == false )
	{
		if ( obj.name == "zoomenhance" )
		{
			$("#digitalzoom").attr("disabled", false);
		}
		else if ( obj.name == "digitalzoom" )
		{
			$("#zoomenhance").attr("disabled", false);
		}
	}
}

function genDynamicMiscFunction()
{
	var bSupportEPTZ = !ParamUndefinedOrZero("capability_eptz");
	var bSupportFreezeImg = !ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_freeze");
	var bSupportAFOptions = !ParamUndefinedOrZero("capability_camctrl_c"+giCH_Curr+"_focusmode");
	var bSupportWasherCtrlOptions = !ParamUndefinedOrZero("capability_peripheral_c"+giCH_Curr+"_washer_support");
	
	if (true == bSupportAFOptions)
	{
		var opt = eval("capability_camctrl_c"+giCH_Curr+"_focusmode");
		var tmp = opt.split(",").sort();
		if ((opt.search("manual") >= 0 && tmp.length > 2) || (opt.search("manual") < 0 && tmp.length > 1))
		{
			var useValue = getParamValueByName("camctrl_c"+giCH_Curr+"_focusmode");
			var useIndex = 0;
			var manualIndex = -1;
			$(document.getElementById('select_ptzpanel_mode_blk')).append(""	
			+' <dt id="select_autofocus_mode_blk">'
			+' <span title="symbol">'+translator("focus_mode")+'</span>:&nbsp;'
			+' <select id="autofocus_opt_selector" name="camctrl_c'+giCH_Curr+'_focusmode" style="" class="position_1">'
			+' </select>'
			+' </dt>'
			);
			for (var i = 0; i <= tmp.length; i++)
			{
				var newItem = null;
				var newFocusOptItem = function (item) {
					var newOption = document.createElement('option');
					newOption.innerHTML =  getAutofocusNaming(item);
					newOption.value = item;
					document.getElementById('autofocus_opt_selector').appendChild(newOption);
					return newOption;
        			}

				if (manualIndex >=0 && i == tmp.length)
				{
					newItem = newFocusOptItem (tmp[manualIndex]);
				}
				else if ("manual" == tmp[i])
				{
					manualIndex = i;
					continue;
				}
				else
				{
					newItem = newFocusOptItem (tmp[i]);
				}
	
				if (newItem != null && useValue == newItem.value)
				{
					document.getElementById('autofocus_opt_selector').selectedIndex = useIndex;
				}

				useIndex ++;
			}
   
			var sel = document.getElementById("autofocus_opt_selector");
			sel.style.width = ((sel.offsetWidth < 200) ? '200' : ((sel.offsetWidth > 260)? '260' : sel.offsetWidth));
		}
	}

	if (true == bSupportWasherCtrlOptions) 
	{
		var opt = eval("capability_peripheral_c0_washer_mode");
		var tmp = opt.split(",").sort();
	
		$(document.getElementById('select_autofocus_mode_blk')).append(""	
		+' <dt id="select_washer_mode_blk">'
		+' <span title="symbol">'+translator("washer_options")+'</span>:&nbsp;'
		+' <select id="washer_opt_selector" name="peripheral_c'+giCH_Curr+'_camclean_washer_mode" style="" class="position_1">'
		+' </select>'
		+' </dt>'
		);
		
		var initUsedValue = queryWasherMode();
		var useIndex = 0;
		for (var i = 0; i < tmp.length; i++)
		{
			var newItem = null;
			var newWasherOptItem = function (item) {
				var newOption = document.createElement('option');
				newOption.innerHTML = getWasherNaming(item);
				newOption.value = item;
				document.getElementById('washer_opt_selector').appendChild(newOption);
				return newOption;
        	}

			newItem = newWasherOptItem (tmp[i]);

			if (newItem != null && initUsedValue == newItem.value)
			{
				document.getElementById('washer_opt_selector').selectedIndex = useIndex;
			}

			useIndex ++;
		}
   
		var sel = document.getElementById("washer_opt_selector");
		sel.style.width = ((sel.offsetWidth < 200) ? '200' : ((sel.offsetWidth > 260)? '260' : sel.offsetWidth));
		
		$(document.getElementById('select_washer_mode_blk')).append(""	
		+' <dt id="text_washer_dwellingtime_blk">'
		+' <span title="symbol">'+translator("washer_dwelling_time")+'</span>:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;'
		+' <input name="peripheral_c'+giCH_Curr+'_camclean_washer_dwelltime" type="text" title="param,num,999,15" size="12" maxlength="3"/> (15~999) '
		+' <span title="symbol">'+translator("seconds")+'</span>'
		+' </dt>'
		);

		$('input[name="peripheral_c'+giCH_Curr+'_camclean_washer_dwelltime"]').val(queryWasherDwelltime());
	}

	if (false == bSupportEPTZ)
	{
		$('input:checkbox[name=zoomenhance]').attr('checked',false);
		$("#zoomenhance").attr("disabled", true);
		$("#zoomenhance").hide();
	}

	if (true == bSupportFreezeImg)
	{
		// Insert this option if support
    		$(document.getElementById("select_osd_mode_blk")).before(""
		+' <dt id="select_image_freeze_blk">'
		+' <span id="imagefreeze">'
		+' <input name="image_c'+giCH_Curr+'_freeze" type="hidden" title="param"/>'
		+' <input type="checkbox" name="patrol_imgfreeze" onclick="updatecheck(this.form.image_c'+giCH_Curr+'_freeze, this)"/>'
		+' <span title="symbol">'+translator("freeze_image_during_patrol")+'</span>'
		+' </span>'
		+' </dt>'
                );
		// Update checkbox state by value
		$('input[name="image_c'+giCH_Curr+'_freeze"').val(getParamValueByName("image_c"+giCH_Curr+"_freeze"));
		$('input:checkbox[name=patrol_imgfreeze]').attr('checked',(1 == getParamValueByName("image_c"+giCH_Curr+"_freeze"))? true:false);
	}
}

var tidSubmitPresetPre = null;
var waitSlideLatency = 500;
function SubmitPreset(selObj)
{
        if (tidSubmitPresetPre != null) {
		clearTimeout(tidSubmitPresetPre);
	}
        tidSubmitPresetPre = setTimeout(function() {
		var CGICmd='/cgi-bin/camctrl/recall.cgi?recall=' + encodeURIComponent($(selObj).selectedOptions().text());
                $.ajaxSetup({ cache: false, async: true});
                $.get(CGICmd)
                Log("Send: %s",CGICmd);
	}, waitSlideLatency);
}
