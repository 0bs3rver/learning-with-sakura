var giCH_Curr = 0;
var giTab_Curr = 0;

function loadCurrentSetting()
{	
	giCH_Curr = Number(getCookie("channelsource"));

	// capability group
	{
		var capabilityStr="capability_daynight_c"+ giCH_Curr +"_support&capability_daynight_c" + giCH_Curr + "_lightsensor";
	}
	// ircutcontrol
	{
		var ircutcontrolStr="&ircutcontrol_mode";
	}

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?"+capabilityStr+ircutcontrolStr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	
	loadlanguage();
	parent.document.getElementById("profiletab").height = 39;
	document.getElementById("content").style.visibility = "visible";

	$("#sensortab_outline", window.parent.document).css("display", "block");
}

function receivedone()
{
	/* if ircutcontrol is auto mode, sensor page will disable sensor profile tab function.
	 * So we not use tabsUI to control tabs UI */
	if (eval("capability_daynight_c" + giCH_Curr + "_support") == "1"
			&& eval("capability_daynight_c" + giCH_Curr + "_lightsensor") == "0"
			&& eval("ircutcontrol_mode") == "auto")
	{
		$(".tabs").append("<div class='tab-bottom-line'></div>")
		
		/* sensor tab */
		$(".tabs li").eq(0).css({"z-index":"2", "background-color":"#fff"});
		$(".tabs li").eq(0).children("a").css("color" , "#0186d1");

		/* sensor profile tab */
		document.getElementById("profile_tab_link").removeAttribute('href');
		document.getElementById("Profile_Tab").removeAttribute('onclick');
		$(".tabs li").eq(1).css({"z-index":"0", "background-color":"#fff"});
		$(".tabs li").eq(1).children("a").css("color" , "#d4d4d4");
	}
	else
	{
	tabsUI(0);
}
}

function changeProfile(idx)
{
	if (giTab_Curr == parseInt(idx, 10))
	{
		return;
	}

	giTab_Curr = parseInt(idx, 10);

	setCookie("sensorprofileindex",idx);
	//$("#expwinbutton", window.parent.document).hide()
	$("#sensortab_outline", window.parent.document).css("display", "block");

	// reload profile content 
	$("#exposurepage", window.parent.document).attr("src", "");
	$("#exposurepage", window.parent.document).remove();
	$("#sensortab_outline", window.parent.document).append("<iframe src='/setup/media/sensor.html?ch="+ giCH_Curr +"' id='exposurepage' width='100%' height='100px' scrolling=yes frameborder=0></iframe>")

	// reload view page
	$("#viewpage", window.parent.document).attr("src", "");
	$("#viewpage", window.parent.document).remove();
	$("#expwinbutton", window.parent.document).before("<iframe id='viewpage' src='/setup/media/viewpage.html?ch="+ giCH_Curr +"&exposure' id='viewpage' width='100%' height='100px' scrolling='auto' frameborder=0></iframe>");

	// non-IE with jpeg view, we should change the image quality selection to default setting "good"
	if (true != bIsWinMSIE)
	{
		getIframeDocumentById("resizebutton").getElementById("imagequality").selectedIndex = 2; 
	}
}
