
function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?camctrl&uart", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	if (window.XMLHttpRequest)
		receiveparam();
	document.title=translator("camera_control");
	loadlanguage();
}

function receivedone()
{
    for (i=1; i <= capability_nmediastream; i++)
    {
        $("#StreamSelector").addOption(i,i);
    }
	document.getElementById("content").style.visibility = "visible";

	if (camctrl_c0_isptz == 0)
	{
		DisableMode();
	}
	else if (camctrl_c0_isptz == 1)
	{
		//Custom camera doesn't support preset.
		if(uart_i0_ptzdriver != 127 && uart_i0_ptzdriver != 128)
		{
			document.getElementById("preset_position").disabled = false;
		}
		EnableMode(1);
	}
	else if (camctrl_c0_isptz == 2)
	{
		EnableMode(2);
	}
	
	form=document.forms[0];
	
	if (form.uart_i0_ptzdriver.length == 2)
	{
		for (var i = 0; i < 20; i++)
		{
			var PtzDrvName = eval('uart_ptzdrivers_i' + i + '_name');
			if (PtzDrvName)
			{
				form.uart_i0_ptzdriver.options[++form.uart_i0_ptzdriver.length-1].text=PtzDrvName;
				form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.length-1].value=i;
			}
			else
			{
				break;
			}
		}
	}
}

function submitform()
{
	document.forms[0];
	
	if(checkvalue())
	{
		return;
	}

	if (CheckEmptyString(form.camctrl_c0_cameraid))
	{
		return;
	}
	form.submit();
	
	if (form.rs485setting_2.checked == true)
	{
		uart_i0_ptzdriver = form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex].value;
		camctrl_c0_isptz = 1;
	}
	else
	{
		uart_i0_ptzdriver = 128;
		camctrl_c0_isptz = 0;
	}
	ShowPresetButton();
}

function CheckInputText(InputText)
{
  if (!checkNumberString(InputText))
  {
    InputText.focus();
    return;
  }  
  if (parseInt(InputText.value) > 255 || parseInt(InputText.value) < 0)
  {
  	alert(translator("please_input_a_value_between_0_and_255"));
  	InputText.focus();
  	return;
  }
}

function checkNumberString(instr){
    for (i = 0; i < instr.value.length; i++){
        c = instr.value.charAt(i);
        
        if (!(c>='0' && c<='9'))
        {
          alert(translator("please_input_a_valid_value"));
          return 0;
        }
    }

   return 1;
}

function DisableMode()
{
	document.getElementById("ptz_camera").style.display = "none";
	document.getElementById("port_settings").style.display = "none";
	document.getElementById("buttons").style.display = "none";
}

function EnableMode(mode)
{
	if (mode == 1)
	{
		document.getElementById("ptz_camera").style.display = "block";
		document.getElementById("port_settings").style.display = "block";
		document.getElementById("buttons").style.display = "block";
		
	}
	else if (mode == 2)
	{
		document.getElementById("ptz_camera").style.display = "none";
		document.getElementById("port_settings").style.display = "block";
		document.getElementById("buttons").style.display = "none";
	}
}

function SubmitCameraType()
{
	if (document.forms[0].rs485setting_1.checked == true)
	{
		document.getElementById("uart_i0_ptzdriver").value = 128;
		document.getElementById("uart_enablehttptunnel").value = 0;
		// document.getElementById("camctrl_enableptztunnel").value = 0;
		DisableMode();
		ShowPresetButton();
	}
	else if (document.forms[0].rs485setting_2.checked == true)
	{
		document.getElementById("uart_enablehttptunnel").value = 0;
		EnableMode(1);
	}
	else if (document.forms[0].rs485setting_3.checked == true)
	{
		document.getElementById("uart_enablehttptunnel").value = 1;
		// document.getElementById("camctrl_enableptztunnel").value = 0;
		EnableMode(2);
	}
}

function openurl_wider(urladdr, h, w)
{
	var subWindow = window.open(urladdr, "","height="+h+",width="+w+",scrollbars=yes, status=yes");
	subWindow.focus();
}

function openCustumCmdPage()
{
	form=document.forms[0];
    var CustomCmdURI = "/setup/custom_cmd.html?";

    if (form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex].value == "127")
    {
        CustomCmdURI = CustomCmdURI + "CustomDriver=true";
    }
    else
    {
        CustomCmdURI = CustomCmdURI + "CustomDriver=false";
    }
    openurl_wider(CustomCmdURI, 600, 500);
}

function ShowPresetButton()
{
	form=document.forms[0];
	selectedDriver = form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex];
	if (camctrl_c0_isptz == 1 && selectedDriver.value == uart_i0_ptzdriver && selectedDriver.text != "Custom camera" && selectedDriver.text != "None")
	{
		document.getElementById("preset_position").disabled = false;
	}
	else
	{
		document.getElementById("preset_position").disabled = true;
	}
}
