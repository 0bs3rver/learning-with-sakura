function loadCurrentSetting()
{
	$('#result_table_head tr').eq(0).css({'background-color':'#d3d3d3', 'font-weight':'bold'});
	$('#result_table_head').attr({'border':'0', 'cellspacing':'3'});
	$('#result_table_head tr').css('text-align','center');
	
	loadlanguage();
	site_survey();
}

function site_survey()
{
	$('#result_table').html('<h3 style="position:fixed; top:140px; left: 130px">Searching nearby AP, please wait... <img src="/css/images/ajax-loader.gif" width="20px" height="20px"></h3>');
	$.ajax({
		type: 'GET',
		cache: false,
		url: '/cgi-bin/admin/site_survey.cgi',
		//password: "admin",
		success: function(response){
			siteSurveySucceed(response);
		},
		error: function(){
			siteSurveyFail();
		}
	});	
}

function siteSurveySucceed(response)
{
	showResult(response);
}

// Load site survey results
function showResult(sitesurvey_result)
{
	eval(sitesurvey_result);
	sortResult();
	
	// Generate html code
	result_html = '';
	for (var i = 0; i < result.length; i++)
	{
		result_html += '<table><tr>';
		for (var j = 0; j < result[i].length; j++)
		{
			if (j == 0)
				result_html += '<td style="width:185px"><a href="javascript:fillUpWLANSettings(' + i + ');self.parent.tb_remove();">' + result[i][j] + '</a></td>';
			else if (j == 1)
				result_html += '<td style="width:125px"><div id="percentBar' + i + '" class="percentBarDiv"></div></td>';
			else if (j == 2)
			{
				if (result[i][j] == 'NONE')
					result_html += '<td style="width:165px">No Security</td>';
				else
					result_html += '<td style="width:165px">' + result[i][j] + '</td>';
			}
			else
			{
				//alert("Oops! The format of the returned site survey result is wrong!");
			}	
		}
		result_html += '</tr></table>';
	}
	
	$('#result_table').html(result_html);
	
	$('.percentBarDiv').css({'margin-left': '5px'});
	$('#result_table').attr({'border':'0', 'cellspacing':'3'});
	$('#result_table tr').css('text-align','center');

	// Load percentage bar
	for (var i = 0; i < result.length; i++)
	{	
		var tmpBarName = "percentBar" + i;
		
		// Decide bar color by percentage.
		// Quality: bad <---------> good
		//          Red    Yellow   Green
		var signal = result[i][1];
		if (signal >= 80)		barColor = '#01DF01'; // green
		else if (signal >= 75)	barColor = '#3ADF00';
		else if (signal >= 70)	barColor = '#74DF00';
		else if (signal >= 65)	barColor = '#A5DF00';
		else if (signal >= 60)	barColor = '#D7DF01';
		else if (signal >= 55)	barColor = '#DBA901';
		else if (signal >= 50)	barColor = '#DF7401';
		else if (signal >= 45)	barColor = '#DF3A01';
		else 					barColor = '#DF0101'; // red
		
		percentBar({
			id: tmpBarName,
			width: 115,
			height: 12,
			bgColorBar: '#FFF',
			bgColorPercent: barColor,
			borderStyle: 'none',
			bgImageBar: '',
			bgImagePercent: '',
			percent: signal,
			displayOut: 'no'
		});
	}
}

function sortResult()
{
	// Sort by SSID for removing duplicated SSIDs
	result.sort(function(a,b) {
		a = a[0];
		b = b[0];

		return (a.toLowerCase() == b.toLowerCase() ? 0 : (a.toLowerCase() < b.toLowerCase() ? -1 : 1))
	});
	
	// Remove duplicated SSIDs if the encryptions are the same (the one with smaller signal level will be removed)
	for (var i = 0; i < result.length - 1; i++)
	{
		if (result[i][0] == result[i+1][0] && result[i][2] == result[i+1][2])
		{
			var tmp = result[i][1] < result[i+1][1] ? i : i + 1;
			result.splice(tmp, 1);
		}
	}
	
	// Sort by signal strength
	result.sort(function(a,b) {
		return parseInt(b[1],10) - parseInt(a[1],10);
	});
}

function fillUpWLANSettings(APIndex)
{
	var encryptionStr = result[APIndex][2];
	var encryptionValue;
	var algorithm;
	
	if (encryptionStr.match('WPA2'))
	{
		encryptionValue = 3;
	}
	else if (encryptionStr.match('WPA'))
	{
		encryptionValue = 2;
	}
	else if (encryptionStr.match('WEP'))
	{
		encryptionValue = 1;
	}
	else
	{
		encryptionValue = 0;
	}
	
	if (encryptionStr.match('TKIP'))
	{
		algorithm = 'TKIP';
	}
	else if (encryptionStr.match('AES'))
	{
		algorithm = 'AES';
	}
	
	top.document.getElementsByName('wireless_ssid')[0].value = result[APIndex][0];
	top.document.getElementsByName('wireless_encrypt')[0].value = encryptionValue;	
	top.document.getElementsByName('wireless_algorithm')[0].value = algorithm;	
	top.showmode();	// Reinitialize wireless page. Note that showmode() is parent page's function (in wireless.js).
}
