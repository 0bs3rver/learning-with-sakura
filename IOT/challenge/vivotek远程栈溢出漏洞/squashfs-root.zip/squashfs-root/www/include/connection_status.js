function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/connst.cgi?_l=1", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title = translator("connection_status");
	document.getElementById("returnpage").value="setup/security/connection_status.html";

	if (ipfilter_type == 0) $(":button:eq(1)").hide(); 
}

function loadvaluedone()
{
	document.getElementById("connstlist").innerHTML = "<br>" + connst_list;
	$("#connstlist table").attr({"border":"0", "cellspacing":"3"}).css("width", "100%");
	$("#connstlist table tr").eq(0).css({"background-color":"#d3d3d3", "font-weight":"bold"});
	loadlanguage();
}

function checkDenyList(ipType, ipAddress)
{
	var isFull = true;
	for (iCnt = 0; iCnt < 10;  iCnt++)
	{
		if (ipType == "ipv4")
		{
			existRule = eval("ipfilter_ipv4list_i" + iCnt);
		}
		else
		{
			existRule = eval("ipfilter_ipv6list_i" + iCnt);
		}

		if (existRule == "")
		{
			isFull = false;
		}
		else
		{
			if (ipAddress == existRule)
			{
				alert(translator("this_rule_is_already_existed"));
				return -1;
			}
		}
	}
	if (isFull)
	{
		alert(translator("no_more_deny_list_to_enter"));
		return -1;
	}
	else
	{
		return 0;
	}
}

function add2Deny()
{
	var input = document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
	{
		if(input[i].type=="checkbox")
		{
			if (input[i].checked == true)
			{
				offsetAddr = input[i].value.lastIndexOf("_t=");
				ipType = input[i].value.substr(offsetAddr + 3, 4);
				//alert(input[i].value + "\n" + offsetAddr + "\n" + ipType);
				offsetAddr2 = input[i].value.lastIndexOf("_r=");
				end = input[i].value.length;
				ipAddress = input[i].value.substring(offsetAddr2 + 3, end);
				if (checkDenyList(ipType, ipAddress))
				{
					return -1;
				}
			}
		}
	}
	document.getElementById("action").value = "1";
	document.connst.submit();
}

function disconnect()
{
	document.getElementById("action").value = "2";
	document.connst.submit();
}
