function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&system_hostname&capability_nmediastream&capability_ndo", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("homepage_layout");		
	//Nifty("div#video-area");
	//Nifty("div#outter-wrapper");
	//Nifty("div#control-area","tr");
	//Nifty("div#configuration-area","br");	
	document.getElementById("wiredIE").style.visibility = "visible";
	ButtonControlBar();
	loadlanguage();
}

function receivedone()
{
	document.getElementById("content").style.visibility = "visible";
	GenerateDOList();
}

function loadvaluedone()
{
	updateColor(layout_theme_option)
	updateLogo(getCheckedValue(document.forms[0].layout_logo_default),"nonSlide");	
	if (CustomLogoExist == 1)
	{
  	resizeLayoutCustomLogo();
  	resizeLayoutPreviewLogo();
  }
	document.getElementById("page_title").innerHTML = system_hostname;

   var tran = document.getElementById("control-bar").getElementsByTagName("button");    
   for (var i = 0; i < tran.length; i++) 
       tran[i].title = translator(tran[i].title);
	
	if (layout_logo_powerbyvvtk_hidden == 0)
	{
		document.getElementById("configuration-area-footer").style.visibility="visible";
	}
	else
	{
		document.getElementById("configuration-area-footer").style.visibility="hidden";
	}
	if (layout_custombutton_manualtrigger_show == 1)
	{
		document.getElementById("manual_trigger_ctrl").style.display="";
	}
	else
	{
		document.getElementById("manual_trigger_ctrl").style.display="none";
	}

}

function updateCustomButton(inputName, checkbox)
{
	if (checkbox.checked)
	{
		inputName.value = "0";
		document.getElementById("manual_trigger_ctrl").style.display="";
	}
	else
	{
		inputName.value = "1";	
		document.getElementById("manual_trigger_ctrl").style.display="none";
	}
	updatecheck(inputName, checkbox);
}

function ButtonControlBar()
{
	if(document.all)
	{
		document.execCommand("BackgroundImageCache",false,true); 
	} 
	document.onmouseover=document.onmouseout=document.onmousedown=document.onmouseup=function(e)
	{ 
	    var ee=e==null?event.srcElement:e.target; 
	    e = e||event; 

	    if(ee.tagName!="BUTTON" || ee.clientWidth!=ee.offsetWidth) 
	        return;
					
	    X = parseInt(ee.style.backgroundPosition.split(" ")[0]).toString(10);
			
	    if(e.type=="mousedown")
			{		 		   
			    ee.style.backgroundPosition= X +"px " + -2*ee.offsetHeight+"px"
	        if(document.all) 
	            ee.hideFocus=true 
	        else 
	            return false					
	    } 
	    else if(e.type=="mouseover"||e.type=="mouseup") 
			{
					ee.style.backgroundPosition=X+"px " + -ee.offsetHeight+"px"
			}
	    else//(e.type=="mouseout") 
			{
				  ee.style.backgroundPosition=X+"px " + "0px";
			}
	} 
}


function pickcolor(element)
{	
	if(typeof(myWindow) != "undefined" && !myWindow.closed)
	{	
		//myWindow.location.href= "/colorpicker/colorpicker.htm#"+element.id;
		myWindow.ID = element.id;
		myWindow.currentColor = Colors.ColorFromHex(element.value);
		myWindow.colorChanged('box');
		//myWindow.location.reload();
		myWindow.focus()
	}
	else
	{
	 	myWindow = window.open("/colorpicker/colorpicker.htm#"+element.id,"",",toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no, width=500,height=320, left=0, top=400");
	} 
	scrollTo(0,0);
}

function updateColor(object)
{
	switch(object)
	{
		case "1":
				document.getElementById("control-area").getElementsByTagName("table")[0].style.color = "#000"
				document.getElementById("C1").value = "#000000"
				document.getElementById("C1").style.background = "#000000"
				document.getElementById("C1").style.color = "#ffffff"				
				
				//document.getElementById("configuration-area").getElementsByTagName("table")[0].style.color = "#fff" 
				document.getElementById("C2").value = "#ffffff"
				document.getElementById("C2").style.background = "#ffffff"
				
				document.getElementById("page_title").style.color = "#098bd6"
				document.getElementById("C3").value = "#098bd6"
				document.getElementById("C3").style.background = "#098bd6"
				
				document.getElementById("control-area").style.backgroundColor = "#c4eaff" 
				document.getElementById("C4").value = "#c4eaff"
				document.getElementById("C4").style.background = "#c4eaff"
				
				document.getElementById("configuration-area").style.backgroundColor = "#0186D1"
				document.getElementById("C5").value = "#0186D1"
				document.getElementById("C5").style.background = "#0186D1"
				
				document.getElementById("video-area").style.backgroundColor = "#c4eaff"
				document.getElementById("C6").value = "#c4eaff"
				document.getElementById("C6").style.background = "#c4eaff"
				
				document.getElementById("outter-wrapper-layout").style.borderColor = "#0186D1"				
				document.getElementById("C7").value = "#0186D1"
				document.getElementById("C7").style.background = "#0186D1"
				break;
				
		case "2":
				document.getElementById("control-area").getElementsByTagName("table")[0].style.color = "#000000"
				document.getElementById("C1").value = "#000000"
				document.getElementById("C1").style.background = "#000000"
				document.getElementById("C1").style.color = "#ffffff"
				
				//document.getElementById("configuration-area").getElementsByTagName("table")[0].style.color = "#ffffff" 
				document.getElementById("C2").value = "#ffffff"
				document.getElementById("C2").style.background = "#ffffff"
				
				document.getElementById("page_title").style.color = "#aeacad"
				document.getElementById("C3").value = "#aeacad"
				document.getElementById("C3").style.background = "#aeacad"
				
				document.getElementById("control-area").style.backgroundColor = "#cccccc"
				document.getElementById("C4").value = "#cccccc"
				document.getElementById("C4").style.background = "#cccccc"
				
				document.getElementById("configuration-area").style.backgroundColor = "#aeacad"
				document.getElementById("C5").value = "#aeacad"
				document.getElementById("C5").style.background = "#aeacad"
				
				document.getElementById("video-area").style.backgroundColor = "#cccccc"
				document.getElementById("C6").value = "#cccccc"
				document.getElementById("C6").style.background = "#cccccc"
				
				document.getElementById("outter-wrapper-layout").style.borderColor = "#aeacad"		
				document.getElementById("C7").value = "#aeacad"
				document.getElementById("C7").style.background = "#aeacad"
				
				break;

		case "3":
				document.getElementById("control-area").getElementsByTagName("table")[0].style.color = "#ffffff"
				document.getElementById("C1").value = "#ffffff"
				document.getElementById("C1").style.background = "#ffffff"
				document.getElementById("C1").style.color = "#000000"
				
				//document.getElementById("configuration-area").getElementsByTagName("table")[0].style.color = "#ffffff" 
				document.getElementById("C2").value = "#ffffff"
				document.getElementById("C2").style.background = "#ffffff"
				document.getElementById("C2").style.color = "#000000"

				document.getElementById("page_title").style.color = "#323232"				
				document.getElementById("C3").value = "#323232"
				document.getElementById("C3").style.background = "#323232"

				document.getElementById("control-area").style.backgroundColor = "#565656"
				document.getElementById("C4").value = "#565656"
				document.getElementById("C4").style.background = "#565656"
				
				document.getElementById("configuration-area").style.backgroundColor = "#323232"
				document.getElementById("C5").value = "#323232"
				document.getElementById("C5").style.background = "#323232"
				
				document.getElementById("video-area").style.backgroundColor = "#565656"
				document.getElementById("C6").value = "#565656"
				document.getElementById("C6").style.background = "#565656"
				
				document.getElementById("outter-wrapper-layout").style.borderColor = "#323232"	
				document.getElementById("C7").value = "#323232"
				document.getElementById("C7").style.background = "#323232"				
				break;
				
		case "4":
				document.getElementById("control-area").getElementsByTagName("table")[0].style.color = layout_theme_color_font
				document.getElementById("C1").value = layout_theme_color_font
				document.getElementById("C1").style.background = layout_theme_color_font			
				
				//document.getElementById("configuration-area").getElementsByTagName("table")[0].style.color = layout_theme_color_configfont
				document.getElementById("C2").value = layout_theme_color_configfont
				document.getElementById("C2").style.background = layout_theme_color_configfont
				
				document.getElementById("page_title").style.color = layout_theme_color_titlefont
				document.getElementById("C3").value = layout_theme_color_titlefont
				document.getElementById("C3").style.background = layout_theme_color_titlefont
				
				document.getElementById("control-area").style.backgroundColor = layout_theme_color_controlbackground
				document.getElementById("C4").value = layout_theme_color_controlbackground
				document.getElementById("C4").style.background = layout_theme_color_controlbackground
				
				document.getElementById("configuration-area").style.backgroundColor = layout_theme_color_configbackground
				document.getElementById("C5").value = layout_theme_color_configbackground
				document.getElementById("C5").style.background = layout_theme_color_configbackground
				
				document.getElementById("video-area").style.backgroundColor = layout_theme_color_videobackground
				document.getElementById("C6").value = layout_theme_color_videobackground
				document.getElementById("C6").style.background = layout_theme_color_videobackground
				
				document.getElementById("outter-wrapper-layout").style.borderColor = layout_theme_color_case
				document.getElementById("C7").value = layout_theme_color_case
				document.getElementById("C7").style.background = layout_theme_color_case		
				break;
				
		default:
				break;			
	}	
}
var CustomLogoExist = 0;

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
		
	var Form = document.forms[0];	
	Form.enctype = "";
	if(document.getElementsByName("layout_theme_option")[3].checked)
	{
		Form.layout_theme_color_font.value = document.getElementById("C1").value
		Form.layout_theme_color_configfont.value = document.getElementById("C2").value
		Form.layout_theme_color_titlefont.value = document.getElementById("C3").value
		Form.layout_theme_color_controlbackground.value = document.getElementById("C4").value
		Form.layout_theme_color_configbackground.value = document.getElementById("C5").value
		Form.layout_theme_color_videobackground.value = document.getElementById("C6").value
		Form.layout_theme_color_case.value = document.getElementById("C7").value
	}
	else
	{	
		Form.layout_theme_color_font.value = layout_theme_color_font;
		Form.layout_theme_color_configfont.value = layout_theme_color_configfont;
		Form.layout_theme_color_titlefont.value = layout_theme_color_titlefont
		Form.layout_theme_color_controlbackground.value = layout_theme_color_controlbackground
		Form.layout_theme_color_configbackground.value = layout_theme_color_configbackground
		Form.layout_theme_color_videobackground.value = layout_theme_color_videobackground
		Form.layout_theme_color_case.value = layout_theme_color_case

	}
	if (CustomLogoExist == 0) Form.layout_logo_default[0].checked = true;
	Form.submit();
}



function updateLogo(object,Slide)
{
    var formalLink = layout_logo_link;
    if ((formalLink.indexOf("http://") != 0) &&
        (formalLink.indexOf("https://") != 0))
    {
        formalLink = "http://" + formalLink;
    }

	if(object == 1)
	{
		if(Slide == "Slide")
		{
			//SlideToggle(document.getElementById("custom_logo_noteBox"),"Close","Slide");			
			//SlideToggle(document.getElementById("Upload"),"Close","Slide");
			$("#custom_logo_noteBox").slideUp("slow");
			$("#Upload").slideUp("slow");			
		}

		else
		{
			//SlideToggle(document.getElementById("Upload"),"Close","nonSlide");
			//SlideToggle(document.getElementById("custom_logo_noteBox"),"Close","nonSlide");		
			$("#Upload").css("display","none");
			$("#custom_logo_noteBox").css("display","none");
		}
		
		document.getElementById("layout_logo_icon").innerHTML = "<span></span><a href=\"" + formalLink + "\" target=\"_blank\"><img   alt=\"logo\" style=\"border:0;\"src=\"" + "/pic/VIVOTEK_Logo.gif" + "\" /></a>";
	}
	else
	{
		if(Slide == "Slide")
		{
			//SlideToggle(document.getElementById("custom_logo_noteBox"),"Open","Slide");
			//SlideToggle(document.getElementById("Upload"),"Open","Slide");
			$("#custom_logo_noteBox").slideDown("slow");
			$("#Upload").slideDown("slow");					
		}
			
		else
		{
			//SlideToggle(document.getElementById("custom_logo_noteBox"),"Open","nonSlide");
			//SlideToggle(document.getElementById("Upload"),"Open","nonSlide");
			$("#custom_logo_noteBox").css("display","block");
			$("#Upload").css("display","block");
		}
								
		if(CustomLogoExist == 1)
		{
			document.getElementById("layout_logo_icon").innerHTML = "<span></span><a href=\"" + formalLink + "\" target=\"_blank\"><img   alt=\"custom_logo\" style=\"border:0;\"src=\"" + "/pic/custom_logo.jpg" + "\" /></a>";
		}
	}
}


function SubmitUploadLogo()
{	
	var form = document.forms[0];

	if (form.uploadLogoFile.value == "")
	{
		alert(translator("no_logo_specified"));
		return -1;
	}
		
	var suffix = form.uploadLogoFile.value.split(".");
	suffix = suffix[suffix.length - 1].toLowerCase();
	if (suffix == 'jpg' || suffix == 'jpeg' || suffix == 'png' || suffix == 'gif')
	{
	form.action = "/cgi-bin/admin/upload_logo.cgi";
	form.enctype="multipart/form-data";
	form.method="post";
	form.target="_self";
	
	form.layout_logo_default[0].disabled = true;
	form.layout_logo_default[1].disabled = true;	
	
	form.layout_logo_link.disabled = true;
	form.layout_theme_option[0].disabled = true;
	form.layout_theme_option[1].disabled = true;
	form.layout_theme_option[2].disabled = true;
	form.layout_theme_option[3].disabled = true;
	form.layout_theme_color_font.disabled = true;
	form.layout_theme_color_configfont.disabled = true;
	form.layout_theme_color_titlefont.disabled = true;
	form.layout_theme_color_controlbackground.disabled = true;
	form.layout_theme_color_configbackground.disabled = true;
	form.layout_theme_color_videobackground.disabled = true;
	form.layout_theme_color_case.disabled = true;
		form.layout_logo_powerbyvvtk_hidden.disabled = true;
	document.getElementsByName("return")[0].disabled = true;

		CustomLogoExist = 0;
	 	form.submit();
  }
  else 
	{
  	alert(translator("only_filenames_with_a_jpg_png_or_gif_extension_are_valid"));
  	return -1;
  }
}

function updatePowerByVVTKLogo(inputName, checkbox)
{
	if (checkbox.checked)
	{
		inputName.value = "1";
		document.getElementById("configuration-area-footer").style.visibility="hidden";
	}
	else
	{
		inputName.value = "0";	
		document.getElementById("configuration-area-footer").style.visibility="visible";
	}
}

function updateCustomLogo()
{
		var XMLHttpRequestCustomLogo = false;
		if (window.XMLHttpRequest)
			XMLHttpRequestCustomLogo = new XMLHttpRequest();
		else if (window.ActiveXObject)
			XMLHttpRequestCustomLogo = new ActiveXObject("Microsoft.XMLHTTP");
		XMLHttpRequestCustomLogo.open("GET", "/pic/custom_logo.jpg", false);
		XMLHttpRequestCustomLogo.setRequestHeader("If-Modified-Since","0");
		XMLHttpRequestCustomLogo.send(null);
		if(XMLHttpRequestCustomLogo.status == 200)
		{
				CustomLogoExist = 1;
				document.write("<img   alt='logo' src='/pic/custom_logo.jpg'/>");				
		}		
		else
		{
				//alert("not exist")
				CustomLogoExist = 0;
			}
}

function resizeLayoutCustomLogo()
{
		var custom_logo_img = document.getElementById("custom_logo_img").getElementsByTagName("img")[0];
		var widthRatio = custom_logo_img.width / 160;
		var heightRatio = custom_logo_img.height / 50;
		if(widthRatio > 1 || heightRatio > 1)
		{			
			var param = (heightRatio>widthRatio)?".height='50'":".width='160'";
			eval('document.getElementById("custom_logo_img").getElementsByTagName("img")[0]' + param);
		}
}

function resizeLayoutPreviewLogo()
{
		var custom_logo_img = document.getElementById("layout_logo_icon").getElementsByTagName("img")[0];

		var widthRatio = custom_logo_img.width / 160;
		var heightRatio = custom_logo_img.height / 50;
		if(widthRatio > 1 || heightRatio > 1)
		{			
			var param = (heightRatio>widthRatio)?".height='50'":".width='160'";
			eval('document.getElementById("layout_logo_icon").getElementsByTagName("img")[0]' + param);			
		}
}

function GenerateDOList()
{
//    for (iDO = parseInt(capability_ndo, 10)-1 ; iDO >= 0; iDO--)
	for (iDO = 0 ; iDO >= 0; iDO--) // We just generate one digital output for demo homepage layout 
	{
		if(parseInt(capability_ndo, 10) == "1")
		{
			digital_output_num='';
		}
		else
		{
			digital_output_num=eval(iDO+1);
		}
		$(document.getElementById("manual_trigger_ctrl")).after(""
		+'<tr id="digital_output'+eval(iDO+1)+'" height="22px">'
		+'  <td>'
		+'    <span title="symbol" style="margin-left:0px;margin-right=0px">'+translator("digital_output")+'</span>'+digital_output_num+':&nbsp;'
		+'  </td>'
		+'  <td>'
		+'    <div id="digitalOutPut-bar" style="margin-left:0px">'
		+'      <button   class="btn_do_on" style="background-Position: 0px 0px;"></button>'
		+'      <button   class="btn_do_off" style="background-Position: -24px 0px;"></button>'
		+'    </div>'
		+'  </td>'
		+'</tr>');
	}
}
