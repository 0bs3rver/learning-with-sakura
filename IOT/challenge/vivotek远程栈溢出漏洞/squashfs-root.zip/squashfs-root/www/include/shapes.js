
var eShapeType = {"Rectangle":0, "Field":1, "Polyline":2};
var enumArrowType = {
	"arrowNone" : 0,
	"arrowDilate" : 1, 
	"arrowErode" : 2 };
var eVcaDirection = {"any":0, "left":1, "right":2};
var MAX_POLYFIELD_POINTS = 20;
var MIN_POLYFIELD_POINTS = 3;
var MAX_POLYLINE_POINTS = 3;
	
// public function
function isCrossLine(p11, p12, p21, p22)
{
	var	line1, line2, line3, line4;
	var	vecP1x, vecP1y, vecP2x, vecP2y, vecP3x, vecP3y, vecP4x, vecP4y, vecP5x, vecP5y, vecP6x, vecP6y;

	vecP1x = p12.x - p11.x;
	vecP1y = p12.y - p11.y;
	vecP2x = p22.x - p11.x;
	vecP2y = p22.y - p11.y;
	vecP3x = p21.x - p11.x;
	vecP3y = p21.y - p11.y;
	vecP4x = p22.x - p21.x;
	vecP4y = p22.y - p21.y;
	vecP5x = p11.x - p22.x;
	vecP5y = p11.y - p22.y;
	vecP6x = p12.x - p21.x;
	vecP6y = p12.y - p21.y;
	
	line1 = (vecP1x * vecP2y) - (vecP1y * vecP2x);
	line2 = (vecP1x * vecP3y) - (vecP1y * vecP3x);
	line3 = (vecP4x * vecP5y) - (vecP4y * vecP5x);
	line4 = (vecP4x * vecP6y) - (vecP4y * vecP6x);

	if ((line1 * line2 < 0) && (line3 * line4 < 0))
	{
		return true;
	}
	return false;
}

function getSide(lineP1, lineP2, p)
{
	if ( ((lineP2.x-lineP1.x) * (p.y-lineP1.y) - (p.x-lineP1.x) * (lineP2.y-lineP1.y)) <= 0) //left side
	{
		return "Left";
	}
	else
	{
		return "Right";
	}
}

function getDistancePoints(p1, p2, distance, dirPts)
{
	if (dirPts.length < 2)
		return;

	var cenX = (p2.x + p1.x) / 2;
	var cenY = (p2.y + p1.y) / 2;
	var disX = p2.x - p1.x;
	var disY = p2.y - p1.y;
	var unitLen = distance / (Math.sqrt(disX * disX + disY * disY));
	var resX1 = parseInt(cenX + unitLen * (p1.y - p2.y), 10);
	var resY1 = parseInt(cenY + unitLen * disX, 10);
	var resX2 = parseInt(cenX - unitLen * (p1.y - p2.y), 10);
	var resY2 = parseInt(cenY - unitLen * disX, 10);
	
	var cenPt = new jsPoint(resX1, resY1);
	if (getSide(p1,p2,cenPt) == "Left")
	{
		dirPts[0].x = parseInt(resX1, 10);
		dirPts[0].y = parseInt(resY1, 10); //left point
		dirPts[1].x = parseInt(resX2, 10);
		dirPts[1].y = parseInt(resY2, 10); //right point
	}
	else
	{
		dirPts[1].x = parseInt(resX1, 10);
		dirPts[1].y = parseInt(resY1, 10); //right point
		dirPts[0].x = parseInt(resX2, 10);
		dirPts[0].y = parseInt(resY2, 10); //left point
	}
}

function getDirectionPoints(mySel, distance)
{
	var points = mySel.shapeBase.points;
	var dirPts = new Array(2);
	dirPts[0] = new jsPoint(0,0); //save left point
	dirPts[1] = new jsPoint(0,0); //save right point
	for (var i = 0; i < points.length-1; i++)
	{
		var p1 = points[i];
		var p2 = points[i+1];
		getDistancePoints(p1, p2, distance, dirPts);
		if (mySel.leftDirPts.length <= i)
		{
			//var pt = new jsPoint(dirPts[0].x, dirPts[0].y);
			var leftPt = new jsPoint(dirPts[0].x, dirPts[0].y);
			mySel.leftDirPts.push(leftPt);
			var rightPt = new jsPoint(dirPts[1].x, dirPts[1].y);
			mySel.rightDirPts.push(rightPt);
		}
		else
		{
			mySel.leftDirPts[i].x = dirPts[0].x;
			mySel.leftDirPts[i].y = dirPts[0].y;
			mySel.rightDirPts[i].x = dirPts[1].x;
			mySel.rightDirPts[i].y = dirPts[1].y;
		}
	}
}

function drawArrow(ctx,p1,p2,size)
{ 
	ctx.save(); 
	
	// Rotate the context to point along the path 
	var dx = p2.x-p1.x, dy=p2.y-p1.y, len=Math.sqrt(dx*dx+dy*dy); 
	ctx.translate(p2.x,p2.y); 
	ctx.rotate(Math.atan2(dy,dx)); 
 	
 	ctx.fillStyle = 'rgba(255, 0, 0, 0.8)';
 	ctx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
    // line 
    ctx.lineCap = 'round'; 
    ctx.beginPath(); 
    ctx.moveTo(0,0); 
    ctx.lineTo(-len,0); 
    ctx.closePath(); 
    ctx.stroke(); 
 
    // arrowhead 
    ctx.beginPath(); 
    ctx.moveTo(0,0); 
    ctx.lineTo(-size,-size); 
    ctx.lineTo(-size, size); 
    ctx.closePath(); 
    ctx.fill(); 
 
    ctx.restore(); 
}

// 0  1  2
// 3     4
// 5  6  7
// draw arrow one the rectangle to indicate it is prefer to minimize / maximum object size
function arrowDilate(context, controlpts)
{
	var half = mySelBoxSize/2;
  	var pt1 = new jsPoint();
  	var pt2 = new jsPoint();
  	var len = 15; //length of arrow
  	var cur = controlpts[1];
  	pt1.x = cur.x+half;
  	pt1.y = cur.y+mySelBoxSize;
  	pt2.x = pt1.x;
  	pt2.y = pt1.y-len;
  	drawArrow(context, pt1, pt2, 5);
  	cur = controlpts[4];
  	pt1.x = cur.x;
  	pt1.y = cur.y+half;
	pt2.x = pt1.x+len;
	pt2.y = pt1.y;
	drawArrow(context, pt1, pt2, 5);
	cur = controlpts[6];
	pt1.x = cur.x+half;
	pt1.y = cur.y;
	pt2.x = pt1.x;
	pt2.y = pt1.y+len;
	drawArrow(context, pt1, pt2, 5);
  	cur = controlpts[3];
  	pt1.x = cur.x+mySelBoxSize;
  	pt1.y = cur.y+half;
  	pt2.x = pt1.x-len;
  	pt2.y = pt1.y;
  	drawArrow(context, pt1, pt2, 5);
}

function arrowErode(context, controlpts)
{
	var half = mySelBoxSize/2;
  	var pt1 = new jsPoint();
  	var pt2 = new jsPoint();
  	var len = 15; //length of arrow
  	var cur = controlpts[1];
  	pt1.x = cur.x+half;
  	pt1.y = cur.y;
  	pt2.x = pt1.x;
  	pt2.y = pt1.y+len;
  	drawArrow(context, pt1, pt2, 5);
  	cur = controlpts[4];
  	pt1.x = cur.x+mySelBoxSize;
  	pt1.y = cur.y+half;
	pt2.x = pt1.x-len;
	pt2.y = pt1.y;
	drawArrow(context, pt1, pt2, 5);
	cur = controlpts[6];
	pt1.x = cur.x+half;
	pt1.y = cur.y+mySelBoxSize;
	pt2.x = pt1.x;
	pt2.y = pt1.y-len;
	drawArrow(context, pt1, pt2, 5);
  	cur = controlpts[3];
  	pt1.x = cur.x;
  	pt1.y = cur.y+half;
  	pt2.x = pt1.x+len;
  	pt2.y = pt1.y;
  	drawArrow(context, pt1, pt2, 5);
}

// -- class
function BaseShape()
{
	this.mySelWidth = 2;
	this.mySelBoxSize = 6;
	this.mySelColor = '#CC0000';
  	this.fill = '#444444';
  	this.id = -1;
  	this.shapeType;
  	this.points = new Array();
  		
  	this.setControlPoints = function(points)
  	{
  		for (var i = 0; i < points.length; i++)
		{
			this.points.push(new jsPoint(parseInt(points[i].x), parseInt(points[i].y)));
		}
  	}
  	this.getHitControlPointIndex = function(mousePt)
  	{
  		for (var j = 0; j < this.points.length; j++) //get the selected control point
		{
			var cur = this.points[j];
			// we dont need to use the ghost context because
	        // selection handles will always be rectangles
	        if (mousePt.x >= cur.x - this.mySelBoxSize  && mousePt.x <= cur.x + this.mySelBoxSize &&
	            mousePt.y >= cur.y - this.mySelBoxSize && mousePt.y <= cur.y + this.mySelBoxSize) 
	        {
	        	// we found one!
	    		return j; // return index of control points;
	        }
		}
  	}
  	this.getPoints = function()
  	{
  		return this.points;
  	}
  	this.setResizeDrag = function(expectResizeIndex, p)
	{
		this.points[expectResizeIndex].x = p.x;
		this.points[expectResizeIndex].y = p.y;
	}
}

function RectangleShape()
{
	this.x = 0;
  	this.y = 0;
  	this.w = 1; // default width and height?
  	this.h = 1;
	this.bDbClick = true;
	this.shapeBase = new BaseShape;
	this.shapeBase.shapeType = eShapeType.Rectangle;
	this.arrowType = enumArrowType.arrowNone;
	// set up the selection handle boxes
  	for (var i = 0; i < 8; i ++) 
  	{
    	var pt = new jsPoint;
    	this.shapeBase.points.push(pt);
  	}
  	this.resetControlPoints = function()
  	{
  		var controlPts = this.shapeBase.points;
  		var half = this.shapeBase.mySelBoxSize / 2;  
  		// top left, middle, right
  		controlPts[0].x = this.x-half;
  		controlPts[0].y = this.y-half;
  
  		controlPts[1].x = this.x+this.w/2-half;
  		controlPts[1].y = this.y-half; 
  
  		controlPts[2].x = this.x+this.w-half;
  		controlPts[2].y = this.y-half;
  
  		//middle left
      	controlPts[3].x = this.x-half;
      	controlPts[3].y = this.y+this.h/2-half;
      
      	//middle right
      	controlPts[4].x = this.x+this.w-half;
      	controlPts[4].y = this.y+this.h/2-half;
      
      	//bottom left, middle, right
      	controlPts[6].x = this.x+this.w/2-half;
      	controlPts[6].y = this.y+this.h-half;
      
      	controlPts[5].x = this.x-half;
      	controlPts[5].y = this.y+this.h-half;
      
      	controlPts[7].x = this.x+this.w-half;
      	controlPts[7].y = this.y+this.h-half;
  	}
  	this.setParam = function(id, fill, points)
	{
		if (points.length < 2) //(left,top), (right, bottom)
		{
			alert("Invalid Rectangle");
		}
		this.shapeBase.id = id;
		this.shapeBase.fill = fill;
		this.x = points[0].x;
		this.y = points[0].y;
		this.w = points[1].x - points[0].x;
		this.h = points[1].y - points[0].y;
		this.resetControlPoints();
	}
	this.setResizeDrag = function(expectResizeIndex, p)
	{
		var minObjSizeW = 8;
		var minObjSizeH = 8;
		var mySel = this;
		var mx = p.x;
		var my = p.y;
		// time ro resize!
		var oldx = mySel.x;
		var oldy = mySel.y;
	    
	    // 0  1  2
	    // 3     4
	    // 5  6  7
		switch (expectResizeIndex) 
		{
  			case 0:
  				if (mx >= mySel.x+mySel.w || my >= mySel.y+mySel.h)
  					return;
  			
  				//check rect size
  				if (mySel.w + oldx - mx < minObjSizeW || mySel.h + oldy - my < minObjSizeH)
  					return;
  				
    			mySel.x = mx;
    			mySel.y = my;
    			mySel.w += oldx - mx;
    			mySel.h += oldy - my;
    			break;
  			case 1:
  				if (my >= mySel.y+mySel.h)
  					return;
  				//check rect size
    			if (mySel.h + oldy - my < minObjSizeH)
    				return;
    			mySel.y = my;
    			mySel.h += oldy - my;
    			break;
  			case 2:
  				if (mx <= mySel.x || my >= mySel.y+mySel.h)
  					return;
  				//check rect size
        		if (mx - oldx < minObjSizeW || mySel.h + oldy - my < minObjSizeH)
        			return;
        		
    			mySel.y = my;
    			mySel.w = mx - oldx;
    			mySel.h += oldy - my;
    			break;
  			case 3:
  				if (mx >= mySel.x+mySel.w)
  					return;
  				//check rect size
        		if (mySel.w + oldx - mx < minObjSizeW)
        			return;
        		
    			mySel.x = mx;
    			mySel.w += oldx - mx;
    			break;
  			case 4:
  				if (mx <= mySel.x)
  					return;
  				//check rect size
    			if (mySel.w + mx - oldx < minObjSizeW)
    				return;
    			mySel.w = mx - oldx;
    			break;
  			case 5:
  				if (mx >= mySel.x+mySel.w || my <= mySel.y)
  					return;
  				//check rect size
        		if (mySel.w + oldx - mx < minObjSizeW || my - oldy < minObjSizeH)
        			return;
    			mySel.x = mx;
    			mySel.w += oldx - mx;
    			mySel.h = my - oldy;
    			break;
  			case 6:
  				if (mx <= mySel.x)
  					return;
  				//check rect size
    			if (my - oldy < minObjSizeH)
    				return;
    			mySel.h = my - oldy;
    			break;
  			case 7:
  				if (mx <= mySel.x || my <= mySel.y)
  					return;
  				//check rect size
    			if (mx - oldx < minObjSizeW || my - oldy < minObjSizeH)
    				return;
    			mySel.w = mx - oldx;
    			mySel.h = my - oldy;
    			break;
		}
	}
	this.getPoints = function()
	{
		return this.shapeBase.getPoints();
	}
	this.getHitControlPointIndex = function(p)
	{
		return this.shapeBase.getHitControlPointIndex(p);
	}
	this.isFillRect = function(flag)
	{
		mIsFillRect = flag;
	}
	this.isContain = function(p)
  	{
		//check is in the rect container.
		if (p.x < this.x || p.y < this.y || p.x > this.x+this.w || p.y > this.y+this.h)
		{
			return false;
		}
		return true;
  	}
  	this.draw = function(context, mySel, isDrawControl, curPoint) 
  	{
  		if (mIsFillRect == true) // fill the rectangle
  		{
	      	context.fillStyle = this.shapeBase.fill;
	      	context.fillRect(this.x,this.y,this.w,this.h);
        }
        // draw the boundary of rectangle
        context.strokeStyle = this.shapeBase.fill;
  		context.lineWidth = this.shapeBase.mySelWidth;
  		context.strokeRect(this.x,this.y,this.w,this.h);
    	// draw selection
    	// this is a stroke along the box and also 8 new selection handles
      	// 0  1  2
      	// 3     4
      	// 5  6  7
      	if (isDrawControl == true)
      	{
	  		this.resetControlPoints();
	    }

      	context.fillStyle = this.shapeBase.mySelColor;
	    if (mySel == this && isDrawControl == true) 
    	{
	      	for (var i = 0; i < 8; i ++) 
	      	{
	        	//var cur = selectionHandles[i];
	        	var cur = this.shapeBase.points[i];
	        	context.fillRect(cur.x, cur.y, this.shapeBase.mySelBoxSize, this.shapeBase.mySelBoxSize);
	      	}
	      	//draw arrow
	      	if (this.arrowType == enumArrowType.arrowDilate)
	      	{
	      		arrowDilate(context, this.shapeBase.points);
	      	}
	      	else if (this.arrowType == enumArrowType.arrowErode)
	      	{
	      		arrowErode(context, this.shapeBase.points);
	      	}
    	}
  	}
}

function LineShape()
{
	this.shapeBase = new BaseShape;
	this.shapeBase.shapeType = eShapeType.Polyline;
	this.leftDirPts = new Array();
	this.rightDirPts = new Array();
	this.unselectFill = '#444444';
	this.direction = 'Any';
	this.bDbClick = true;
	
	this.setParam = function(id, fill, points, direction)
	{
		this.shapeBase.id = id;
		this.shapeBase.fill = fill;
		this.direction = direction;
		this.unselectFill = fill.replace(/[^,]+(?=\))/, '0.3')
		this.shapeBase.setControlPoints(points);
	}
	this.getPoints = function()
	{
		return this.shapeBase.getPoints();
	}
	this.getHitControlPointIndex = function(p)
	{
	 	return this.shapeBase.getHitControlPointIndex(p);
	}
	this.setResizeDrag = function(expectResizeIndex, p)
	{
		this.shapeBase.setResizeDrag(expectResizeIndex, p);
	}
	this.isContain = function(p)
  	{
  		return false; // line is not a close region, so it not support isContain;
  	}
	this.draw = function(context, mySel, isDrawControl, curPoint)
  	{
  		var controlPts = this.shapeBase.points;
  		if (mySel == this || isDrawControl == false)
      	{
  			context.fillStyle = this.shapeBase.fill;
  	  		context.strokeStyle = this.shapeBase.fill;
        }
        else
        {
        	context.fillStyle = this.unselectFill;
  	  		context.strokeStyle = this.unselectFill;
        }
	  	//draw polygone
	  	if (controlPts.length == 0) 
	  	{
	  		return;
	  	}
    
  	  	if (controlPts.length >= 2)
  	  	{
  	  	  	context.lineWidth = 3;
  	  	  	for (var i = 0; i<controlPts.length - 1; i++)
      	  	{
      	  		context.beginPath();
      	  	  	context.moveTo(controlPts[i].x, controlPts[i].y);
      	  	  	context.lineTo(controlPts[i+1].x, controlPts[i+1].y);
      	  	  	context.stroke();
      	  	}
  	  	}
  	  	if (controlPts.length < MAX_POLYLINE_POINTS)
  	  	{
  	  		context.beginPath();
  	  	   	context.moveTo(controlPts[controlPts.length - 1].x, controlPts[controlPts.length - 1].y);
  	  	   	context.lineTo(mx, my);
  	  	   	context.stroke();
  	  	}
  	  	
      	// draw the polyline points box
      	// draw selection
      	// this is a stroke along the box and also 8 new selection handles
      	if (isDrawControl) // draw control points
      	{
	  	  	var half = this.shapeBase.mySelBoxSize / 2;
	  	 	context.fillStyle = this.shapeBase.mySelColor;
	  	  	for (var i = 0; i < controlPts.length; i ++) 
	  	  	{
	  	  	  	var cur = controlPts[i];
	    	  	context.fillRect(cur.x - half, cur.y - half, this.shapeBase.mySelBoxSize, this.shapeBase.mySelBoxSize);
	  	  	}
      	}
      	
      	if (mySel == this)
      	{
      		//draw arrow
      	  	context.strokeStyle = this.shapeBase.fill;
    	  	context.lineWidth = 3;
     
      	  	//draw line's arrow
      	  	var num = controlPts.length;
      	  	if (num == MAX_POLYLINE_POINTS)
      	  	{
      	  	  	var dirLen = 10;
      	  	  	getDirectionPoints(mySel, dirLen);
      	  	  	
      	  	  	var cenPt = new jsPoint();
      	  	  	var p2;
      	  	  	for (var i = 0; i < controlPts.length-1; i++)
      	  	  	{
      	  	  	  	cenPt.x = (controlPts[i].x+controlPts[i+1].x)/2;
      	  	  	  	cenPt.y = (controlPts[i].y+controlPts[i+1].y)/2;
      	  	  	  	//left arrow
      	  	  	  	if (mySel.direction == "Any" || mySel.direction == "Left")
      	  	  	  	{
      	  	  	  	  	p2 = mySel.leftDirPts[i];
      	  	  		  	drawArrow(context, cenPt, p2, 5);
      	  	  	  	}
      	  	  	  	//right arrow
      	  	  	  	if (mySel.direction == "Any" || mySel.direction == "Right")
      	  	  	  	{
      	  	  	  	  	p2 = mySel.rightDirPts[i];
      	  	  		  	drawArrow(context, cenPt, p2, 5);
      	  	  	  	}
      	  	  	}
      	  	}
      	}
  	}
}

function FieldShape()
{
	this.shapeBase = new BaseShape;
	this.shapeBase.shapeType = eShapeType.Field;
	this.bDbClick = false;
	
	function isValidPoint(pointsList, newPt)
	{
		var points = pointsList;
		
		if (points.length >= 2)
		{
			var newPt1 = points[points.length-1];
			var newPt2 = newPt;
			for (var i = 0; i < points.length-1; i++)
			{
				if (isCrossLine(points[i], points[i+1], newPt1, newPt2) == true)
				{
					return true;
				}
			}
		}
		
		return false;
	}
	this.setParam = function(id, fill, points)
	{
		this.shapeBase.fill = fill;
		this.shapeBase.id = id;
		if (points != null)
		{
			this.shapeBase.setControlPoints(points);
		}
	}
  	this.isContain = function(p)
  	{
  		if (this.bDbClick == true) // this field has become a close region
  		{
	  		for (var i = 0; i < this.shapeBase.points.length - 1; i++)
	  		{
	  			if ( getSide(this.shapeBase.points[i], this.shapeBase.points[i+1], p) == 'Left')
	  			{
	  				return false;
	  			}
	  		}
	  			
	  		return true;
  		}
  		
  		return false;
  	}
  	this.addControlPoint = function(p)
  	{
  		if (this.bDbClick == true)
  		{
  			return;
  		}
  		if (this.shapeBase.points.length >= MAX_POLYFIELD_POINTS)
  		{
  			alert(translator("exceed_field_point_num"));
  			this.bDbClick = true
  			return;
  		}
  		// check is valid new point: the new point can't cross the previous lines
  		if (isValidPoint(this.shapeBase.points, p) == false)
  		{
	  		var point = new jsPoint(p.x, p.y);
	  		this.shapeBase.points.push(point);
  		}
  	}
  	this.getPoints = function()
	{
		return this.shapeBase.getPoints();
	}
  	this.getHitControlPointIndex = function(p)
  	{
  		return this.shapeBase.getHitControlPointIndex(p);
  	}
  	this.setResizeDrag = function(expectResizeIndex, p)
	{
		//check is cross line - can't move the control point then produce the crossing line.
		var points = this.shapeBase.points;
		var preInx = (expectResizeIndex-1+points.length)%points.length;
		var prePt = points[preInx];
		var aftInx = (expectResizeIndex+1+points.length)%points.length;
		var aftPt = points[aftInx];
		for (var i = 0; i < points.length; i++)
		{
			var inx1 = i % points.length;
			var inx2 = (i+1) % points.length;
			//because mouse down point has a range of area, so it would become cross line with neighbors. 
			if ((inx1 != expectResizeIndex && inx2 != expectResizeIndex) && isCrossLine(points[inx1], points[inx2], prePt, p) == true)
			{
				return;
			}
			if ((inx1 != expectResizeIndex && inx2 != expectResizeIndex) && isCrossLine(points[inx1], points[inx2], aftPt, p) == true)
			{
				isCrossLine(points[inx1], points[inx2], orgPt, p);
				return;
			}
		}
		this.shapeBase.setResizeDrag(expectResizeIndex, p);
	}
  	this.draw = function(context, mySel, isDrawControl, curPoint)
  	{
  		var controlPts = this.shapeBase.points;
  		context.fillStyle = this.shapeBase.fill;
  		context.strokeStyle = this.shapeBase.fill;
      	//draw polygone
	    if (controlPts.length == 0) 
	    {
	    	return;
	    }
	    
      	if (this.bDbClick == true) // fill polygon
      	{
	      	context.beginPath();
	      	context.moveTo(controlPts[0].x, controlPts[0].y);
	      	for (var i = 1; i<controlPts.length; i++)
	      	{
	      		context.lineTo(controlPts[i].x, controlPts[i].y);
	      	}
	      	context.closePath();
	      	context.fill();
      	}
      	else  //draw poly line
      	{
      		if (controlPts.length >= 2)
      	  	{
      	  		context.lineWidth = this.shapeBase.mySelWidth;
      	  	  	for (var i = 0; i<controlPts.length - 1; i++)
	      	  	{
	      	  		context.beginPath();
	      	  	  	context.moveTo(controlPts[i].x, controlPts[i].y);
	      	  	  	context.lineTo(controlPts[i+1].x, controlPts[i+1].y);
	      	  	  	context.stroke();
	      	  	}
      	  	}
      	  	if (curPoint!=null && controlPts.length > 0)
      	  	{
      	  		context.beginPath();
      	  	  	context.moveTo(controlPts[controlPts.length - 1].x, controlPts[controlPts.length - 1].y);
      	  	  	context.lineTo(curPoint.x, curPoint.y);
      	  	  	context.stroke();
      	  	}
      	}
      	// draw selection
    	// this is a stroke along the box and also 8 new selection handles
    	if (mySel == this) 
    	{
      		context.strokeStyle = this.shapeBase.fill;
      		context.lineWidth = this.shapeBase.mySelWidth;
      		context.strokeRect(this.x,this.y,this.w,this.h);
      
      		if (isDrawControl)
      		{
	      		// draw the polyfield points box
	      		var half = this.shapeBase.mySelBoxSize / 2;
	      		context.fillStyle = this.shapeBase.mySelColor;
	      		for (var i = 0; i < controlPts.length; i ++) 
	      		{
	        		var cur = controlPts[i];
	        		context.fillRect(cur.x - half, cur.y - half, this.shapeBase.mySelBoxSize, this.shapeBase.mySelBoxSize);
	      		}
      		}
    	}
  	}
}

function ShapesArray(canvasId, callbackFun, isEnableControl)
{
	// holds all our fields
	var mShapeList = []; 
	var mIsControl = isEnableControl;
	// Hold canvas information
	var canvas;
	var ctx;
	var INTERVAL = 20;  // how often, in milliseconds, we check to see if a redraw is needed
	
	var isSettingNewField = false;
	var isDrag = false;
	var isResizeDrag = false;
	var expectResize = -1; // New, will save the # of the selection handle if the mouse is over one.
	var mousePt = new jsPoint(0, 0); // mouse coordinates
	 // when set to true, the canvas will redraw everything
	 // invalidate() just sets this to false right now
	 // we want to call invalidate() whenever we make a change
	var canvasValid = false;

	// The node (if any) being selected.
	// If in the future we want to select multiple objects, this will get turned into an array
	var mySel = null;
	// since we can drag from anywhere in a node
	// instead of just its x/y corner, we need to save
	// the offset of the mouse when we start dragging.
	var offsetx, offsety;

	// Padding and border style widths for mouse offsets
	var stylePaddingLeft, stylePaddingTop, styleBorderLeft, styleBorderTop;

	// callback function: return current selected rectangle
	var callbackSelected = callbackFun;
	
	initial(canvasId);
	
	function initial(canvasId)
	{
		// initialize our canvas, add a ghost canvas, set draw loop
		// then add everything we want to intially exist on the canvas
	  	canvas = document.getElementById(''+canvasId+'');
	  	if (typeof window.G_vmlCanvasManager != "undefined")
	  	{
	  		canvas = window.G_vmlCanvasManager.initElement(canvas);
	  	}
      	ctx = canvas.getContext('2d');
      
	  	//fixes a problem where double clicking causes text to get selected on the canvas
	  	canvas.onselectstart = function () { return false; }
	  
	  	// fixes mouse co-ordinate problems when there's a border or padding
	  	// see getMouse for more detail
	  	if (document.defaultView && document.defaultView.getComputedStyle) // for IE9
	  	{
	    	stylePaddingLeft = parseInt(document.defaultView.getComputedStyle(canvas, null)['paddingLeft'], 10)     || 0;
	    	stylePaddingTop  = parseInt(document.defaultView.getComputedStyle(canvas, null)['paddingTop'], 10)      || 0;
	    	styleBorderLeft  = parseInt(document.defaultView.getComputedStyle(canvas, null)['borderLeftWidth'], 10) || 0;
	    	styleBorderTop   = parseInt(document.defaultView.getComputedStyle(canvas, null)['borderTopWidth'], 10)  || 0;
	  	}
	  	else // below IE8
	  	{
	  		stylePaddingLeft = parseInt(canvas.currentStyle.paddingLeft);
	    	stylePaddingTop  = parseInt(canvas.currentStyle.paddingTop);
	    	styleBorderLeft  = parseInt(canvas.currentStyle.borderLeftWidth);
	    	styleBorderTop   = parseInt(canvas.currentStyle.borderTopWidth);
	  	}
	  
	  	// make mainDraw() fire every INTERVAL milliseconds
	  	setInterval(mainDraw, INTERVAL);
	  	
	  	if (isEnableControl)
	  	{
	  		// set our events. Up and down are for dragging,
		  	// double click is for finish setting the control point for this field.
		  	canvas.onmousedown = myDown;
		  	canvas.onmouseup = myUp;
		  	canvas.ondblclick = myDblClick;
		  	canvas.onmousemove = myMove;
		  	canvas.onmouseout = myMouseOut;
	  	}
	  	
	  	clear(ctx);
	}
	
	//wipes the canvas context
	function clear(c) 
	{
		c.clearRect(0, 0, canvas.width, canvas.height);
	}
	function myUp()
	{
  		isDrag = false;
  		isResizeDrag = false;
  		expectResize = -1;
	}
	
	function myMouseOut(e)
	{
		if (mySel != null)
		{
			getMouse(e);
			if (isResizeDrag == true)
			{
				mySel.setResizeDrag(expectResize, mousePt);
				invalidate();
			}
			myUp();
		}
	}
	
	function myMove(e)
	{
		if (mySel != null)
		{
			getMouse(e);
			if (isSettingNewField == true)
			{
				invalidate();
				return;
			}
			if (isResizeDrag == true)
			{
				mySel.setResizeDrag(expectResize, mousePt);
				invalidate();
			    return;
			}
			if (isDrag == true)
			{
				var newX = mousePt.x - offsetx;
	  			var newY = mousePt.y - offsety;
	  			if (newX < 0 || newY < 0 || newX+mySel.w > canvas.width || newY+mySel.h > canvas.height)
	  				return;
	    		mySel.x = newX;
	    		mySel.y = newY;   
				invalidate();
			    return;
			}
		}
		// not over a selection box, return to normal
    	myUp();
  		this.style.cursor='auto';
	}
	// Happens when the mouse is clicked in the canvas
	function myDown(e)
	{
		getMouse(e);
		if (isSettingNewField == true && mySel != null)
		{
			// find the current setting field
			mySel.addControlPoint(mousePt);
			if (mySel.bDbClick == true)
			{
				isSettingNewField = false;
			}
			invalidate();
			return;
		}
		//check priority is mySel > control point > region contain
		if (mySel != null) 
		{
			expectResize = mySel.getHitControlPointIndex(mousePt);
			if (expectResize >= 0)
			{
				this.style.cursor='crosshair';
				isResizeDrag = true;
				invalidate();
				return;
			}
		}
		for (var i = 0; i < mShapeList.length; i++)
		{
			expectResize = mShapeList[i].getHitControlPointIndex(mousePt);
			if (expectResize >= 0)
			{
				mySel = mShapeList[i];
				this.style.cursor='crosshair';
				isResizeDrag = true;
				invalidate();
				return;
			}
		}
		for (var i = 0; i < mShapeList.length; i++)
		{
			if (mShapeList[i].bDbClick == true && mShapeList[i].isContain(mousePt) == true)
			{
				mySel = mShapeList[i];
				if (mySel.shapeBase.shapeType==eShapeType.Rectangle)
				{
					offsetx = mousePt.x - mySel.x;
		      		offsety = mousePt.y - mySel.y;
					isDrag = true;
				}
				invalidate();
				return;
			}
		}
	}
	function myDblClick(e) //only process for field type
	{
		isSettingNewField = false;
		
		if (mySel == null)
			return;
		if (mySel.bDbClick)
			return;
		
  		var polyfield = mySel;
  		var points = polyfield.getPoints();
	  		
  		// because DBClick would add one more point from myDown - IE9, but IE8 would not add it point.
  		// so check the last two point and remove the repeat one.
  		if ((points[points.length-1].x == points[points.length-2].x) && (points[points.length-1].y == points[points.length-2].y))
  		{
  			//remove the repeat point
  			points.splice(points.length-1, 1);
  		}
  		// remove the last click point
  		points.splice(points.length-1, 1); 
  		
  		if (polyfield.bDbClick == true || points.length < MIN_POLYFIELD_POINTS)
  		{
  	  		//alert("number of point is too few to create a polyfield");
  	  		return;
  		}
  		
  		polyfield.bDbClick = true;
  		invalidate();
	}
	
	// Sets mousePt.x,mousePt.y to the mouse position relative to the canvas
	// unfortunately this can be tricky, we have to worry about padding and borders
	function getMouse(e) 
	{
    	var element = canvas, offsetX = 0, offsetY = 0;

      	if (element.offsetParent) 
      	{
      		do 
      		{
          		offsetX += element.offsetLeft;
          		offsetY += element.offsetTop;
        	} while ((element = element.offsetParent));
      	}

      	// Add padding and border style widths to offset
      	offsetX += stylePaddingLeft;
      	offsetY += stylePaddingTop;

	    offsetX += styleBorderLeft;
      	offsetY += styleBorderTop;
		if (e != null)
		{
      		mousePt.x = e.pageX - offsetX;
      		mousePt.y = e.pageY - offsetY
      	}
      	else
      	{
      		// belows IE8 need to recalculate position for scrollbar position.
      		var scrollLeft = document.body.parentElement.scrollLeft;
      		var scrollTop = document.body.parentElement.scrollTop;
      		mousePt.x = event.clientX - offsetX + scrollLeft;
      		mousePt.y = event.clientY - offsetY + scrollTop;
      	}
      	// because mouse would be out of canvas, so we must validate the mouse position.
      	mousePt.x = mousePt.x < 0? 0: mousePt.x;
      	mousePt.y = mousePt.y < 0? 0: mousePt.y;
      	mousePt.x = mousePt.x >= canvas.width ? canvas.width : mousePt.x;
      	mousePt.y = mousePt.y >= canvas.height ? canvas.height : mousePt.y;
	}

	// Main draw loop.
	// While draw is called as often as the INTERVAL variable demands,
	// It only ever does something if the canvas gets invalidated by our code
	function mainDraw() 
	{
		if (canvasValid == false) 
		{
			clear(ctx);
		
			//draw field
			var l = mShapeList.length;
			for (var i = 0; i < l; i++) 
			{
				if (mIsControl == true)
				{
					mShapeList[i].draw(ctx, mySel, mIsControl, mousePt);
				}
				else
				{
					mShapeList[i].draw(ctx, mShapeList[i], mIsControl, mousePt);
				}
			}
			// Add stuff you want drawn on top all the time here
			canvasValid = true;
		}
	}

	function invalidate() 
	{
	  	canvasValid = false;
	  	if (mySel != null && callbackSelected != null)
  		{
  			var wd = 0, ht = 0;
  			if (mySel.shapeBase.shapeType == eShapeType.Rectangle)
  			{
  				wd = mySel.w;
  				ht = mySel.h;
  			}
	  		callbackSelected(mySel.shapeBase, wd, ht);
  		}
	}
	
	// add field 
	function addField(id, fill, points)
	{
		var fieldshape = new FieldShape;
		
		fieldshape.setParam(id, fill, points);
		if (points == null) // new field
		{
			fieldshape.bDbClick = false;
			isSettingNewField = true;
		}
		else
		{
			fieldshape.bDbClick = true;
		}
		mShapeList.push(fieldshape);
		//set focus of this object
		mySel = mShapeList[mShapeList.length-1];
	}
	// add polyline
	function addPolyline(id, fill, points, direction)
	{
		var polyline = new LineShape;
		if (!points) //create a defualt polyline
		{
			points = new Array();
			var point = new jsPoint(canvas.width/2, canvas.height/3);
			points.push(point);
			point = new jsPoint(canvas.width/2 - 30, canvas.height / 2);
			points.push(point);
			point = new jsPoint(canvas.width/2, canvas.height*2/3);
			points.push(point);
		}
		polyline.setParam(id, fill, points, direction);
		mShapeList.push(polyline);
		//set focus of this object
		mySel = mShapeList[mShapeList.length-1];
	}
	// add rectangle
	function addRectangle(id, fill, points, isFillRect)
	{
		var rect = new RectangleShape;
		rect.setParam(id, fill, points);
		rect.isFillRect(isFillRect);
		mShapeList.push(rect);
		//set focus of this object
		mySel = mShapeList[mShapeList.length-1];
	}
	// user assign line points to create a polyline
	this.add = function(id, type, fill, points, others)
	{
		switch(type)
		{
			case eShapeType.Rectangle:
				addRectangle(id, fill, points, others);  //others = isFillRect
				break;
			case eShapeType.Polyline:
				addPolyline(id, fill, points, others); //others = direction
				break;
			case eShapeType.Field:
				addField(id, fill, points);
				break;
			default:
				break;
		}
		
		invalidate();
	}
	this.remove = function(type, id)
	{
		for (var i = mShapeList.length-1; i >= 0; i--)
		{
			if (mShapeList[i].shapeBase.shapeType == type && mShapeList[i].shapeBase.id == id)
			{
				mShapeList.splice(i, 1);
			}
		}
		if (mShapeList.length > 0)
		{
			mySel = mShapeList[mShapeList.length-1];
		}
		invalidate();
	}
	this.removeShape = function(type)
	{
		for (var i = mShapeList.length-1; i >= 0; i--)
		{
			if (mShapeList[i].shapeBase.shapeType == type)
			{
				mShapeList.splice(i, 1);
			}
		}
		if (mShapeList.length > 0)
		{
			mySel = mShapeList[mShapeList.length-1];
		}
		invalidate();
	}
	this.removeAll = function()
	{
		mShapeList.splice(0, mShapeList.length);
		invalidate();
	}
	
	this.getShapePointsById = function(type, id)
	{
		for(var i = 0; i < mShapeList.length; i++)
		{
			var base = mShapeList[i].shapeBase;
			if (base.shapeType == type && base.id == id)
			{
				return base.points;
			}
		}
		return null;
	}
	
	this.getShapePointsByIndex = function(type, index)
	{
		var inx = 0;
		for(var i = 0; i < mShapeList.length; i++)
		{
			var base = mShapeList[i].shapeBase;
			if (base.shapeType == type)
			{
				if (index == inx)
				{
					return base.points;
				}
				inx++;
			}
		}
		return null;
	}
	this.updateRectSizeById = function(id, updateWd, updateHt)
	{
		for(var i = 0; i < mShapeList.length; i++)
		{
			var base = mShapeList[i].shapeBase;
			if (base.shapeType == eShapeType.Rectangle && base.id == id)
			{
				mySel = mShapeList[i];
				mySel.w = (mySel.x + updateWd > canvas.width)? canvas.width - mySel.x: updateWd;
				mySel.h = (mySel.y + updateHt > canvas.height)? canvas.height - mySel.y: updateHt;
				
				invalidate();
			}
		}
	}
	this.getShapesNumber = function()
	{
		return mShapeList.length;
	}
	this.getDirection = function(id)
	{
		for (var i = 0; i < mShapeList.length; i++)
		{
			var shape = mShapeList[i]
			var base = shape.shapeBase;
			if (base.shapeType == eShapeType.Polyline&& base.id == id)
			{
				return shape.direction;
			}
		}
		return "Any";
	}
	this.setDirection = function(id, direction)
	{
		for (var i = 0; i < mShapeList.length; i++)
		{
			var shape = mShapeList[i]
			var base = shape.shapeBase;
			if (base.shapeType == eShapeType.Polyline&& base.id == id)
			{
				shape.direction = direction;
				invalidate();
				return;
			}
		}
	}
}

