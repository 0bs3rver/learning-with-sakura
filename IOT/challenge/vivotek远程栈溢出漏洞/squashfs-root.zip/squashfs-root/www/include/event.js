eval(location.search.toString().slice(1));
added=0;
var preChangeMediaType;
var typeList  = new Array("motion",  "seq",      "di",      "tampering", "vi",      "pir",     "temperature", "vadp",      "volalarm", "shockalarm");
var childList = new Array("mdChild", "seqChild", "diChild", "tdChild",   "viChild", "pdChild", "temChild",    "vadpChild", "adChild");
var gVadpTrigNum;
var giCH_Curr = 0;
function loadCurrentSetting()
{
	bSaved = false;
	var params = "vadp_event&event&server&media&motion_c"+giCH_Curr+"&recording_i0_dest&recording_i1_dest&ircutcontrol_enableextled&capability_supportsd&capability_tampering&capability_thermal_temperaturedetection&camctrl_c"+giCH_Curr+"&capability_ptzenabled&capability_npreset&capability_localstorage_smartsd&capability_supporttriggertypes&event_i0_action_custom0&event_i0_action_custom1&event_i0_action_custom2";
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?" + params, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("event");
	loadlanguage();
	
}

function receivedone()
{
	// Note some RD2's check rule comes from wiki. They check bit7 first:
	// [1] is external PT and check camctrl_c0_isptz for a mechanical ptz switch.
	// [0] is internal PT, and check bit2(pan), bit3(tilt), bit4(zoom), bit5(focus) to confirm the internal ptz capability.
	
	if (isSpeedDome(getParamValueByName("capability_ptzenabled")) == 1)
	{
		ShowPresetSelction();
		$("#object_tracking").show();
		document.getElementById("preset_locations_speeddome").style.display="inline-block";
	}
	else if (isIZ(getParamValueByName("capability_ptzenabled")) == 1)
	{
		ShowPresetSelction();
		$("#object_tracking").hide();
		document.getElementById("preset_locations_iz").style.display="inline-block";
	}
	else if ((capability_ptzenabled & 0x01) == 1 && parseInt(eval("camctrl_c"+giCH_Curr+"_isptz")) == 1)
	{
		ShowPresetSelction();
		$("#object_tracking").hide();
		document.getElementById("preset_locations").style.display="inline-block";
	}
	else
	{
		document.getElementById("goto_preset").style.display="none";
		document.getElementById("goto_preset_note").style.display="none";
		$("#object_tracking").hide();
	}

	GenerateDIDOList();
	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
	{
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	}
	var input=document.getElementsByTagName("select");
	for (var i = 0; i < input.length; i++)
	{
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	}

	if ((isSpeedDome(getParamValueByName("capability_ptzenabled")) == 1) || (isIZ(getParamValueByName("capability_ptzenabled")) == 1))
	{
		updateGoto();
	}
	else if ((capability_ptzenabled & 0x01) == 1 && parseInt(eval("camctrl_c"+giCH_Curr+"_isptz")) == 1)
	{
		updateGoto();
	}
	
	eval("mdwin=event_i"+index+"_mdwin");
	document.getElementsByName("win")[0].checked=mdwin&1?1:0;
	document.getElementsByName("win")[1].checked=mdwin&2?1:0;
	document.getElementsByName("win")[2].checked=mdwin&4?1:0;
	document.getElementsByName("win")[3].checked=mdwin&8?1:0;
	document.getElementsByName("win")[4].checked=mdwin&16?1:0;
	
	eval("manualtrigger=event_i"+index+"_vi");
	document.getElementsByName("vin")[0].checked=manualtrigger&1?1:0;
	document.getElementsByName("vin")[1].checked=manualtrigger&2?1:0;
	document.getElementsByName("vin")[2].checked=manualtrigger&4?1:0;

	if(motion_c0_win_i0_enable=="0")
		document.getElementById("mdwin0").style.display="none";	 
	if(motion_c0_win_i1_enable=="0")
		document.getElementById("mdwin1").style.display="none";	
	if(motion_c0_win_i2_enable=="0")
		document.getElementById("mdwin2").style.display="none";
	if(motion_c0_win_i3_enable=="0")
		document.getElementById("mdwin3").style.display="none";
	if(motion_c0_win_i4_enable=="0")
		document.getElementById("mdwin4").style.display="none";
	
	//profile setting	
	eval("mdwin_p=event_i"+index+"_mdwin0");
	document.getElementsByName("win_p")[0].checked=mdwin_p&1?1:0;
	document.getElementsByName("win_p")[1].checked=mdwin_p&2?1:0;
	document.getElementsByName("win_p")[2].checked=mdwin_p&4?1:0;
	document.getElementsByName("win_p")[3].checked=mdwin_p&8?1:0;
	document.getElementsByName("win_p")[4].checked=mdwin_p&16?1:0;
	
	if(motion_c0_profile_i0_win_i0_enable=="0")
		document.getElementById("mdwin_p0").style.display="none";	 
	if(motion_c0_profile_i0_win_i1_enable=="0")
		document.getElementById("mdwin_p1").style.display="none";	
	if(motion_c0_profile_i0_win_i2_enable=="0")
		document.getElementById("mdwin_p2").style.display="none";
	if(motion_c0_profile_i0_win_i3_enable=="0")
		document.getElementById("mdwin_p3").style.display="none";
	if(motion_c0_profile_i0_win_i4_enable=="0")
		document.getElementById("mdwin_p4").style.display="none";

	eval("weekday=event_i"+index+"_weekday");
	document.getElementsByName("day")[0].checked=weekday&64?1:0;
	document.getElementsByName("day")[1].checked=weekday&32?1:0;
	document.getElementsByName("day")[2].checked=weekday&16?1:0;
	document.getElementsByName("day")[3].checked=weekday&8?1:0;
	document.getElementsByName("day")[4].checked=weekday&4?1:0;
	document.getElementsByName("day")[5].checked=weekday&2?1:0;
	document.getElementsByName("day")[6].checked=weekday&1?1:0;
	
	if(server_i0_name=="")
		document.getElementById("server0").style.display="none";
	if(server_i1_name=="")
		document.getElementById("server1").style.display="none";
	if(server_i2_name=="")
		document.getElementById("server2").style.display="none";
	if(server_i3_name=="")
		document.getElementById("server3").style.display="none";
	if(server_i4_name=="")
		document.getElementById("server4").style.display="none";

	initPage();

	for (iIndex = 0; iIndex < 5; iIndex++)
	{
		if (eval("server_i" + iIndex + "_type") != "ns")
		{
			document.getElementById("server_view_" + iIndex).style.display = "none";
			document.getElementById("server" + iIndex + "_datefolder_checkbox").style.display = "none";
		}
		else
		{
			document.getElementById("server_i" + iIndex + "_datefolder").value = "event_i" + index + "_action_server_i" + iIndex + "_datefolder"
		}
	}

	if ($("tr[id^=server]:visible").length != 0 )
	{
		$("#backupBlk").show();
	}
	else
	{
		$("#backupBlk").hide();
	}
	
	if (ParamUndefinedOrZero("capability_localstorage_smartsd"))
	{		
		document.getElementById("smartSD").style.display = "none";
	}
	else
	{
		if( ParamUndefinedOrZero("smartsd_attached"))
		{
			document.getElementById("smartSD").style.display = "none";
		}
	}


	if (!ParamUndefinedOrZero("event_i0_action_custom0_name") && event_i0_action_custom0_name != "")
	{
		document.getElementById("custom0").style.display = "block";
		document.getElementById("custom0_name").innerHTML = event_i0_action_custom0_name;
	}	

	if (!ParamUndefinedOrZero("event_i0_action_custom1_name") && event_i0_action_custom1_name != "")
	{
		document.getElementById("custom1").style.display = "block";
		document.getElementById("custom1_name").innerHTML = event_i0_action_custom1_name;
	}
	if (!ParamUndefinedOrZero("event_i0_action_custom2_name") && event_i0_action_custom2_name != "")
	{
		document.getElementById("custom2").style.display = "block";
		document.getElementById("custom2_name").innerHTML = event_i0_action_custom2_name;
	}


	vadp_ui();
	HideUnsupportTriggerType();
}

function loadvaluedone()
{

	if(document.getElementById("begintime").value=="00:00" && document.getElementById("endtime").value=="24:00")
	{
		document.getElementsByName("method")[0].checked=1;
		document.getElementById("begintime").disabled="disabled";
		document.getElementById("endtime").disabled="disabled";
	}
	else
		document.getElementsByName("method")[1].checked=1;
	
	if(document.getElementsByTagName("input")[0].value=="")
	{
		document.forms[0].reset();
		added=1;
	}
	
	var eventName = eval('event_i'+index+'_name');
	
	if (eventName != "")
	{
		document.getElementById("eventName").disabled=true;
	}

	// di triggerStatus
	var triggerStatusValue;
	for ( num=0 ; num < parseInt(capability_ndi,10) ; num++ )
	{
		di_triggerstatus="triggerstatus"+num;
		dieXs="die"+num+"s"
		
		if ( num == 0 )//for di1
		{	
			triggerStatusValue = (eval('event_i'+index+'_triggerstatus'))+","+(eval('event_i'+index+'_exttriggerstatus'));
		}
		else//for di2, di3, di4.....
		{	
			triggerStatusValue = (eval('event_i'+index+'_exttriggerstatus'+num));
		}

		triggerStatusValue = (triggerStatusValue.replace(/~/g, "_"));
		splited = triggerStatusValue.split(",");
		
		for (var i=0; i<splited.length; i++)
		{
			for (var j=0; j < document.getElementsByName(di_triggerstatus).length; j++)
			{	
				if (document.getElementsByName(di_triggerstatus)[j].value == splited[i])
				{
					document.getElementsByName(di_triggerstatus)[j].checked=true;
				}
			}
		}
	}

	
//  triggerStatusValue = (eval('event_i'+index+'_exttriggerstatus2'));
//  triggerStatusValue = (triggerStatusValue.replace(/~/g, "_"));
//  splited = triggerStatusValue.split(",");
//  for (var i=0; i<splited.length; i++)
//  {
//    for (var j=0; j < document.getElementsByName("triggerstatus2").length; j++)
//    {	
//      if (document.getElementsByName("triggerstatus2")[j].value == splited[i])
//      {
//        document.getElementsByName("triggerstatus2")[j].checked=true;
//      }
//    }
//  }

	// tampering triggerStatus
	var tampering_triggerStatusValue = (eval('event_i'+index+'_triggerstatus'))+","+(eval('event_i'+index+'_exttriggerstatus'));
	splited = tampering_triggerStatusValue.split(",");

	for (var i=0; i < document.getElementsByName("tampering_triggerstatus").length; i++)
	{
		document.getElementsByName("tampering_triggerstatus")[i].checked=false;
		for (var j=0; j<splited.length; j++)
		{	
			if (document.getElementsByName("tampering_triggerstatus")[i].value == splited[j])
			{
				document.getElementsByName("tampering_triggerstatus")[i].checked=true;
			}
		}
	}

   	//audio detect
	eval("valevel=event_i"+index+"_valevel");
	document.getElementsByName("valevel_n")[0].checked=valevel&1?1:0;

	//audio detect profile
	eval("valevel0=event_i"+index+"_valevel0");
	document.getElementsByName("valevel_p")[0].checked=valevel0&1?1:0;

    	if ( capability_supportsd == "0" )
	{
		document.getElementById("backupBlk").style.display = "none";
		document.getElementById("localStorageSD").style.display = "none";
	}
	
	displayGotoSync(document.getElementById("action_goto"));
}

function initPage()
{
	var hideArray = new Array();
	var triggerType = eval('event_i' + index + '_trigger');

	for (idx = 0; idx < typeList.length; idx++)
	{
		if (triggerType != typeList[idx])
		{
			hideArray.push(childList[idx]);
		}
	}
	
	/*switch (triggerType)
	{
		case "motion":
			hideArray.push("seqChild", "diChild", "tdChild", "viChild", "adChild");
			break;
		case "seq":
			hideArray.push("mdChild", "diChild", "tdChild", "viChild", "adChild");
			break;
		case "di":
			hideArray.push("seqChild", "mdChild", "tdChild", "viChild", "adChild");
			break;
		case "boot":
			hideArray.push("seqChild", "mdChild", "diChild", "tdChild", "viChild", "adChild");
			break;
		case "recnotify":
			hideArray.push("seqChild", "mdChild", "diChild", "tdChild", "viChild", "adChild");
			break;
		case "tampering":
			hideArray.push("seqChild", "mdChild", "diChild", "viChild", "adChild");
			break;
		case "vi":
			hideArray.push("seqChild", "mdChild", "diChild", "tdChild", "adChild");
			break;	
		case "volalarm":	
			hideArray.push("seqChild", "mdChild", "diChild", "tdChild", "viChild");
			break;
	}*/
   jQuery.each(hideArray, function(i) { 
     $("#" + hideArray[i]).css("display","none");
   });    
 
	if (triggerType == "recnotify")
	{
		fillMediaSpecific(translator("recording_notify_message"), 101);
		preChangeMediaType = "recnotify";
	}
	else
	{
		fillMediaOptions();
		preChangeMediaType = "normal";
	}
	if (triggerType == "smartsd")
	{
		document.getElementById("localStorageSD").style.display = "none";
		document.getElementById("action_sd").checked = false;
	}
}

function updateTriggerList(triggerType)
{
	for (idx = 0; idx < typeList.length; idx++)
	{
		if (triggerType != typeList[idx])
		{
			$('#' + childList[idx]).slideUp('slow');
		}
		else
		{
			$('#' + childList[idx]).slideDown('slow');
		}
	}
	if (triggerType == "smartsd")
	{
		document.getElementById("localStorageSD").style.display = "none";
		document.getElementById("action_sd").checked = false;
	}
	else
	{
		document.getElementById("localStorageSD").style.display = "block";
	}
}

function viewInfo(server)
{
	if (server.id == "cf_view")
	{
		//cf[2~4] is a symbolic link to /mnt/auto/CF/${event_i[0~2]_action_cf_folder}
		//dest = "cf.html?index=" + eval(index + 2);
		dest = "/setup/localstorage/storage_searching_view.html";
		var subWindow = window.open(dest, "", 'modal=yes, width=800, height=900, resizable=no, scrollbars=yes');
		subWindow.focus();
	}
	else
	{	//parse 1 character from addr 12 (ex. server_view_1)
		var serverIdx = server.id.substr(12, 1);
		dest="/setup/recording/recording_network.html?index=" + serverIdx;
		openurl(dest);
	}
}

function checkname()
{
	if (CheckEmptyString(document.getElementsByTagName("input")[0]) == -1)
	{
		return -1;
	}
	if((document.getElementsByTagName("input")[0].value==event_i0_name ||
		document.getElementsByTagName("input")[0].value==event_i1_name ||
		document.getElementsByTagName("input")[0].value==event_i2_name) && added==1)
	{
		alert(translator("the_name_has_already_existed"));
		return -1;
	}
	else
		return 0;
}

function submitform()
{
	var f = document.forms[0];
	document.getElementById("mdwin").value=document.getElementsByName("win")[0].checked+document.getElementsByName("win")[1].checked*2+document.getElementsByName("win")[2].checked*4+document.getElementsByName("win")[3].checked*8+document.getElementsByName("win")[4].checked*16;
	document.getElementById("vi").value=document.getElementsByName("vin")[0].checked+document.getElementsByName("vin")[1].checked*2+document.getElementsByName("vin")[2].checked*4;
	document.getElementById("mdwin_p").value=document.getElementsByName("win_p")[0].checked+document.getElementsByName("win_p")[1].checked*2+document.getElementsByName("win_p")[2].checked*4+document.getElementsByName("win_p")[3].checked*8+document.getElementsByName("win_p")[4].checked*16;
	//audio detect
	document.getElementById("valevel_n").value=(document.getElementsByName("valevel_n")[0].checked)?1:0;
	document.getElementById("valevel_p").value=(document.getElementsByName("valevel_p")[0].checked)?1:0;

	// submit di triggerStatus
	var value_count = 0;
	for ( num=0, bitwise=1 ; num < parseInt(capability_ndi, 10) ; num++ , bitwise*=2)
	{
		di_triggerstatus="triggerstatus"+num;
		
		if ( document.getElementsByName(di_triggerstatus)[0].checked ||
			 document.getElementsByName(di_triggerstatus)[1].checked ||
			 document.getElementsByName(di_triggerstatus)[2].checked )
		value_count += bitwise;	
	}
	document.getElementById("di").value=value_count;
	
	//di1
	var triggerStatusValue = new Array();
	var triggerStatusArray = document.getElementsByName("triggerstatus0");
	for (var i=0; i < triggerStatusArray.length; i++)
	{
		if (triggerStatusArray[i].checked)
		{
			triggerStatusValue.push(triggerStatusArray[i].value.replace("_", "~"));
		}
	}

	if (triggerStatusValue.length > 0)
	{
		document.getElementById("dis").value = triggerStatusValue[0];
		if (triggerStatusValue.length == 1)
			document.getElementById("dies").value ="";
		else
		{
			document.getElementById("dies").value = triggerStatusValue[1];
			for (var i=2; i < triggerStatusValue.length; i++)
			{
				document.getElementById("dies").value += "," + triggerStatusValue[i];
			}
		}
	}
	else
	{
		document.getElementById("dis").value = "";
		document.getElementById("dies").value = "";
	}

	//di2,di3,di4..........
	if (parseInt(capability_ndi,10) > 1)	
	{
		for ( num=1 ; num < parseInt(capability_ndi,10) ; num++ )
		{
			di_triggerstatus="triggerstatus"+num;
			dieXs="die"+num+"s"
		
			var triggerStatusValue = new Array();
			var triggerStatusArray = document.getElementsByName(di_triggerstatus);	
			for (var i=0; i < triggerStatusArray.length; i++)
			{
				if (triggerStatusArray[i].checked)
				{
					triggerStatusValue.push(triggerStatusArray[i].value.replace("_", "~"));
				}
			}
			document.getElementById(dieXs).value = "";
			for (var i=0; i < triggerStatusValue.length; i++)
			{
				document.getElementById(dieXs).value += triggerStatusValue[i];

				if ( i+1 <  triggerStatusValue.length)
				{
					document.getElementById(dieXs).value += ","
				}
			}
		}
	}

	var VadpValue, VadpTrigIdx, VadpN;
	VadpValue = 0;
	VadpN = document.getElementsByName("vadpn");
	for (var i = 0; i < gVadpTrigNum; i++)
	{
		VadpTrigIdx = VadpN[i].id;
		VadpTrigIdx = VadpTrigIdx[VadpTrigIdx.length - 1];
		VadpValue += (VadpN[i].checked * (1 << VadpTrigIdx));
	}
	document.getElementById("vadp").value = VadpValue;

	event_index_trigger="event_i"+index+"_trigger";

	if ( document.getElementsByName(event_index_trigger)[2].checked != 1 &&     //if not di
		 document.getElementsByName(event_index_trigger)[5].checked != 1 &&		//if not audio
		 document.getElementsByName(event_index_trigger)[8].checked != 1 )      //if not tampering
	{
		document.getElementById("dis").value = "trigger";
		document.getElementById("dies").value = "";
		if (parseInt(capability_ndi,10) > 1)	
		{
			for (iDI = 1; iDI < parseInt(capability_ndi, 10) ; iDI++)
			{
				document.getElementById("die"+iDI+"s").value = "";
			}
		}
	}

    if ( document.getElementsByName(event_index_trigger)[5].checked == 1)     //if audio detection
	{
		document.getElementById("dis").value = $(f).find("select[id=audio_triggerstatus]").val();
		document.getElementById("die1s").value = $(f).find("select[id=audio_profile_triggerstatus]").val();
	}
	
	if ( document.getElementsByName(event_index_trigger)[8].checked == 1)     //if tampering detection
	{
		// submit tampering triggerStatus
		var tampering_triggerStatusValue = new Array();
		var tampering_triggerStatusArray = document.getElementsByName("tampering_triggerstatus");
		for (var i=0; i < tampering_triggerStatusArray.length; i++)
		{
			if (tampering_triggerStatusArray[i].checked)
			{
				tampering_triggerStatusValue.push(tampering_triggerStatusArray[i].value);
			}
		}
		if (tampering_triggerStatusValue.length > 0)
		{
			document.getElementById("dis").value = tampering_triggerStatusValue[0];
			if (tampering_triggerStatusValue.length == 1)
				document.getElementById("dies").value ="";
			else
			{
				document.getElementById("dies").value = tampering_triggerStatusValue[1];
				for (var i=2; i < tampering_triggerStatusValue.length; i++)
				{
					document.getElementById("dies").value += "," + tampering_triggerStatusValue[i];
				}
			}
		}
		else
		{
			document.getElementById("dis").value = "";
			document.getElementById("dies").value = "";
		}
	}

	document.getElementById("weekday").value=document.getElementsByName("day")[0].checked*64+document.getElementsByName("day")[1].checked*32+document.getElementsByName("day")[2].checked*16+document.getElementsByName("day")[3].checked*8+document.getElementsByName("day")[4].checked*4+document.getElementsByName("day")[5].checked*2+document.getElementsByName("day")[6].checked;
	
	document.getElementById("begintime").disabled="";
	document.getElementById("endtime").disabled="";
	
	if (CheckEmptyString(document.getElementById("begintime")) ||
		CheckEmptyString(document.getElementById("endtime")) ||
		CheckEmptyString(document.getElementById("delay")) ||
		CheckEmptyString(document.getElementById("inter")))
	{
		if (!ParamUndefinedOrZero("capability_ndo") && CheckEmptyString(document.getElementById("action_do_i0_duration")))
		{
			return -1;
		}
		return -1;
	}
	
	/*if (document.getElementById("begintime").value >= document.getElementById("endtime").value)
	{
		alert(translator("please_enter_a_valid_time"));
		return -1;
	}*/
	
	if(checkname() || checkvalue())
	{
		return -1;
	}

	
	updatecheckById("server_i0_datefolder", document.forms[0].server_i0_checkbox);
	updatecheckById("server_i1_datefolder", document.forms[0].server_i1_checkbox);
	updatecheckById("server_i2_datefolder", document.forms[0].server_i2_checkbox);
	updatecheckById("server_i3_datefolder", document.forms[0].server_i3_checkbox);
	updatecheckById("server_i4_datefolder", document.forms[0].server_i4_checkbox);

	if ("volalarm" != $(f).find(":radio[name=event_i"+index+"_trigger]:checked")[0].value)
	{
		//$(f).find("select[name=event_i"+index+"_triggerstatus]")[0].value = "trigger";
		$(f).find("select[name=event_i"+index+"_triggerstatus]").attr("disabled", true); 
		//$(f).append("<input name='event_i" + index + "_triggerstatus' value='trigger' type='hidden'");
	}
	bSaved = true;
	f.submit();

	$(f).find("select[name=event_i"+index+"_triggerstatus]").attr("disabled", false); 
	//$(f).find("input[name=event_i"+index+"_triggerstatus]").remove();
}

function changemethod()
{
	if(document.getElementsByName("method")[0].checked==1)
	{
		document.getElementById("begintime").disabled="disabled";
		document.getElementById("endtime").disabled="disabled";
		document.getElementById("begintime").value="00:00";
		document.getElementById("endtime").value="24:00";
	}
	else
	{
		document.getElementById("begintime").disabled="";
		document.getElementById("endtime").disabled="";
	}
}

function testsd()
{
	form1=document.sd_test;
	form1.action.value=document.getElementById("action_cf_enable").value;

	if (form1.action.value == 1)
	{
		window.open("", "testsd", "height=100,width=400");
		form1.target="testsd";
		form1.submit();
	}
}

function ShowPresetSelction()
{
	var i = 0;
	var list=document.getElementById("action_goto_name");
	var max_preset_count = getParamValueByName('capability_npreset');
	if (max_preset_count == "")
	{
		max_preset_count = 20; // To prevent a standard product might lose this capability_npreset.
	}
	for (i = 0; i < max_preset_count; i++)
	{
		var PreName = getParamValueByName('camctrl_c0_preset_i' + i + '_name');
		
		if (PreName != "")
		{
			list.options[++list.length-1].text=PreName;
			list.options[list.length-1].value=PreName;			
		}	
	}
}

function fillMediaOptions()
{
	if(media_i0_name!="")
	{
		document.getElementById("action_server_i0_media").options[++document.getElementById("action_server_i0_media").length-1].text=media_i0_name;
		document.getElementById("action_server_i0_media").options[document.getElementById("action_server_i0_media").length-1].value=0;
		document.getElementById("action_server_i1_media").options[++document.getElementById("action_server_i1_media").length-1].text=media_i0_name;
		document.getElementById("action_server_i1_media").options[document.getElementById("action_server_i1_media").length-1].value=0;
		document.getElementById("action_server_i2_media").options[++document.getElementById("action_server_i2_media").length-1].text=media_i0_name;
		document.getElementById("action_server_i2_media").options[document.getElementById("action_server_i2_media").length-1].value=0;
		document.getElementById("action_server_i3_media").options[++document.getElementById("action_server_i3_media").length-1].text=media_i0_name;
		document.getElementById("action_server_i3_media").options[document.getElementById("action_server_i3_media").length-1].value=0;
		document.getElementById("action_server_i4_media").options[++document.getElementById("action_server_i4_media").length-1].text=media_i0_name;
		document.getElementById("action_server_i4_media").options[document.getElementById("action_server_i4_media").length-1].value=0;
		document.getElementById("action_cf_media").options[++document.getElementById("action_cf_media").length-1].text=media_i0_name;
		document.getElementById("action_cf_media").options[document.getElementById("action_cf_media").length-1].value=0;
	}
	if(media_i1_name!="")
	{
		document.getElementById("action_server_i0_media").options[++document.getElementById("action_server_i0_media").length-1].text=media_i1_name;
		document.getElementById("action_server_i0_media").options[document.getElementById("action_server_i0_media").length-1].value=1;
		document.getElementById("action_server_i1_media").options[++document.getElementById("action_server_i1_media").length-1].text=media_i1_name;
		document.getElementById("action_server_i1_media").options[document.getElementById("action_server_i1_media").length-1].value=1;
		document.getElementById("action_server_i2_media").options[++document.getElementById("action_server_i2_media").length-1].text=media_i1_name;
		document.getElementById("action_server_i2_media").options[document.getElementById("action_server_i2_media").length-1].value=1;
		document.getElementById("action_server_i3_media").options[++document.getElementById("action_server_i3_media").length-1].text=media_i1_name;
		document.getElementById("action_server_i3_media").options[document.getElementById("action_server_i3_media").length-1].value=1;
		document.getElementById("action_server_i4_media").options[++document.getElementById("action_server_i4_media").length-1].text=media_i1_name;
		document.getElementById("action_server_i4_media").options[document.getElementById("action_server_i4_media").length-1].value=1;
		document.getElementById("action_cf_media").options[++document.getElementById("action_cf_media").length-1].text=media_i1_name;
		document.getElementById("action_cf_media").options[document.getElementById("action_cf_media").length-1].value=1;

	}
	if(media_i2_name!="")
	{
		document.getElementById("action_server_i0_media").options[++document.getElementById("action_server_i0_media").length-1].text=media_i2_name;
		document.getElementById("action_server_i0_media").options[document.getElementById("action_server_i0_media").length-1].value=2;
		document.getElementById("action_server_i1_media").options[++document.getElementById("action_server_i1_media").length-1].text=media_i2_name;
		document.getElementById("action_server_i1_media").options[document.getElementById("action_server_i1_media").length-1].value=2;
		document.getElementById("action_server_i2_media").options[++document.getElementById("action_server_i2_media").length-1].text=media_i2_name;
		document.getElementById("action_server_i2_media").options[document.getElementById("action_server_i2_media").length-1].value=2;
		document.getElementById("action_server_i3_media").options[++document.getElementById("action_server_i3_media").length-1].text=media_i2_name;
		document.getElementById("action_server_i3_media").options[document.getElementById("action_server_i3_media").length-1].value=2;
		document.getElementById("action_server_i4_media").options[++document.getElementById("action_server_i4_media").length-1].text=media_i2_name;
		document.getElementById("action_server_i4_media").options[document.getElementById("action_server_i4_media").length-1].value=2;
		document.getElementById("action_cf_media").options[++document.getElementById("action_cf_media").length-1].text=media_i2_name;
		document.getElementById("action_cf_media").options[document.getElementById("action_cf_media").length-1].value=2;

	}
	if(media_i3_name!="")
	{
		document.getElementById("action_server_i0_media").options[++document.getElementById("action_server_i0_media").length-1].text=media_i3_name;
		document.getElementById("action_server_i0_media").options[document.getElementById("action_server_i0_media").length-1].value=3;
		document.getElementById("action_server_i1_media").options[++document.getElementById("action_server_i1_media").length-1].text=media_i3_name;
		document.getElementById("action_server_i1_media").options[document.getElementById("action_server_i1_media").length-1].value=3;
		document.getElementById("action_server_i2_media").options[++document.getElementById("action_server_i2_media").length-1].text=media_i3_name;
		document.getElementById("action_server_i2_media").options[document.getElementById("action_server_i2_media").length-1].value=3;
		document.getElementById("action_server_i3_media").options[++document.getElementById("action_server_i3_media").length-1].text=media_i3_name;
		document.getElementById("action_server_i3_media").options[document.getElementById("action_server_i3_media").length-1].value=3;
		document.getElementById("action_server_i4_media").options[++document.getElementById("action_server_i4_media").length-1].text=media_i3_name;
		document.getElementById("action_server_i4_media").options[document.getElementById("action_server_i4_media").length-1].value=3;
		document.getElementById("action_cf_media").options[++document.getElementById("action_cf_media").length-1].text=media_i3_name;
		document.getElementById("action_cf_media").options[document.getElementById("action_cf_media").length-1].value=3;

	}
	if(media_i4_name!="")
	{
		document.getElementById("action_server_i0_media").options[++document.getElementById("action_server_i0_media").length-1].text=media_i4_name;
		document.getElementById("action_server_i0_media").options[document.getElementById("action_server_i0_media").length-1].value=4;
		document.getElementById("action_server_i1_media").options[++document.getElementById("action_server_i1_media").length-1].text=media_i4_name;
		document.getElementById("action_server_i1_media").options[document.getElementById("action_server_i1_media").length-1].value=4;
		document.getElementById("action_server_i2_media").options[++document.getElementById("action_server_i2_media").length-1].text=media_i4_name;
		document.getElementById("action_server_i2_media").options[document.getElementById("action_server_i2_media").length-1].value=4;
		document.getElementById("action_server_i3_media").options[++document.getElementById("action_server_i3_media").length-1].text=media_i4_name;
		document.getElementById("action_server_i3_media").options[document.getElementById("action_server_i3_media").length-1].value=4;
		document.getElementById("action_server_i4_media").options[++document.getElementById("action_server_i4_media").length-1].text=media_i4_name;
		document.getElementById("action_server_i4_media").options[document.getElementById("action_server_i4_media").length-1].value=4;
		document.getElementById("action_cf_media").options[++document.getElementById("action_cf_media").length-1].text=media_i4_name;
		document.getElementById("action_cf_media").options[document.getElementById("action_cf_media").length-1].value=4;
	}
}

function updateGoto() 
{
	var selObj = document.getElementById("action_goto_name");
	
	getParamValueByName("value="+selObj.name);
	for (i = 0; i < selObj.length; i ++)
	{	    
		if (selObj.options[i].text == value)
		{
			selObj.options[i].selected = true;
			break;
		}				
	}
}

function fillMediaSpecific(name, value)
{
	document.getElementById("action_server_i0_media").options[0].text=name;
	document.getElementById("action_server_i0_media").options[0].value=value;
	document.getElementById("action_server_i1_media").options[0].text=name;
	document.getElementById("action_server_i1_media").options[0].value=value;
	document.getElementById("action_server_i2_media").options[0].text=name;
	document.getElementById("action_server_i2_media").options[0].value=value;
	document.getElementById("action_server_i3_media").options[0].text=name;
	document.getElementById("action_server_i3_media").options[0].value=value;
	document.getElementById("action_server_i4_media").options[0].text=name;
	document.getElementById("action_server_i4_media").options[0].value=value;
	document.getElementById("action_cf_media").options[0].text=name;
	document.getElementById("action_cf_media").options[0].value=value;

}

function clearSelects()
{
	document.getElementById("action_server_i0_media").options[0].text="-----None-----";
	document.getElementById("action_server_i0_media").options[0].value="";
	document.getElementById("action_server_i0_media").length=1;
	document.getElementById("action_server_i1_media").options[0].text="-----None-----";
	document.getElementById("action_server_i1_media").options[0].value="";
	document.getElementById("action_server_i1_media").length=1;
	document.getElementById("action_server_i2_media").options[0].text="-----None-----";
	document.getElementById("action_server_i2_media").options[0].value="";
	document.getElementById("action_server_i2_media").length=1;
	document.getElementById("action_server_i3_media").options[0].text="-----None-----";
	document.getElementById("action_server_i3_media").options[0].value="";
	document.getElementById("action_server_i3_media").length=1;
	document.getElementById("action_server_i4_media").options[0].text="-----None-----";
	document.getElementById("action_server_i4_media").options[0].value="";
	document.getElementById("action_server_i4_media").length=1;
	document.getElementById("action_cf_media").options[0].text="-----None-----";
	document.getElementById("action_cf_media").options[0].value="";
	document.getElementById("action_cf_media").length=1;
}

function changeMedia(judgement)
{
	checksmartSD();
	if (judgement == "recnotify")
	{
		clearSelects();
		fillMediaSpecific(translator("recording_notify_message"), 101);
	}
	else
	{
		// If previous trigger type is not "recnotify", don't reset media options
		if (preChangeMediaType == "recnotify")
		{
			clearSelects();
		fillMediaOptions();
		}
	}
	preChangeMediaType = judgement;
}
function checksmartSD()
{
	if (ParamUndefinedOrZero("capability_localstorage_smartsd"))
	{	
		document.getElementById("localStorageSD").style.display = "none";    
	}
}

function updateDO(Id, checkbox)
{
	if(ircutcontrol_enableextled == "1")
	{
		//document.getElementById("extir_on_warning_message").style.display="";
		//document.getElementById("extir_on_warning_message").slideDown('slow');
		$("#extir_on_warning_message").slideDown("slow");
		checkbox.checked = false;
		return;
	}
	
	updatecheckById(Id, checkbox);
}

function GenerateDIDOList()
{
	//Generate DI in Trigger step
	$(document.getElementById("diList")).append(""	
	+'<input name="event_index_di" type="hidden" id="di"/>'
	+'<input name="event_index_triggerstatus" type="hidden" id="dis"/>'
	+'<input name="event_index_exttriggerstatus" type="hidden" id="dies"/>'
    +'<input name="event_index_exttriggerstatus1" type="hidden" id="die1s"/>');

	//die1s is both for DI2 and audio detection profile, so add die2s since DI3 
	if(parseInt(capability_ndi, 10) > 2)
	{
		for (iDI = 2; iDI < parseInt(capability_ndi, 10) ; iDI++)
		{
			$(document.getElementById("diList")).append(""	
			+'<input name="event_index_exttriggerstatus'+iDI+'" type="hidden" id="die'+iDI+'s"/>');
		}
	}

	for (iDI = 0; iDI < parseInt(capability_ndi, 10) ; iDI++)
	{
		triggerstatus_num = iDI;
		$(document.getElementById("diList")).append(""
		+'<dt>'
		+'  <span title="symbol">'+translator("digital_input")+'</span><span id="digital_input_num_'+iDI+'"> '+eval(iDI+1)+'</span> :'
		+'  <span id="di'+eval(3*iDI)+'">'
		+'    <input  name="triggerstatus'+triggerstatus_num+'" value="trigger" type="checkbox"/>'
		+'    <span title="symbol">'+translator("active")+'</span>'
		+'  </span>'
		+'  <span id="di'+eval(3*iDI+1)+'">'
		+'    <input  name="triggerstatus'+triggerstatus_num+'" value="normal_trigger" type="checkbox"/>'
		+'    <span title="symbol">'+translator("normal_to_active")+'</span>'
		+'  </span>'
		+'  <span id="di'+eval(3*iDI+2)+'">'
		+'    <input  name="triggerstatus'+triggerstatus_num+'" value="trigger_normal" type="checkbox"/>'
		+'    <span title="symbol">'+translator("active_to_normal")+'</span>'
		+'  </span>'
		+'</dt>');
	}
	//If only 1 DI, hide the number
	if(parseInt(capability_ndi, 10) == 1)
	{
		$("#digital_input_num_0").hide();	
	}
	
	//Generate DO in Action step
	for (iDO = parseInt(capability_ndo, 10)-1 ; iDO >= 0; iDO--)
	{
		if(parseInt(capability_ndo, 10) == 1)
		{
			trigger_do_num = '';
		}
		else
		{
			trigger_do_num = '_'+eval(iDO+1);
		}
		$(document.getElementById("action")).prepend(""
		+'<dt id=do'+iDO+'>'
		+'  <span title="symbol" style=" margin-left:4px;" >'+translator("trigger_D_O"+trigger_do_num+"_for")+'</span>'
		+'  <input name="event_index_action_do_i'+iDO+'_duration" style="margin-left:4px;margin-right:4px;"type="text" id="action_do_i'+iDO+'_duration" title="param,num,999,1" value="1" size="3" maxlength="3"/>'
		+'  <span title="symbol">'+translator("seconds")+'</span>'
		+'</dt>');
		document.getElementById("action_do_i"+iDO+"_duration").defaultValue=1;

		if(iDO == 0 )
		{
			$(document.getElementById("do"+iDO)).prepend(""
			+'<input name="event_index_action_do_i0_enable" type="hidden" id="action_do_i0_enable" title="param" value="0"/>'
			+'<input  type="checkbox" onclick="updateDO(\'action_do_i0_enable\', this)"/>');
		}
		else
		{
			$(document.getElementById("do"+iDO)).prepend(""
			+'<input name="event_index_action_do_i'+iDO+'_enable" type="hidden" id="action_do_i'+iDO+'_enable" title="param" value="0"/>'
			+'<input  type="checkbox" onchange="updatecheckById(\'action_do_i'+iDO+'_enable\', this)"/>');
		}
		document.getElementById("action_do_i"+iDO+"_enable").defaultValue=0;
	}	
	//Append external ir led warning message in the last element
	$(document.getElementById("do"+(parseInt(capability_ndo, 10)-1))).append(""
		+'<div id="extir_on_warning_message" style="overflow: hidden; display:none">'
		+'  <p class="note">'
		+'  <span title="symbol">'+translator("please_go_to")+'</span>&nbsp;'
		+'  <span class="link" onclick="window.open(\'/setup/media/imaging.html\',\'\',\'width=860, height=700, scrollbars=yes, status=yes,resizable=yes\')" title="symbol">image</span>&nbsp;'
		+'  <span title="symbol">'+translator("turn_on_extir_warning_message_for_do_action")+'</span>'
		+'  </p>'
		+'</div>');
}

function HideUnsupportTriggerType()
{
	//Hide DI if not support DI
	if (ParamUndefinedOrZero("capability_ndi"))
	{
		$("#diParent").hide();
	}

	if (capability_supporttriggertypes.search("shockalarm") < 0)
	{
		$("#gsensorParent").hide();
	}	
	//Hide PIR if not support PIR
	if (ParamUndefinedOrZero("capability_npir"))
	{
		$("#pdParent").hide();
	}
	//Hide VADP event if not support vadp event trigger
	//0x10 means capability_vadp_supportfeature=16 and it presents vadp event triggr
	if (!(parseInt(capability_vadp_supportfeature,10) & 0x10))
	{
		$("#vadpParent").hide();
		$("#vadp-trig-menu").hide();
	}
	//Hide audio detection if not support audioin	
	if (ParamUndefinedOrZero("capability_naudioin"))
	{
		$("#adParent").hide();
	}
	//Hide camera tampering detection if not support tampering detection
	if (ParamUndefinedOrZero("capability_tampering"))
	{
		$("#tdParent").hide();
	}
	//Hide temperature detection if not support temperature detection	
	if (ParamUndefinedOrZero("capability_thermal_temperaturedetection"))
	{
		$("#temParent").hide();
	}
}

function vadp_ui()
{
	var i;
	var vadp_trig_bit = eval('event_i' + index + '_vadp');
	var topic_name, trigger_name;
	
	gVadpTrigNum = 0;
	EVTMGR_TRIG_NUM = eval(vadp_event_ntrigger);

	for (i = 0; i < EVTMGR_TRIG_NUM; i++)
	{
		topic_name 		= eval('vadp_event_triggerlist_i' + i + '_topic');
		
		if (topic_name == '')
		{
			continue;
		}
		topic_split 	= topic_name.split("/");
		trigger_name 	= topic_split[topic_split.length - 1];
		
		$('#vadp_trigger_list').append('<dt><input name="vadpn" type="checkbox" id="vadp_trig_idx_' + i + '"/><span title="' + topic_name + '">' + trigger_name + '</span></dt>');
		if (((vadp_trig_bit >> i) & 1) != 0)
		{
			document.getElementById('vadp_trig_idx_' + i).checked = 1;
		}
		gVadpTrigNum++;
	}
}

function displayGotoSync(chkbox)
{
	if (document.getElementById("goto_preset").style.display == "none")
	{
		$("#gotoSync").slideUp();
		return;
	}

	if (chkbox.checked)
	{
		$("#gotoSync").slideDown();
	}
	else
	{
		$("#gotoSync").slideUp();
	}
}
