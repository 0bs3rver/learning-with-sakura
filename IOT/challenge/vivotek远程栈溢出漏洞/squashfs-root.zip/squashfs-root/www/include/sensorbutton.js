function loadCurrentSetting()
{	
	loadlanguage();
	parent.document.getElementById("exposurebutton").height = document.body.scrollHeight;
	document.getElementById("content").style.visibility = "visible";
}

function RestoreButton()
{
	getIframeDocumentById("exposurepage").getElementById("exposureRestoreButton").click();
}

function SaveButton()
{
	getIframeDocumentById("exposurepage").getElementById("exposureSaveButton").click();
}


