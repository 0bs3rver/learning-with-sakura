var g_ChannelDivider = 2/capability_nvideoin;
//PM_WINDOW_SIZE and PM_Window_selected is for non-IE(WIN) only
var PM_WINDOW_SIZE = 5;
var PM_Window_selected = -1; // serve as the first element or selected element to show the PM page default window_name.
var WinLessPluginCtrl;
eval(location.search.toString().slice(1));  //giCH_Curr=X

//For Polygon
var POLYGON_POINTS_NUM = 4;
var PM_Window_MOUSEON = -1;
var mouseX = 0;
var mouseY = 0;
var canvasDiv;
var gr;
var col;
var pen;
var points = new Array();
var winPoints = new Array(PM_WINDOW_SIZE);
var WinIndex = 0;
var CreatingWin = -1;

var ie = false;
if(document.all)
	ie = true;

for (i = 0; i < PM_WINDOW_SIZE; i++)
{
	winPoints[i] = new Array();
}

//Plugin constant.
var PLUGIN_ID = "WinLessPluginCtrl";
var PLUGIN_NAME = "VVTK_Plugin_Installer.exe";
var PLUGIN_VER = "1,0,0,114";
var CLASS_ID = "64865E5A-E8D7-44C1-89E1-99A84F6E56D0";
var FFTYPE = "application/x-streamctrl";
var FF_VER = "1.0.0.88";
var VNDPWRAPPER_VER = "1,0,0,69";
var FF_XPI_DESCRIPTION = "Installer Management v" + FF_VER;
var PLUGIN_LANG="EN";
var BUFFERTIME=getCookie("streamingbuffertime");
var HTTP_METHOD = document.URL.split(":");
//Global variable.
var giCH_Curr = 0;
var giTargetStream = 0;
var gImgW = 320;
var gImgH = 240;
var gImg = null;
var gImgUrl;
var gTimer;
var gQuality = 3;
var giNonIERefreshImgPeriod = 1000; //ms, MIN is 1000.
var Width, Height;
//For 320x240 coordinate
var giCurDomainSizeW = 320;
var giCurDomainSizeH = 240;

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

eval("VideoSize=videoin_c" + giCH_Curr + "_s" + giTargetStream + "_resolution");
eval("codectype=videoin_c" + giCH_Curr + "_s" + giTargetStream + "_codectype");
if(codectype=="mpeg4" || codectype=="h264")
    eval("AccessName=network_rtsp_s" + giTargetStream + "_accessname");
else
    eval("AccessName=network_http_s" + giTargetStream + "_accessname");

function loadCurrentSetting()
{
	var tmp = location.href.split("?");
	var tmp2;

	tmp = tmp[1].split("&");
	tmp2 = tmp[0].split("=");

	if (tmp2[0] == 'ch')
	{
		giCH_Curr = parseInt(tmp2[1], 10);
		if (giCH_Curr >= parseInt(capability_nvideoin))
		{
			giCH_Curr = 0;
		}
	}
	
	if (parseInt(capability_nmediastream, 10) >= 2)
	{
		giTargetStream = FullviewStreamIndex();
	}

	eval("VideoSize=videoin_c" + giCH_Curr + "_s" + giTargetStream + "_resolution");
	eval("codectype=videoin_c" + giCH_Curr + "_s" + giTargetStream + "_codectype");
	if(codectype=="mpeg4" || codectype=="h264")
    	eval("AccessName=network_rtsp_s" + giTargetStream + "_accessname");
	else
    	eval("AccessName=network_http_s" + giTargetStream + "_accessname");

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?privacymask", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("privacy_mask");
	loadlanguage();

	Width = VideoSize.split("x")[0];
	Height = VideoSize.split("x")[1];

    for (var i = 0; i < capability_nvideoin; i++)
    {
        if ( i == giCH_Curr )
        {
            $("#enable_c"+i).show();
            eval("enabled=privacymask_c"+i+"_enable");
            if (enabled == '1')
            {
                $("#enable_c"+i).attr("checked", true);
            }
            else
            {
                $("#enable_c"+i).attr("checked", false);
            }
        }
        else
        {
            $("#enable_c"+i).hide();
        }
    }
	
	if (bIsWinMSIE)
	{
		$("#imagecoverBlock").css("background-color","#FFFFFF");
		$("#imagecoverBlock").css("opacity","0.01");
		if( eval("videoin_c"+giCH_Curr+"_rotate") == 90 || eval("videoin_c"+giCH_Curr+"_rotate") == 270)
		{
			$("#StreamContainer").addClass("StreamContainerStyleRotation");
		}
		else
		{
			$("#StreamContainer").addClass("StreamContainerStyle");
		}
		$('#imagecoverBlock').css('width', $("#StreamContainer").width() + "px");
		$('#imagecoverBlock').css('height', $("#StreamContainer").height() + "px");

		//initial PM Window by jQueryUI, enable window point draggable
		$('.PWP_style').live("mouseover", function() {     
			$(this).draggable({          
            	cursor: 'move',  
            	handle: 'div',
            	containment: '#imagecoverBlock',
            	drag: function(e, ui)
            	{
                	var self = $(this).data("draggable");
                	var pointX, pointY;
                	//$("#log-top").html(self.position.top.toFixed() + "px");
					//$("#log-left").html(self.position.left.toFixed() + "px");
					WinIndex = parseInt($(this).parent().attr("id").charAt($(this).parent().attr("id").length -1));
					var PointIndex = parseInt($(this).parent().children().index($(this)));
					if (eval('privacymask_c' + giCH_Curr + '_win_i' + WinIndex + '_enable') == '1')
					{
						points = winPoints[WinIndex];
						pointX = parseInt(self.position.left.toFixed());
						pointY = parseInt(self.position.top.toFixed());
						if (Width == Height) // Fisheye
						{
							pointX = (pointX>=160)? (pointX+6) : pointX;
							pointY = (pointY>=160)? (pointY+6) : pointY;
						}
						else
						{
							pointX = (pointX>=160)? (pointX+6) : pointX;
							pointY = (pointY>=120)? (pointY+6) : pointY;
						}
						
						//prevent to draw a dup point
						bDupPoint = false;
						for(var i = 0; i < points.length; i++)
						{
							if( (pointX == points[i].x) && (pointY == points[i].y) )
							{
								bDupPoint = true;
								break;
							}
						}
						
						if(!bDupPoint)
						{
							points[PointIndex - 5].x = pointX;
							points[PointIndex - 5].y = pointY;
						}
						
						$("#PolyMask" + PM_Window_selected).children().css("opacity","0.01");
						$("#PolyMask" + WinIndex).empty();
						$("#PolyMask" + WinIndex).parent().children().slice(0,POLYGON_POINTS_NUM).remove();
						drawPolygon(WinIndex);
					}
					else
					{
						points[PointIndex - 1].x = parseInt(self.position.left.toFixed());
						points[PointIndex - 1].y = parseInt(self.position.top.toFixed());
					}
            	},
            	stop: function()
            	{
                	var self = $(this).data("draggable");
            	}
        	});   
		});
    }
}

function receivedone()
{
	if (bIsWinMSIE)
	{    	
		$("#JSPlugin").css("display", "block");
	}	
}

function loadvaluedone()
{	
    var iIndex;
	var strPlugin = "";

	eval("VideoSize=videoin_c"+giCH_Curr+"_s"+giTargetStream+"_resolution");
	eval("CodecType=videoin_c"+giCH_Curr+"_s"+giTargetStream+"_codectype");
	if ("h264" == CodecType || "mpeg4" == CodecType || "svc" == CodecType)
	{
		eval("AccessName=network_rtsp_s"+giTargetStream+"_accessname");
	}
	else
	{
		eval("AccessName=network_http_s"+giTargetStream+"_accessname");
	}

	//Default use auto-size.
	Width = VideoSize.split("x")[0];
	Height = VideoSize.split("x")[1];
	gImgH = Math.floor(Height * gImgW / Width);

	if (eval("capability_videoin_c" + giCH_Curr + "_rotation") == 1)
	{
		if (eval("videoin_c" + giCH_Curr + "_rotate") == 90 || eval("videoin_c" + giCH_Curr + "_rotate") == 270)
		{
			eval(swap('gImgH', 'gImgW'));
			eval(swap('giCurDomainSizeH', 'giCurDomainSizeW'));
		}
	}
	
	//Create streaming
	if (true == bIsWinMSIE)
	{
		strPlugin = "<object class=CropZone id=\"" + PLUGIN_ID + "\" width=" + gImgW + " height=" + gImgH;
		strPlugin += " standby=\"Loading plug-in...\" classid=CLSID:" + CLASS_ID;
		strPlugin += " codebase=\"/" + PLUGIN_NAME + "#version=" + PLUGIN_VER + "\">";
		if ("https" == HTTP_METHOD[0])
		{
			strPlugin += "<param name=\"HttpPort\" VALUE=\"" +  network_https_port + "\" >";
		}
		else
		{
			strPlugin += "<param name=\"HttpPort\" VALUE=\"" +  network_http_port + "\" >";
		}
		strPlugin += '<param name="ReadSettingByParam " VALUE="1">';
		strPlugin += '<param name="MediaType" VALUE="2">';
		strPlugin += '<param name="DisplayErrorMsg" value="true">';
		strPlugin += '<param name="IgnoreCaption" value="true">';
		strPlugin += '<param name="IgnoreBorder" value="true">';
		strPlugin += "<param name=\"ViewStream\" VALUE=\"" + giTargetStream + "\">";
		strPlugin += "<param name=\"ViewChannel\" VALUE=\"" + (giCH_Curr+1) + "\">";
		strPlugin += '<param name="VSize" VALUE="CMS">';
	 	strPlugin += '<param name="Stretch" VALUE="true">';
		strPlugin += '<param NAME="StretchFullScreen" VALUE="false">';
		strPlugin += '<param NAME="PluginCtrlID" VALUE="">';
		strPlugin += "<PARAM NAME=\"Url\" VALUE=" + document.URL + ">";
		strPlugin += "<PARAM NAME=\"ControlPort\" VALUE="+network_rtsp_port+">";
		strPlugin += '<PARAM NAME="EnableJoystick" VALUE="false">';
		strPlugin += '<PARAM NAME="UpdateJoystickInterval" VALUE="100">';
		strPlugin += '<PARAM NAME="JoystickSpeedLvs" VALUE="5">';
		strPlugin += "<param name=\"Language\" VALUE=\"" + PLUGIN_LANG + "\">";
		strPlugin += '<param name="MP4Conversion" VALUE="true">';
		strPlugin += '<param name="EnableFullScreen" VALUE="false">';
		strPlugin += '<param name="AutoStartConnection" VALUE="true">';
		strPlugin += '<param name="ClickEventHandler" VALUE="0">';
		strPlugin += "<param name=\"StreamingBufferTime\" VALUE=\"" + BUFFERTIME + "\">";
		strPlugin += '<PARAM NAME="BeRightClickEventHandler" VALUE="false">';
		strPlugin += '<param name="ClientOptions" value="122">';
		strPlugin += '<param name="PlayMute" value="true">';
		strPlugin += '<param name="MicMute" value="true">';
		strPlugin += '<param name="BeAspectRatio" value="true">';
		strPlugin += '<param name="AspectRatioSection" value="0">';
		strPlugin += "</object>";

		$("#showimageBlock").append(strPlugin);
	}
	else
	{
		document.getElementById("snapshotstream").src = "/pic/noimg.jpg";
		gImgUrl = "/cgi-bin/viewer/video.jpg?channel="+giCH_Curr+"&streamid="+giTargetStream+"&resolution="+gImgW+"x"+gImgH;
		document.getElementById("snapshotstream").width = gImgW;
		document.getElementById("snapshotstream").height = gImgH;
		document.getElementById("snapshotstream").style.display = "block";

		if (gImg == null)
		{
			gImg = new Image();
			gImg.onload = function()
			{
				document.getElementById("snapshotstream").src = gImg.src;
				gTimer = setTimeout("updateImg()", giNonIERefreshImgPeriod);
			};

			gImg.onerror = function()
			{
				gROITimer = setTimeout("updateROIImg()", guiROIRefreshImgTime_ms);
			};
		}
		gTimer = setTimeout("updateImg()", 100);
	}

	parent.document.getElementById("privacy").height = gImgH +120;

    //For Polygon
    if (bIsWinMSIE)
	{
		$('#imagecoverBlock').css('width', gImgW + "px");
		$('#imagecoverBlock').css('height', gImgH + "px");
		
		canvasDiv=document.getElementById("imagecoverBlock");
		gr=new jsGraphics(canvasDiv);

		canvasDiv.onmousemove = getMouseXY;
		
        //Initial Privacy Mask Window, loading size and position of all PM_Window
        for (iIndex = 0; iIndex < PM_WINDOW_SIZE; iIndex++)
        {
        	$("input[name=pm_window_name" + iIndex + "]:eq(0)").keyup(function(){
				var iNameIndex = parseInt($(this).attr("name").charAt($(this).attr("name").length -1));
				eval("privacymask_c" + giCH_Curr + "_win_i" + iNameIndex + "_name = $(this).val()");
			});
		
			if (eval('privacymask_c' + giCH_Curr + '_win_i' + iIndex + '_enable') == '1')
        	{
				$("#PM_window_name" + iIndex).css("display","block");
				$("input[name=pm_window_name" + iIndex + "]:eq(0)").val(eval('privacymask_c' + giCH_Curr + '_win_i' + iIndex + '_name'));
			
				var polygonwin = eval('privacymask_c' + giCH_Curr + '_win_i'+iIndex+'_polygon').split(',');
				WinIndex = iIndex;
				for (j = 0; j < POLYGON_POINTS_NUM; j++)
				{	
					if(eval("videoin_c"+giCH_Curr+"_rotate") ==90 || eval("videoin_c"+giCH_Curr+"_rotate") ==270)
					{
						// handle rotation by rotating the coordinate system
						mouseX = parseInt(polygonwin[j*2+1]*gImgW/giCurDomainSizeW);
						mouseY = parseInt(polygonwin[j*2]);
					}
					else
					{
						mouseX = parseInt(polygonwin[j*2]);
						mouseY = parseInt(polygonwin[j*2+1]*gImgH/giCurDomainSizeH);
					}
					drawPoint();
				}
			}
        }

        //set the 1st exist PMW to be focused
        PM_Window_MOUSEON = getPMWCandidate();
        if(PM_Window_MOUSEON != -1)		//PM Window exists
		{
			setFocusWin(this);
		}

		if (getFirstFreeWindow() < 0)                                                                                              
		{
			$("#btnNewPM").attr("disabled", true);
		}
		else
		{
			$("#btnNewPM").attr("disabled", false);
		}
    }


	if (capability_nvideoin < 8)
	{
		$(".additional-channel").hide();
	}
}

function submitform(a, b, iChanIndex)
{
    updatecheck(a, b);

    if (b.checked)
      eval("privacymask_c"+iChanIndex+"_enable=1");
    else
      eval("privacymask_c"+iChanIndex+"_enable=0");

    document.forms[0].submit();
}

function getFirstFreeWindow()
{
    for (i = 0; i < PM_WINDOW_SIZE; i++) 
    {
        if (eval('privacymask_c' + giCH_Curr + '_win_i' + i + '_enable') == '0')
        {
            return i;
        }
    }	
    return -1;
}

function getPMWCandidate()
{
    for (i = 0; i < PM_WINDOW_SIZE; i++) 
    {
        if (eval('privacymask_c' + giCH_Curr + '_win_i' + i + '_enable') == '1')
        {
            return i;
        }
    }
    return -1;
}

function newPMWindow()
{
    var freeWindowIndex = getFirstFreeWindow();
    eval('privacymask_c' + giCH_Curr + '_win_i' + freeWindowIndex + '_enable = -1'); //Add -1 status means DrawWindow start but not complete yet
    if(freeWindowIndex == -1)
	{
        return -1;
	}
    else
    {
        $("#PM_window_name" + freeWindowIndex).css("display","block");
		WinIndex = CreatingWin = freeWindowIndex;
		
		PM_Window_MOUSEON = WinIndex;
		setFocusWin(this);
		
		canvasDiv.onclick=drawPoint;
    	
		//disable new when creating window.
		$("#btnNewPM").attr("disabled", true);
		//$("body").css({cursor: 'url(/pic/pen.cur), default'});
		//$("#imagecoverBlock").css({cursor: 'url(/pic/pen.cur), default'});
		$("body").css("cursor","crosshair");
		$("#imagecoverBlock").css("cursor","crosshair");
    }    
}

function checkPMWname()
{
	var enable, name;
	var title;
    for (var i = 0; i < PM_WINDOW_SIZE; i++) 
    {
        eval("enable = privacymask_c" + giCH_Curr + "_win_i" + i + "_enable");
		eval("name = privacymask_c" + giCH_Curr + "_win_i"+ i +"_name");
		
		if (enable == '1' && name == "")
		{
			alert(translator("please_insert_window_names_on_all_windows"));
			return -1;
		}
		
		if ((enable == '0' && name != "") || enable == '-1')
		{
			alert(translator("please_draw_window_on_live_image"));
			return -1;
		}
		
		//check invalid chr
		title = $("input:[name=pm_window_name" + i + "]").attr("title").split(",");
		checkStringSize($("input:[name=pm_window_name" + i + "]")[0]);
		if(checkInString($("input:[name=pm_window_name" + i + "]")[0]))
			return -1;
		if(title[2]=="empty")
			if(CheckEmptyString($("input:[name=pm_window_name" + i + "]")[0]))
				return -1;	
		if(title[2]=="space")
		{
			if(checkInSpace($("input:[name=pm_window_name" + i + "]")[0]))
				return -1;
		}
		else if (title[2]=="accessname")
		{
			if (checkAccessName($("input:[name=pm_window_name" + i + "]")[0]))
				return -1;
		}
	}
	return 0;
}

function savePMWindow()
{
    if(checkvalue())
    {
        return -1;
    }
	
	if(checkPMWname())
    {
        return -1;
    }

    var params = "";
    for (i = 0; i < PM_WINDOW_SIZE; i++) 
    {
        if (eval("privacymask_c" + giCH_Curr + "_win_i" + i + "_enable") == '1')
        {
        	params += 
        	"privacymask_c" + giCH_Curr + "_win_i"+ i +"_enable=" + eval("privacymask_c" + giCH_Curr + "_win_i" + i + "_enable")+"&"+
        	"privacymask_c" + giCH_Curr + "_win_i"+ i +"_name="+ encodeURIComponent(eval("privacymask_c" + giCH_Curr + "_win_i"+ i +"_name"))+"&"+
			"privacymask_c" + giCH_Curr + "_win_i"+ i +"_polygon="+ eval("privacymask_c" + giCH_Curr + "_win_i"+ i +"_polygon")+"&";
		}
		else
		{
			params += 
        	"privacymask_c" + giCH_Curr + "_win_i"+ i +"_enable=0&"+
        	"privacymask_c" + giCH_Curr + "_win_i"+ i +"_name=&"+
       		"privacymask_c" + giCH_Curr + "_win_i"+ i +"_polygon=&";
		}
    }

    $.ajax({
        type: "POST",
        cache: false,
        url: "/cgi-bin/admin/setparam.cgi",
        data: params,
        success: function(){
            alert(translator("save_window_completed"));            
        },
        error: function(){
            alert(translator("save_window_failed"));
        }
    });

}

function switchChannel(selectedIndex, bFirstLoad)
{
    var iIndex;

    giCH_Curr = parseInt(selectedIndex/g_ChannelDivider);
    eval("VideoSize=videoin_c"+ giCH_Curr + "_s" + giTargetStream + "_resolution");
    eval("codectype=videoin_c"+ giCH_Curr + "_s" + giTargetStream + "_codectype");

    if (codectype == "mjpeg")
        eval("AccessName=network_http_c" + giCH_Curr + "_s" + giTargetStream + "_accessname");
    else //(codectype == "mpeg4") || (codectype == "h264")
        eval("AccessName=network_rtsp_c" + giCH_Curr + "_s" + giTargetStream + "_accessname");
	
    for (var i = 0; i < capability_nvideoin; i++)
    {
        if (i == giCH_Curr)
        {
            $("#enable_c"+i).show();
            eval("enabled=privacymask_c"+i+"_enable");
            if (enabled == '1')
            {
                $("#enable_c"+i).attr("checked", true);
            }
            else
            {
                $("#enable_c"+i).attr("checked", false);
            }
        }
        else
        {
            $("#enable_c"+i).hide();

            //Clear windows of other channels
            for (iIndex = 0; iIndex < PM_WINDOW_SIZE; iIndex++)
            {
				if (eval('privacymask_c' + i + '_win_i' + iIndex + '_enable') == '1')
				{
					winPoints[iIndex] = new Array();
					$("#PolyWin" + iIndex).empty();
					$("#PolyWin" + iIndex).append("<DIV id=\"PolyMask" + iIndex + "\"></DIV>");
					$("input[name=pm_window_name" + iIndex + "]:eq(0)").val("");

					$("#PM_window_name" + iIndex).css("display","none");
				}
            } 
        }
    }

    //Initial Privacy Mask Window, loading size and position of all PM_Window
    for (iIndex = 0; iIndex < PM_WINDOW_SIZE; iIndex++)
	{
		if (eval('privacymask_c' + giCH_Curr + '_win_i' + iIndex + '_enable') == '1')
		{
			$("#PM_window_name" + iIndex).css("display","block");
			$("input[name=pm_window_name" + iIndex + "]:eq(0)").val(eval('privacymask_c' + giCH_Curr + '_win_i' + iIndex + '_name'));

			var polygonwin = eval('privacymask_c' + giCH_Curr + '_win_i'+iIndex+'_polygon').split(',');
			WinIndex = iIndex;
			for (j = 0; j < POLYGON_POINTS_NUM; j++)
			{
				if (eval("videoin_c"+giCH_Curr+"_rotate") == 90 || eval("videoin_c"+giCH_Curr+"_rotate") == 270)
				{
					// handle rotation by rotating the coordinate system
					mouseX = parseInt(polygonwin[j*2+1]*gImgW/giCurDomainSizeW);
					mouseY = parseInt(polygonwin[j*2]);
				}
				else
				{
					// the way to handle window coordinate with old venc
					mouseX = parseInt(polygonwin[j*2]);
					mouseY = parseInt(polygonwin[j*2+1]*gImgH/giCurDomainSizeH);
				}
				drawPoint();
			}
		}
	}

    //set the 1st exist PMW to be focused
    PM_Window_MOUSEON = getPMWCandidate();
    if(PM_Window_MOUSEON != -1)		//PM Window exists
	{
		setFocusWin(this);
	}

	if (getFirstFreeWindow() < 0)                                                                                              
	{
		$("#btnNewPM").attr("disabled", true);
	}
	else
	{
		$("#btnNewPM").attr("disabled", false);
	}

    WinLessPluginCtrl = document.getElementById(PLUGIN_ID);
    setTimeout("WinLessPluginCtrl.PlayMute = true", 1);
}

//For Polygon
//Determining Whether A Point Is Inside A Polygon
/*function pointInPolygon(p)
{
  j = POLYGON_POINTS_NUM - 1;
  polygonInside = false;

  for (i = 0; i < POLYGON_POINTS_NUM; i++)
  {
    	if (((winPoints[p][i].y < mouseY) && (winPoints[p][j].y >= mouseY)) || 
    		((winPoints[p][j].y < mouseY) && (winPoints[p][i].y >= mouseY)) )
    	{
      		if (winPoints[p][i].x + (mouseY - winPoints[p][i].y) / (winPoints[p][j].y - winPoints[p][i].y) * (winPoints[p][j].x - winPoints[p][i].x) < mouseX)
      		{
        		polygonInside = !polygonInside;
      		}
      	}
    	j = i;
  }
  return polygonInside;
}*/

//Get mouse position
function getMouseXY(e)
{
	var mouseXorig;
	var mouseYorig;

	if (ie) 
	{
		mouseXorig = event.clientX + document.body.parentElement.scrollLeft;
		mouseYorig = event.clientY + document.body.parentElement.scrollTop;
	} 
	else 
	{ 
		mouseXorig = e.pageX;
		mouseYorig = e.pageY;
	}

	if (mouseXorig < 0){mouseXorig = 0;}
	if (mouseYorig < 0){mouseYorig = 0;}

	mouseXorig = mouseXorig - parseInt($(canvasDiv).offset().left, 10);
	mouseYorig = mouseYorig - parseInt($(canvasDiv).offset().top, 10);

	mouseX = mouseXorig.toFixed();
	mouseY = mouseYorig.toFixed();
	
	return true;
}

function setPenColor(WinIndex)
{
	col=new jsColor("red");
	switch(WinIndex)
	{
		case 0:
			col = new jsColor("#00FFFF");
			break;
		case 1:
			col = new jsColor("#FFA851");
			break;
		case 2:
			col = new jsColor("#80FF80");
			break;
		case 3:
			col = new jsColor("#FFFF80");
			break;
		case 4:
			col = new jsColor("#626262");
			break;
		default:
			return false;
	}

	pen = new jsPen(col,2);
	
	return true;	
}

function focusWin(WinIndex)
{
	PM_Window_MOUSEON = WinIndex;
	setFocusWin(this);
		
	return;
}

function setFocusWin(obj, event)
{
	if (event != undefined)
	{
		event.stopPropagation();
	}
	
	col = new jsColor("#FFFFFF");
	$("#PolyMask" + PM_Window_selected).children().css("opacity","0.01");
	$("#PolyMask" + PM_Window_MOUSEON).children().css("opacity","0.4");
	PM_Window_selected = PM_Window_MOUSEON;
		
	return;
}
	
function drawPoint()
{
	//prevent clicking on same point as previous
	for (var i = 0; i < points.length; i++)
	{
		if( (mouseX == points[i].x) && (mouseY == points[i].y) )
		{
			return;
		}
	}
	gr.fillRectangle(new jsColor("green"),new jsPoint(mouseX-3,mouseY-3),6,6);
	points[points.length]=new jsPoint(mouseX,mouseY);
	if (points.length == POLYGON_POINTS_NUM)
	{
		$("#PolyMask" + PM_Window_selected).children().css("opacity","0.01");
		drawPolygon(WinIndex);
	}
}

function mouseOver(obj)
{
	$(obj).css("cursor","pointer");
	PM_Window_MOUSEON = parseInt($(obj).attr("id").charAt($(obj).attr("id").length -1));
}

function mouseOut(obj)
{
	PM_Window_MOUSEON = -1;
}
	
function drawPolygon(WinIndex)
{
  	var polygonwin;	
  	if(!setPenColor(WinIndex))
	    return;
	
	gr.drawPolygon(pen,points);
	col = new jsColor("#FFFFFF");
	gr.fillPolygon(col,points);
	$("#PolyMask" + WinIndex).children().css("opacity","0.4");
	$("#PolyMask" + WinIndex).bind("mouseover", function(){mouseOver(this);});
	$("#PolyMask" + WinIndex).bind("mouseout", function(){mouseOut(this);});
	$("#PolyMask" + WinIndex).bind("click", function(event){setFocusWin(this, event);});
	
	winPoints[WinIndex] = points;
	clearPreviousPoints();
	PM_Window_MOUSEON = WinIndex;
	setFocusWin(this);
	if (eval("videoin_c"+giCH_Curr+"_rotate") == 90 || eval("videoin_c"+giCH_Curr+"_rotate") == 270)
	{
		// handle rotation by rotating the coordinate system
		polygonwin = winPoints[WinIndex][0].y + "," + parseInt(winPoints[WinIndex][0].x*giCurDomainSizeW/gImgW) + "," +
					 winPoints[WinIndex][1].y + "," + parseInt(winPoints[WinIndex][1].x*giCurDomainSizeW/gImgW) + "," +
					 winPoints[WinIndex][2].y + "," + parseInt(winPoints[WinIndex][2].x*giCurDomainSizeW/gImgW) + "," +
					 winPoints[WinIndex][3].y + "," + parseInt(winPoints[WinIndex][3].x*giCurDomainSizeW/gImgW);
	}
	else
	{
		// the way to handle window coordinate with old venc
		polygonwin = winPoints[WinIndex][0].x + "," + parseInt(winPoints[WinIndex][0].y*giCurDomainSizeH/gImgH) + "," +
					 winPoints[WinIndex][1].x + "," + parseInt(winPoints[WinIndex][1].y*giCurDomainSizeH/gImgH) + "," +
					 winPoints[WinIndex][2].x + "," + parseInt(winPoints[WinIndex][2].y*giCurDomainSizeH/gImgH) + "," +
					 winPoints[WinIndex][3].x + "," + parseInt(winPoints[WinIndex][3].y*giCurDomainSizeH/gImgH);
	}

    eval('privacymask_c' + giCH_Curr + '_win_i' + WinIndex + '_enable = 1');
    eval('privacymask_c' + giCH_Curr + '_win_i' + WinIndex + '_polygon = polygonwin');

	$("body").css("cursor","default");
	$("#imagecoverBlock").css("cursor","default");
	canvasDiv.onclick="";
	CreatingWin = -1;
	
	//enable new when has free window.
	if (getFirstFreeWindow() != -1)
	{
		$("#btnNewPM").attr("disabled", false);
	}
}

function clearWin(WinIndex)
{	
	winPoints[WinIndex] = new Array();
	$("#PolyWin" + WinIndex).empty();
	$("#PolyWin" + WinIndex).append("<DIV id=\"PolyMask" + WinIndex + "\"></DIV>");
	$("input[name=pm_window_name" + WinIndex + "]:eq(0)").val("");
	
	$("#PM_window_name" + WinIndex).css("display","none");
	eval('privacymask_c' + giCH_Curr + '_win_i' + WinIndex + '_enable = 0');
	eval('privacymask_c' + giCH_Curr + '_win_i' + WinIndex + '_name = ""');
	eval('privacymask_c' + giCH_Curr + '_win_i' + WinIndex + '_polygon = ""');
	
	//clean selected window
	if(WinIndex == PM_Window_selected)
	{
  		PM_Window_selected = getPMWCandidate();
  		
  		if (PM_Window_selected != -1)
		{
			PM_Window_MOUSEON = PM_Window_selected;
			setFocusWin(this);
		}
		else
		{
			PM_Window_selected = -1;
		}	
	}
	
	//clean creating window
	if(WinIndex == CreatingWin || CreatingWin == -1)
	{
		canvasDiv.onclick="";
		$("body").css("cursor","default");
		$("#imagecoverBlock").css("cursor","default");
		clearPreviousPoints();
		$("#btnNewPM").attr("disabled", false);
	}
}

function clearPreviousPoints()
{
	points=new Array();
}

function updateImg()
{
	var da;

	da = new Date();
	gImg.src = ""+gImgUrl+"&quality="+gQuality+"&date="+da.getTime();
}
