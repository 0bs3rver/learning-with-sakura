
function loadCurrentSetting()
{	
	loadlanguage();
	parent.document.getElementById("resizebutton").height = 20; 
	document.getElementById("content").style.visibility = "visible";

	if (true != bIsWinMSIE)
	{
		document.getElementById("qualityTitle").innerHTML = translator("quality") + ":";
		document.getElementById("qualityTitle").style.display = "inline";
		document.getElementById("imagequality").style.display = "inline";
	}

	changeButtonlayout($("button.viewstyle:[title*='Auto-Fit']")[0], "Auto");
}

function changeButtonlayout(obj)
{
	// Reset default state, except "4:3" btn
	$(".viewstyle").attr("disabled", false).each(function(){
		posObj = $(this).css("backgroundPosition").split(" ");
		$(this).css("backgroundPosition", posObj[0] + " 0px");
	});
	// set selected button state
	var posObj = $(obj).css("backgroundPosition").split(" ");
	$(obj).css("backgroundPosition", posObj[0] + " -36px").attr("disabled", true);
}

function resize(obj, param)
{
	changeButtonlayout(obj);
	if (param == 'Auto')
	{
		getIframeDocumentById("viewpage").getElementById("resize_button_auto").click();
	}
	else if (param == '100')
	{
		getIframeDocumentById("viewpage").getElementById("resize_button_full").click();
	}
}

function changeimageQuality(obj)
{
	var element = getIframeDocumentById("viewpage").getElementById("imagequality"); 
	element.value =	 obj.options[obj.selectedIndex].value;
	element.onchange();
}

