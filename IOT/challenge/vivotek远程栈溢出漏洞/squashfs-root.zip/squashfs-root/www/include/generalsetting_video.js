

var giCH_Curr = 0;
var gbFE = false;
var gbNoticed = false;
var gPreRotationAngle;
var gPreRotationEnable;
	var bRotateOnEISHidden = false;
var gEnableextled;
var bEIS = false;
	var bISOnRotationHidden = false;
var sensitivityStrings = ["low", "normal", "high"];
var fontPathVVTK       = "/usr/share/VVTK.ttf";
var fontPathCustomized = "/mnt/flash2/customized.ttf";

//Called when the Web page is on loading.
function loadCurrentSetting()
{	
	var tmp = location.href.split("?");
    	var tmp2 = tmp[1].split("=");

	if (tmp2[0] == 'ch')
	{
		giCH_Curr = parseInt(tmp2[1], 10);
	}

	// capability group
	{
		var capabilityStr=
				"&capability_videoin_c"+giCH_Curr+"_lens_type"+
				"&capability_videoin_c"+giCH_Curr+"_rotation"+
				"&capability_eptz"+"&capability_npreset"+"&capability_smartstream_support"+"&capability_ptzenabled"+
				"&capability_image_c"+giCH_Curr+"_remotefocus"+
				"&capability_image_c"+giCH_Curr+"_focuswindow_nwindow"+
				"&capability_image_c"+giCH_Curr+"_sensortype"+
				"&capability_videoin_c"+giCH_Curr+"_fisheye_mounttype"+
				"&capability_image_c"+giCH_Curr+"_is_affect"+
				"&capability_image_c"+giCH_Curr+"_is_mode"+
				"&capability_videoin_c"+giCH_Curr+"_rotationaffect";
	}
	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&videoin_c"+giCH_Curr+capabilityStr+"&image_c"+giCH_Curr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();
}

function findISImpact()
{
	if ("-" != eval("capability_image_c"+giCH_Curr+"_is_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_is_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("rotation:hidden:"))
			{
				bISOnRotationHidden = true;
			}
		}
	}
}

function findRotateImpact()
{
	if (!ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_rotationaffect"))
	{
		tmp = eval("capability_videoin_c"+giCH_Curr+"_rotationaffect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("eis:hidden:"))
			{
				bRotateOnEISHidden = true;
			}
		}
	}
}

//Called when the Web page is loaded done.
//Start point of this code.
function receivedone()
{
	// EIS
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_is_mode"))
	{
		if (("eis" == eval("capability_image_c"+giCH_Curr+"_is_mode")) 
		&& ((0 != parseInt(eval("image_c"+giCH_Curr+"_eis_mode"))) || (0 != parseInt(eval("image_c"+giCH_Curr+"_profile_i0_eis_mode")))))
		{
			bEIS = true;
			findISImpact();
		}
	}
	
	//Text on video.
	document.getElementById("textonvideo_string").value = eval("videoin_c"+giCH_Curr+"_text");
	if (0 == parseInt(eval("videoin_c"+giCH_Curr+"_imprinttimestamp")))
	{
		document.getElementById("textonvideo_control").checked = false;
	}
	else
	{
		document.getElementById("textonvideo_control").checked = true;
	}

	$(document.getElementById("TextPosition")).children().each(
		function()
		{
			if (eval("videoin_c"+giCH_Curr+"_textonvideo_position") == this.value)
			{	
				this.selected = true;
			}
		}
	);
	document.getElementById("textpos").style.display = "block";

	for (var iFontSize = 20 ; iFontSize <=40; iFontSize +=5)
	{
		$("#FontSize").addOption(iFontSize,iFontSize,false);
	}

	$(document.getElementById("FontSize")).children().each(
		function()
		{
			if (eval("videoin_c"+giCH_Curr+"_textonvideo_size") == this.value)
			{	
				this.selected = true;
			}
		}
	);
	document.getElementById("textsize").style.display = "block";

	ShowVideoFontChoiceUI();

	$(document.getElementById("TextFont")).children().each(
		function()
		{
			if (eval("videoin_c"+giCH_Curr+"_textonvideo_fontpath") == this.value)
			{	
				this.selected = true;
			}
		}
	);

	//Fisheye mount type.
	if (eval("capability_videoin_c"+giCH_Curr+"_lens_type") == "fisheye")
	{
		gbFE = true;
		document.getElementById("femounttype").style.display = "block";
		var mounttypes = capability_videoin_c0_fisheye_mounttype;
		if(mounttypes.indexOf("ceiling") == -1)
		{
			document.getElementById("ceiling").style.display = "none";
			document.getElementById("ceiling_span").style.display = "none";
		}
		if(mounttypes.indexOf("wall") == -1)
		{
			document.getElementById("wall").style.display = "none";
			document.getElementById("wall_span").style.display = "none";
		}
		if(mounttypes.indexOf("floor") == -1)
		{
			document.getElementById("floor").style.display = "none";
			document.getElementById("floor_span").style.display = "none";
		}		

		if (eval("videoin_c"+giCH_Curr+"_mounttype") == "ceiling")
		{
			document.getElementById("ceiling").checked = true;
			document.getElementById("wall").checked = false;
			document.getElementById("floor").checked = false;
		}
		else if (eval("videoin_c"+giCH_Curr+"_mounttype") == "wall")
		{
			document.getElementById("ceiling").checked = false;
			document.getElementById("wall").checked = true;
			document.getElementById("floor").checked = false;
		}
		else if (eval("videoin_c"+giCH_Curr+"_mounttype") == "floor")
		{
			document.getElementById("ceiling").checked = false;
			document.getElementById("wall").checked = false;
			document.getElementById("floor").checked = true;
		}
	}

	//Color
	if (1 == parseInt(eval("videoin_c"+giCH_Curr+"_color")))
	{
		document.getElementById("color").checked = true;
		document.getElementById("mono").checked = false;
	}
	else
	{
		document.getElementById("color").checked = false;
		document.getElementById("mono").checked = true;
	}

	//CMOS Frequency.
	if (60 == parseInt(eval("videoin_c"+giCH_Curr+"_cmosfreq")))
	{
		document.getElementById("cmosfreq60").checked = true;
		document.getElementById("cmosfreq50").checked = false;
	}
	else
	{
		document.getElementById("cmosfreq60").checked = false;
		document.getElementById("cmosfreq50").checked = true;
	}

	//Flip
	if (0 == parseInt(eval("videoin_c"+giCH_Curr+"_flip")))
	{
		document.getElementById("flip").checked = false;
	}
	else
	{
		document.getElementById("flip").checked = true;
	}

	//Mirror
	if (0 == parseInt(eval("videoin_c"+giCH_Curr+"_mirror")))
	{
		document.getElementById("mirror").checked = false;
	}
	else
	{
		document.getElementById("mirror").checked = true;
	}
	
	// Rotation
	if (1 == eval("capability_videoin_c"+giCH_Curr+"_rotation"))
	{
		if (bEIS && bISOnRotationHidden)
		{
			document.getElementById("rotate_section").style.display = "none";
			document.getElementById("rotate_section_layout").style.display = "none";
		}
		else
		{
			document.getElementById("rotate_section").style.display = "block";
			document.getElementById("rotate_section_layout").style.display = "block";
			if(eval("videoin_c"+giCH_Curr+"_rotate") == 0)
			{
				document.getElementById("rotate_enable").checked = gPreRotationEnable = false;
				gPreRotationAngle = 0;
			}
			else
			{
				document.getElementById("rotate_enable").checked = gPreRotationEnable = true;
				document.getElementById("rotate_angle").value= gPreRotationAngle = eval("videoin_c"+giCH_Curr+"_rotate");
			}
	
			if (eval("videoin_c"+giCH_Curr+"_rotate") != 0)
			{
				$("#rotateChild").show();
			}
			else
			{
				$("#rotateChild").hide();
			}
		}
		
		findRotateImpact();
	}

	parent.document.getElementById("generalpage_video").height=document.body.scrollHeight;
}


//Called when all objects in Web page is ready.
function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";

}

function changeText(text)
{
	if (-1 == checkInString(text))
	{
		text.value = eval("videoin_c"+giCH_Curr+"_text");
		return;
	}

	eval("videoin_c"+giCH_Curr+"_text=text.value");
}

function setText(checked)
{
	if (false == checked)
	{
		eval("videoin_c"+giCH_Curr+"_imprinttimestamp=0");
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_imprinttimestamp=1");
	}
}

function setMountType(type)
{
	if (type == "ceiling")
	{
		eval("videoin_c"+giCH_Curr+"_mounttype='ceiling'");
		document.getElementById("ceiling").checked = true;
		document.getElementById("wall").checked = false;
		document.getElementById("floor").checked = false;
	}
	else if (type == "wall")
	{
		eval("videoin_c"+giCH_Curr+"_mounttype='wall'");
		document.getElementById("ceiling").checked = false;
		document.getElementById("wall").checked = true;
		document.getElementById("floor").checked = false;
	}
	else if (type == "floor")
	{
		eval("videoin_c"+giCH_Curr+"_mounttype='floor'");
		document.getElementById("ceiling").checked = false;
		document.getElementById("wall").checked = false;
		document.getElementById("floor").checked = true;
	}
}

function setColor(bColor)
{
	if (0 == bColor)
	{
		eval("videoin_c"+giCH_Curr+"_color=0");
		document.getElementById("color").checked = false;
		document.getElementById("mono").checked = true;
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_color=1");
		document.getElementById("color").checked = true;
		document.getElementById("mono").checked = false;
	}
}

function setCMOSFreq(freq)
{
	if (50 == freq)
	{
		eval("videoin_c"+giCH_Curr+"_cmosfreq=50");
		document.getElementById("cmosfreq60").checked = false;
		document.getElementById("cmosfreq50").checked = true;
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_cmosfreq=60");
		document.getElementById("cmosfreq60").checked = true;
		document.getElementById("cmosfreq50").checked = false;
	}
}

function setFlip(checked)
{
	if ( (false == gbNoticed) )
	{
		if ( showFlipMirrorWarningMsg())
		{
			gbNoticed = true;
		}
		else
		{
			if (0 == parseInt(eval("videoin_c"+giCH_Curr+"_flip")))
			{
				document.getElementById("flip").checked = false;
			}
			else
			{
				document.getElementById("flip").checked = true;
			}
			return;
		}
	}

	if (false == checked)
	{
		eval("videoin_c"+giCH_Curr+"_flip=0");
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_flip=1");
	}
}

function setMirror(checked)
{
	if ( (false == gbNoticed) )
	{
		if ( showFlipMirrorWarningMsg())
		{
			gbNoticed = true;
		}
		else
		{
			if (0 == parseInt(eval("videoin_c"+giCH_Curr+"_mirror")))
			{
				document.getElementById("mirror").checked = false;
			}
			else
			{
				document.getElementById("mirror").checked = true;
			}
			return;
		}
	}

	if (false == checked)
	{
		eval("videoin_c"+giCH_Curr+"_mirror=0");
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_mirror=1");
	}
}

function changeFontPos(pos)
{
	eval("videoin_c"+giCH_Curr+"_textonvideo_position='"+pos+"'");
}

function changeFontSize(size)
{
	eval("videoin_c"+giCH_Curr+"_textonvideo_size='"+size+"'");
}

function saveGeneralSettingsVideo()
{
	var XMLHttpRequestObject = null;
	var commitList = "";
	var tmp = "";

	$("#videoSettingsSaveButton").attr("disabled", true);

	if (window.XMLHttpRequest)
	{
		XMLHttpRequestObject = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{
		XMLHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	tmp = "videoin_c"+giCH_Curr+"_";

	commitList = "/cgi-bin/admin/setparam.cgi?"+ tmp+"text="+encodeURIComponent(eval(tmp+"text"))+"&"+
		tmp+"imprinttimestamp="+eval(tmp+"imprinttimestamp")+"&"+
		tmp+"color="+eval(tmp+"color")+"&"+
		tmp+"cmosfreq="+eval(tmp+"cmosfreq")+"&"+
		tmp+"flip="+eval(tmp+"flip")+"&"+
		tmp+"mirror="+eval(tmp+"mirror");

	// Text on video
	commitList = commitList +"&"+tmp+"textonvideo_position="+eval(tmp+"textonvideo_position");
	commitList = commitList +"&"+tmp+"textonvideo_size="+eval(tmp+"textonvideo_size");
	commitList = commitList +"&"+tmp+"textonvideo_fontpath="+eval(tmp+"textonvideo_fontpath");
	
	if (true == gbFE)
	{
		commitList = commitList +"&"+tmp+"mounttype="+eval(tmp+"mounttype");
	}

	// Rotation
	if (1 == eval("capability_videoin_c"+giCH_Curr+"_rotation"))
	{
		commitList = commitList +"&"+tmp+"rotate="+eval(tmp+"rotate");
	}
	
	XMLHttpRequestObject.open("GET", commitList);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	//setTimeout('$("#submitBtn").attr("disabled", false)', 500);
	setTimeout('$("#videoSettingsSaveButton").attr("disabled", false)', 500);

	gPreRotationEnable = document.getElementById("rotate_enable").checked;
	gPreRotationAngle = document.getElementById("rotate_angle").value;
}

function judgeToShowRotateWarningMsg(senderFlag)
{
	var selectEnableValue = document.getElementById("rotate_enable").checked;
	var selectAngleValue = document.getElementById("rotate_angle").value;
	if (gPreRotationEnable == 1)
	{
		if (senderFlag == 0)
		{
			if ((gPreRotationEnable != selectEnableValue) || (gPreRotationAngle != selectAngleValue))
			{
				if (showRotateWarningMsg() != true)
				{
					document.getElementById("rotate_enable").checked = gPreRotationEnable;
					document.getElementById("rotate_angle").value = gPreRotationAngle;
				}
			}
		}
		else
		{
			if (gPreRotationAngle != selectAngleValue)
			{
				if (showRotateWarningMsg() != true)
				{
					document.getElementById("rotate_angle").value = gPreRotationAngle;
				}
			}
		}
	}
	else
	{
		if (senderFlag == 0)
		{
			if (gPreRotationEnable != selectEnableValue)
			{
				if (showRotateWarningMsg() != true)
				{
					document.getElementById("rotate_enable").checked = gPreRotationEnable;
				}
			}
		}
	}
}

function showRotateWarningMsg()
{
	// the warning message of clearing settings
	var msgContent = composeRotateWarningMsg();
	
	return confirm(msgContent);
}

function composeRotateWarningMsg()
{
	var msgStart = translator("switch_to_rotate_warning_message") + "\n\n";

	// general features
	var msgClearItems = translator("video_settings") + "\n" + translator("motion") + "\n" + translator("privacy_mask") + "\n" + translator("exposure_window") + "\n";

	// optional features
	if (capability_eptz != 0)
	{
		msgClearItems += translator("viewing_window");
		msgClearItems += "\n";
	}
	if (capability_npreset != 0)
	{
		msgClearItems += translator("preset_position");
		msgClearItems += "\n";
	}
	if (parseInt(eval("capability_image_c"+giCH_Curr+"_remotefocus")) == 4 || 
	    parseInt(eval("capability_image_c"+giCH_Curr+"_remotefocus")) == 1 ||
	    ! ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_focuswindow_nwindow"))
	{
		msgClearItems += translator("focus_window");
		msgClearItems += "\n";
	}

	return msgStart + msgClearItems;
}

function showFlipMirrorWarningMsg()
{
	// the warning message of clearing settings
	var msgContent = composeFlipMirrorWarningMsg();
	if (null != msgContent)
	{	
		return confirm(msgContent);
	}
	return true;
}

function composeFlipMirrorWarningMsg()
{
	var msgStart = translator("switch_to_filp_mirror_warning_message") + "\n\n";

	// general features
	var msgClearItems = "";

	// optional features
	if (isSpeedDome(capability_ptzenabled) != "1")
	{
		msgClearItems += translator("motion") + "\n" + translator("privacy_mask") + "\n" + translator("exposure_window") + "\n";
	}
	if (capability_eptz != 0)
	{
		msgClearItems += translator("viewing_window");
		msgClearItems += "\n";
	}
	if ((capability_npreset != 0) && (isSpeedDome(capability_ptzenabled) != "1"))
	{
		msgClearItems += translator("preset_position");
		msgClearItems += "\n";
	}
	if (parseInt(eval("capability_image_c"+giCH_Curr+"_remotefocus")) == 4 || 
	    parseInt(eval("capability_image_c"+giCH_Curr+"_remotefocus")) == 1 ||
	    ! ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_focuswindow_nwindow"))
	{
		msgClearItems += translator("focus_window");
		msgClearItems += "\n";
	}
	
	if (msgClearItems == "")
	{
		return null;
	}

	return msgStart + msgClearItems;
}


function switchRotateUI_MsgCheck(RotateOn)
{
	if (RotateOn)
	{		
		if(bRotateOnEISHidden)
		{
			if(!confirm("EIS will be disabled after enable video rotation. Do you want to continue?"))
			{
				return false;
			}
		}
	}
	return true;
}

function updateRotateValue()
{
	var enable = document.getElementById("rotate_enable").checked;
	var angle  = document.getElementById("rotate_angle").value;

	if (false == switchRotateUI_MsgCheck(enable))
	{
		if (true == enable)
		{
			document.getElementById("rotate_enable").checked = false;
		}
		else
		{
			document.getElementById("rotate_enable").checked = true;
		}
		return;
	}
	
	if(enable)
	{
		$("#rotateChild").show();
		videoin_c0_rotate = angle;
	}
	else
	{
		$("#rotateChild").hide();
		videoin_c0_rotate = 0;
	}
}

function ShowVideoFontChoiceUI()
{
	//If the upload ttf file exist, hide the upload button and show delete button
	if (eval("videoin_c"+giCH_Curr+"_textonvideo_uploadfilename") == "")
	{
		$("#deletefont").hide();
	}
	else
	{
		$("#uploadfont").hide();
		$(document.getElementById("TextFont")).append(""
		+'<option value="/mnt/flash2/upload.ttf" title="param">'+eval("videoin_c0_textonvideo_uploadfilename")+'</option>');


		if(eval("videoin_c"+giCH_Curr+"_textonvideo_fontpath") == "/usr/share/font/Default.ttf")
		{
			$("#deletefont").attr("disabled",true);
		}
		else
		{
			$("#deletefont").removeAttr("disabled");
		}
	}
}

function disableDeleteButton(SelectValue)
{
	//default ttf file cannot be deleted
	if(SelectValue == "/usr/share/font/Default.ttf")
	{
		$("#deletefont").attr("disabled",true);
	}
	else
	{
		$("#deletefont").removeAttr("disabled");
	}
	eval("videoin_c"+giCH_Curr+"_textonvideo_fontpath='"+SelectValue+"'");
}

function deleteUploadFont()
{
	if (confirm(translator("do_you_want_del_upload_font")))
	{
		var queryStr = "/cgi-bin/admin/deleteUploadfont.cgi";
		SendHttpRequest(queryStr, false);
		location.reload();
	}
}
