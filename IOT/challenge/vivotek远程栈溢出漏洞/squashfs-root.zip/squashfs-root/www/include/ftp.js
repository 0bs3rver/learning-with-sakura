function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info_language&system_info_customlanguage&network", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
        document.title=translator("ftp");
	loadlanguage();
}

function receivedone()
{
	document.getElementById("ftpChild").style.display="none";
}

function loadvaluedone()
{
	if(network_ftp_enable == 1)
	{
		$("#ftpChild").slideDown("slow");
	}
	else
	{
		$("#ftpChild").slideUp("slow");
	}
	
	document.getElementById("content").style.visibility = "visible";
}

function checkftp(inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		$("#ftpChild").slideDown("slow");
	}
	else
	{
		$("#ftpChild").slideUp("slow");
	}
}

function submitform()
{
	var network_rtcp_videoport = parseInt(network_rtp_videoport) + 1;
	var network_rtcp_audioport = parseInt(network_rtp_audioport) + 1;
	var videoport;
	var audioport;
	var ftpport = document.getElementById("network_ftp_port").value;
	
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		videoport = eval('parseInt(network_rtsp_s'+i+'_multicast_videoport) + 1');
		audioport = eval('parseInt(network_rtsp_s'+i+'_multicast_audioport) + 1');
		eval('var network_rtsp_s'+i+'_multicast_rtcp_videoport = '+videoport);
		eval('var network_rtsp_s'+i+'_multicast_rtcp_audioport = '+audioport);
	}
	var port = new Array(network_http_port,                  //0
						 network_http_alternateport,         //1
						 network_https_port,				 //2
						 network_sip_port,                   //3
						 ftpport,                   //4
						 network_rtsp_port,                  //5
						 network_rtp_videoport,              //6
						 network_rtcp_videoport.toString(),    //7
						 network_rtp_audioport,              //8
						 network_rtcp_audioport.toString()             //9
					 );
	// Dynamic push audio and video port into port array 
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		port.push(eval('network_rtsp_s'+i+'_multicast_videoport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_rtcp_videoport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_audioport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_rtcp_audioport'));
	}
	
	if(checkvalue())
	{
		return -1;
	}
	
	// Check port conflict: ftp_port	
	if(CheckEmptyString(port[4]) == -1)
	{
		return -1
	}

	for (var j = 0; j < port.length; j++)
	{
		if (j == 4)
		{
			continue;
		}
		if (port[4] == port[j])
		{
			document.getElementById("network_ftp_port").select();
			document.getElementById("network_ftp_port").focus();
			alert(translator("ftp_port_can_not_be_the_same_as_other_port"));
			return -1;
		}
	}

	document.forms[0].submit();
}
