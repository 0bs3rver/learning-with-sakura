function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&network&capability_bootuptime&capability_network_wireless", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("maintenance");

	if (ParamUndefinedOrZero("capability_image_c0_remotefocus"))
	{
		$("#restore_default_except_focusvalue").hide();
		$("#focus_position").hide();
	}
	
	if (document.getElementById("adv_maintain") != null) 
	{
		if (g_mode == "0") {
			$("fieldset").removeClass("tabs-fieldset");
			$("div.tabs").css("display","none");
			$("div.tab-content").attr("class", "");
			$("#tabs-1").css("display","block");
		}
		else
		{
			$("div.tabs").css("display","block");
			$("#tabs-1").parent("div").attr("class","tab-content");

			var aTab = document.URL.split('#')[1];
			if (aTab == undefined)
			{
				tabsUI(0);
			}
			else
			{
				if (aTab == "tabs-1")
				{
					tabsUI(0);
				}
				else if (aTab == "tabs-2")
				{
					tabsUI(1);
				}
				else
				{
					tabsUI(0); // default
				}
			}
		}
	}

	if (!ParamUndefinedOrZero("capability_network_wireless"))
	{
		document.getElementById("notification_span1").innerHTML="the_device_will_be_reset_back_to_the_autonomous_ap_mode_and_the_current_connection_with_other_ap_will_be_disabled";
		document.getElementById("notify_location").style.display = 'none';
		document.getElementById("notification_span2").style.display = 'none';
	}

	loadlanguage();
}

var have_submit = false;

function checkUpgradeFirm()
{
  var form = document.FirmUpgrade;
  var re = /(\.pkg)$/i;
  
  if (have_submit)	return -1;

  if ((form.fimage.value == "") || (!re.test(form.fimage.value)))
  {
    alert(translator("no_firmware_specified"));
    return;
  }
  have_submit = true;
  form.submit();
  
  $("#maintain_cnt").hide();
  $("iframe[name='upgrade_fw_info']").show();
  
}

function RebootCamera()
{
	showNotification(capability_bootuptime);
}

function RestoreDefault()
{
	var form = document.RestoreDefaultSettings;
	var bshowNotification = 0;
	var restoretime = parseInt(capability_bootuptime) + 30;

        // restore to default Language: English, when user use his own Custom language as default Web language
        // but doesn't backup Custom language when restore to default
        if( system_info_customlanguage_count != "0" && lan >= 100 && !form.restore_default_except_customlang.checked)
        {
            setCookie("lan", 0);
        }

	if ((!form.restore_default_except_daylight.checked) && 
	    (!form.restore_default_except_network.checked) &&
		(!form.restore_default_except_customlang.checked) &&
		(!form.restore_default_except_vadp.checked) &&
		(!form.restore_default_except_focusvalue.checked))
	{

		addElement("system_restore");
		showNotification(restoretime);
	form.submit();		
		return 0;
	}

	if (form.restore_default_except_daylight.checked)
	{
		addElement("system_restoreexceptdst");
		bshowNotification = 1;
	}
	
	if (form.restore_default_except_network.checked)
	{
		addElement("system_restoreexceptnet");
		bshowNotification = 1;
	}
	
	if (form.restore_default_except_customlang.checked)
	{
		addElement("system_restoreexceptlang");
		bshowNotification = 1;
	}
	
	if (form.restore_default_except_vadp.checked)
	{
		addElement("system_restoreexceptvadp");
		bshowNotification = 1;
	}
	
	if (form.restore_default_except_focusvalue.checked)
	{
		addElement("system_restoreexceptfocusvalue");
		bshowNotification = 1;
	}

	if (bshowNotification == 1)
	{
		showNotification(restoretime);
	}
	
	form.submit();
}
function addElement(inputname)
{
	var newElement = document.createElement("input");

	newElement.type = "hidden";
	newElement.name = inputname;
	newElement.value = "1";
	
	var targetForm = document.getElementById("DefaultButton");
	var parentNode = targetForm.parentNode;
	var newChild = parentNode.insertBefore(newElement, targetForm);	
}

function checkUploadDstFile()
{
	var form = document.uploadFile;
	
	if (have_submit) 
		return -1;
	
	if (form.uploadDstRule.value == "") 
	{
    	alert(translator("select_a_file_before_click_on_upload"));
    	return -1;
  	}
  	
  	var suffix = form.uploadDstRule.value.split(".");

	if (suffix[suffix.length-1] != 'xml')
	{
		alert(translator("the_file_must_have_a_xml_file_suffix"));
		
		return -1;
	}

	have_submit = true;
	
	// Connect with ie8 and https will result in error, add null.html to avoid the issue, suck.
	window.open("/setup/null.html", "testdst", "height=180,width=500");
	form.target="testdst";
	
	form.submit();
}


function checkUploadLangFile()
{
	var form = document.uploadLangFile;
	
	if (have_submit) 
		return -1;
	
	if (form.uploadLanguage.value == "") 
	{
    	alert(translator("select_a_file_before_click_on_upload"));
    	return -1;
  	}
  	
  	var suffix = form.uploadLanguage.value.split(".");

	if (suffix[suffix.length-1] != 'xml')
	{
		alert(translator("the_file_must_have_a_xml_file_suffix"));
		
		return -1;
	}

	have_submit = true;
	
	// Connect with ie8 and https will result in error, add null.html to avoid the issue, suck.
	window.open("/setup/null.html", "testlan", "height=180,width=500");
	form.target="testlan";
	
	form.submit();
}

function checkUploadBackupFile()
{
	var form = document.uploadBackupFile;
	
	if (have_submit) 
		return -1;

	if (form.uploadBackup.value == "") 
	{
    	alert(translator("select_a_file_before_click_on_upload"));
    	return -1;
  	}

	have_submit = true;
	// Connect with ie8 and https will result in error, add null.html to avoid the issue, suck.
	window.open("/setup/null.html", "testbackup", "height=180,width=500");
	form.target="testbackup";

	form.submit();
}

function openurl_wider(urladdr, h, w)
{
	var subWindow = window.open(urladdr, "","height="+h+",width="+w+",scrollbars=yes, status=yes, toolbar=yes");
	subWindow.focus();
}

function formatsd()
{
	var forms = document.FormatSD;
	window.open("", "formatsd", "height=100,width=400");
	forms.submit();
}
function umountsd()
{
	var forms = document.UmountSD;
	window.open("", "umountsd", "height=100,width=400");
	forms.submit();
}

function submitform_exportLang()
{
	var form = document.export_language;
	form.currentlanguage.value = lan;
	form.submit();	
}
