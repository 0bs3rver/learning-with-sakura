
/* Video Info */
var giCH_Curr		= 0;
var g_StreamInfo	= {width: undefined, height: undefined}; // Viewing size
var g_SensorInfo	= {width: undefined, height: undefined}; // Video maximum size

var g_aspectRatio	= 1;
var g_vsRatio		= 1;

/* Focuswindow Control */
var g_FW_CustomInfo	= {width: undefined, height: undefined, x: undefined, y: undefined, show: false};
var g_FW_SizeRange	= {width: {min: undefined, max: undefined}, height: {min: undefined, max: undefined}};
var g_FW_HomeRange 	= {left: {min: undefined, max: undefined}, right: {min: undefined, max: undefined},
			   top: {min: undefined, max: undefined}, low: {min: undefined, max: undefined}};

var g_window_ratio;

/* Remotefocus Control*/
var g_bStartAutoFocus = false;
var g_bResetFocus = false;
var g_bStartDrawing = false;
var g_bZoomMotorMoving = false;

var g_bOpenIris = true;
var g_bFullRangeScan = false;

var g_iMotorPosition;
var g_objCtrlButton;

var gUI_ZoomMotorIndex = 0;
var gUI_FocusMotorIndex = 0;

var gUI_ZoomTotalStep;// = 1000;
var gUI_FocusTotalStep;// = 2000;//6000;//2000;

var gUI_ZoomStart   = 0;
var gUI_ZoomEnd;// 	  = 1000; 		
var gUI_ZoomWalkStep;//  = gUI_ZoomEnd - gUI_ZoomStart;

var gUI_FocusStart;
var gUI_FocusEnd;
var gUI_FocusWalkStep;

var gFac_FocusPosition = 0.0;
var gFac_ZoomPosition = 0.0;

var g_preColor;
var g_DrawScanBarSpeed = 7;//20;//7; // sync with motor scan speed

var g_bFocusOnly = false;

/* Capability change */
var IS_BACKFOCUS = 4;
var MOTOR_DISABLE = 0;
var MOTOR_STOP    = 8;

var giMagicWidth = 558; //px, so magic!
var giMagicTop = 21; //px, so magic!
var giPaddingX;

var g_videoOrientation = {flip: false, mirror: false, rotate: 0};
function checkOrientation()
{
	if (!ParamUndefinedOrZero("videoin_c" + giCH_Curr + "_flip"))
	{
		g_videoOrientation.flip = true;
	}

	if (!ParamUndefinedOrZero("videoin_c" + giCH_Curr + "_mirror"))
	{
		g_videoOrientation.mirror = true;
	}

	if (!ParamUndefinedOrZero("videoin_c" + giCH_Curr + "_rotate"))
	{
		g_videoOrientation.rotate = videoin_c0_rotate;
	}
}

function loadCurrentSetting()
{
	var capabilityStr = "&capability_nmediastream"+
			    "&capability_image_c"+giCH_Curr+"_remotefocus"+
			    "&capability_image_c"+giCH_Curr+"_iristype"+
			    "&capability_image_c"+giCH_Curr+"_focuswindow";
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?videoin&videoinpreview&system_date&system_time"+capabilityStr, false);	
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	document.title=translator("focus_and_zoom");
	loadlanguage();
}

function receivedone()
{
	GenerateRemoteFocusUI();
}

function loadvaluedone()
{
	initShowImage();
	document.getElementById("content").style.visibility = "visible";

	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_remotefocus") || !ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_focuswindow_nwindow"))
	{ 
		initFocusWindow();
		loadUISetting_Focuswindow();
	}

	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_remotefocus"))
	{
		initRemoteFocusButton();
		loadUISetting_RemoteFocus();
		if(capability_image_c0_iristype != "piris" && capability_image_c0_iristype != "dciris")
		{
			g_bOpenIris = false;
			$("#fully_opened_iris").attr("disabled",true);
			$("#OpenIris").attr("disabled",true);
			$("#EnableIris").attr("disabled",true);
		}
		$(window.parent.document.getElementById("remotefocus")).height(parseInt($("body").height()));
	}
}

var fnAutoResize = function() {
	switchView($("button.viewstyle:eq(1)")[0], 'Auto', true);
};

function initShowImage()
{
	var sensor_size = videoin_c0_crop_size.split('x');

	checkOrientation(); //flip, mirro, or rotate.
	if (!g_videoOrientation.rotate)
	{
		g_SensorInfo  = {width: sensor_size[0], height: sensor_size[1]};
	}
	else
	{
		g_SensorInfo  = {width: sensor_size[1], height: sensor_size[0]};
	}	

	streamsource = capability_nmediastream - 1;
	eval("VideoSize=videoin_c0_s"+streamsource+"_resolution");
	eval("codectype=videoin_c0_s"+streamsource+"_codectype");

	if(codectype=="mpeg4" || codectype=="h264")
	{
	  eval("AccessName=network_rtsp_s"+streamsource+"_accessname");
	}
	else
	{
	  eval("AccessName=network_http_s"+streamsource+"_accessname");
	}
	evalPluginSize();

	showimage_innerHTML('8', 'showimageBlock', false, true, false);

	// Init viewsizemode button state, set to Auto on default
	switchView($("button.viewstyle:[title*='Auto-Fit']")[0], "Auto", true);
    
	//While leave Focus Page, whatever the iris should be set to EnableIris
}

//use bForce = true for switchView(Auto) onresize
function switchView(obj, param, bForce)
{
  var bOverSize = false;

	// 1: 100%, 2: Best-fit, 3: 50%, 4: 25%
	// +------------------------------+
	// | $(window).height();          |
	// | $(window).width();           |
	// | $(document).height();        |
	// | $(document).wdith();         |
	// +------------------------------+


  // Reset default state, except "4:3" btn
  $(".viewstyle:gt(0)").attr("disabled", false).each(function(){
    posObj = $(this).css("backgroundPosition").split(" ");
    $(this).css("backgroundPosition", posObj[0] + " 0px");
  });
  // set selected button state
  var posObj = $(obj).css("backgroundPosition").split(" ");
  $(obj).css("backgroundPosition", posObj[0] + " -36px").attr("disabled", true);


	Log("$(window).height()=" + $(window).height()       +
		", $(window).width()=" + $(window).width()       +
		", $(document).height()=" + $(document).height() +
		", $(document).wdith()=" + $(document).width());

	//Video Server, use D1, 4CIF.. as VideoSize param, so we need to do some modification here.
	if (system_info_firmwareversion.match(/VS/) != null)
	{
		var VideoSizeW = Width;
		var VideoSizeH = Height;
	}
	else
	{
		var VideoSizeW = VideoSize.split('x')[0];
		var VideoSizeH = VideoSize.split('x')[1];
	}

	var bStretch = true;

	// default value: 100%
	var tmpHeight = Height + Y_OFFSET;
	var tmpWidth = Width + X_OFFSET;

	// Mainly used for Video Server 4:3 mode! Other models don't need this!
	// **********************************************************************
	var evalByAspectRatio = function(destVar, srcVar1, srcVar2)
	{
		if (destVar.match(/tmpWidth/) != null)
		{
			if (g_aspectRatio == 1)
			{
				tmpWidth = srcVar1 + X_OFFSET;
			}
			else
			{
				tmpWidth = srcVar2 * g_aspectRatio + X_OFFSET;
			}
		}
		else
		{
			if (g_aspectRatio == 1)
			{
				tmpHeight = srcVar1 + Y_OFFSET;
			}
			else
			{
				tmpHeight = srcVar2 / g_aspectRatio + Y_OFFSET;
			}
		}
	};
	// **********************************************************************

	switch(param)
	{
		case 'Auto':
			showimage_innerHTML('8', 'showimageBlock', false, true, false);
			tmpWidth = 550;
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");

			if (g_videoOrientation.rotate)
			{
				evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Width/Height), tmpWidth);
				eval(swap('tmpWidth' , 'tmpHeight' ));
			}

			g_StreamInfo.width = tmpWidth;
			g_StreamInfo.height = tmpHeight;
			break;

		case '100':
			g_vsRatio = 1;
			showimage_innerHTML('8', 'showimageBlock', false, true, false);

			Width = parseInt(Width, 10);
			Height = parseInt(Height, 10);
			tmpWidth = Width + X_OFFSET;
			
			if (tmpWidth > 550)
			{
				tmpWidth = 550;
				bOverSize = true;
			}
			else
			{
				tmpWidth = 550;
				bOverSize = false;
			}
			
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");

			if (g_videoOrientation.rotate)
			{
				evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Width/Height), tmpWidth);
				eval(swap('tmpWidth', 'tmpHeight'));
			}

			break;

		case '50':
			g_vsRatio = 1/2;
			showimage_innerHTML('8', 'showimageBlock', false, true, false);
			
			tmpWidth = Width/2 + X_OFFSET;
			if (tmpWidth > 550)
			{
				tmpWidth = 550;
				bOverSize = true;
			}
			
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");
			break;

		case '25':
			g_vsRatio = 1/4;
			showimage_innerHTML('8', 'showimageBlock', false, true, false);
			
			tmpWidth = Width/4+ X_OFFSET;
			evalByAspectRatio("tmpHeight", Height/4, Width/4);
			$(window).unbind("resize");
			break;

		default:
			alert('Do nothing now');
			break;
	}

	if(bIsWinMSIE)
	{
		$("#"+PLUGIN_ID)[0].Stretch = bStretch;
	}

	if (param == "100")
	{
		if (bOverSize == true)
		{
			$("#"+PLUGIN_ID).attr("height", Height).height(Height);
			$("#"+PLUGIN_ID).attr("width", Width).width(Width);
		}
		else
		{
			$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
			$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
		}	
	}
	else if (param == "50")
	{	
		if (bOverSize == true)
		{
			$("#"+PLUGIN_ID).attr("height", Height / 2).height(Height / 2);
			$("#"+PLUGIN_ID).attr("width", Width / 2).width(Width / 2);
		}
		else
		{
			$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
			$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
		}	
	}
	else
	{	
		$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
		$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);	
	}

	// whether rotate or not, put image in the center
	giPaddingX = parseInt((giMagicWidth - tmpWidth)/2, 10);
	$("#StreamContainer").css("margin-left", giPaddingX);

	$("#showimageBlock").height(tmpHeight).width(tmpWidth).css("overflow","auto");

  g_window_ratio = param;
  if (g_window_ratio != 'Auto')
  {// Disable focus window
    $('#focus_window').css("display","none");

    $('#full_view').attr("disabled", "disabled");
    $('#custom').attr("disabled", "disabled");
    //$('#window_width').attr("disabled", "disabled");
    //$('#window_height').attr("disabled", "disabled");
  }
  else
  {// Enable focus window
    if (g_FW_CustomInfo.show == true)
    {
		  $('#focus_window').css("width",g_FW_CustomInfo.width);
		  $('#focus_window').css("height",g_FW_CustomInfo.height);
		  $('#focus_window').css("top",g_FW_CustomInfo.y);
		  $('#focus_window').css("left",g_FW_CustomInfo.x);

		  $('#focus_window').show().mousedown();
		  $('#focus_window').find(".FW_drag").css("backgroundColor","transparent");
		  $('#focus_window').css("backgroundColor","transparent");
		  $('#focus_window').css("filter","alpha(Opacity=90)").css("opacity","0.9").css("-moz-opacity","0.9");
    }

    if (g_bStartAutoFocus == false)
    {
      $('#focus_window').attr("disabled", "");

      $('#full_view').attr("disabled", "");
      $('#custom').attr("disabled", "");
      //$('#window_width').attr("disabled", "");
      //$('#window_height').attr("disabled", "");
    }
    else
    {
      $('#focus_window').attr("disabled", "disable");
    }
  }
}

function initFocusWindow()
{
	var tmpSensor = {width: g_SensorInfo.width, height: g_SensorInfo.height};
	var tmpStream = {width: g_StreamInfo.width, height: g_StreamInfo.height};

	if (g_videoOrientation.rotate)
	{
		swapValue(tmpSensor, 'width', 'height'); // non-rotated base
		swapValue(tmpStream, 'width', 'height'); // non-rotated base
	}

	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_focuswindow_nwindow"))
	{
		var leftRange	= capability_image_c0_focuswindow_range.split(",")[0].split("~");
		var rightRange	= capability_image_c0_focuswindow_range.split(",")[1].split("~");
		var topRange	= capability_image_c0_focuswindow_range.split(",")[2].split("~");
		var lowRange	= capability_image_c0_focuswindow_range.split(",")[3].split("~");
		g_FW_HomeRange.left	= {min: leftRange[0], max: leftRange[1]};
		g_FW_HomeRange.right	= {min: rightRange[0], max: rightRange[1]};
		g_FW_HomeRange.top	= {min: topRange[0], max: topRange[1]};
		g_FW_HomeRange.low	= {min: lowRange[0], max: lowRange[1]};
		g_FW_SizeRange.width.min  = Math.ceil((g_FW_HomeRange.right.min - g_FW_HomeRange.left.max) * tmpStream.width / tmpSensor.width);
		g_FW_SizeRange.height.min = Math.ceil((g_FW_HomeRange.low.min - g_FW_HomeRange.top.max) * tmpStream.height / tmpSensor.height);
		g_FW_SizeRange.width.max  = Math.floor((g_FW_HomeRange.right.max - g_FW_HomeRange.left.min) * tmpStream.width / tmpSensor.width);
		g_FW_SizeRange.height.max = Math.floor((g_FW_HomeRange.low.max - g_FW_HomeRange.top.min) * tmpStream.height / tmpSensor.height);
	}	
	else
	{
		var definedSize		= {width: {min: 192, max: 0.6 * tmpSensor.width}, height: {min: 144, max: 0.6 * tmpSensor.height}};
		g_FW_HomeRange.left	= {min: 0, max: tmpSensor.width - definedSize.width.min};
		g_FW_HomeRange.right	= {min: definedSize.width.min, max: tmpSensor.width};
		g_FW_HomeRange.top	= {min: 0, max: tmpSensor.height - definedSize.height.min};
		g_FW_HomeRange.low	= {min: definedSize.height.min, max: tmpSensor.height};
		g_FW_SizeRange.width.min  = Math.ceil(definedSize.width.min * tmpStream.width / tmpSensor.width);
		g_FW_SizeRange.height.min = Math.ceil(definedSize.height.min * tmpStream.height / tmpSensor.height);
		g_FW_SizeRange.width.max  = Math.floor(definedSize.width.max * tmpStream.width / tmpSensor.width);
		g_FW_SizeRange.height.max = Math.floor(definedSize.height.max * tmpStream.height / tmpSensor.height);
	}

	if (g_videoOrientation.rotate)
	{
		swapValue(g_FW_HomeRange, 'left', 'top');
		swapValue(g_FW_HomeRange, 'right', 'low');
		swapValue(g_FW_SizeRange, 'width', 'height');
	}

	createFocusWindow();
}

function createFocusWindow()
{
	var load_window = {width: undefined, height: undefined, x: undefined, y: undefined};
	load_window.width  = parseInt(focuswindow_c0_win_i0_size.split("x")[0]);
	load_window.height = parseInt(focuswindow_c0_win_i0_size.split("x")[1]);
	load_window.x = parseInt(focuswindow_c0_win_i0_home.split(",")[0]);
	load_window.y = parseInt(focuswindow_c0_win_i0_home.split(",")[1]);

	// To transform the window unit from config to web-ui.
	if (g_videoOrientation.rotate)
	{
		swapValue(load_window, 'width', 'height');
		swapValue(load_window, 'x', 'y');
	}

	g_FW_CustomInfo.width = Math.round(load_window.width * g_StreamInfo.width / g_SensorInfo.width);
	g_FW_CustomInfo.height = Math.round(load_window.height * g_StreamInfo.height / g_SensorInfo.height);
	g_FW_CustomInfo.x = Math.round(load_window.x * g_StreamInfo.width / g_SensorInfo.width);
	g_FW_CustomInfo.y = Math.round(load_window.y * g_StreamInfo.height / g_SensorInfo.height);

	if (focuswindow_c0_win_i0_enable == "1")
	{
		setTimeout("show_window('focus_option')", 200);
	}
}

function loadUISetting_RemoteFocus()
{
	if (!g_bFocusOnly)
	{
		gUI_ZoomTotalStep = remote_focus_zoom_motor_end;
		gUI_ZoomStart = remote_focus_zoom_motor_start;
		gUI_ZoomWalkStep = gUI_ZoomTotalStep - gUI_ZoomStart;
		gUI_ZoomFactor = remote_focus_zoom_motor_end / gUI_ZoomTotalStep;
	}

	gUI_FocusTotalStep = remote_focus_focus_motor_end;
	gUI_FocusFactor = remote_focus_focus_motor_end / gUI_FocusTotalStep;

	updateFocusScanRange();
	updateMotorIndex();

	if (!g_bFocusOnly)
	{
		$("#slider_zoomBar").slider({
			min: 0,
			max: gUI_ZoomWalkStep,
			animate: true,
			range: "min",
			value: gUI_ZoomMotorIndex,
			slide: function(event, ui)
			{
			},
			change: function(event, ui)
			{
				zoomBarDirect(ui.value);
			}							
		});
	}

  	$("#slider_focusBar").slider({
		min: 0,
	  	max: gUI_FocusWalkStep,
      		animate: true,
      		range: "min",
      		value: gUI_FocusMotorIndex,
      		slide: function(event, ui)
      		{
      		},
      		change: function(event, ui)
      		{
        		focusBarDirect(ui.value);
      		}							
  	});

	//$("#slider_focusBar").slider("option", "value", gUI_FocusMotorIndex);
	//$("#slider_zoomBar").slider("option", "value", gUI_ZoomMotorIndex);
}

function loadUISetting_Focuswindow()
{
	if (bIsWinMSIE || ffversion >= 3 || bIsChrome)
	{
		//openChannel()
		$("#StreamContainer").addClass("StreamContainerStyle");

		/*
		 * create temporay focus window div block.
		 */
		var window_string = translator("focus_window");
		$("#StreamContainer").append(""
				+ '<div id="focus_window" class="FW_style">'
				+ '<div class="FW_drag">'
				+ '<span title="" class="FW_title">' + window_string + '</span>'
				+ '</div>'
				+ '</div>');

		/*
		 * initial focus window by jQueryUI, enable resizable and draggable
		 */

		$('.FW_style').resizable({
			containment: "#StreamContainer",
			//helper: "proxy",
			handles: 'all',
			autoHide: false,
			minWidth:  g_FW_SizeRange.width.min,
			minHeight: g_FW_SizeRange.height.min,
			maxWidth:  g_FW_SizeRange.width.max,
			maxHeight: g_FW_SizeRange.height.max,
			resize: function(e, ui)
			{
			},
			stop: function(e, ui)
			{
				g_FW_CustomInfo.width = strictFocusWindow($(this),'width');
				g_FW_CustomInfo.height = strictFocusWindow($(this),'height');
				apply_window('focus_option');
			}
		})
		.draggable({
			cursor: 'move',
			handle: 'div',
			containment: "#StreamContainer",
			drag: function(e, ui)
			{
			},
			stop: function()
			{
				g_FW_CustomInfo.x = strictFocusWindow($(this),'x');
				g_FW_CustomInfo.y = strictFocusWindow($(this),'y');				
				apply_window('focus_option');
			}
		})
    		.css("display","none");
	}
}

function initRemoteFocusButton()
{
	var BtnObj = document.getElementsByTagName("button");
	for (i = 0; i < BtnObj.length; i++) 
	{
		if (BtnObj[i].id != "btn_zoom_wide" && BtnObj[i].id != "btn_zoom_tele" && BtnObj[i].id != "btn_focus_near" && BtnObj[i].id != "btn_focus_far")
			continue;
		addEventSimple(BtnObj[i], 'mouseover', BtnHandler);
		addEventSimple(BtnObj[i], 'mouseout', BtnHandler);
		addEventSimple(BtnObj[i], 'mousedown', BtnHandler);
		addEventSimple(BtnObj[i], 'mouseup', BtnHandler);
	}
}

function BtnHandler(event)
{
	var object = event.srcElement ? event.srcElement : event.target;    
	if (object.clientWidth != object.offsetWidth || object.disabled == true) return;

	X = parseInt(object.style.backgroundPosition.split(" ")[0]).toString(10);
	if (event.type == "mousedown")
	{
		object.style.backgroundPosition = X + "px " + -2 * object.offsetHeight + "px";
		if (document.all) 
			object.hideFocus = true;
		else 
			return false;
	}
	else if (event.type == "mouseover" || event.type == "mouseup") 
	{
		object.style.backgroundPosition = X + "px " + -object.offsetHeight + "px";
	}
	else//(e=="mouseout") 
	{
		object.style.backgroundPosition = X + "px " + "0px";
	}
}

function strictFocusWindow(obj, option)
{
	var iTitleHeight = $('.FW_drag').height();
	var resizer = obj.data("resizable");
	var dragger = obj.data("draggable"); 
	var rtnValue = null;
	var minValue, maxValue;

	switch(option)
	{
		case 'x':
			//Check left range
			minValue = Math.ceil(g_FW_HomeRange.left.min * g_StreamInfo.width / g_SensorInfo.width);
			maxValue = Math.floor(g_FW_HomeRange.left.max * g_StreamInfo.width / g_SensorInfo.width);
			if (dragger.position.left < minValue)
			{
				dragger.position.left = minValue;
				obj.css("left", minValue);
			}
			else if (dragger.position.left > maxValue)
			{
				dragger.position.left = maxValue;
				obj.css("left", maxValue);
			}
			//Check right range
			minValue = Math.ceil(g_FW_HomeRange.right.min * g_StreamInfo.width / g_SensorInfo.width) - obj.width();
			maxValue = Math.floor(g_FW_HomeRange.right.max * g_StreamInfo.width / g_SensorInfo.width) - obj.width();
			if (dragger.position.left < minValue)
			{
				dragger.position.left = minValue;
				obj.css("left", minValue);
			}
			else if (dragger.position.left > maxValue)
			{
				dragger.position.left = maxValue;
				obj.css("left", maxValue);
			}
			rtnValue = dragger.position.left;
			break;
		case 'y':
			//Check top range
			minValue = Math.ceil(g_FW_HomeRange.top.min * g_StreamInfo.height / g_SensorInfo.height);
			maxValue = Math.floor(g_FW_HomeRange.top.max * g_StreamInfo.height / g_SensorInfo.height);
			if (dragger.position.top < minValue)
			{
				dragger.position.top = minValue;
				obj.css("top", minValue);
			}
			else if (dragger.position.top > maxValue)
			{
				dragger.position.top = maxValue;
				obj.css("top", maxValue);
			}
			//Check low range
			minValue = Math.ceil(g_FW_HomeRange.low.min * g_StreamInfo.height / g_SensorInfo.height) - obj.height();
			maxValue = Math.floor(g_FW_HomeRange.low.max * g_StreamInfo.height / g_SensorInfo.height) - obj.height();
			if (dragger.position.top < minValue)
			{
				dragger.position.top = minValue;
				obj.css("top", minValue);
			}
			else if (dragger.position.top > maxValue)
			{
				dragger.position.top = maxValue;
				obj.css("top", maxValue);
			}
			rtnValue = dragger.position.top;			
			break;
		case 'width':
			//Check width range
			minValue = Math.ceil(g_FW_HomeRange.right.min * g_StreamInfo.width / g_SensorInfo.width) - resizer.position.left;
			maxValue = Math.floor(g_FW_HomeRange.right.max * g_StreamInfo.width / g_SensorInfo.width) - resizer.position.left;
			if (obj.width() < minValue)
			{
				resizer.size.width = minValue;
				obj.css("width", minValue);
			}
			else if (obj.width() > maxValue)
			{
				resizer.size.width = maxValue;
                                obj.css("width", maxValue);
			}
			rtnValue = obj.width();
			break;
		case 'height':
			//Check height range
			minValue = Math.ceil(g_FW_HomeRange.low.min * g_StreamInfo.height / g_SensorInfo.height) - resizer.position.top;
			maxValue = Math.floor(g_FW_HomeRange.low.max * g_StreamInfo.height / g_SensorInfo.height) - resizer.position.top;
			if (obj.height() < minValue)
			{
				resizer.size.height = minValue;
				obj.css("height", minValue);
			}
			else if (obj.height() > maxValue)
			{
				resizer.size.height = maxValue;
				obj.css("height", maxValue);
			}
			rtnValue = obj.height();
			break;
		default:
			break;
	}

	return rtnValue;
}

function updateFocusWindow()
{

	$('#focus_window').css("width",g_FW_CustomInfo.width);
	$('#focus_window').css("height",g_FW_CustomInfo.height);
	$('#focus_window').css("top",g_FW_CustomInfo.y);
	$('#focus_window').css("left",g_FW_CustomInfo.x);

	g_FW_CustomInfo.show = true;
    
	$('#focus_window').show().mousedown();
}

function hideWindows()
{

    g_FW_CustomInfo.show = false;
    $('#focus_window').css("display","none");

    //$('#window_width').attr("value", "");
    //$('#window_height').attr("value", "");
}

function show_window(window_option)
{

  if (window_option == "focus_option")
  {
    updateFocusWindow();
    $('#full_view').attr("checked", "");
    $('#custom').attr("checked", "checked");

    // document.getElementById("width_box").style.display = "";
    // document.getElementById("height_box").style.display = "";
  }
  else
  {
    hideWindows();
    $('#full_view').attr("checked", "checked");
    $('#custom').attr("checked", "");
    
    //document.getElementById("width_box").style.display = "none";
    //document.getElementById("height_box").style.display = "none";
  }
}

function do_orientation()
{

}

function undo_orientation()
{

}

function apply_window(window_option)
{
	// To transform the window unit from web-ui to config.
	var save_window = {width: undefined, height: undefined, x: undefined, y: undefined};
	save_window.width  = Math.floor((g_FW_CustomInfo.width * g_SensorInfo.width) / g_StreamInfo.width);
	save_window.height = Math.floor((g_FW_CustomInfo.height * g_SensorInfo.height) / g_StreamInfo.height);
	save_window.x = Math.floor((g_FW_CustomInfo.x * g_SensorInfo.width) / g_StreamInfo.width);
	save_window.y = Math.floor((g_FW_CustomInfo.y * g_SensorInfo.height) / g_StreamInfo.height);

	if (g_videoOrientation.rotate)
	{
		swapValue(save_window, 'width', 'height');
		swapValue(save_window, 'x', 'y');
	}

	var WindowHome = save_window.x + "," + save_window.y;
	var WindowSize = save_window.width + "x" + save_window.height;
	var apply_window_settings = "";
	if (window_option == "focus_option")
	{
		apply_window_settings = "/cgi-bin/admin/setparam.cgi?focuswindow_c0_win_i0_enable=1" + 
					"&focuswindow_c0_win_i0_home=" + escape(WindowHome) + 
					"&focuswindow_c0_win_i0_size=" + escape(WindowSize);
	}
	else
	{
		apply_window_settings = "/cgi-bin/admin/setparam.cgi?focuswindow_c0_win_i0_enable=0";
	}
	$.get(apply_window_settings);
}

function zoomBarAdjust(bar, direction, steps)
{
	var curPos = parseInt($("#" + bar).slider("value"), 10);
	var moveStep = parseInt(steps, 10);


  if (g_bStartAutoFocus == false)
  {
    switch(direction) {
      case '-':
        $("#" + bar).slider("value", curPos - moveStep);
        break;
      case '+':
        $("#" + bar).slider("value", curPos + moveStep);
        break;
    }
  }
}

function focusBarAdjust(bar, direction, steps)
{
	var curPos = parseInt($("#" + bar).slider("value"), 10);
    var moveStep = parseInt(steps, 10);


  if (g_bStartAutoFocus == false)
  {
    switch(direction) {
		  case '-':
        $("#" + bar).slider("value", curPos - moveStep);
        break;
      case '+':
        $("#" + bar).slider("value", curPos + moveStep);
        break;
    }
  }
}

function focusBarDirect(position)
{
  if ((g_bStartAutoFocus == false) && (g_bZoomMotorMoving == false) &&(g_bResetFocus == false) )
  {
	var UIFocusPosition = position + parseInt(gUI_FocusStart, 10);
	stepFocusTransferUI2Fac(UIFocusPosition);
    $.get("/cgi-bin/admin/remotefocus.cgi?function=focus&direction=direct&position=" + gFac_FocusPosition);
  }
}

function waitZoomEnd()
{
  $.get("/cgi-bin/admin/remotefocus.cgi?function=getstatus", function(result){
    eval(result);
	updateFocusScanRange();
	updateMotorIndex();
	
    $("#slider_focusBar").slider("value", gUI_FocusMotorIndex);

//  if ((remote_focus_focus_enable != 0) || (remote_focus_zoom_enable != 0))
	if (remote_focus_zoom_enable != MOTOR_DISABLE)
    {
      setTimeout("waitZoomEnd();", 500);
    }
    else
    {
      g_bZoomMotorMoving = false;
    }
  })
}

function zoomBarDirect(position)
{
  if (g_bStartAutoFocus == false)
  {	
    //Reset gradient bar
    g_bStartDrawing = false;

    for (i = 0 ; i < gUI_FocusWalkStep ; i ++)
    {
      $("#td_position" + i).css("background-color", "#FFFFFF");
    }

    g_bZoomMotorMoving = true;
	var UIZoomPosition = position + parseInt(gUI_ZoomStart, 10);
	stepZoomTransferUI2Fac(UIZoomPosition);
    $.get("/cgi-bin/admin/remotefocus.cgi?function=zoom&direction=direct&position=" + gFac_ZoomPosition);
    setTimeout("waitZoomEnd();", 100);
  }
}

function autoMovePointer(button)
{
  $.get("/cgi-bin/admin/remotefocus.cgi?function=getstatus", function(result){
    eval(result);
	updateFocusScanRange();
	updateMotorIndex();
	
	$("#slider_focusBar").slider("value", gUI_FocusMotorIndex);
	if (!g_bFocusOnly)
	{
		$("#slider_zoomBar").slider("value", gUI_ZoomMotorIndex);
	}

	if (remote_focus_focus_enable != MOTOR_DISABLE  && remote_focus_focus_enable != MOTOR_STOP)
	{
		setTimeout("autoMovePointer();", 500);
	}
	else
	{
		enableComponent();
		g_bStartAutoFocus = false;
		
			
		//if (!ParamUndefinedOrZero("capability_image_c0_backfocus"))
		if (capability_image_c0_remotefocus == IS_BACKFOCUS)
		{
			g_objCtrlButton.value = translator("fine_tune_focus");
		}
		else
		{
			g_objCtrlButton.value = translator("perform_auto_focus"); //assume capability_image_c0_backfocus = 0 && capability_image_c0_remotefocus = 1
		}
	}
  })
}

function scanDrawBar()
{
  var color;
	var UIFocusPosition = g_iMotorPosition;
	stepFocusTransferUI2Fac(UIFocusPosition);

  $.get("/cgi-bin/admin/remotefocus.cgi?function=getparam&position=" + gFac_FocusPosition, function(result){
    eval(result);

	
    if ((remote_focus_focus_value == 0) && (remote_focus_focus_enable != MOTOR_DISABLE) && (g_iMotorPosition == 0))
    {
      setTimeout("scanDrawBar();", 500);
    }
    else
    {
		 if (remote_focus_focus_value != 0)
		 {
	
		if (remote_focus_value_mode == 0)
		{
			//day mode 
				//color = Math.floor((remote_focus_focus_value / 700000) * 255);
				color = Math.floor((remote_focus_focus_value / 10000000) * 255);
		}
		else
		{
			//night mode
				//color = Math.floor((remote_focus_focus_value / 2000) * 255);
				color = Math.floor((remote_focus_focus_value / 5000000) * 255);
		}
	
      if (color < 0)
        color = 0;
      else if (color > 255)		
        color = 255;
      color = 255 - color;
		
			for (i = 0; i < g_DrawScanBarSpeed; i++)
			{
      if (color < 16)
      {
        $("#td_position" + g_iMotorPosition).css("background-color"
                    , "#0" + color.toString(16) + "0" + color.toString(16) + "FF");
      }
      else
      {
        $("#td_position" + g_iMotorPosition).css("background-color"
                    , "#" + color.toString(16) + color.toString(16) + "FF");
      }
	              g_iMotorPosition ++;				  
			}
			g_preColor = color;	
		 }
		 else
		 {
			  color = g_preColor;

			  if (color < 16)
			  {
				$("#td_position" + g_iMotorPosition).css("background-color"
							, "#0" + color.toString(16) + "0" + color.toString(16) + "FF");
			  }
			  else
			  {
				$("#td_position" + g_iMotorPosition).css("background-color"
							, "#" + color.toString(16) + color.toString(16) + "FF");
			  }
      g_iMotorPosition ++;
		 }


      if ((g_iMotorPosition < gUI_FocusWalkStep) && (g_bStartDrawing == true))
      {
        setTimeout("scanDrawBar();", 150);
      }
    }
  })
}

function scanMovePointer()
{

  $.get("/cgi-bin/admin/remotefocus.cgi?function=getstatus", function(result){
    eval(result);
	updateMotorIndex();
	
	$("#slider_focusBar").slider("value", gUI_FocusMotorIndex);
	if (!g_bFocusOnly)
	{
		$("#slider_zoomBar").slider("value", gUI_ZoomMotorIndex);
	}

	if (remote_focus_focus_enable != MOTOR_DISABLE && remote_focus_focus_enable != MOTOR_STOP)
	{
		setTimeout("scanMovePointer();", 500);
	}
	else
	{
		enableComponent();
		g_bStartAutoFocus = false;
		g_objCtrlButton.value = translator("full_range_scan_focus");

	}
  })
}

function updateIris(checkbox)
{
	if (checkbox.checked)
	{
		g_bOpenIris = true;
	}
	else
	{
		g_bOpenIris = false;
	}
}

function switchToFullScan(checkbox)
{
	if (checkbox.checked)
	{
		g_bFullRangeScan = true;
	}
	else
	{
		g_bFullRangeScan = false;
	}
}

function performAutoFocus(button)
{
	if (g_bFullRangeScan == true)
	{
		performFocusScan(button);
	}
	else
	{
		performFineTuneFocus(button);
	}
}

function performFineTuneFocus(button)
{
    if (g_bStartAutoFocus == true)
    {
      enableComponent();
      g_bStartDrawing = false;

      $.get("/cgi-bin/admin/remotefocus.cgi?function=stop");
    }
	else
	{
		disableComponent();
	    $('#FocusScan').attr("disabled", "disabled")	
		
		g_bStartAutoFocus = true;
		
			//if (!ParamUndefinedOrZero("capability_image_c0_backfocus")) 
		if (capability_image_c0_remotefocus == IS_BACKFOCUS)
		{
			button.value = translator("stop_focus");
		}
		else
		{
			button.value = translator("stop_auto_focus"); //assume capability_image_c0_backfocus = 0 && capability_image_c0_remotefocus = 1
		}

		g_objCtrlButton = button;
		if((g_bOpenIris == true) && ((!ParamUndefinedOrZero("capability_image_c0_remotefocus"))&&(capability_image_c0_remotefocus != IS_BACKFOCUS)))
		{
			$.get("/cgi-bin/admin/remotefocus.cgi?function=auto&iris");
		}
		else
		{
			$.get("/cgi-bin/admin/remotefocus.cgi?function=auto");
		}
		setTimeout("autoMovePointer();", 200);
	}
}

function performFocusScan(button)
{
    if (g_bStartAutoFocus == true)
    {
      enableComponent();
      g_bStartDrawing = false;

      $.get("/cgi-bin/admin/remotefocus.cgi?function=stop");
    }
	else
	{
		disableComponent();
	    $('#FineTuneFocus').attr("disabled", "disabled")	
		
		g_bStartAutoFocus = true;

			//if (!ParamUndefinedOrZero("capability_image_c0_backfocus")) 
		if (capability_image_c0_remotefocus == IS_BACKFOCUS)
		{
			button.value = translator("stop_focus");
		}
		else
		{
			button.value = translator("stop_auto_focus"); //assume capability_image_c0_backfocus = 0 && capability_image_c0_remotefocus = 1
		}

		g_objCtrlButton = button;
		if((g_bOpenIris == true) && ((!ParamUndefinedOrZero("capability_image_c0_remotefocus"))&&(capability_image_c0_remotefocus != IS_BACKFOCUS)))
		{
			$.get("/cgi-bin/admin/remotefocus.cgi?function=scan&iris");
		}
		else
		{
			$.get("/cgi-bin/admin/remotefocus.cgi?function=scan");
		}

		setTimeout("scanMovePointer();", 200);
	}
}

function disableComponent()
{

  $('#full_view').attr("disabled", "disabled");
  $('#custom').attr("disabled", "disabled");
  //$('#window_width').attr("disabled", "disabled");
  //$('#window_height').attr("disabled", "disabled");
  $('#focus_window').attr("disabled", "disabled");
  $('#full_range_scan').attr("disabled", "disabled");
  $('#fully_opened_iris').attr("disabled", "disabled");
}

function enableComponent()
{

  if (g_window_ratio == 'Auto')
  {
    $('#full_view').attr("disabled", "");
    $('#custom').attr("disabled", "");
    //$('#window_width').attr("disabled", "");
    //$('#window_height').attr("disabled", "");
    $('#focus_window').attr("disabled", "");
  }

  $('#full_range_scan').attr("disabled", "");
  $('#FineTuneFocus').attr("disabled", "");
  $('#FocusScan').attr("disabled", "");
  if(capability_image_c0_iristype == "piris" || capability_image_c0_iristype == "dciris")
  {
	  $('#fully_opened_iris').attr("disabled", "");
  }
}

function updateFocusScanRange()
{
	StepTransferFac2UI();
	gUI_FocusWalkStep = gUI_FocusEnd - gUI_FocusStart;
	
	// Update focus bar
	$("#slider_focusBar").slider( "option", "max", gUI_FocusWalkStep);
/*	
	// Update gradient bar
	var innerHTML_str = "";
	for (i = 0; i < gUI_FocusWalkStep; i++)
	{
		innerHTML_str += '<td id="td_position' + i + '" style="background-color: #FFFFFF; width: 1px;"></td>';
	}

	$("#gradientBar").html(innerHTML_str);
*/	
	
}

function updateMotorIndex()
{
	gUI_FocusMotorIndex = remote_focus_focus_motor / gUI_FocusFactor - gUI_FocusStart;
	
	if (!g_bFocusOnly)
	{
		gUI_ZoomMotorIndex = remote_focus_zoom_motor / gUI_ZoomFactor - gUI_ZoomStart;
	}
}

function StepTransferFac2UI()
{

	gUI_FocusStart  = remote_focus_focus_motor_start / gUI_FocusFactor;
	gUI_FocusEnd = remote_focus_focus_motor_end / gUI_FocusFactor ;
}

function stepFocusTransferUI2Fac(UIFocusPosition)
{
	gFac_FocusPosition = UIFocusPosition * gUI_FocusFactor;
}

function stepZoomTransferUI2Fac(UIZoomPosition)
{
	gFac_ZoomPosition = UIZoomPosition * gUI_ZoomFactor;
}

function OpenIris()
{
	if(g_bOpenIris == false)
	{
		g_bOpenIris = true;
	}
	$.get("/cgi-bin/admin/remotefocus.cgi?function=irisopen");
}

function EnableIris()
{
	if(g_bOpenIris == true)
	{
		g_bOpenIris = false;
	}
	$.get("/cgi-bin/admin/remotefocus.cgi?function=irisenable");
}
function ResetABF()
{
	g_bResetFocus = true;
	$.get("/cgi-bin/admin/remotefocus.cgi?function=resetfocus");
	$("#slider_focusBar").slider("value", gUI_FocusTotalStep);
	setTimeout("resetMovePointer();", 2100);
}

function resetMovePointer(button)
{
	$.get("/cgi-bin/admin/remotefocus.cgi?function=getstatus",function(result){
		eval(result);	
		updateFocusScanRange();
		updateMotorIndex();
		$("#slider_focusBar").slider("value", remote_focus_focus_motor);
	})
	g_bResetFocus = false;
}

function GenerateRemoteFocusUI()
{
	//if (!ParamUndefinedOrZero("capability_image_c0_remotefocus"))
	if ((!ParamUndefinedOrZero("capability_image_c0_remotefocus"))&&(capability_image_c0_remotefocus != IS_BACKFOCUS))
	{
		$(document.getElementById("focuswindow")).before(""
		+' <table class="default" id="ZoomMotorCtrlArea">'
		+'   <tr style="height: 30px">'
		+'     <td style="width: 60px"><span title="symbol">zoom</span></td>'
		+' 	<td style="padding:0px 3px;"><input  type="button" value="<<"; onclick="zoomBarAdjust(\'slider_zoomBar\', \'-\', \'10\')"; style="width: 30px;height: 20px;"/></td>'
		+'     <td style="padding:0px 0px;"><input  type="button" value="<"; onclick="zoomBarAdjust(\'slider_zoomBar\', \'-\', \'1\')"; style="width: 30px;height: 20px;"/></td>'
		+'     <td style="width: 300px; padding: 0px 8px;">'
		+'       <div id="slider_zoomBar" style="margin-top: 5px;">'
		+'       <div class="ui-slider-handle" id="title_zoomBar"></div>'
		+'       </div>'
		+'     </td>'
		+' 	<td style="padding:0px 3px;"><input  type="button" value=">"; onclick="zoomBarAdjust(\'slider_zoomBar\', \'+\', \'1\')"; style="width: 30px;height: 20px;"/></td>'
		+'     <td style="padding:0px 0px;"><input  type="button" value=">>"; onclick="zoomBarAdjust(\'slider_zoomBar\', \'+\', \'10\')"; style="width: 30px;height: 20px;"/></td>'
		+'   </tr>'
		+' </table>'     
		+' <!-- Focus bar -->'
		+' <table class="default">'
		+'   <tr style="height: 25px;">'
		+'     <td style="width: 60px"><span title="symbol">focus</span></td>'
		+' 	<td style="padding:0px 3px;"><input  type="button" value="<<"; onclick="focusBarAdjust(\'slider_focusBar\', \'-\', \'15\')"; style="width: 30px;height: 20px;"/></td>'
		+'     <td style="padding:0px 0px;"><input  type="button" value="<"; onclick="focusBarAdjust(\'slider_focusBar\', \'-\', \'1\')"; style="width: 30px;height: 20px;"/></td>'
		+'     <td style="width: 300px; padding: 0px 8px;">'
		+'       <div id="slider_focusBar" style="height: 28px; margin-top: 5 px; background: transparent url(/pic/remotefocus_slidertrack2.png) scroll 0 0;">'
		+'       <div class="ui-slider-handle" id="title_focusBar" style="top:6px;"></div>'
		+'       </div>'
		+'     </td>'
		+' 	<td style="padding:0px 3px;"><input  type="button" value=">"; onclick="focusBarAdjust(\'slider_focusBar\', \'+\', \'1\')"; style="width: 30px;height: 20px;"/></td>'
		+'     <td style="padding:0px 0px;"><input  type="button" value=">>"; onclick="focusBarAdjust(\'slider_focusBar\', \'+\', \'15\')"; style="width: 30px;height: 20px;"/></td>'
		+'   </tr>'
		+' </table>'
		+' <br/>'
		+' <!-- Auto focus button -->'
		+' <fieldset class="tabs-fieldset">'
		+'   <legend><strong><span title="symbol">auto_focus</span></strong></legend>'
		+'   <table class="default">'
		+'     <tr style="height: 30px">'
		+'       <td ><input id="full_range_scan" type="checkbox" onclick="switchToFullScan(this);"/><span title="symbol">full_range_scan</span></td>'
		+'       <td style="width: 10px"></td>'
		+'       <td ><input id="fully_opened_iris" type="checkbox" checked="checked" onclick="updateIris(this);"/><span title="symbol">fully_opened_iris</span></td>'
		+'       <td style="width: 10px"></td>'
		+'       <td ><input  type="button" title="symbol" onclick="performAutoFocus(this)" value="'+translator("perform_auto_focus")+'"/></td>'
		+'     </tr>'
		+'   </table>'
		+' </fieldset>');
	}
	//if (!ParamUndefinedOrZero("capability_image_c0_backfocus"))
	if (capability_image_c0_remotefocus == IS_BACKFOCUS)
	{
		g_bFocusOnly = true;
		$(document.getElementById("focuswindow")).after(""
         +'<fieldset class="tabs-fieldset" id="remotefocusUI">'
		 +'  <legend><strong><span title="symbol">'+translator("focus_adjustment")+'</span></strong></legend>'
		 +'  <table class="default">'
		 +'  	<tr style="height: 30px" id="abf_step1">'
		 +'  		<td style="width: 20px">1.</td>'
		 +'  		<td colspan="4"><input  type="button" title="symbol" onclick="ResetABF(this)" value="'+translator("reset")+'"/>'
		 +'  		<span title="symbol">'+translator("to_default_back_focus_position")+'</span></td>'
		 +'  	</tr>'
		 +'  	<tr style="height: 30px">'
		 +'  		<td style="width: 20px" id="abf_step2">2.</td>'
		 +'  		<td colspan="3"><input type="button" title="symbol" id="OpenIris" onclick="OpenIris(this)" value="'+translator("open_iris")+'"/></td>'
		 +'  	</tr>'
		 +'  	<tr style="height: 30px" id="abf_step3">'
		 +'  		<td style="width: 20px">3.</td>'
		 +'  		<td colspan="4"><span title="symbol">'+translator("abf_adjustment_message")+'</span></td>'
		 +'  	</tr>'
		 +'  </table>'
		 +'  <table class="default">'
		 +'  	<tr style="height: 30px">'
		 +'  		<td style="width: 20px" id="abf_step4">4.</td>'
		 +'  		<td><input type="button" title="symbol" id="FineTuneFocus" onclick="performFineTuneFocus(this)" value="'+translator("fine_tune_focus")+'"/></td>'
		 +'  		<td style="width: 10px"></td>'
		 +'  		<td><input type="button" title="symbol" id="FocusScan" onclick="performFocusScan(this)" value="'+translator("full_range_scan_focus")+'"/></td>'
		 +'  	</tr>'
		 +'  	<tr>'
		 +'  </table>'
		 +'  		<!-- Focus bar -->'
		 +'  		<table class="default">'
		 +'  			<tr style="height: 25px;">'
		 +'  				<td style="width: 60px"><span title="symbol">'+translator("focus")+'</span></td>'
		 +'  				<td style="padding:0px 3px;"><input  type="button" value="<<"; onclick="focusBarAdjust(\'slider_focusBar\', \'-\', \'15\')"; style="width: 30px;height: 20px;"/></td>'
		 +'  				<td style="padding:0px 0px;"><input  type="button" value="<"; onclick="focusBarAdjust(\'slider_focusBar\', \'-\', \'1\')"; style="width: 30px;height: 20px;"/></td>'
		 +'  				<td style="width: 300px; padding: 0px 8px;">'
		 +'  					<div id="slider_focusBar" style="height: 28px; margin-top: 5 px; background: transparent url(/pic/remotefocus_slidertrack2.png) scroll 0 0;">'
		 +'  						<div class="ui-slider-handle" id="title_focusBar" style="top:6px;"></div>'
		 +'  					</div>'
		 +'  				</td>'
		 +'  				<td style="padding:0px 3px;"><input  type="button" value=">"; onclick="focusBarAdjust(\'slider_focusBar\', \'+\', \'1\')"; style="width: 30px;height: 20px;"/></td>'
		 +'  				<td style="padding:0px 0px;"><input  type="button" value=">>"; onclick="focusBarAdjust(\'slider_focusBar\', \'+\', \'15\')"; style="width: 30px;height: 20px;"/></td>'
		 +'  			</tr>'
		 +'  		</table>'
		 +'	 </tr>'
		 +'  	<table class="default">'
		 +'  		<tr style="height: 30px">'		   		
		 +'  			<td style="width: 20px" id="abf_step5">5.</td>'
		 +'  			<td><input type="button" title="symbol" id="EnableIris" onclick="EnableIris(this)" value="'+translator("enable_iris")+'"/></td>'
		 +'  		</tr>'
		 +'  	</table>'
	 	 +' </fieldset>');
	}
}

function swapValue(obj, prop_key_1, prop_key_2)
{
	var prop_value_1 = 0;
	var prop_value_2 = 0;

	for(var prop_key in obj)
	{
    		if(obj.hasOwnProperty(prop_key))
		{
			if (prop_key == prop_key_1)
			{
        			prop_value_1 = obj[prop_key];
			}
    			if (prop_key == prop_key_2)
			{
        			prop_value_2 = obj[prop_key];
			}
		}
	}
	obj[prop_key_1] = prop_value_2;
	obj[prop_key_2] = prop_value_1;
}

function includeClear(targetFile)
{
        var includeList = document.getElementsByTagName("script");
        var iLastIndex = includeList.length;
        var bClearAll = (targetFile)? false : true;

        for (iLastIndex; iLastIndex >= 0; iLastIndex--)
        {
                if (includeList[iLastIndex]
                                && includeList[iLastIndex].getAttribute("src") != null
                                && ((bClearAll)?bClearAll:(includeList[iLastIndex].getAttribute("src").indexOf(targetFile) != -1)))
                {
                        includeList[iLastIndex].parentNode.removeChild(includeList[iLastIndex]);
                }
        }
}

