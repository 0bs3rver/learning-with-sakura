var EAccountType = {
	"root" : 0,
	"user" : 1, };

function loadCurrentSetting()
{			
	//if (navigator.appVersion.indexOf("MSIE 6.") != -1) changeClasses(document);
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info_language&system_info_customlanguage&security&network_http_anonymousviewing", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("user_account");

	if (g_mode == "0")
	{
        $("#adv_security").css("display","none");
		$("#privilege_management_tab").css("display","none");
	}
		
	judgeToDisplayPirvilege();

	loadlanguage();
}

function receivedone()
{
	loadlist();
	document.getElementsByName("security_user_i0_pass")[0].value = getDefaultPassword();
	document.RootPassword.confirm.value = getDefaultPassword();
	document.getElementById("content").style.visibility = "visible";
}

function loadvaluedone()
{
	if (security_privilege_do == "view")
	{
		$("#priDoOperator").attr("checked",true);
		$("#priDoViewer").attr("checked",true);
	}
	else if (security_privilege_do == "operator")
	{
		$("#priDoOperator").attr("checked",true);
		$("#priDoViewer").attr("checked",false);
	}
	else
	{
		$("#priDoOperator").attr("checked",false);
		$("#priDoViewer").attr("checked",false);
	}
	
	if (security_privilege_camctrl == "view")
	{
		$("#priPTZOperator").attr("checked",true);
		$("#priPTZViewer").attr("checked",true);
	}
	else if (security_privilege_camctrl == "operator")
	{
		$("#priPTZOperator").attr("checked",true);
		$("#priPTZViewer").attr("checked",false);
	}
	else
	{
		$("#priPTZOperator").attr("checked",false);
		$("#priPTZViewer").attr("checked",false);
	}

	$("a[href=" + document.location.hash + "]").click();
}

function onchangeUserList()
{
	var sform = document.ManageUser;

	sform.privilege.value = aUserPrivList[sform.index.value];
	if (sform.index.value == "0") // add new user
	{
		document.getElementById("addButton").disabled = false;
		document.getElementById("deleteButton").disabled = true;
		document.getElementById("updateButton").disabled = true;
		document.getElementsByName("userpass")[0].value = "";
		document.getElementById("DAUTOID_security_confirm_user_password").value = "";
		sform.tempname.value = "";
		sform.tempname.disabled = false;
	}
	else
	{
		document.getElementById("addButton").disabled = true;
		document.getElementById("deleteButton").disabled = false;
		document.getElementById("updateButton").disabled = false;
		document.getElementsByName("userpass")[0].value = getDefaultPassword();
		document.getElementById("DAUTOID_security_confirm_user_password").value = getDefaultPassword();
		sform.tempname.value = aUserNameList[sform.index.value][1];
		sform.tempname.disabled = true;
	}
}

function checkUser(theUserCtrl)
{
	var aUser = theUserCtrl.value;

	for (i = 0; i < aUser.length; i++)
	{
		c = aUser.charAt(i);
		if (!( (c>='@' && c<='Z') || (c>='a' && c<='z') || (c>='0' && c<='9') || c=="!" ||
			c=="$" || c=="%" || c=="-" || c=="." || c=="^" || c=="_" || c=="~"))
		{
			alert(translator("you_have_used_invalid_characters_passwd"));
			theUserCtrl.focus();
			theUserCtrl.select();
			return -1;
		}
	}
	return 0;
}

function checkPasswordVal(theAccountType)
{
	var passwordval;
	if (theAccountType == EAccountType.root)
	{
		passwordval = document.getElementsByName("security_user_i0_pass")[0].value;
	}
	else 
	{
		passwordval = document.getElementsByName("userpass")[0].value;
	}

	if(checkDefaultPassword(passwordval) != 0)
	{
		document.getElementsByName("security_user_i0_pass")[0].disabled = true;
		document.getElementsByName("userpass")[0].disabled = true;
	}
	
	return 0;
}

function saveRoot()
{
	if (document.RootPassword.security_user_i0_pass.value == "")
	{
		alert(translator("blank_root_password_will_disable_user_authentication"));
	}
	aRet = checkPassword(document.RootPassword.security_user_i0_pass, document.RootPassword.confirm);
	if (aRet != 0){
		return;
	}
	if(checkPasswordVal(EAccountType.root) != 0)
	{
		return -1;
	}
	document.RootPassword.submit();
}

function addUserList()
{
	var sform = document.ManageUser;
	
	if (sform.tempname.value=="")
		return;
	
	if (sform.index.length >= 21){
		alert(translator("no_more_account_for_this_new_user"));
		return;
	}
	
	for (var i = 1; i < sform.index.length; i++)
	{
		if (sform.tempname.value == sform.index.options[i].text)
		{
			alert(translator("the_name_has_already_existed"));
			return;
		}
	}
	if (checkUser(sform.tempname) != 0)
	{
		return;
	}
	
	if (checkPassword(sform.userpass, sform.confirm) != 0)
	{
		return;
	}

	if (checkPasswordVal(EAccountType.user) != 0)
	{
		return -1;
	}
	
	sform.username.value = sform.tempname.value;
	sform.method.value = "add"
	sform.submit();
}

function delUserList()
{
	var sform = document.ManageUser;
	var msg = translator("do_you_really_want_to_remove_this_user");
	
	if (confirm(msg))
	{
		sform.username.value = sform.tempname.value;
		sform.method.value = "delete";
		sform.submit();
	}
}

function modUserList()
{
	var sform = document.ManageUser;

	if (checkPassword(sform.userpass, sform.confirm) != 0)
	{
		return; 
	}	
	if (checkPasswordVal(EAccountType.user) != 0)
	{
		return -1;
	}
	sform.username.value = sform.tempname.value;
	sform.method.value = "edit";

	sform.submit();
}

function loadlist()
{
	var sform = document.ManageUser;
	var userName = "";
	var userPrivilege = "";
	
	aUserNameList[0][0] = true;
	aUserNameList[0][1] = "--" + translator("add_new_user") + "--";
	aUserPrivList[0] = "admin";
	for (var i = 1; i <= 20; ++i)
	{
		eval("userName = security_user_i" + i + "_name");
		eval("userPrivilege = security_user_i" + i + "_privilege");
		if (userName.length != 0)
		{
			aUserNameList[i][0] = true;
			aUserNameList[i][1] = userName;

			aUserPrivList[i] = userPrivilege;
		}
	}

	updateDynSelOpt(sform.index, aUserNameList);
	onchangeUserList();
}

var aUserNameList = new Array(21);
var aUserPrivList = new Array(21);
for (i = 0; i < 21; i ++)
{
	aUserNameList[i] = new Array(false, "", i);
	aUserPrivList[i] = new Array("");
}


function savePrivilege()
{
	var f = document.ManagePrivilege;
	
	if (f.priDoViewer.checked) 
		f.security_privilege_do.value = 'view';
	else if (f.priDoOperator.checked) 
		f.security_privilege_do.value = 'operator';
	else
		f.security_privilege_do.value = 'admin';
	

	if (f.priPTZViewer.checked)
		f.security_privilege_camctrl.value = 'view';
	else if (f.priPTZOperator.checked)
		f.security_privilege_camctrl.value = 'operator';
	else
		f.security_privilege_camctrl.value = 'admin';

	f.network_rtsp_anonymousviewing.value = f.network_http_anonymousviewing.value;
	if (network_http_anonymousviewing != f.network_http_anonymousviewing.value)
	{
		if (f.network_http_anonymousviewing.value == 0)
		{
			var msg = "/cgi-bin/admin/connst.cgi?_a=5";
			XMLHttpRequestObject.open("GET", msg, false);
			XMLHttpRequestObject.send(null);
		}
	}

	f.submit();
}

function updatePriDoCheck(obj)
{	
	if(obj.id == "priDoViewer")
	{
		if(obj.checked)
			$("#priDoOperator").attr("checked",true);		  
	}
	else if(obj.id == "priDoOperator")
	{
		if($("#priDoViewer").attr("checked"))
			$("#priDoViewer").attr("checked",false);
	}
}

function updatePriPTZCheck(obj)
{
	if(obj.id == "priPTZViewer")
	{
		if(obj.checked)
			$("#priPTZOperator").attr("checked",true);		  
	}
	else if(obj.id == "priPTZOperator")
	{
		if($("#priPTZViewer").attr("checked"))
			$("#priPTZViewer").attr("checked",false);
	}
}

function judgeToDisplayPirvilege()
{
	if ((capability_ndo == 0) && (capability_ptzenabled == 0) &&(capability_eptz == 0) &&(capability_fisheye == 0)) 
	{
		// hide DO & PTZ segments
		$("#OperatorParent").css("display","none");
		$("#ViewerParent").css("display","none");
	}
	else 
	{
		if (capability_ndo == 0) 
		{
			// hide DO segments
			$("#segmentDoOperator").css("display","none");
			$("#segmentDoViewer").css("display","none");
		}
		if (capability_ptzenabled == 0 && capability_eptz == 0 && (capability_fisheye == 0)) 
		{
			// hide PTZ segments
			$("#segmentPTZOperator").css("display","none");
			$("#segmentPTZViewer").css("display","none");
		}
	}
}
