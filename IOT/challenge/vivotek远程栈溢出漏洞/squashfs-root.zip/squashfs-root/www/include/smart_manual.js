var previewFlag = 0;
var orig_exposurewin_mode;
var minexposure, maxexposure, fixexposure, piris_sensitivity, piris_response, piris_position;
var mingain, maxgain, fixgain;
var SHUTTER_SPEED_LEN = 13;

var aShutterSpeedTbl = new Array(32000, 16000, 8000, 4000, 2000, 1000, 500, 480, 250, 240, 120, 100, 60, 50, 30, 25, 15, 5);
var aMaxShutterSpeed = new Array(SHUTTER_SPEED_LEN);
var bModified = false;	

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

function loadCurrentSetting()
{		
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?videoin&videoinpreview&ircutcontrol&system_date&system_time&exposurewin&capability_nmediastream&capability_image_c0_iristype", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	//document.title = translator("profile_of_exposure_settings");
	loadlanguage();	

	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};
	
	//updata 
	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;
			
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];
		
		if(!type || compare(type.description, plugin.description)) {
			xpi = plugin.xpi;
		}
	
		if(xpi) {
			if( window.InstallTrigger == undefined) // It means this page is include in other page
				parent.window.InstallTrigger.install(xpi); 
			else
				window.InstallTrigger.install(xpi);
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');
		}																					   //
	}
	
	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}

	$('#InstallerArea').hide();

	winless_loadCurrentSetting();

	if(typeof(RtspVapgCtrl) != "undefined")
		SetPluginString(RtspVapgCtrl);
	reDrawPlugin();

}

function disableItem(obj, checkbox)
{
	if (checkbox.checked == true)
	{
		obj.disabled = true;
	}
	else
	{
		obj.disabled = false;
	}
}

function receivedone()
{
	winless_receivedone();
}

function loadvaluedone()
{
	var pf = document.profileset;

	winless_loadvaluedone();

	checkEPWinType(false);
}



function submitform(mode)
{
	
	if (mode == "restore" && (bModified== true || bModifyWin == true)) 
	{
		
		checkEPWinType(false);
	
		//exposure window
		var w_ratio;
		var h_ratio;

		if (bRotate)
		{
			w_ratio = ($("#"+PLUGIN_ID).width()- X_OFFSET) / 240;
			h_ratio = ($("#"+PLUGIN_ID).height()- Y_OFFSET) / 320;
		}
		else
		{
			w_ratio = ($("#"+PLUGIN_ID).width()- X_OFFSET) / 320;
			h_ratio = ($("#"+PLUGIN_ID).height()- Y_OFFSET) / 240;
		}
		
		
		var params = "";
		for (i = 0; i < EP_WINDOW_NUMBER; i++) 
		{
			if (!ParamUndefinedOrZero("capability_smartstream_version")&&capability_smartstream_version == "2.0")
			{
				if (bRotate)
				{
					$('#EPWindow' + i).css({
						"width": 	eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[1])*w_ratio) +2+2) + "px"'),
						"height": 	eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[0])*h_ratio) +2+18+2) + "px"' ),
						"top": 		eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[0])*h_ratio) +5-2) + "px"'),
						"left": 	eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[1])*w_ratio) +5-2) + "px"')
					})

					g_a320x240_EPW_width[i] = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[1]))');
					g_a320x240_EPW_height[i]  = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[0]))');
					g_a320x240_EPW_left[i]    = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[1]))');
					g_a320x240_EPW_top[i]   = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[0]))');
				}
				else
				{
					$('#EPWindow' + i).css({
						"width": 	eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[0])*w_ratio) +2+2) + "px"' ),
						"height": 	eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[1])*h_ratio) +2+18+2) + "px"'),
						"top": 		eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[1])*h_ratio) +5-2) + "px"'),
						"left": 	eval('Math.round((parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[0])*w_ratio) +5-2) + "px"')
					})

					g_a320x240_EPW_width[i]  = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[0]))');
					g_a320x240_EPW_height[i] = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size.split("x")[1]))');
					g_a320x240_EPW_left[i]   = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[0]))');
					g_a320x240_EPW_top[i]    = eval('Math.round(parseInt(videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home.split(",")[1]))');
				}

				params += 	"videoin_c0_s"+g_streamsource + g_codec +"_smartstream2_win_i"+ i +"_enable="+ eval("videoin_c0_s"+g_streamsource + g_codec +"_smartstream2_win_i"+i+"_enable")+"&"+
							"videoin_c0_s"+g_streamsource + g_codec +"_smartstream2_win_i"+ i +"_home="	+ eval("videoin_c0_s"+g_streamsource + g_codec +"_smartstream2_win_i"+ i +"_home")+"&"+
							"videoin_c0_s"+g_streamsource + g_codec +"_smartstream2_win_i"+ i +"_size="	+ eval("videoin_c0_s"+g_streamsource + g_codec +"_smartstream2_win_i"+ i +"_size")+"&";
			}
		};

		$.ajax({
			type: "POST",
			cache: false,
			url: "/cgi-bin/admin/setparam.cgi",
			data: params
		});
		bModifyWin = false;
		bModified = false;
	}
	else if (mode == "save")
	{
		if (checkvalue())
		{
			return -1;
		}
		
	
		for (i = 0; i < EP_WINDOW_NUMBER; i++) 
		{
			if (bRotate)
			{
				tmp = g_a320x240_EPW_width[EP_Window_selected]; 
				g_a320x240_EPW_width[EP_Window_selected] = g_a320x240_EPW_height[EP_Window_selected];
				g_a320x240_EPW_height[EP_Window_selected] = tmp;

				tmp = g_a320x240_EPW_left[EP_Window_selected]; 
				g_a320x240_EPW_left[EP_Window_selected] = g_a320x240_EPW_top[EP_Window_selected];
				g_a320x240_EPW_top[EP_Window_selected] = tmp;
			}

			if (!ParamUndefinedOrZero("capability_smartstream_version")&&capability_smartstream_version == "2.0")
			{
				eval('videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_enable=' + ($('#EPWindow'+ i).css("display") == "none" ? 0: 1));
				eval('videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_size="' + g_a320x240_EPW_width[i] + 'x' + g_a320x240_EPW_height[i] + '"');
				eval('videoin_c0_s'+g_streamsource + g_codec +'_smartstream2_win_i' + i + '_home="' + g_a320x240_EPW_left[i] + ',' + g_a320x240_EPW_top[i] + '"');
			}
			
		}

		bModifyWin = false;
		bModified = false;
	}
}

function RestoreSetting()
{
	submitform("restore");

}


function checkEPWinType(IsModified)
{
	$("#EPWinCustom").css("display","block");

	for (i = 0; i < EP_WINDOW_NUMBER; i++)
	{
		if (!ParamUndefinedOrZero("capability_smartstream_version")&&capability_smartstream_version == "2.0")
		{
			$('#EPWindow' + i).css({
				display: (eval('videoin_c0_s'+g_streamsource+ g_codec +'_smartstream2_win_i' + i + '_enable') == '0')? "none" : "block"
			})
		}
	}
	
	bModified = IsModified;
}
