function mySleep(naptime){
         naptime = naptime * 1000;
         var sleeping = true;
         var now = new Date();
         var alarm;
         var startingMSeconds = now.getTime();
         while(sleeping){
             alarm = new Date();
             alarmMSeconds = alarm.getTime();
             if(alarmMSeconds - startingMSeconds > naptime){ sleeping = false; }
         }        
}

function showimage2(type, destBlock, iwidth, iheight, filePath)
{
	// showimage(0)  begin  
	var str_innerHTML = "";

	platform = navigator.platform.substr(0, 3);
	if (bIsWinMSIE) 
	{
		switch (type)
		{
			case '2':
			W=iwidth + X_OFFSET;
			H=iheight + Y_OFFSET;
			STRETCH = 1;
			break;              
		}

		// The ActiveX plug-in  
		str_innerHTML = "<object id=\"" + PLUGIN_ID + "\" width=" + W + " height=" + H;
		str_innerHTML += " standby=\"Loading plug-in...\" classid=CLSID:" + CLASS_ID;
		str_innerHTML += " codebase=\"/" + PLUGIN_NAME + "#version=" + PLUGIN_VER + "\">";
		str_innerHTML += "<param name=\"BePlaybackChannel\" VALUE=\"true\">";
		if (1 == STRETCH)
		{
			str_innerHTML += "<param name=\"Stretch\" VALUE=\"true\">";
		}
		else
		{
			str_innerHTML += "<param name=\"Stretch\" VALUE=\"false\">";
		}
		/*
		if (codectype == "mpeg4" || codectype=="h264") 
			str_innerHTML += "<param name=\"Url\" VALUE=\"rtsp://" + location.hostname + "/" + AccessName + "\">";
		else 
		{
			thisURL = document.URL;
			http_method = thisURL.split(":");
			if (http_method[0] == "https") 
			{
				str_innerHTML += "<param name=\"Url\" VALUE=\"https://" + location.host + "/" + AccessName + "\">";
			}
			else 
			{
				str_innerHTML += "<param name=\"Url\" VALUE=\"http://" + location.host + "/" + AccessName + "\">";
			}
			str_innerHTML += "<param name=\"ServerModelType\" VALUE=\"0\">";
		}

		switch (type)
		{
			case '2':
				str_innerHTML += "<PARAM NAME=\"ControlType\" VALUE=0>";
				str_innerHTML += "<PARAM NAME=\"ClientOptions\" VALUE=\"639\">";    
				break;
		}

		str_innerHTML += "<param name=\"ViewStream\" VALUE=\"" + streamsource + "\">";
		str_innerHTML += "<param name=\"VSize\" VALUE=\"CMS\">";
		str_innerHTML += "<param name=\"Stretch\" VALUE=\"" + STRETCH + "\">";
		
		// Support Joystick
		str_innerHTML += "<PARAM NAME=\"EnableJoystick\" VALUE=\"false\">";
		str_innerHTML += "<PARAM NAME=\"UpdateJoystickInterval\" VALUE=\"100\">";
		str_innerHTML += "<PARAM NAME=\"JoystickSpeedLvs\" VALUE=\"5\">";
		str_innerHTML += "<PARAM NAME=\"BeRightClickEventHandler\" VALUE=\"false\">";

		str_innerHTML += "<param name=\"Language\" VALUE=\"" + PLUGIN_LANG + "\">";
		str_innerHTML += "<param name=\"MP4Conversion\" VALUE=\"true\">";
		str_innerHTML += "<param name=\"AutoStartConnection\" VALUE=\"true\">";
		str_innerHTML += "<PARAM NAME=\"UserDateFormat\" VALUE=\"true\">";              
		str_innerHTML += translator("this_is_a_plugin_activex");
		str_innerHTML += "<br>";
		str_innerHTML += translator("if_you_see_this_text_your_browser_does_not_support_or_has_disabled_activex");
		str_innerHTML += "<p/>";
		str_innerHTML += "</object>";
		*/
		// Support Joystick
        str_innerHTML += "<param name=\"EnableJoystick\" VALUE=\"false\">";
        str_innerHTML += "<param name=\"AutoStartConnection\" VALUE=\"false\>";
        str_innerHTML += "<param name=\"UserDateFormat\" VALUE=\"true\">";
		str_innerHTML += "<param name=\"IgnoreCaption\" VALUE=\"true\">";              
        str_innerHTML += translator("this_is_a_plugin_activex");
        str_innerHTML += "<br>";
        str_innerHTML += translator("if_you_see_this_text_your_browser_does_not_support_or_has_disabled_activex");
        str_innerHTML += "<p/>";
        str_innerHTML += "</object>";
	}
	else if (bIsFireFox || bIsChrome)
    {
		switch (type)
        {
            case '2':
            W=iwidth + X_OFFSET;
            H=iheight + Y_OFFSET;
            STRETCH = 1;
            break;
        }

        // The ActiveX plug-in
        str_innerHTML = "<object id=\"" + PLUGIN_ID + "\" type=\""+FFTYPE+"\" width=" + W + " height=" + H + ">";
        str_innerHTML += "<param name=\"BePlaybackChannel\" VALUE=\"1\">";
        str_innerHTML += "<param name=\"Stretch\" VALUE=\"" + STRETCH + "\">";

        // Support Joystick
        str_innerHTML += "<param name=\"EnableJoystick\" VALUE=\"0\">";
        str_innerHTML += "<param name=\"AutoStartConnection\" VALUE=\"0\">";
        str_innerHTML += "<param name=\"UserDateFormat\" VALUE=\"1\">";
		str_innerHTML += "<param name=\"IgnoreCaption\" VALUE=\"1\">";
        str_innerHTML += "</object>";

    }
	else if (navigator.appName == "Netscape") 
	{
		switch (type)
		{
			case '2':
				W=Number(iwidth) + X_OFFSET;
				H=Number(iheight) + Y_OFFSET;
				break;              
		}
		str_innerHTML += "<embed SCALE=\"ToFit\" width=\"" + W + "\" height=\"" + H + "\"";
		//str_innerHTML += " type=\"video/quicktime\" qtsrc=\"rtsp://" + location.hostname + "/" + AccessName + "\"";
		//str_innerHTML += " type=\"video/m4v\" src=\"../NCMF/keke/abc.mp4\" ";
		var realPath = filePath.split("NCMF");
		str_innerHTML += " type=\"video/m4v\" src=\"../NCMF/" + realPath[1] + "\"";
		str_innerHTML += " qtsrcdontusebrowser src=\"/realqt.mov\" autoplay=\"true\" controller=\"true\"\>";
	}
	else 
	{
		str_innerHTML += "Please use Firefox, Mozilla or Netscape<br>";
	}
	// update Div(display_image)  
	document.getElementById(destBlock).innerHTML = str_innerHTML;
	//mySleep(5);
}

