function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&thermal", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("temperature_detection");
	loadlanguage();
	//if(typeof(RtspVapgCtrl)!="undefined")
	//SetPluginString(RtspVapgCtrl);
}

function submitform()
{
	form = document.forms[0];

	if(checkvalue())
	{
		return -1;
	}
	else
	{
		form.submit();
	}
}
