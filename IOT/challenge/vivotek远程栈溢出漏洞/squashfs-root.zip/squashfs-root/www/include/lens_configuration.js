var iUserNum = 0;

function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?lens&capability_bootuptime", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("lens_configuration");

	loadlanguage();
}

function receivedone()
{
	calculateUserLensNum();
	checkDelete();
	initLenList();
	checkLenProfile();
}

function calculateUserLensNum()
{
	for (var i = 0; i < parseInt(lens_user_totalnumbers, 10); i++)
	{
		if (eval('lens_user_i'+ i +'_name') != "")
		{
			iUserNum++;
		}
	}
}

function checkDelete()
{
	if (iUserNum > 0)
	{
		$("#delete_lens_profile_span").show();
		$("#delete_lens_profile_form").show();
	}
	else
	{
		$("#delete_lens_profile_span").hide();
		$("#delete_lens_profile_form").hide();
	}
}

function initLenList() {
	// choose list
	var chooseSelect = document.getElementById("choose_lens_profile_select");
	chooseSelect.options.length = 0;
	// delete list
	var deleteSelect = document.getElementById("delete_lens_profile_select");
	deleteSelect.options.length = 0;

	for (var i = 0; i < parseInt(lens_default_totalnumbers, 10); i++)
	{
		if (eval('lens_default_i'+ i +'_name') != '')
		{
			chooseSelect.options.add(new Option(
						eval('lens_default_i'+ i +'_name'),
						eval('lens_default_i'+ i +'_name')));
			
			if(String('lens_default_i'+ i) == lens_selected)
			{
				selectedIndex = i;
			}
		}
	}
	
	var user_index = parseInt(lens_default_totalnumbers, 10);
	for (var i = 0; i < parseInt(lens_user_totalnumbers, 10); i++)
	{
		if (eval('lens_user_i'+ i +'_name') != '')
		{
			chooseSelect.options.add(new Option(
						eval('lens_user_i'+ i +'_name'),
						eval('lens_user_i'+ i +'_name')));
			deleteSelect.options.add(new Option(
						eval('lens_user_i'+ i +'_name'),
						eval('lens_user_i'+ i +'_name')));
			
			if(String('lens_user_i'+ i) == lens_selected)
			{
				selectedIndex = user_index;
			}
			user_index++;
		}
	}

	chooseSelect.selectedIndex = selectedIndex;
	deleteSelect.selectedIndex = 0;
}

function checkLenProfile()
{
	var currentLens = eval(lens_selected + '_name');

	$("#choose_lens_profile_select").change(function() {
		selectedLens = $("#choose_lens_profile_select option:selected").text();

		if (currentLens != selectedLens)
	{
		$("#warning").show();
		$("#choose_lens_profile_input").val(translator("reboot"));
	}
		else
	{
		$("#warning").hide();
		$("#choose_lens_profile_input").val(translator("save"));
	}
	});
}

function rebootSystem()
{
	$.ajax({
		type: "POST",
		cache: false,
		url: "/cgi-bin/admin/setparam.cgi",
		data: "system_reset=1"
	});
	
	showNotification(capability_bootuptime);
}

function chooseLenProfile()
{
	var currentLens = eval(lens_selected + '_name');
	var selectedLens = $("#choose_lens_profile_select option:selected").text();
	
	if (currentLens != selectedLens)
	{
		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/update_lens.cgi?choose_lens=" + selectedLens, true);
		XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
		XMLHttpRequestObject.onreadystatechange = function() {
			if(XMLHttpRequestObject.readyState == 4
					&& XMLHttpRequestObject.status == 200)
			{
				rebootSystem();
			}
		}
		XMLHttpRequestObject.send(null);
	}
}

function uploadLenResponse() {
	var ret = $('#ret_page').contents().find('p').html();
	
	if(ret == null)
	{
		ret = "upload_fail";
	}
	
	alert(translator(ret));
	window.location.reload();
}

function uploadLenProfile()
{
	var max_profiles = parseInt(lens_user_totalnumbers, 10);

	var callback = function () {
		uploadLenResponse();
		$('#frame').unbind('load', callback);
	};
	$('#ret_page').bind('load', callback);

	var form = document.upload_lens_profile_form;
	//var re = /(\.xml)$/i;

	if ((form.upload_lens_profile_input.value == ""))
			//|| (!re.test(form.upload_lens_profile_input.value)))
	{
		alert(translator("no_config_file_specified"));
		return;
	}

	if (iUserNum >= max_profiles)
	{
		alert(translator("max_no_of_lens_configurations_is_reached"));
		return;
	}

	form.submit();
}

function deleteLenProfile()
{
	var ret = confirm(translator("delete_this_lens_configuration"));

	if (ret == true)
	{
		var currentLens = eval(lens_selected + '_name');
		var deleteLens = $("#delete_lens_profile_select option:selected").text();
		
		if ( currentLens == deleteLens )
		{
			alert(translator("not_allow_to_delete_the_current_lens_configuration_file"));
			return;
		}

		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/update_lens.cgi?delete_lens=" + deleteLens, true);
		XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
		XMLHttpRequestObject.onreadystatechange = function() {
			if (XMLHttpRequestObject.readyState == 4
					&& XMLHttpRequestObject.status == 200)
			{
				window.location.reload();
			}
		}
		XMLHttpRequestObject.send(null);
	}
}

function lensSelectTest()
{
	var objSelect = document.getElementById("choose_lens_profile_select");
	console.log(objSelect.selectedIndex + " " + $("#choose_lens_profile_select option:selected").text());
}

