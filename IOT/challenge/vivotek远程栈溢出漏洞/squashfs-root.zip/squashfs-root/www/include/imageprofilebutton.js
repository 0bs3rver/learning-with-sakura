var giCH_Curr = 0;
var giTab_Curr = 0;

function loadCurrentSetting()
{	
	loadlanguage();
	//parent.document.getElementById("profiletab").height = document.body.scrollHeight;
	document.getElementById("content").style.visibility = "visible";

	giCH_Curr = Number(getCookie("channelsource"));
	$("#imagetab_outline", window.parent.document).css("display", "block");
	tabsUI(0);
}

function changeProfile(idx)
{
	if (giTab_Curr == parseInt(idx, 10))
	{
		return;
	}

	giTab_Curr = parseInt(idx, 10);

	setCookie("imageprofileindex",idx);
	$("#imagetab_outline", window.parent.document).css("display", "block");

	// reload profile content 
	$("#imagepage", window.parent.document).attr("src", "");
	$("#imagepage", window.parent.document).remove();
	$("#imagetab_outline", window.parent.document).append("<iframe src='/setup/media/image.html?ch="+ giCH_Curr +"' id='imagepage' width='100%' height='100px' scrolling=yes frameborder=0></iframe>");

	// reload view page
	$("#viewpage", window.parent.document).attr("src", "");
	$("#viewpage", window.parent.document).remove();
	$("#profiletab", window.parent.document).before("<iframe id='viewpage' src='/setup/media/viewpage.html?ch="+ giCH_Curr +"&image' id='viewpage' width='100%' height='100px' scrolling='auto' frameborder=0></iframe>");


	// non-IE with jpeg view, we should change the image quality selection to default setting "good"
	if (true != bIsWinMSIE)
	{
		getIframeDocumentById("resizebutton").getElementById("imagequality").selectedIndex = 2; 
	}
}
