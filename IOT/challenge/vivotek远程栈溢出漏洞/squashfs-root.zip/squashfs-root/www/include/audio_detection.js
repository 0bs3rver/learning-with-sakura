
var g_viewportWidth;
var g_viewportHeight;

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&audioin", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("audio_detection");
	//document.title="Audio Ddetection";
	loadlanguage();

	//morse code: "audio"
	konami(function(){
		$("#debug").toggle();
	}, [65, 85, 68, 73, 79]);
	
	//initial value
	g_viewportWidth = $(window.top).width();
	g_viewportHeight = $(window.top).height();

	top.document.body.onresize = function()
	{
		g_viewportWidth = $(window.top).width();
		g_viewportHeight = $(window.top).height();

		if(top.$('#TB_iframeContent').length)
		{
			configureProfileButton(1);
		}
	}; 
}

function receivedone() 
{
	if ("1" == audioin_c0_mute)
	{
		$("#warningBlk").show();
		$("#enable_c0_audiodetect + input").attr("disabled", true);
	}

    initAudioVolumeSlider();
	document.getElementById("content").style.visibility = "visible";
}

function submitform()
{
    form = document.forms[0];
    
	if(checkvalue())
	{
		return -1;	
	}
	else
	{
        form.audioin_c0_alarm_level.value = $("#audioVolumeBlock").slider("value");
		form.submit();
	}
}

function SetVolumeNotify(codectype)
{
    // +-------------------------------------------------------+
    // |               Interval       SampleCount              |
    // | AAC     :      200              500                   |
    // | GSM-AMR :      100               10                   |
    // | G.711   :      200              200                   |
    // +-------------------------------------------------------+
    
    switch(codectype) 
    {
        case 'aac4':
            iInterval  = 500;
            iSampleCnt = 500;
            break;
        case 'gamr':
            iInterval  = 500;
            iSampleCnt = 10;
            break;
        case 'g711':
            iInterval  = 500;
            iSampleCnt = 200;
            break;

        default:
            iSampleCnt = 50;
			break;
    }
}

var g_Alarm_level = audioin_c0_alarm_level;

function initAudioVolumeSlider()
{
    $("#audioVolumeBlock").slider({
        orientation: "vertical",
        min: 0,
        max: 100,
        value: audioin_c0_alarm_level,
        animate: true,
        slide: function(event, ui) {
            Log("Set volume = %s", ui.value);
            $("#alarmLevel").val(ui.value);
            
			if (bIsWinMSIE || bIsFireFox || bIsChrome)
            {
                var tmpAlarmArray = [];
                for (var i = 0; i <= 60; i += 1) tmpAlarmArray.push([i, ui.value]);
                var tmpCan = frames[1].canvasHandle.getData();
                tmpCan[0].data = tmpAlarmArray;
                frames[1].canvasHandle.setData(tmpCan);
                frames[1].canvasHandle.draw();
            }
        }
    });
    
    $("#audioVolumeBlock.ui-widget-content").css("background", "#EF2929 url(/pic/audioLevelV.png) repeat-y 0 0")
                                            .css("border", "1px solid #545454")
                                            .css("-moz-border-radius", "0px");

    $(".ui-slider-handle").css("height", "7px")
	                      .css("cursor", "pointer")
	                      .before('<div class="ui-slider-range ui-widget-header" style="_font-size:1px; width:100%; height: 100%; background: #eee;)"/>');

	$(".ui-slider-range").css("MozBorderRadius", 0);
    
    $("#alarmLevel").val(audioin_c0_alarm_level);
}

function configureProfileButton(param)
{
	var popwindowWidth = 650;
	if (g_viewportWidth < (popwindowWidth-30)) 
	{
		popwindowWidth = g_viewportWidth*0.5+30;	
	}
	var popwindowHeight = g_viewportHeight*0.9;

	if (param == 0) 
	{
		var thick_box_param = "TB_iframe=true&width="+popwindowWidth+"&height="+popwindowHeight+"&modal=true&TB_iniframe=true&inlineID=placeholder";
		top.$('#TB_window').css("width", null);
		top.$('#TB_window').css("margin-top", -(popwindowHeight/2));
		top.$('#TB_window').css("margin-left", -(popwindowWidth/2));

		$("#audiodetectionProfile").attr("alt", "audio_detection_profile.html?" + thick_box_param);

		includeClear();
	}
	else
	{
		top.$('#TB_iframeContent').css("width", popwindowWidth+"px");
		top.$('#TB_iframeContent').css("height", popwindowHeight+"px");
		top.$('#TB_window').css("width", null);
		top.$('#TB_window').css("margin-top", -(popwindowHeight/2));
		top.$('#TB_window').css("margin-left", -(popwindowWidth/2));
	}
}

function includeClear(targetFile)
{
        var includeList = document.getElementsByTagName("script");
        var iLastIndex = includeList.length;
        var bClearAll = (targetFile)? false : true;

        for (iLastIndex; iLastIndex >= 0; iLastIndex--)
        {
                if (includeList[iLastIndex]
                    && includeList[iLastIndex].getAttribute("src") != null
                    && ((bClearAll)?bClearAll:(includeList[iLastIndex].getAttribute("src").indexOf(targetFile) != -1)))
                {
                        includeList[iLastIndex].parentNode.removeChild(includeList[iLastIndex]);
                }
        }
}

