function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&syslog", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("logs");
	loadlanguage();
}
function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	else
		document.forms[0].submit();
}

function receivedone()
{
	updateRemoteLog();
	if (syslog_setparamlevel == "0")
	{
		$("#setparameter").css("display", "none");
	}
	document.getElementById("content").style.visibility = "visible";
}

function updateRemoteLog()
{
	if (syslog_enableremotelog == 1)
	{
		$("#log_server_setting").show(); 
	}
	else
	{
		$("#log_server_setting").hide(); 
	} 
}
function updateRemoteLogcheck(inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		$("#log_server_setting").slideDown("slow");
	}
	else
	{
		$("#log_server_setting").slideUp("slow");
	}
}
