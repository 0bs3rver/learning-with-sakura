function loadCurrentSetting() 
{

	if ("1" == audioin_c0_alarm_enable && "0" == audioin_c0_mute)
	{
		parent.$("#ajax-loader").show(); 
		loadlanguage();	

		if (bIsWinMSIE) 
		{
			IEComet("/cgi-bin/admin/volalarm.cgi?ua=iesux&interval=300", audioCallbackFn);
		}
		else
		{
			AjaxComet("/cgi-bin/admin/volalarm.cgi?interval=300");
		}
	}

}

var options = {
    series: {
        lines: { show: true },
        points: { show: false}
    },
    xaxis: {
        ticks: [],
        min: 0,
        max: 60 
    },
    yaxis: {
        ticks: 10,
        min: 0,
        max: 100
    },
    grid: {
        backgroundColor: { colors: ["#fff", "#eee"] }
    },
    legend: {
        show: true
    }
};

var volArray = [], alarmArray = [];
for (var i = 0; i <= 60; i += 1) volArray.push([i, 0]);
for (var i = 0; i <= 60; i += 1) alarmArray.push([i, parent.g_Alarm_level]);

var canvasHandle;
//setTimeout(function(){canvasHandle = parent.$.plot(parent.$("#placeholder"), [{label: "&nbsp;Alarm Level", data: alarmArray, color: "#ff9c9c"}, {label: "&nbsp;Volume", data: volArray}], options);},100);
canvasHandle = parent.$.plot(parent.$("#placeholder"), [{label: "&nbsp;Alarm Level", data: alarmArray, color: "#ff9c9c"}, {label: "&nbsp;Volume", data: volArray}], options);

var iCounter = 0;

function IEComet(url, callback) 
{
	transferDoc = new ActiveXObject("htmlfile");
	transferDoc.open();
	transferDoc.write( "<html><div><iframe src=\"" + url + "\"></iframe></div><\/html>");
	transferDoc.close();
	transferDoc.parentWindow.callback = callback;
	setInterval( function () {}, 10000); // this eliminates the DOM usage limit inside the iframe 
}

function AjaxComet(url) 
{
	var request = $.get(url);
	var pos = 0;
	//request._onreadystatechange = request.onreadystatechange; // save original handler
	request.onreadystatechange = function () {
		//request._onreadystatechange();                        // execute original handler
		if (request.readyState === 3) {
			var text = request.responseText; 
			//console.log("pos: "+ pos + "," + text.substring(pos));
			audioCallbackFn(text.substring(pos));
			pos = text.length;
		}
	};
}

function callback(data) 
{
	return audioCallbackFn(data);
}

function audioCallbackFn(maxVol) 
{
	parent.$("#ajax-loader").hide(); 
	//console.log(maxVol);
	if (maxVol)
	{
		parent.$("div.ui-slider-range").css("height", 100-maxVol + "%").css("width", "100%");

		//if(iCounter++ % 5 == 0)
		{
			var tmpVolArray = volArray;
			tmpVolArray.pop();
			for (var i = 0; i < tmpVolArray.length; i += 1)
			{
				tmpVolArray[i][0] = i+1;
			}
			tmpVolArray.unshift([0, maxVol]);
			//volArray.unshift([0, maxVol]);

			var tmpCan = canvasHandle.getData();
			tmpCan[1].data = tmpVolArray;
			canvasHandle.setData(tmpCan);
			canvasHandle.draw();
		}
	}
	else
	{
		parent.$("div.ui-slider-range").css("width", "100%");
	}
}

