var DstTimer=0;
var DStTimerID=null;
var system_datetemp=0;
var system_timetemp=0;
function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info&system_daylight&system_timezoneindex&system_updateinterval&system_ntp&system_datetime&system_ledoff&system_hostname&system_date&system_time", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	document.title=translator("general_settings");
	
	if (g_mode == "0")
	{
		$("#adv_system").css("display","none");
	}
	
	loadlanguage();	
	starttimer();
	
	//work not well in IE6, remove temporary
	//$('#system_datetemp').datepicker({dateFormat: "yy/mm/dd", showOn: "both", buttonImage: "http://ui.jquery.com/repository/demos_templates/images/calendar.gif", buttonImageOnly: true, changeFirstDay: false });	

}
function receivedone()
{	
	var form = document.forms[0];
	
	if(system_updateinterval!=0)
	{
		document.forms[0].method[3].checked = true;
		$("#autoChild").show();
	}
	
	document.getElementById("content").style.visibility = "visible";
	
	SendXMLHttprequestHandler();
	
	system_datetemp = system_date;
	system_timetemp = system_time;
	form.system_datetemp.value = system_datetemp;
	form.system_timetemp.value = system_timetemp;
	if(system_daylight_enable == "0") 
	{//SlideToggle(document.getElementById("dstStartEndBox"),"Close","nonSlide");
		$("#dstStartEndBox").css("display","none");
	}
}

function loadvaluedone()
{
	var hideArray = new Array();
	var netForm = document.forms[0];
	var timemethod = getCheckedValue(netForm.method);
/*			
	if (timemethod == "keep")
	{	
		hideArray.push("syncChild");
		hideArray.push("manuChild");
		hideArray.push("autoChild");
	}
	else if (timemethod == "sync")
	{
		hideArray.push("manuChild");
		hideArray.push("autoChild");
	}
	else if (timemethod == "manu")
	{
		hideArray.push("syncChild");
		hideArray.push("autoChild");
	}
	else //auto
	{
		hideArray.push("syncChild");
		hideArray.push("manuChild");
	}
	hideBlocks(hideArray,"nonSlide");*/
	
	$("dt.parent input").click(function(){
		$(this).parent().next("dt.child").slideDown("slow").siblings("dt.child:visible").slideUp("slow");
	});
	
	$("#keepParent input").click(function(){
		$("dt.child").slideUp("slow");
	});
	
	updateDaylightBox(document.getElementById("timezonelist"));

}

var timerID = null;
var timerRunning = false;
function display(){
  var form = document.system;
  var PCdate = new Date();
  var CurrentTime = "";
  var CurrentDate = "";

  if (PCdate.getHours() < 10) {
    CurrentTime = CurrentTime + "0";
  }
  CurrentTime = CurrentTime + PCdate.getHours() + ":";

  if (PCdate.getMinutes() < 10) {
    CurrentTime = CurrentTime + "0";
  }
  CurrentTime = CurrentTime + PCdate.getMinutes() + ":";

  if (PCdate.getSeconds() < 10) {
    CurrentTime = CurrentTime + "0";
  }
  CurrentTime = CurrentTime + PCdate.getSeconds();

  form.pctime.value = CurrentTime;

  CurrentDate = CurrentDate + (PCdate.getFullYear()) + "/";

  if ((PCdate.getMonth()+1) < 10) {
    CurrentDate = CurrentDate + "0";
  }
  CurrentDate = CurrentDate + (PCdate.getMonth()+1) + "/";

  if (PCdate.getDate() < 10) {
    CurrentDate = CurrentDate + "0";
  }
  CurrentDate = CurrentDate + PCdate.getDate();

  form.pcdate.value = CurrentDate;

  timerID = setTimeout("display()",1000);
  timerRunning = true;
}

function stoptimer() {
  if(timerRunning) {
    clearTimeout(timerID);
  }
  timerRunning = false;
}

function starttimer() {
  stoptimer();
  display();
}

function submitform(save_btn)
{
	var form = document.forms[0];

	if(!form.method[2].checked)
	{
		form.system_datetemp.value = "2009/02/09";
		form.system_timetemp.value = "11:03:45";
	}

	if(checkvalue())
	{
		return -1;
	}
	else
	{
	  if(form.method[0].checked)	// keep
	  {
		form.system_date.value = "keep";
		form.system_time.value = "keep";
		form.system_datetemp.value = "keep";
		form.system_timetemp.value = "keep";
		form.system_updateinterval.options[form.system_updateinterval.selectedIndex].value=0;
		//form.system_updateinterval.value=system_updateinterval;
	  }
	  else if (form.method[1].checked)  // sync with PC
	  {
		RemoveDomDateAndTime();
		SetDateTime(form.pcdate.value, form.pctime.value);
		//form.system_date.value = form.pcdate.value;
		//form.system_time.value = form.pctime.value;
		form.system_updateinterval.options[form.system_updateinterval.selectedIndex].value=0;
	  }
	  else if(form.method[2].checked)	// manual
	  {
		SetDateTime(form.system_datetemp.value, form.system_timetemp.value);
		RemoveDomDateAndTime();
		form.system_updateinterval.options[form.system_updateinterval.selectedIndex].value=0;
	  }
	  else if(form.method[3].checked)	// auto
	  {
		form.system_date.value = "keep";
		form.system_time.value = "auto";
		form.system_datetemp.value = "keep";
		form.system_timetemp.value = "auto";
	  }
	  
	  if (form.system_datetime.value == "")
	  {
		  var sysDateTimeId = document.getElementById("system_datetime");
			var SysDateTimeParent = sysDateTimeId.parentNode;
			
			SysDateTimeParent.removeChild(sysDateTimeId);
	  }

	  form.submit();
	  save_btn.disabled = true;
	  //setTimeout("location.reload();", 5000);

	}
}

function SendXMLHttprequestHandler()
{
	if (window.XMLHttpRequest)
	{
		XMLHttpRequestObject = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{
		XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	if (window.ActiveXObject)
		XMLHttpRequestObject.onreadystatechange = DisplayDST;

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_daylight_auto", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	
	if (window.XMLHttpRequest)
		DisplayDST();
	
	DstTimer++;
	DstTimerID = setTimeout("SendXMLHttprequestHandler();", 2000);
	
	if (DstTimer > 4)
	{
		clearTimeout(DstTimerID);
		DstTimer = 0;
		
		return;
	}
}

function DisplayDST()
{
	var form = document.forms[0];
	
	if (XMLHttpRequestObject.readyState == 4 && XMLHttpRequestObject.status == 200)
	{
		eval(XMLHttpRequestObject.responseText);

		form.system_daylight_auto_begintime.value = system_daylight_auto_begintime;
		form.system_daylight_auto_endtime.value = system_daylight_auto_endtime;
	}
	
}

function SwitchDSTSetting(inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	
	ShowAutoDaylightTime(inputName.value);
}

function ShowAutoDaylightTime(inputValue)
{
	if (inputValue == "1")
	{
		//SlideToggle(document.getElementById("dstStartEndBox"),"Open","Slide");
		$("#dstStartEndBox").slideDown("slow");
		
	}
	else if (inputValue == "0")
	{
		//SlideToggle(document.getElementById("dstStartEndBox"),"close","Slide");
		$("#dstStartEndBox").slideUp("slow");
	}
}

function SetDaylightTimeDisplay()
{
	var form = document.forms[0];
	
	form.system_daylight_auto_begintime.value=system_daylight_auto_begintime;
	form.system_daylight_auto_endtime.value=system_daylight_auto_endtime;
}

function RemoveDomDateAndTime()
{
	var sysDateId = document.getElementById("system_date");
	var SysDateParent = sysDateId.parentNode;
	var sysTimeId = document.getElementById("system_time");
	var SysTimeParent = sysTimeId.parentNode;
	
	SysDateParent.removeChild(sysDateId);
	SysTimeParent.removeChild(sysTimeId);	
}

function SetDateTime(date, time)
{
	var form = document.forms[0];
	
	var year = date.substring(0, 4);
	var month = date.substring(5, 7);
	var day = date.substring(8, 10);
	var hour = time.substring(0, 2);
	var minute = time.substring(3, 5);
	var sec = time.substring(6, 8);
		
	form.system_datetime.value=month+day+hour+minute+year+"."+sec;
}


function updateDaylightBox(object)
{
	if (system_daylight_timezones.indexOf(','+object.options[object.selectedIndex].value) == -1) 
	{
		$("#daylightBox").slideUp("slow");
		if (document.getElementById("enable_dst").checked) 
		{
			$("#dstStartEndBox").slideUp("slow");
		}
	}
	else
	{
		$("#daylightBox").slideDown("slow");
		if(document.getElementById("enable_dst").checked) $("#dstStartEndBox").slideDown("slow");
	}
}
