function loadCurrentSetting()
{
	paramIndex1 = location.search.toString().indexOf("&");
//	alert(location.search.toString().slice(paramIndex1 + 1));
	if (paramIndex1 != -1)
	{
		eval(location.search.toString().slice(1, paramIndex1));
//		alert("index=" + index);
		eval(location.search.toString().slice(paramIndex1 + 1));
//		alert("folder=" + folder);
	}
	else
	{
		eval(location.search.toString().slice(1));
//		page = 1;
	}
	if (typeof(folder) != "undefined")
	{
		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/fileoptr.cgi?_j=file_list&_s=" + folder + "&_l=cf"+index, true);
		document.getElementById("foldername").value = folder;
		document.title = translator("file_list") + " of " + folder;
	}
	else
	{
		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/fileoptr.cgi?_j=file_list&_l=cf"+index, true);
		document.getElementById("prebutton").style.display = "none";
		document.title = translator("file_list");
	}
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	loadlanguage();
	document.getElementById("cf").value = "cf" + index;
	document.getElementById("returnpage").value = "setup/cf.html?index=" + index;
}

function loadvaluedone()
{
	document.getElementById("filelist").innerHTML = "<br>" + file_list;
}

function deleteall()
{
		if (typeof(folder) != "undefined")
		{
		var cgiList = "/cgi-bin/admin/fileoptr.cgi?_s=" + folder + "&_a=cf" + index + "&_m=setup/cf.html?index=" + index;
		}
		else
		{
		var cgiList = "/cgi-bin/admin/fileoptr.cgi?_a=cf" + index + "&_m=setup/cf.html?index=" + index;
	}
	location.replace(cgiList);
}

function PreviousPage()
{
	if (typeof(cfpath) == "undefined")
		var url = "cf.html?index=" + index;
	else
		var url = "cf.html?index=" + index + "&cfpath='" + cfpath + "'";
	window.open(url, "_self", "width=800, height=600, scrollbars=yes, status=yes");
}
