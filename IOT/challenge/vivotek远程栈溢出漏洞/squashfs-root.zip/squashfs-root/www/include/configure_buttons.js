var WinLessPluginCtrl;

var giCH_Curr = 0;
var g_FunctionID = 0;

var BUTTON_GENERAL_ACTION_NUMBER = 21;
var BUTTON_NORMAL_FUNCTION_NUMBER = 19;

var BUTTON_DEFAULT_NUMBER = 12;
var BUTTON_FUNCTION_NUMBER = BUTTON_DEFAULT_NUMBER;

var MANUAL_DEFAULT_NUMBER = 4;
var MANUAL_FUNCTION_NUMBER = MANUAL_DEFAULT_NUMBER;

var DO_DEFAULT_NUMBER = 4;
var DO_FUNCTION_NUMBER = DO_DEFAULT_NUMBER;

var FOCUS_DEFAULT_NUMBER = 1;
var FOCUS_FUNCTION_NUMBER = FOCUS_DEFAULT_NUMBER;

var PRESET_DEFAULT_NUMBER = 20;
var PRESET_FUNCTION_NUMBER = PRESET_DEFAULT_NUMBER;
var EPRESET_FUNCTION_NUMBER = PRESET_DEFAULT_NUMBER;

/*var FuncArr = ["toogle_play_pause", "stop_streaming", "snapshot", "fullscreen", "start_stop_recording",
               "pan", "patrol", "stop", "zoom_in", "zoom_out", "digital_output_on_off", "digital_output_on_off", "digital_output_on_off", "digital_output_on_off",
			   "manual_trigger_on_off", "manual_trigger_on_off", "manual_trigger_on_off"];*/
var FuncArr = new Array(BUTTON_NORMAL_FUNCTION_NUMBER);

var FuncNameOnButton; 


$.Installer =
{
plugins:
    {
mime: "application/x-installermgt"
, description: "Installer Management v1.0.0.47"
, xpi:
        { "Installer Management v1.0.0.47" : "npVivotekInstallerMgt.xpi"
        }
    }
};

String.format = function() 
{ 
    if( arguments.length == 0 ) 
    { 
        return null; 
    } 
    var str = arguments[0]; 
    for(var i=1;i<arguments.length;i++) 
{
        var re = new RegExp('\\{' + (i-1) + '\\}','gm'); 
        str = str.replace(re, arguments[i]); 
    } 
    return str; 
}

// used to set joystick's action map within plugin
function _actionAssign(BtnIdx,ActionIdx,erase)
{
    if(erase)
    {
      var RegJoystickActBtnMap1 = WinLessPluginCtrl.GetSettings(parseInt(5));
      var ActBtnMapArr = RegJoystickActBtnMap1.split('');
  
      for (ActIndex in ActBtnMapArr)
      {
            // only judge BtnIdx to reset map
        if (parseInt(ActBtnMapArr[ActIndex], 16) == BtnIdx)
        {     
          WinLessPluginCtrl.SetJoystickButtonAction(BtnIdx, parseInt(ActIndex), erase);
          break;
        }
      }   
        FuncNameOnButton[BtnIdx] = -1;
        $('#Btn' + BtnIdx).text('');
    }
    else
    {
        WinLessPluginCtrl.SetJoystickButtonAction(BtnIdx, parseInt(ActionIdx), erase);
        FuncNameOnButton[BtnIdx] = ActionIdx;
        // Get function name by button id
        var funcName = GetFuncNameByFunctionID(ActionIdx);
        $('#Btn' + BtnIdx).text(funcName);
    }
}
      
function checkActionDuplication(actionName)
{
    for (var i=1; i <= BUTTON_FUNCTION_NUMBER; i++)
    {
        if (document.getElementById("Btn"+i).innerHTML == actionName)
        {
            return i;
        }
    }

    return 0;
}

function actionAssign(erase)
{
    var BtnIdx = document.getElementById('JoystickBtnList').selectedIndex + 1;
    var actionIdx = document.getElementById('action').selectedIndex;
    var g_FunctionID = actionIdx;
    
    var funcHiddenManualNumber	= MANUAL_DEFAULT_NUMBER - 3; // It always has 3 items now.
    var funcHiddenDONumber	= DO_DEFAULT_NUMBER - DO_FUNCTION_NUMBER;
    var funcHiddenAutofocus	= (!FOCUS_FUNCTION_NUMBER);
    var funcReserveNumber 	= funcHiddenManualNumber + funcHiddenDONumber + funcHiddenAutofocus;
    var funcBeforePresetBtn	= BUTTON_NORMAL_FUNCTION_NUMBER - funcReserveNumber;
    var funcBeforeAutofocus	= funcBeforePresetBtn - 1 + funcHiddenAutofocus;
    var funcBeforeManualBtn	= funcBeforeAutofocus - MANUAL_DEFAULT_NUMBER + funcHiddenManualNumber;
    var funcBeforeDigitaloutput	= funcBeforeManualBtn - DO_DEFAULT_NUMBER + funcHiddenDONumber;

    if (g_FunctionID >= funcBeforePresetBtn)
    {
	g_FunctionID = BUTTON_GENERAL_ACTION_NUMBER 
			+ (g_FunctionID - funcBeforePresetBtn);
    }
    else if (g_FunctionID >= funcBeforeAutofocus)
    {
	g_FunctionID = (BUTTON_NORMAL_FUNCTION_NUMBER - FOCUS_DEFAULT_NUMBER) 
			+ (g_FunctionID - funcBeforeAutofocus);
    }
    else if (g_FunctionID >= funcBeforeManualBtn)
    {
	g_FunctionID = (BUTTON_NORMAL_FUNCTION_NUMBER - FOCUS_DEFAULT_NUMBER - MANUAL_DEFAULT_NUMBER) 
			+ (g_FunctionID - funcBeforeManualBtn);
    }
    else if (g_FunctionID >= funcBeforeDigitaloutput)
    {
	g_FunctionID = (BUTTON_NORMAL_FUNCTION_NUMBER - FOCUS_DEFAULT_NUMBER - MANUAL_DEFAULT_NUMBER - DO_DEFAULT_NUMBER) 
			+ (g_FunctionID - funcBeforeDigitaloutput);
    }

    var actionName = GetFuncNameByFunctionID(g_FunctionID);   
    if (erase)
    {
        _actionAssign(BtnIdx, g_FunctionID, erase);
        return;
    }
    else
    {
        var AssignMsg =String.format(translator("click_ok_to_assign_action_to_button"), translator("ok"), actionName, translator("botton") + ' ' + BtnIdx); 
        // 1. check action duplication
        var DupBtnIdx = checkActionDuplication(actionName);
        if (DupBtnIdx != 0)
        {
            var WarnMsgFmt = translator("warning") + '!\n' + translator("this_action_is_already_assigned_to") ;
            var WarnMsg = String.format(WarnMsgFmt, actionName, translator("botton") + ' ' + DupBtnIdx);
            if (!confirm(WarnMsg+"\n"+AssignMsg))
                return ;
        }
        // 2. check button duplication
        var OldactionName = FuncNameOnButton[BtnIdx]; 
        if (OldactionName != -1)
        {
            var WarnMsgFmt = translator("warning") + '!\n' + translator("this_button_is_already_assigned_to") ;
            var WarnMsg = String.format(WarnMsgFmt.replace('(%s)','"{0}"'), $('#Btn' + BtnIdx).text());
            if(!confirm(WarnMsg+"\n"+AssignMsg))
                return;
        }
        _actionAssign(DupBtnIdx, g_FunctionID, true); // delete old button for this action
        _actionAssign(BtnIdx, g_FunctionID, false);
    }
}


function loadCurrentSetting()
{
    XMLHttpRequestObject.open("GET", "/cgi-bin/viewer/getparam.cgi?capability_ndo&capability_npreset&capability_camctrl_c"+giCH_Curr+"_zoommodule", false);
    XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
    XMLHttpRequestObject.send(null);

    //Install FF plugin
    if (navigator.userAgent.match("Firefox") != null)
    {
        var xpi = undefined;

        var version = function(name)
        {
            var pos = name.search(" v");
            if(pos == -1)
            {
                return [];
            }
            return name.substr(pos + 2).split(".");
        };

        var compare = function(cur, src)
        {
            var cur = version(cur);
            var src = version(src);
            for(var i = 0; i < 4; ++i)
            {
                if(src[i] > cur[i])
                {
                    return true;
                }
                else if(src[i] < cur[i])
                {
                    return false;
                }
            }
        };

        var plugin = $.Installer.plugins;
        var type = window.navigator.mimeTypes[plugin.mime];

        if(!type || compare(type.description, plugin.description))
        {
            xpi = plugin.xpi;
        }

        if(xpi)
        {
            window.InstallTrigger.install(xpi);
        }
    }
    else if (bIsChrome)
    {
        var crx = undefined;
        var plugin = $.Installer.plugins;
        var type = window.navigator.mimeTypes[plugin.mime];

        if(!type || compare(type.description, plugin.description))
        {
            // update chrome extension : crx
            $("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="../npVivotekInstallerMgt.crx"></iframe>');
        }																					   //
    }

    if (bIsFireFox || bIsChrome)
    {
        $('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"><param name="InstallerPath" value="http://'+window.location.hostname+'/VVTK_Plugin_Installer.exe" /></object>');
    }
    $('#InstallerArea').hide();

    loadlanguage();

    WinLessPluginCtrl = document.getElementById("WinLessPluginCtrl0");
    
/*     try
    {
      WinLessPluginCtrl = window.opener.document.getElementById("WinLessPluginCtrl0");
    }
    catch(err)
    {
      if(WinLessPluginCtrl == null)
      {
        WinLessPluginCtrl = document.getElementById("WinLessPluginCtrl0");
      }
    } */

    var nJoystickNum = WinLessPluginCtrl.GetAttachedJoystickNumber();

    if (nJoystickNum == 0)
    {
        document.getElementById("assignButton").disabled = true;
        document.getElementById("eraseButton").disabled = true;
        document.getElementById("ActionListTable").style.display="None"; 
        return;
    }

    WinLessPluginCtrl.CurrentJoystickIndex = window.opener.document.getElementById("WinLessPluginCtrl0").CurrentJoystickIndex;
    var numOfJoyStickButton = BUTTON_FUNCTION_NUMBER = WinLessPluginCtrl.GetJoystickButtonNumber(WinLessPluginCtrl.CurrentJoystickIndex);

    FuncNameOnButton = new Array(numOfJoyStickButton);
    for(i=1; i<=numOfJoyStickButton; ++i)
    {
        FuncNameOnButton[i] = -1;
    }

    var tableStr = "<tr align=center>";
    for(i=1; i<=numOfJoyStickButton; ++i)
    {
        tableStr += "<tr align=center>";
        tableStr += "<td>"+i+"</td>";
        tableStr += "<td id= Btn"+i+"></td>";
        tableStr += "</tr>";

        var buttonItem = new Option(i, i);
        document.getElementById("JoystickBtnList").options.add(buttonItem);
    }

    $('#ActionListTable').append(tableStr);

    GenBtnFunctionList();

    var RegJoystickActBtnMap = WinLessPluginCtrl.GetSettings(parseInt(5));
    if (RegJoystickActBtnMap)
    {
        SetButtonListByRegistryMap(RegJoystickActBtnMap);
    }
	
}

function GenBtnFunctionList()
{
	var iContFuncIndex = 0;
	iContFuncIndex = GenNormalFunctionArray (iContFuncIndex);
	iContFuncIndex = GenDigitalOutputOptionByCapability (iContFuncIndex);
	iContFuncIndex = GenManualTriggerOptionByCapability (iContFuncIndex);
	iContFuncIndex = GenAutofocusOptionByCapability (iContFuncIndex);
	iContFuncIndex = GenPresetOptionByCapability (iContFuncIndex);
}

function GenNormalFunctionArray(iCont)
{
	var iCurrent = iCont;
	var iNormalFunctionAmount = document.getElementById("action").options.length;
	for (var i = 0; i < iNormalFunctionAmount; i++)
	{
		FuncArr[i + iCont] = document.getElementById("normol_"+i).text;
		iCurrent ++;
	}
	
	return iCurrent;
}

function GenManualTriggerOptionByCapability(iCont)
{
	var iCurrent = iCont;
	var iManualOptionAmount = 3;

	for(var i = 0; i < MANUAL_FUNCTION_NUMBER; ++i)
	{
		if (i < iManualOptionAmount)
		{
			$(document.getElementById("action")).addOption("manual_trigger_on_off_"+(i + 1), translator("manual_trigger_on_off")+" "+(i + 1), false);
		}
		FuncArr[i + iCont] = translator("manual_trigger_on_off")+" "+(i + 1);
		iCurrent ++;
	}
	
	return iCurrent;
}

function GenDigitalOutputOptionByCapability(iCont)
{
	var iCurrent = iCont;
	var iDigitalOutputAmount = getParamValueByName("capability_ndo");
	DO_FUNCTION_NUMBER = (iDigitalOutputAmount != "")? iDigitalOutputAmount : DO_FUNCTION_NUMBER;

	for(var i = 0; i < DO_DEFAULT_NUMBER; ++i)
	{
		if (i < DO_FUNCTION_NUMBER)
		{
			$(document.getElementById("action")).addOption("digital_output_on_off_"+(i + 1), translator("digital_output_on_off")+" "+(i +1), false);
		}
		FuncArr[i + iCont] = translator("digital_output_on_off")+" "+(i + 1);
		iCurrent ++;
	}

	return iCurrent;
}

function GenAutofocusOptionByCapability(iCont)
{
	var iCurrent = iCont;

	FOCUS_FUNCTION_NUMBER = (getParamValueByName("capability_camctrl_c"+giCH_Curr+"_zoommodule") == 1)? 1 : 0;

	if (FOCUS_FUNCTION_NUMBER != 0)
	{
		$(document.getElementById("action")).addOption("auto_focus", translator("auto_focus"), false);
		FuncArr[iCont] = translator("auto_focus");
		iCurrent ++;
	}

	return iCurrent;
}

function GenPresetOptionByCapability(iCont)
{
	var iCurrent = iCont;
	var iPresetAmount = getParamValueByName("capability_npreset");
	PRESET_FUNCTION_NUMBER = (iPresetAmount != "")? iPresetAmount : PRESET_FUNCTION_NUMBER;
 
	for(var i=0; i < PRESET_FUNCTION_NUMBER; ++i)
	{
		$(document.getElementById("action")).addOption("preset_"+(i + 1), translator("preset")+" "+(i + 1), false);
		iCurrent ++;
	}
	return iCurrent;
}

function SetButtonListByRegistryMap(ActBtnMap)
{
    // make a string to array
    var ActBtnMapArr = ActBtnMap.split('');

    // restore function mapping on button list
    for (ActIndex in ActBtnMapArr)
    {
        if (ActBtnMapArr[ActIndex] != 0)
        {
	    var ascii_a_hex = 0x61; ascii_0_hex = 0x30; int_10_hex = 0x0a;
	    var BtnReg = parseInt(ActBtnMapArr[ActIndex].charCodeAt(0).toString(16), 16);
            var BtnIdx = (BtnReg >= ascii_a_hex) ? (BtnReg - ascii_a_hex + int_10_hex) : (BtnReg - ascii_0_hex); 
            var FuncName = GetFuncNameByFunctionID(parseInt(ActIndex));
            $('#Btn' + BtnIdx).text(FuncName);
            FuncNameOnButton[BtnIdx] = parseInt(ActIndex);
        }
    }
}

function GetFuncNameByFunctionID(funid)
{
    var funcName = '';
    var iTotalFunction = document.getElementById("action").options.length;
    var iPresetBase = iTotalFunction - PRESET_FUNCTION_NUMBER;

    // consist of function name
    if (funid < BUTTON_NORMAL_FUNCTION_NUMBER)
    {
        funcName = FuncArr[funid];
    }
    else if (funid >= BUTTON_GENERAL_ACTION_NUMBER && funid <= (BUTTON_GENERAL_ACTION_NUMBER + PRESET_FUNCTION_NUMBER))
    {
	funid = iPresetBase + (funid - BUTTON_GENERAL_ACTION_NUMBER);
        funcName += document.getElementById("action").options[funid].text;
    }
    else
    {
        var streamId = Math.round((funid - BUTTON_NORMAL_FUNCTION_NUMBER - PRESET_FUNCTION_NUMBER) / EPRESET_FUNCTION_NUMBER) + 1;
        var epresetd = ((funid - BUTTON_NORMAL_FUNCTION_NUMBER - PRESET_FUNCTION_NUMBER + 1) % EPRESET_FUNCTION_NUMBER);
        funcName += ("Stream_" + streamId + "_EPreset_" + epresetd);
    }

    return funcName;
}

function ActivXplugin()
{
    var PluginObj = '';

    if (bIsWinMSIE)
    {
        PluginObj += '<object Id="WinLessPluginCtrl0" CLASSID="CLSID:64865E5A-E8D7-44C1-89E1-99A84F6E56D0" width=10 height=10>';
    }
    else
    {
        PluginObj += '<div style="position:absolute; width:10; height:10; overflow:hidden;">';
        PluginObj += '<object class=CropZone ID="WinLessPluginCtrl0"  type="application/x-streamctrl" width=10 height=10>';
    }
    PluginObj += '<param name="ViewStream" value="0">';
    PluginObj += '<param name="HttpPort" value=80>';
    PluginObj += '<param name="ControlPort" value=554>';
    PluginObj += '<param name="Stretch" value=1>';
    PluginObj += '<param name="EnableJoystick" value=1>';  // Enable joystick
    PluginObj += '<param name="JoystickBtnTriggerStyle" value=1>'; //<!-- style 0: release,  style 1: press release
    PluginObj += '<param name="JoystickSpeedLvs" value=5>';
    PluginObj += '<param name="JoystickPanSpeedLvs" value=64>';
    PluginObj += '<param name="JoystickTiltSpeedLvs" value=5>';
    PluginObj += '<param name="JoystickZoomSpeedLvs" value=5>';
    PluginObj += '<param name="JoystickSpeedPercentage" value=50>';
    PluginObj += '</object>';

    if (!bIsWinMSIE)
        PluginObj += '</div>';

    //document.write(PluginObj);
	document.getElementById('JoyStickPluginContainer').innerHTML = PluginObj;
	
	if(bIsWinMSIE)
       $("#JoyStickPluginContainer").hide();
}
