//declare the global variable
var g_availableUrl;

//chage state
function statechange(retc, str, url)
{
	var checkObj		= $("#tabs-1 :button")[0];
	var onlineObj		= $("#tabs-1 :button")[1];
	var offlineObj	= $("#tabs-1 :button")[2];
	var str_innerHTML;
        var str_innerURL;	
	if (null != str.match("onlycheck"))
	{
		if (0 == retc)
		{
			$("#status").css("color", "black").css("font-weight", "normal");
			if ($("#expresslink_url_id").attr("value") == "")
			{
				str_innerHTML = translator("expresslink_hint_input_hostname");
			}
			else
			{
				str_innerHTML = translator("expresslink_hint_host_name_valid2");
			} 
			document.getElementById("statuswarning").innerHTML = "";
		}
		else if (1 == retc)
		{
			$("#statuswarning").css("color", "black").css("font-weight", "normal");
			str_innerHTML = '<p class=note>' + translator("expresslink_msg_assignment_is_in_used");
			 document.getElementById("statuswarning").innerHTML = str_innerHTML;
		}
		else
		{
			$("#statuswarning").css("color", "black").css("font-weight", "normal");
                        str_innerHTML = '<p class=note>' + translator("expresslink_msg_enable_expresslink_fail"); + '</p>'
                         document.getElementById("statuswarning").innerHTML = str_innerHTML;
		
		}
	}
	else if (null != str.match("checkonline"))
	{
		if (0 == retc)
		{
			$("#status").css("font-weight", "normal");
			str_innerHTML = translator("expresslink_hint_host_name_valid1");
			document.getElementById("statuswarning").innerHTML = "";
		}
		else if (1 == retc)
		{
			$("#statuswarning").css("color", "black").css("font-weight", "normal");
                        str_innerHTML = '<p class=note>' + translator("expresslink_msg_assignment_is_in_used");
                         document.getElementById("statuswarning").innerHTML = str_innerHTML;
		}
		else
		{
			$("#statuswarning").css("color", "black").css("font-weight", "normal");
                        str_innerHTML = '<p class=note>' + translator("expresslink_msg_enable_expresslink_fail"); + '</p>'
                         document.getElementById("statuswarning").innerHTML = str_innerHTML;

		}
	}
	else if (null != str.match("onlyoffline"))
	{
	        //var tt=$('<a/>').attr('href',url).attr('target','_blank').text(url);	
		var tt;
		tt = '<a href=' + url + '>' + url + '</a>'
		str_innerHTML = translator("expresslink_msg_can_connect_to_camera1") + " " + tt;
		 document.getElementById("statuswarning").innerHTML = str_innerHTML;
	}
	else
	{
		str_innerHTML = '<p class=note>' + translator("expresslink_msg_network_enviroment_not_support") + '</p>'
		document.getElementById("statuswarning").innerHTML = str_innerHTML;
	}
}
//onload
function loadstate()
{
	var keyword;
	var urlStart;
	var urlEnd;
	var expresslinkUrl;
	var url;
	var str;
	var str_innerHTML;
	/*
	$("#status").css("color", "black").css("font-weight", "bold");
	str_innerHTML = '<img src="/pic/ajax-loader.gif" />';
	str_innerHTML += '<span title=\"symbol\">initialize</span>';
	document.getElementById("statuswarning").innerHTML = str_innerHTML;
	*/	
	url = "/cgi-bin/admin/getparam.cgi?expresslink_state&expresslink_url&expresslink_enable";
	$.ajaxSetup({ cache: false});
	$.get(url, function(data, textStatus){
								this;
								if ("success" == textStatus)
								{
									str = data;
									eval(data);
									eval("hostname=expresslink_url");
									//if(hostname[0] == null)
									if ( hostname == "" )
									{
                    /*
										str_innerHTML = '<p class=help>' + translator("express_link_help") + '</p>';
										document.getElementById("statuswarning").innerHTML = str_innerHTML;
                    */
									}
									else
									{
										//statechange(0, data, "http://" + hostname + ".2bthere.net");
										if (null != str.match("onlyoffline"))
										{
											var tt;
                									tt = '<a href=' + 'http://' + hostname + '.2bthere.net' + '>' + 'http://' + hostname + '.2bthere.net' + '</a>'
											str_innerHTML = translator("expresslink_msg_can_connect_to_camera1") + " " + tt;
                 									document.getElementById("statuswarning").innerHTML = str_innerHTML;
										}
										else if (null != str.match("badnetwork"))
										{
											str_innerHTML = '<p class=note>' + translator("expresslink_msg_network_enviroment_not_support") + '</p>'
                									document.getElementById("statuswarning").innerHTML = str_innerHTML;
										}
									}
								}
								else
								{
									console.log("error code: " + textStatus);
								}
								
						 });
	
}

var g_bIsHelpShown = 0;
function help()
{
        if (g_bIsHelpShown == 0)
        {
        var str_innerHTML; 
 
	str_innerHTML = '<p class=help>' + translator("express_link_help") + '</p>';
        document.getElementById("statuswarning").innerHTML = str_innerHTML;
          
          g_bIsHelpShown = 1;
        }
}
//check
function check()
{
	var url;
	var str;
	var str_innerHTML;
	
	//check the text value
	str = $("input[name='expresslink_url']").attr("value");
	if (0 == str.length)
	{
		alert(translator("expresslink_msg_domain_name_can_not_be_empty_warning"));
		return -1;
	}
	
	$("#status").css("color", "black").css("font-weight", "bold");
	str_innerHTML = '<img   src="/pic/ajax-loader.gif" />';
	str_innerHTML += translator("wait");
	document.getElementById("statuswarning").innerHTML = str_innerHTML;
	
	
	
	url = "/cgi-bin/admin/expresslink.cgi?action=check&";
        data = "enable=" + $("input[name='expresslink_enable']").attr("value") + "&hostname="
        +  $("input[name='expresslink_url']").attr("value");
        $.ajaxSetup({ cache: false});
        $.get(url, data, function(data, textStatus){
                     this;
                     if ("success" == textStatus)
                     {
                        str = data;
                        if (null != str.match("retc=0"))
                        {
				$("#status").css("color", "black").css("color", "black").css("font-weight", "normal");
                		 //str_innerHTML = translator("expresslink_msg_network_enviroment_not_support");
                		str_innerHTML = '<p class=note>' + translator("expresslink_msg_network_enviroment_not_support") + '</p>'
                		document.getElementById("statuswarning").innerHTML = str_innerHTML;
                        }
			else if (null != str.match("retc=1"))
                        {
                                //offline succesfully
				document.getElementById("statuswarning").innerHTML = "";
			
			}
			else if (null != str.match("retc=2"))
			{
				tt = '<a href=' + 'http://' + $("input[name='expresslink_url']").attr("value") + '.2bthere.net' + '>' + 'http://' + $("input[name='expresslink_url']").attr("value") + '.2bthere.net' + '</a>'
				str_innerHTML = translator("expresslink_msg_can_connect_to_camera1") + " " + tt;
                 		document.getElementById("statuswarning").innerHTML = str_innerHTML;
			}
			else if (null != str.match("retc=3"))
			{
				$("#statuswarning").css("color", "black").css("font-weight", "normal");
                        	str_innerHTML = '<p class=note>' + translator("expresslink_msg_assignment_is_in_used");
                         	document.getElementById("statuswarning").innerHTML = str_innerHTML;
			}
			else if (null != str.match("retc=4"))
			{
			 	$("#statuswarning").css("color", "black").css("font-weight", "normal");
                        	str_innerHTML = '<p class=note>' + translator("expresslink_msg_enable_expresslink_fail"); + '</p>'
                         	document.getElementById("statuswarning").innerHTML = str_innerHTML;
			}
			else
                        {
                            console.log("error code: " + textStatus);
                        }
		     }
        });

		
	//--------------
}
