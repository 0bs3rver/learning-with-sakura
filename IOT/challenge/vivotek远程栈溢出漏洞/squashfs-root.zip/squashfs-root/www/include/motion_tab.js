//MD_WINDOW_SIZE and MD_Window_selected is for non-IE(WIN) only
var MD_WINDOW_SIZE = parseInt(capability_nmotion,10);
var MD_Window_selected = -1; // serve as the first element or selected element to show the MD page default window_name, sensistivity, percentage value.
var stack_bottomright = {"dir1": "up", "dir2": "left", "firstpos1": 15, "firstpos2": 15};
var g_ChannelDivider = 1;
var channelsource = 0;
var streamsource = FullviewStreamIndex();
var profileIndex = 0;
var WinLessPluginCtrl;

//For 10000x10000 coordinate
var giCurDomainSizeW = 9999;
var giCurDomainSizeH = 9999;

//For Polygon
var POLYGON_POINTS_NUM = 4;
var MD_Window_MOUSEON = -1;
var defaultSensitivity = 80;
var defaultObjsize = 15;
var mouseX = 0;
var mouseY = 0;
var canvasDiv;
var gr;
var col;
var pen;
var points = [];
var winPoints = new Array(MD_WINDOW_SIZE);
var pxPoly = new Array(MD_WINDOW_SIZE);
var checkPoly = new Array(MD_WINDOW_SIZE);
var WinIndex = 0;
var CreatingWin = -1;
var ie=false;

var giProfileIdx;
var gstrProfile;
var TmpProfileEnable;

if(document.all)
	ie=true;

for (i = 0; i < MD_WINDOW_SIZE; i++)
{
	checkPoly[i] = '1';
}

for (i = 0; i < MD_WINDOW_SIZE; i++)
{
	winPoints[i] = [];
}

//Plugin constant.
var PLUGIN_ID = "WinLessPluginCtrl";
var PLUGIN_NAME = "VVTK_Plugin_Installer.exe";
var PLUGIN_VER = "1,0,0,114";
var CLASS_ID = "64865E5A-E8D7-44C1-89E1-99A84F6E56D0";
var FFTYPE = "application/x-streamctrl";
var FF_VER = "1.0.0.88";
var VNDPWRAPPER_VER = "1,0,0,69";
var FF_XPI_DESCRIPTION = "Installer Management v" + FF_VER;
var PLUGIN_LANG="EN";
var BUFFERTIME=getCookie("streamingbuffertime");
var HTTP_METHOD = document.URL.split(":");
		
//Global variable.
var gImgW = 320;
var gImgH = 240;
var gImg = null;
var gImgUrl;
var gTimer;
var gQuality = 3;
var bUpdateImg = false;
var gInitMDWdone = false;
var giNonIERefreshImgPeriod = 100; // 15fps = 66ms, MIN is 1000.
var guiROIRefreshImgTime_ms = 2000;
var bRotate = false;

var Width, Height;

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};

// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

eval("VideoSize=videoin_c" + channelsource + "_s" + streamsource + "_resolution");
eval("codectype=videoin_c" + channelsource + "_s" + streamsource + "_codectype");
if(codectype=="mpeg4" || codectype=="h264")
    eval("AccessName=network_rtsp_s" + streamsource + "_accessname");
else
    eval("AccessName=network_http_s" + streamsource + "_accessname");

function setProfileIndex()
{
	giProfileIdx = Number(getCookie("motionprofileindex"));
	
	if (giProfileIdx === 0)
	{
		gstrProfile = "";
	}
	else
	{
		gstrProfile = "_profile_i" + profileIndex;
	}
}

function checkRotate()
{
	if( eval("capability_videoin_c" + channelsource + "_rotation") == 1 )
	{
		if( eval("videoin_c" + channelsource + "_rotate") == 90 || eval("videoin_c" + channelsource + "_rotate") == 270 )
		{
			bRotate = true;
		}
	}
}

function loadCurrentSetting()
{
	if (!bIsWinMSIE)
	{
		include("/include/DataStream.js");
	}

	setProfileIndex();

	$('#InstallerArea').hide();

	document.title=translator("motion_detection");
	loadlanguage();
	
	
	eval("VideoSize=videoin_c"+ channelsource + "_s" + streamsource + "_resolution");
    eval("codectype=videoin_c"+ channelsource + "_s" + streamsource + "_codectype");
	
	Width = VideoSize.split("x")[0];
	Height = VideoSize.split("x")[1];
	
	//Auto width/height ratio according to full streaming size
	gImgH = gImgW * Height / Width;
	
	checkRotate();
	
	if(bRotate)
	{
		eval(swap('gImgH', 'gImgW'));
	}	
	
    //if (bIsWinMSIE)
	{
		$("#StreamContainer").height(gImgH).width(gImgW).css("position","relative");
		$("#showimageBlock").height(gImgH).width(gImgW).css("overflow","auto");
		$("#imagecoverBlock").height(gImgH).width(gImgW);
		
		//initial MD Window by jQueryUI, enable window point draggable
		$('.PWP_style').live("mouseover", function() {     
			$(this).draggable({          
            	cursor: 'move',  
            	handle: 'div',
            	containment: '#imagecoverBlock',
            	drag: function(e, ui)
            	{
                	var self = $(this).data("draggable");
                	var pointX, pointY;
                	//$("#log-top").html(self.position.top.toFixed() + "px");
					//$("#log-left").html(self.position.left.toFixed() + "px");
					WinIndex = parseInt($(this).parent().attr("id").charAt($(this).parent().attr("id").length -1));
					var PointIndex = parseInt($(this).parent().children().index($(this)));
					if (eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_enable') == '1')
					{
						points = winPoints[WinIndex];
						pointX = parseInt(self.position.left.toFixed());
						pointY = parseInt(self.position.top.toFixed());

						pointX = (pointX>=(gImgW/2)) ? (pointX+6) : pointX;
						pointY = (pointY>=(gImgH/2)) ? (pointY+6) : pointY;

						//prevent to draw a dup point
						bDupPoint = false;
						for(var i = 0; i < points.length; i++)
						{
							if( (points[i].x == pointX) && (points[i].y == pointY) )
							{
								bDupPoint = true;
								break;
							}
						}
						
						if(!bDupPoint)
						{
							points[PointIndex - 5].x = pointX;
							points[PointIndex - 5].y = pointY;
						}
						
						$("#PolyMask" + MD_Window_selected).children().css("opacity","0.01");
						$("#PolyMask" + WinIndex).empty();
						$("#PolyMask" + WinIndex).parent().children().slice(0,POLYGON_POINTS_NUM).remove();
						drawPolygon(WinIndex);
					}
					else
					{
						points[PointIndex - 1].x = parseInt(self.position.left.toFixed());
						points[PointIndex - 1].y = parseInt(self.position.top.toFixed());
					}
            	},
            	stop: function()
            	{
                	var self = $(this).data("draggable");
            	}
        	});   
		}); 
		
		receivedone();
		loadvalue();
		loadvaluedone();
	
		if (bIsWinMSIE)
		{
			WinLessPluginCtrl = document.getElementById(PLUGIN_ID);
			setTimeout("addPluginEvent(WinLessPluginCtrl, 'MDAlert', updatePercentageBar)", 1);	
			setTimeout("WinLessPluginCtrl.PlayMute = true", 1); 
		}

		if (bIsWinMSIE)
		{
			$("#imagecoverBlock").css("background-color","#FFFFFF");
			$("#imagecoverBlock").css("opacity","0.01");
		}
		else
		{
			$("#imagecoverBlock").css("background-color","rgba(255,255,255,0.01)");
		}	  
    }
	
	if(initalFlag == "0" && document.getElementById("logo") !== null) /*for Configuration Page round corner effect*/
	{
		updateLogoInfo();
		resizeLogo();
		
		Nifty("div#outter-wrapper","small","nonShadow");		
		Nifty("div#case","normal","nonShadow");
		document.getElementsByTagName("b")[5].style.position = "relative";
		
		initalFlag = "1";
	}			
}

function receivedone()
{
    //if (bIsWinMSIE)
    {
        $("#slider_sensitivity").slider({
            min: 1,
            max: 100,
            animate: true,
            range: "min",
            slide: function(event, ui)
			{
                $("#MD_sensitivity_value").text(ui.value);
            },
            change: function(event, ui)
			{
				$("#MD_sensitivity_value").text(ui.value);
				eval('motion_c' + channelsource + gstrProfile + '_win_sensitivity = ui.value');
            }							
		});
		
		// In the past the valid range of motion_c0_win_sensitivity is 0~100, now the valid range is changed to 1~100.
		// So we need replace the value "0" with "1" for compatibility.
		if (eval('motion_c' + channelsource + gstrProfile + '_win_sensitivity') == "0")
		{
			eval('motion_c' + channelsource + gstrProfile + '_win_sensitivity = 1');
		}
		
		$('#slider_sensitivity').slider('option', 'value', eval('motion_c' + channelsource + gstrProfile + '_win_sensitivity'));
		$("#MD_sensitivity_value").text($("#slider_sensitivity").slider('value'));

		$("#slider_percentage0").slider({
			min: 1,
			max: 100,
			animate: true,
			range: "min",
			slide: function(event, ui)
			{
				$("#MD_percentage_value0").text(ui.value);
				drawPercentageWin(ui.value);
			},
			change: function(event, ui)
			{
				if(MD_Window_selected != -1)
					eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize = ui.value');
			}							
		});
		$("#MD_percentage_value0").text($("#slider_percentage0").slider('value'));  
		
		$("#slider_percentage1").slider({
			min: 1,
			max: 100,
			animate: true,
			range: "min",
			slide: function(event, ui)
			{
				$("#MD_percentage_value1").text(ui.value);
				drawPercentageWin(ui.value);
			},
			change: function(event, ui)
			{
				if(MD_Window_selected != -1)
					eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize = ui.value');
			}							
		});
		$("#MD_percentage_value1").text($("#slider_percentage1").slider('value'));  
		
		$("#slider_percentage2").slider({
			min: 1,
			max: 100,
			animate: true,
			range: "min",
			slide: function(event, ui)
			{
				$("#MD_percentage_value2").text(ui.value);
				drawPercentageWin(ui.value);
			},
			change: function(event, ui)
			{
				if(MD_Window_selected != -1)
					eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize = ui.value');
			}							
		});
		$("#MD_percentage_value2").text($("#slider_percentage2").slider('value'));  
		
		$("#slider_percentage3").slider({
			min: 1,
			max: 100,
			animate: true,
			range: "min",
			slide: function(event, ui)
			{
				$("#MD_percentage_value3").text(ui.value);
				drawPercentageWin(ui.value);
			},
			change: function(event, ui)
			{
				if(MD_Window_selected != -1)
					eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize = ui.value');
			}							
		});
		$("#MD_percentage_value3").text($("#slider_percentage3").slider('value'));  
		
		$("#slider_percentage4").slider({
			min: 1,
			max: 100,
			animate: true,
			range: "min",
			slide: function(event, ui)
			{
				$("#MD_percentage_value4").text(ui.value);
				drawPercentageWin(ui.value);
			},
			change: function(event, ui)
			{
				if(MD_Window_selected != -1)
					eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize = ui.value');
			}							
		});
		$("#MD_percentage_value4").text($("#slider_percentage4").slider('value'));  			
	}
	
	$( "#PercentageWin" ).draggable({          
		cursor: 'move',
		handle: 'div',
		containment: '#imagecoverBlock',
		drag: function(e, ui)
		{
			var self = $(this).data("draggable");
		},
		stop: function()
		{
			var self = $(this).data("draggable");
			if(self.position.top < 0){
				self.position.top = 0;
			}
			if(self.position.left < 0){
				self.position.left = 0;			
			}
		}
	});
	
}

function loadvaluedone()
{
	var iIndex;
	var strPlugin = "";
	
	if (giProfileIdx == 1)
	{
		$("#enableProfileContent").show();
		
		if ("0" == eval("capability_daynight_c" + channelsource + "_support"))
		{
			document.getElementById("profileNightMode").style.display = "none";
		}
		
		TmpProfileEnable = parseInt(eval("motion_c" + channelsource + gstrProfile + "_enable"));
		if(TmpProfileEnable === 0)
		{
			updateProfileCheck(false);
		}
		else
		{
			updateProfileCheck(true);
		}
	}
	
	//if (bIsWinMSIE)
	{
        //For Polygon
    	canvasDiv=document.getElementById("imagecoverBlock");
		gr=new jsGraphics(canvasDiv);
		canvasDiv.onmousemove = getMouseXY;

        //Initial Motion Detction Window, loading size and position of all MD_Window
        for (iIndex = 0; iIndex < MD_WINDOW_SIZE; iIndex++)
        {	
        	$("input[name=md_window_name" + iIndex + "]:eq(0)").keyup(function(){
					var iNameIndex = parseInt($(this).attr("name").charAt($(this).attr("name").length -1));
					eval("motion_c" + channelsource + gstrProfile + "_win_i" + iNameIndex + "_name = $(this).val()");
			});
						
			if (eval('motion_c' + channelsource + gstrProfile + '_win_i' + iIndex + '_enable') == '1')
        	{
				$("#MD_window_name" + iIndex).css("display","block");
				$("input[name=md_window_name" + iIndex + "]:eq(0)").val(eval('motion_c' + channelsource + gstrProfile + '_win_i' + iIndex + '_name'));
			
				var polygonwin = eval('motion_c' + channelsource + gstrProfile + '_win_i'+iIndex+'_polygonstd').split(',');
				
				/* Apply the conventional coordinate system in Rossini venc, we simply swap x and y
				for (j = 0; j < POLYGON_POINTS_NUM; j++)
				{
					if(bRotate)
					{
						var tmpSwap;
						tmpSwap = polygonwin[j*2];
						polygonwin[j*2] = polygonwin[j*2+1];
						polygonwin[j*2+1] = tmpSwap;						
					}
				}
				*/
				
				for (j = 0; j < POLYGON_POINTS_NUM; j++)
				{
					polygonwin[j*2] = Math.ceil(parseInt(polygonwin[j*2], 10) * gImgW / giCurDomainSizeW);
					polygonwin[j*2+1] = Math.ceil(parseInt(polygonwin[j*2+1], 10) * gImgH / giCurDomainSizeH);
				}

				WinIndex = iIndex;
				for (j = 0; j < POLYGON_POINTS_NUM; j++)
				{	
					mouseX = parseInt(polygonwin[j*2]);
					mouseY = parseInt(polygonwin[j*2+1]);

					drawPoint();
				}
			}
        }

        //set the 1st exist MDW to be focused
        MD_Window_MOUSEON = getMDWCandidate();
		gInitMDWdone = true;
        if(MD_Window_MOUSEON != -1)		//MD Window exists
		{
			setFocusWin(this);
		}
		
		if (getFirstFreeWindow() < 0)
		{
			$("#btnNewMD").attr("disabled", true);
		}
		else
		{
			$("#btnNewMD").attr("disabled", false);
		}
    }

	//Create streaming
	if (bIsWinMSIE)
	{
		strPlugin = "<object class=CropZone id=\"" + PLUGIN_ID + "\" width=" + gImgW + " height=" + gImgH;
		strPlugin += " standby=\"Loading plug-in...\" classid=CLSID:" + CLASS_ID;
		strPlugin += " codebase=\"/" + PLUGIN_NAME + "#version=" + PLUGIN_VER + "\">";
		if ("https" == HTTP_METHOD[0])
		{
			strPlugin += "<param name=\"HttpPort\" VALUE=\"" +  network_https_port + "\" >";
		}
		else
		{
			strPlugin += "<param name=\"HttpPort\" VALUE=\"" +  network_http_port + "\" >";
		}
		strPlugin += '<param name="ReadSettingByParam " VALUE="1">';
		strPlugin += '<param name="MediaType" VALUE="2">';
		strPlugin += '<param name="DisplayErrorMsg" value="true">';
		strPlugin += '<param name="IgnoreCaption" value="true">';
		strPlugin += '<param name="IgnoreBorder" value="true">';
		strPlugin += "<param name=\"ViewStream\" VALUE=\"" + streamsource + "\">";
		strPlugin += "<param name=\"ViewChannel\" VALUE=\"" + (channelsource+1) + "\">";
		strPlugin += '<param name="VSize" VALUE="CMS">';
	 	strPlugin += '<param name="Stretch" VALUE="true">';
		strPlugin += '<param NAME="StretchFullScreen" VALUE="false">';
		strPlugin += '<param NAME="PluginCtrlID" VALUE="">';
		strPlugin += "<PARAM NAME=\"Url\" VALUE=" + document.URL + ">";
		strPlugin += "<PARAM NAME=\"ControlPort\" VALUE="+network_rtsp_port+">";
		strPlugin += '<PARAM NAME="EnableJoystick" VALUE="false">';
		strPlugin += '<PARAM NAME="UpdateJoystickInterval" VALUE="100">';
		strPlugin += '<PARAM NAME="JoystickSpeedLvs" VALUE="5">';
		strPlugin += "<param name=\"Language\" VALUE=\"" + PLUGIN_LANG + "\">";
		strPlugin += '<param name="MP4Conversion" VALUE="true">';
		strPlugin += '<param name="EnableFullScreen" VALUE="false">';
		strPlugin += '<param name="AutoStartConnection" VALUE="true">';
		strPlugin += '<param name="ClickEventHandler" VALUE="0">';
		strPlugin += "<param name=\"StreamingBufferTime\" VALUE=\"" + BUFFERTIME + "\">";
		strPlugin += '<PARAM NAME="BeRightClickEventHandler" VALUE="false">';
		strPlugin += '<param name="ClientOptions" value="122">';
		strPlugin += '<param name="PlayMute" value="true">';
		strPlugin += '<param name="MicMute" value="true">';
		strPlugin += '<param name="BeAspectRatio" value="true">';
		strPlugin += '<param name="AspectRatioSection" value="0">';
		strPlugin += "</object>";

		$("#showimageBlock").append(strPlugin);
	}
	else
	{
		$("#snapshotstream").width(gImgW).height(gImgH).show();
		gImgUrl = "/cgi-bin/viewer/video.jpg?channel="+channelsource+"&streamid="+streamsource+"&resolution="+gImgW+"x"+gImgH;

		if (gImg === null)
		{
			gImg = new Image();
			gImg.onload = function()
			{
				$("#snapshotstream").attr("src", gImg.src);
				gTimer = setTimeout("updateImg()", giNonIERefreshImgPeriod);
			};

			gImg.onerror = function()
			{
				gROITimer = setTimeout("updateROIImg()", guiROIRefreshImgTime_ms);
			};
		}
		gTimer = setTimeout("updateImg()", 100);
	}

}

function getFirstFreeWindow()
{
    for (i = 0; i < MD_WINDOW_SIZE; i++) 
    {
        if (eval('motion_c' + channelsource + gstrProfile + '_win_i' + i + '_enable') == '0')
        {
            return i;
        }
    }	
    return -1;
}

function getMDWCandidate()
{
    for (i = 0; i < MD_WINDOW_SIZE; i++) 
    {
        if (eval('motion_c' + channelsource + gstrProfile + '_win_i' + i + '_enable') == '1')
        {
            return i;
        }
    }
    return -1;
}

function newMDWindow()
{
    var freeWindowIndex = getFirstFreeWindow();
    if(freeWindowIndex == -1) 
	{
		return -1;
	}
    else
    {	
		$("#MD_window_name" + freeWindowIndex).css("display","block");
		$("input[name=md_window_name" + freeWindowIndex + "]:eq(0)").val("Motion" + (freeWindowIndex+1));
		eval("motion_c" + channelsource + gstrProfile + "_win_i" + freeWindowIndex + "_name = \'Motion" + (freeWindowIndex+1) + "\'");
		
		WinIndex = CreatingWin = freeWindowIndex;
			
		MD_Window_MOUSEON = WinIndex;
		setFocusWin(this);
		canvasDiv.onclick=drawPoint;
    	
		// start to draw polygon
		checkPoly[WinIndex] = '0';
		
		//disable new button when creating window.
		$("#btnNewMD").attr("disabled", true);
		$("#case").css("cursor","crosshair");
		$("#imagecoverBlock").css("cursor","crosshair");
    }    
}

function checkMDWname()
{
	var enable, name;
	var title;
    for (var i = 0; i < MD_WINDOW_SIZE; i++) 
    {
        eval("enable = motion_c" + channelsource + gstrProfile + "_win_i" + i + "_enable");
		eval("name = motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_name");
		eval("sensitivity = motion_c" + channelsource + gstrProfile + "_win_sensitivity");
		eval("objsize = motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_objsize");

		if (enable == '1' && name === "")
		{
			alert(translator("please_insert_window_names_on_all_windows"));
			return -1;
		}

		//if ((enable == '0') && (name != ""))
		if (checkPoly[i] == '0')
		{
			alert(translator("please_draw_window_on_live_image"));
			return -1;
		}
		
		//check invalid chr
		title = $("input:[name=md_window_name" + i + "]").attr("title").split(",");
		checkStringSize($("input:[name=md_window_name" + i + "]")[0]);
		if(checkInString($("input:[name=md_window_name" + i + "]")[0]))
			return -1;
		if(title[2]=="empty")
			if(CheckEmptyString($("input:[name=md_window_name" + i + "]")[0]))
				return -1;	
		if(title[2]=="space")
		{
			if(checkInSpace($("input:[name=md_window_name" + i + "]")[0]))
				return -1;
		}
		else if (title[2]=="accessname")
		{
			if (checkAccessName($("input:[name=md_window_name" + i + "]")[0]))
				return -1;
		}
	}
	return 0;
}

function checkMDWobjSize()
{
	var objArea;
	var roiArea;
	var winIdx;
	
    for (winIdx = 0; winIdx < MD_WINDOW_SIZE; winIdx++) 
    {
		eval("enable = motion_c" + channelsource + gstrProfile + "_win_i" + winIdx + "_enable");
		eval("objsize = motion_c" + channelsource + gstrProfile + "_win_i"+ winIdx +"_objsize");
		
		if (enable == '1')
		{
			// sqrt(objArea/(W*H)) = percentage/100
			objArea = gImgW*gImgH*objsize*objsize/10000;
			roiArea = calculatePolyArea(pxPoly[winIdx]);

			if(objArea > roiArea)
			{
				alert(translator("the_item_size_cannot_be_larger_than_the_window_size_otherwise_the_motion_detection_cannot_be_triggered"));
				return -1;
			}
		}		
	}
	
	return 0;
}

function saveMDWindow()
{
    if(checkvalue())
    {
        return -1;
    }

	if(checkMDWname())
	{
		return -1;
	}
	
	if(checkMDWobjSize())
	{
		return -1;
	}	
	
	if ((giProfileIdx == 1) && ($("input[name=motion_c" + channelsource + gstrProfile + "_policy]:checked").val() == "schedule"))
	{
		if(CheckEmptyString( document.getElementById("profileScheduleBeginTime") ))
			return -1;
		if(CheckEmptyString( document.getElementById("profileScheduleEndTime") ))
			return -1;
	}

    var params = "";
	params += "motion_c" + channelsource + gstrProfile + "_win_sensitivity=" + eval("motion_c" + channelsource + gstrProfile + "_win_sensitivity")+"&";
    for (i = 0; i < MD_WINDOW_SIZE; i++) 
    {
        if (eval("motion_c" + channelsource + gstrProfile + "_win_i" + i + "_enable") == '1')
        {
        	params += 
        	"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_enable=" + eval("motion_c" + channelsource + gstrProfile + "_win_i" + i + "_enable")+"&"+
        	"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_name="+ encodeURIComponent(eval("motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_name"))+"&"+
       		"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_polygonstd="+ eval("motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_polygonstd")+"&"+
        	"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_objsize="+ eval("motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_objsize")+"&";
		}
		else
		{
			params += 
        	"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_enable=0&"+
        	"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_name=&"+
       		"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_polygonstd=&"+
       		"motion_c" + channelsource + gstrProfile + "_win_i"+ i +"_objsize="+ defaultObjsize +"&";
		}
    }

	if (giProfileIdx == 1)
	{
		/* ProfileMode setting */
		params += 
		"motion_c" + channelsource + gstrProfile + "_enable=" + TmpProfileEnable +"&"+
		"motion_c" + channelsource + gstrProfile + "_policy=" + $("input:radio:checked[name=motion_c" + channelsource + gstrProfile + "_policy]").val() +"&"+
		"motion_c" + channelsource + gstrProfile + "_begintime=" + $("input[name=motion_c" + channelsource + gstrProfile + "_begintime]").val() +"&"+
		"motion_c" + channelsource + gstrProfile + "_endtime=" + $("input[name=motion_c" + channelsource + gstrProfile + "_endtime]").val() +"&";
	}

    $.ajax({
		async: false,
        type: "POST",
        cache: false,
        url: "/cgi-bin/admin/setparam.cgi",
        data: params,
        success: function(){
			var avMDLangStr = translator("motion_detection");
			var avMLLangStr = translator("save_window_completed");
			parent.$.pnotify({
				pnotify_title: avMDLangStr,
				pnotify_text: avMLLangStr,
				pnotify_notice_icon: 'ui-vadp-icon ui-vadp-icon-signal',
				pnotify_opacity: 0.8,
				pnotify_addclass: "stack-bottomright",
				pnotify_history: false,
				pnotify_stack: stack_bottomright
			});
        },
        error: function(){
			var avMDLangStr = translator("motion_detection");
			var avMLLangStr = translator("save_window_failed");
			parent.$.pnotify({
				pnotify_title: avMDLangStr,
				pnotify_text: avMLLangStr,
				pnotify_type: 'error',
				pnotify_error_icon: 'ui-vadp-icon ui-vadp-icon-alert',
				pnotify_opacity: 0.8,
				pnotify_addclass: "stack-bottomright",
				pnotify_history: false,
				pnotify_stack: stack_bottomright
			});		
        }
    });
}

function updatePercentageBar(MDdata)
{
	if(MD_Window_selected == -1 || MD_Window_selected == CreatingWin || MDdata === "")
	{		
		return -1;
	}

	var MDarray = MDdata.split(',');
	
	if (MDarray.length < (parseInt(MD_Window_selected) + 1))
	{
		return -1;
	}
	
	var MDwin = MDarray[parseInt(MD_Window_selected)].split(':');
	var percentage = parseInt(MDwin[1]);
	var objectPercentage = eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize');
	
	$("#percentage").css("height", (100-parseInt(percentage))*0.7 + "px");
	
	if(percentage >= objectPercentage)
		$("#percentage_container").css("background", "#ff0000"); //red
	else
		$("#percentage_container").css("background", "#00ff00"); //green
}

function clearPercentageBar()
{
	$("#percentage").css("height", 70+"px");
	//setTimeout("clearPercentageBar()", 1000);
}

function switchChannel(selectedIndex, bFirstLoad)
{
    var iIndex;

	//$("#ChannelSelector").val(selectedIndex);
	channelsource = parseInt(selectedIndex/g_ChannelDivider);
	setCookie("channelsource", channelsource);

    eval("VideoSize=videoin_c"+ channelsource + "_s" + streamsource + "_resolution");
    eval("codectype=videoin_c"+ channelsource + "_s" + streamsource + "_codectype");

    if (codectype == "mjpeg")
        eval("AccessName=network_http_s" + streamsource + "_accessname");
    else //(codectype == "mpeg4") || (codectype == "h264")
        eval("AccessName=network_rtsp_s" + streamsource + "_accessname");

	if (bIsWinMSIE)
	{
		WinLessPluginCtrl = document.getElementById(PLUGIN_ID);
		if(!bFirstLoad)
		{
			removePluginEvent(WinLessPluginCtrl, "MDAlert", updatePercentageBar);
			document.getElementById(PLUGIN_ID).RtspStop();
			document.getElementById(PLUGIN_ID).Disconnect();
		}
	}

	$("#showimageBlock").height(gImgH).width(gImgW).css("overflow","auto");

	$('#imagecoverBlock').css('width', $("#StreamContainer").width() + "px");
	$('#imagecoverBlock').css('height', $("#StreamContainer").height() + "px");
	$("input[name='md_window_name']:eq(0)").val("");

    for (var i=0; i < capability_nvideoin; i++)
    {
        if ( i==channelsource )
        {
            $("#enable_c"+i).show();
            eval("enabled=motion_c"+i+"_enable");
            if (enabled == '1')
            {
                $("#enable_c"+i).attr("checked", true);
            }
            else
            {
                $("#enable_c"+i).attr("checked", false);
            }
        
        }
        else
        {
            $("#enable_c"+i).hide();

			if(!bFirstLoad)
			{
	            //Clear windows of other channels
    	        for(iIndex = 0; iIndex < MD_WINDOW_SIZE; iIndex++)
        	    {
					if (eval('motion_c' + i + gstrProfile + '_win_i' + iIndex + '_enable') == '1')
              		{
                		winPoints[iIndex] = [];
                		$("#PolyWin" + iIndex).empty();
                		$("#PolyWin" + iIndex).append("<DIV id=\"PolyMask" + iIndex + "\"></DIV>");
                		$("input[name=md_window_name" + iIndex + "]:eq(0)").val("");

                		$("#MD_window_name" + iIndex).css("display","none");
              		}
            	}
        	}
    	}
	}

	$.ajax({
		url: "/cgi-bin/admin/getparam.cgi?motion_c"+channelsource,
		async: false,
		cache: false,
		success: function (data)
		{
			eval(data);
			loadvaluedone();
		}
	});

	if (bIsWinMSIE)
	{
		WinLessPluginCtrl = document.getElementById(PLUGIN_ID);
		setTimeout("addPluginEvent(WinLessPluginCtrl, 'MDAlert', updatePercentageBar)", 1);	
		setTimeout("WinLessPluginCtrl.PlayMute = true", 1); 
	}
}

//For Polygon
//Determining Whether A Point Is Inside A Polygon
/*function pointInPolygon(p)
{
  j = POLYGON_POINTS_NUM - 1;
  polygonInside = false;

  for (i = 0; i < POLYGON_POINTS_NUM; i++)
  {
    	if (((winPoints[p][i].y < mouseY) && (winPoints[p][j].y >= mouseY)) || 
    		((winPoints[p][j].y < mouseY) && (winPoints[p][i].y >= mouseY)) )
    	{
      		if (winPoints[p][i].x + (mouseY - winPoints[p][i].y) / (winPoints[p][j].y - winPoints[p][i].y) * (winPoints[p][j].x - winPoints[p][i].x) < mouseX)
      		{
        		polygonInside = !polygonInside;
      		}
      	}
    	j = i;
  }
  return polygonInside;
}*/

//Get mouse position
function getMouseXY(e)
{
	if (ie) 
	{
		mouseX = event.clientX + document.body.parentElement.scrollLeft;
		mouseY = event.clientY + document.body.parentElement.scrollTop;
	} 
	else 
	{ 
		mouseX = e.pageX;
		mouseY = e.pageY;
	}
  
	if (mouseX < 0){mouseX = 0;}
	if (mouseY < 0){mouseY = 0;}

	mouseX = mouseX - parseInt($(canvasDiv).offset().left, 10);
	mouseY = mouseY - parseInt($(canvasDiv).offset().top, 10);
  
	return true;
}

function setPenColor(WinIndex)
{
	col=new jsColor("red");
	switch(WinIndex)
	{
		case 0:
			col=new jsColor("#00FFFF");
			break;
		case 1:
			col=new jsColor("#FFA851");
			break;
		case 2:
			col=new jsColor("#80FF80");
			break;
		case 3:
			col=new jsColor("#FFFF80");
			break;
		case 4:
			col=new jsColor("#626262");
			break;
		default:
			return false;
	}
		
	pen=new jsPen(col,2);
	
	return true;	
}

function focusWin(WinIndex)
{
	MD_Window_MOUSEON = WinIndex;
	setFocusWin(this);
		
	return;
}

function setFocusWin(obj, event)
{
	clearPercentageBar();

	if(event !== undefined)
	{
		event.stopPropagation();
	}
	
	$("#PolyMask" + MD_Window_selected).children().css("opacity","0.01");
	$("#PolyMask" + MD_Window_MOUSEON).children().css("opacity","0.2");
	MD_Window_selected = MD_Window_MOUSEON;
	
	//read the corresponding MDW value 
	$("#slider_sensitivity").slider("option", "value", eval('motion_c' + channelsource + gstrProfile + '_win_sensitivity'));
	$("#MD_sensitivity_value").text($("#slider_sensitivity").slider("value"));
	$("#slider_percentage"+MD_Window_selected).slider("option", "value", eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize'));
	$("#MD_percentage_value"+MD_Window_selected).text($("#slider_percentage"+MD_Window_selected).slider("value"));
	
	if(gInitMDWdone)
	{
		for (var i = 0; i < MD_WINDOW_SIZE; i++)
		{
			if( MD_Window_selected == i)
			{
				$("#MD_window_name"+i).slideDown("fast");
				$("#MD_percentage"+i).slideDown("fast");
			}
			else
			{
				$("#MD_window_name"+i).slideUp("fast");
				$("#MD_percentage"+i).slideUp("fast");
			}
		}
	}
	
	drawPercentageWin(0);	// Don't display percentage window when changing motion window
	
	return;
}
	
function drawPoint()
{
	// prevent clicking on same point as previous
	for(var i = 0; i < points.length; i++)
	{
		if( (mouseX == points[i].x) && (mouseY == points[i].y) )
		{
			return;
		}
	}

	gr.fillRectangle(new jsColor("green"),new jsPoint(mouseX-3,mouseY-3),6,6);
	points[points.length]=new jsPoint(mouseX,mouseY);
	if(points.length == POLYGON_POINTS_NUM)
	{
		$("#PolyMask" + MD_Window_selected).children().css("opacity","0.01");
		drawPolygon(WinIndex);
	}
}

function mouseOver(obj)
{
	$(obj).css("cursor","pointer");
	MD_Window_MOUSEON = parseInt($(obj).attr("id").charAt($(obj).attr("id").length -1));
}

function mouseOut(obj)
{
	MD_Window_MOUSEON = -1;
}
	
function drawPolygon(WinIndex)
{
  	var polygonwin;	
  	if(!setPenColor(WinIndex))
	    return;
	
	gr.drawPolygon(pen,points);
	col = new jsColor("#FFFFFF");
	gr.fillPolygon(col,points);
	
	$("#PolyMask" + WinIndex).children().css("opacity","0.4");
	$("#PolyMask" + WinIndex).bind("mouseover", function(){mouseOver(this);});
	$("#PolyMask" + WinIndex).bind("mouseout", function(){mouseOut(this);});
	$("#PolyMask" + WinIndex).bind("click", function(event){setFocusWin(this, event);});
	
	winPoints[WinIndex] = points;
	clearPreviousPoints();
	MD_Window_MOUSEON = WinIndex;
	setFocusWin(this);

	polygonwin = winPoints[WinIndex][0].x + "," + parseInt(winPoints[WinIndex][0].y) + "," +
			     winPoints[WinIndex][1].x + "," + parseInt(winPoints[WinIndex][1].y) + "," +
			     winPoints[WinIndex][2].x + "," + parseInt(winPoints[WinIndex][2].y) + "," +
			     winPoints[WinIndex][3].x + "," + parseInt(winPoints[WinIndex][3].y);

	// save polygon points on web pixel coordinate
	pxPoly[WinIndex] = polygonwin;

	polygonwin = polygonwin.split(',');
	for (j = 0; j < POLYGON_POINTS_NUM; j++)
	{
		polygonwin[j*2] = Math.floor(parseInt(polygonwin[j*2], 10) * giCurDomainSizeW / gImgW);
		polygonwin[j*2+1] = Math.floor(parseInt(polygonwin[j*2+1], 10) * giCurDomainSizeH / gImgH);
		
		/* Apply the conventional coordinate system in Rossini venc, we simply swap x and y
		if(bRotate)
		{
			var tmpSwap;
			tmpSwap = polygonwin[j*2];
			polygonwin[j*2] = polygonwin[j*2+1];
			polygonwin[j*2+1] = tmpSwap;
		}
		*/
	}
	
	// complete drawing polygon 
	checkPoly[WinIndex] = '1';	
	
    eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_enable = 1');
    eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_polygonstd = polygonwin');
	
	$("#case").css("cursor","default");
	$("#imagecoverBlock").css("cursor","default");
	canvasDiv.onclick="";
	CreatingWin = -1;
	
	//enable new button when has free window.
	if (getFirstFreeWindow() != -1)
	{
		$("#btnNewMD").attr("disabled", false);
	}
}

function clearWin(WinIndex)
{	
	// restore checkPoly[WinIndex] to initial value
	checkPoly[WinIndex] = '1';
	
	winPoints[WinIndex] = [];
	$("#PolyWin" + WinIndex).empty();
	$("#PolyWin" + WinIndex).append("<DIV id=\"PolyMask" + WinIndex + "\"></DIV>");
	$("input[name=md_window_name" + WinIndex + "]:eq(0)").val("");
	
	$("#MD_window_name" + WinIndex).css("display","none");
	$("#MD_percentage" + WinIndex).css("display","none");
	eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_enable = 0');
	eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_name = ""');
	eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_objsize =' + defaultObjsize);
	eval('motion_c' + channelsource + gstrProfile + '_win_i' + WinIndex + '_polygonstd = ""');
	
	clearPercentageBar();
	
	//clean selected window
	if(WinIndex == MD_Window_selected)
	{
  		MD_Window_selected = getMDWCandidate();
  		
  		if (MD_Window_selected != -1)
		{
			MD_Window_MOUSEON = MD_Window_selected;
			setFocusWin(this);
		}
		else
		{
			MD_Window_selected = -1;
			$("#MD_sensitivity_value").text(defaultSensitivity);
			$("#slider_sensitivity").slider("option", "value", defaultSensitivity);
			eval('motion_c' + channelsource + gstrProfile + '_win_sensitivity =' + defaultSensitivity);
		}
	}
	
	//clean creating window
	if(CreatingWin == WinIndex || CreatingWin == -1)
	{
		canvasDiv.onclick="";
		$("#case").css("cursor","default");
		$("#imagecoverBlock").css("cursor","default");
		clearPreviousPoints();
		$("#btnNewMD").attr("disabled", false);
	}
}

function clearPreviousPoints()
{
	points = [];
}

function updateImg()
{
	var da;

	da = new Date();
	gImg.src = ""+gImgUrl+"&quality="+gQuality+"&date="+da.getTime();
	
	if (!bIsWinMSIE)
	{
		var xmlhttp = new XMLHttpRequest();
		
		xmlhttp.onload = function(e)
		{
			var arraybuffer = xmlhttp.response;
			var ds = new DataStream(arraybuffer);
			var foundMotion = 0;
			
			ds.endianness = DataStream.BIG_ENDIAN;

			//ff d8
			var readbuffer0;
			var readbuffer1;
			readbuffer0 = ds.readUint8();
			readbuffer1 = ds.readUint8();

			for (var drawWin = 0; drawWin < MD_WINDOW_SIZE; drawWin++)
			{
				$("#RedPolyWin" + drawWin).empty();
			}
			clearPercentageBar();

			for (var index = 2; index < ds.byteLength; index++)
			{
				if (foundMotion == 1)
				{
					break;
				}
				readbuffer0 = ds.readUint8();
						
				//polygon
				if (readbuffer0 == 0x14)
				{
					readbuffer0 = ds.readUint8();
					readbuffer1 = ds.readUint8();
					index += 2;
					
					//check motion header or not
					if (Math.floor(readbuffer0 / 18) == readbuffer1 && readbuffer0 % 18 == 1)
					{
						foundMotion = 1;
							
						var numMotionWindow = readbuffer1;
						var alertFlag = new Array(numMotionWindow);
						var detectPercent = new Array(numMotionWindow);
						
						//read motion information
						for (var windowIndex = 0; windowIndex < numMotionWindow; windowIndex++)
						{							
							readbuffer0 = ds.readUint8();
							readbuffer1 = ds.readUint8();
							index += 2;
							alertFlag[windowIndex] = readbuffer1 >> 7;
							detectPercent[windowIndex] = readbuffer1 & 127;
									
							//motion axis
							var axisJPG = new Array(POLYGON_POINTS_NUM);
							for (var axis = 0; axis < POLYGON_POINTS_NUM; axis++)
							{								
								var x, y;
								
								readbuffer0 = ds.readUint8();
								readbuffer1 = ds.readUint8();
								index += 2;
								x = readbuffer0 * 256 + readbuffer1;
								readbuffer0 = ds.readUint8();
								readbuffer1 = ds.readUint8();
								index += 2;
								y = readbuffer0 * 256 + readbuffer1;								
								axisJPG[axis] = new jsPoint(x,y);
							}
							//console.log("axisJPG: (%s,%s) (%s,%s) (%s,%s) (%s,%s)", axisJPG[0].x, axisJPG[0].y, axisJPG[1].x, axisJPG[1].y, axisJPG[2].x, axisJPG[2].y, axisJPG[3].x, axisJPG[3].y);
							
							drawRedPolygon(windowIndex, alertFlag[windowIndex], axisJPG);
						}
						
						if (MD_Window_selected != -1)
						{
							updatePercentage(detectPercent[parseInt(MD_Window_selected)]);
						}
					}
				}
			}
		};
				
		xmlhttp.open("GET", gImg.src, true);
		xmlhttp.responseType = "arraybuffer";
		xmlhttp.send();	
	}
}

function updateROIImg()
{
	var da;

	if (bUpdateImg === false)
	{
		return;
	}

	da = new Date();
	gImg.src = ""+gImgSrc +"&date="+da.getTime();
}

function drawPercentageWin(percentValue)
{
	var WinWidth = Math.sqrt(gImgW*gImgH)*percentValue/100;
	var WinOpacity = 0.3;
	var WinColor = '#FF0000';
	var minWidth = (gImgW < gImgH) ? gImgW : gImgH;
	
	if(WinWidth <= minWidth)
	{
		/*	Draw square
		 *	
		 *	width = height = a
		 *	sqrt( (a*a)/(W*H) ) = percentValue / 100
		 *	=> a = sqrt(W*H) * percentValue / 100
		 */
		$('#PercentageWin').css({
			"border-width": '0px',
			width: WinWidth + 'px',
			height: WinWidth + 'px',
			top: (gImgH-WinWidth)/2 + 'px',
			left: (gImgW-WinWidth)/2 + 'px',
			opacity: WinOpacity,
			backgroundColor: WinColor
		});
	}
	else
	{
		/*	Draw height=minWidth rectangle
		 *	
		 *	width = a
		 *	sqrt( (a*minWidth)/(W*H) ) = percentValue / 100
		 *	=> a = percentValue * percentValue * W * H / minWidth / 10000
		 */
		WinWidth = percentValue*percentValue*gImgW*gImgH/minWidth/10000;
		if(gImgW > gImgH)
		{
			$('#PercentageWin').css({
				"border-width": '0px',
				width: WinWidth + 'px',
				height: minWidth + 'px',
				top: '0px',
				left: (gImgW-WinWidth)/2 + 'px',
				opacity: WinOpacity,
				backgroundColor: WinColor
			});				
		}
		else
		{
			$('#PercentageWin').css({
				"border-width": '0px',
				width: minWidth + 'px',
				height: WinWidth + 'px',
				top: (gImgH-WinWidth)/2 + 'px',
				left: '0px',
				opacity: WinOpacity,
				backgroundColor: WinColor
			});	
		}		
	}
}

function calculatePolyArea(polyNode)
{
	var i;
	var ROIUpperBoundY, ROILowerBoundY;
	var pdwPolygonPts = new Array(POLYGON_POINTS_NUM*2);
	
	polyNode = polyNode.split(',');
	for(i = 0; i < POLYGON_POINTS_NUM*2; i++)
	{
		pdwPolygonPts[i] = parseInt(polyNode[i], 10);
	}

	// Calculate ROI boundary of Y coordinate
	ROILowerBoundY = ROIUpperBoundY = pdwPolygonPts[1];
	for (i = 1; i < POLYGON_POINTS_NUM; i++)
	{
		ROILowerBoundY = Math.min(ROILowerBoundY, pdwPolygonPts[2*i+1]);
		ROIUpperBoundY = Math.max(ROIUpperBoundY, pdwPolygonPts[2*i+1]);
	}
	
	var adjacentPtI, adjacentPtJ, crossCoordinateX;						  
	var crossNodeX = [];
	var polyArea, scanLineY;
	
	polyArea = 0;
	for (scanLineY = ROILowerBoundY; scanLineY <= ROIUpperBoundY; scanLineY++)
	{
		// Clear crossNodeX array
		crossNodeX.splice(0, crossNodeX.length);
		
		// Find a cross nodes list of adjacent poits connection and scanLineY
		adjacentPtJ = POLYGON_POINTS_NUM - 1;
		for (i = 0; i < POLYGON_POINTS_NUM; i++)
		{
			adjacentPtI = i;
			if ((pdwPolygonPts[2*adjacentPtI+1] > scanLineY && pdwPolygonPts[2*adjacentPtJ+1] <= scanLineY) || 
				(pdwPolygonPts[2*adjacentPtJ+1] > scanLineY && pdwPolygonPts[2*adjacentPtI+1] <= scanLineY))	
			{
				/*   crossCoordinateX - Xi   scanLineY - Yi
				 *   --------------------- = --------------
				 *          Xj - Xi              Yj - Yi
				 */
				crossCoordinateX = ( pdwPolygonPts[2*adjacentPtI] +
					               ( (scanLineY - pdwPolygonPts[2*adjacentPtI + 1]) * (pdwPolygonPts[2*adjacentPtJ] - pdwPolygonPts[2*adjacentPtI]) / (pdwPolygonPts[2*adjacentPtJ + 1] - pdwPolygonPts[2*adjacentPtI + 1]) )
					               );
						 
				crossNodeX.push(Math.floor(crossCoordinateX));
			}
			adjacentPtJ = adjacentPtI;
		}
		
		// Sort the nodes
		crossNodeX.sort(function(a, b){return a-b;});

		// Sum of the pixels between node pairs
		for (i = 0; i < crossNodeX.length; i+=2)
		{
			polyArea += (crossNodeX[i+1] - crossNodeX[i]);
		}
	}
	
	return polyArea;
}

/* Motion profile related function */
function updateProfileCheck(checked)
{
	document.getElementById("enableprofile").checked = checked;

	if (checked)
	{
		TmpProfileEnable = 1;
		$("#enableOpt").show(500);
		checkProfileMode();
	}
	else
	{
		TmpProfileEnable = 0;
		$("#enableOpt").hide(500);
	}

}

function checkProfileMode()
{
	var radioSelected = $("input[name=motion_c" + channelsource + gstrProfile + "_policy]:checked").val();
	if (radioSelected == "schedule")
	{
		$("#scheduleModeChild").css("display","block");
		//$("#scheduleModeChild").slideDown("fast");
	}
	else
	{
		$("#scheduleModeChild").css("display","none");
		//$("#scheduleModeChild").slideUp("fast");
	}
}

/* Non-IE related function, draw alert window and percentage */
function include(filename)
{
	var head = document.getElementsByTagName('head')[0];
	
	script = document.createElement('script');
	script.src = filename;
	script.type = 'text/javascript';
	
	head.appendChild(script);
}

function setRedPenColor()
{
	col = new jsColor("#FF0000");
	pen = new jsPen(col,4);
	
	return true;	
}

function updatePercentage(percentHeader)
{
	var percentage = parseInt(percentHeader);
	var objectPercentage = eval('motion_c' + channelsource + gstrProfile + '_win_i' + MD_Window_selected + '_objsize');
	
	$("#percentage").css("height", (100-parseInt(percentage))*0.7 + "px");
	
	if(percentage >= objectPercentage)
		$("#percentage_container").css("background", "#ff0000"); //red
	else
		$("#percentage_container").css("background", "#00ff00"); //green
}

function drawRedPolygon(drawWin, alertFlag, axisJPG)
{
	if (!setRedPenColor())
	{
		return;
	}
	
	if (alertFlag == 1)
	{
		$("#RedPolyWin" + drawWin).css("opacity","1.0");
	}
	else
	{
		$("#RedPolyWin" + drawWin).css("opacity","0.0");
	}
	
	eval("MaxSize=capability_videoin_c"+ channelsource + "_maxsize");
   	
	MaxWidth = MaxSize.split("x")[0];
	MaxHeight = MaxSize.split("x")[1];
	
	if (bRotate)
	{
		eval(swap('MaxWidth', 'MaxHeight'));
	}
	
	for (var axis = 0; axis < POLYGON_POINTS_NUM; axis++)
	{
		axisJPG[axis].x = Math.floor(axisJPG[axis].x * gImgW / MaxWidth);
		axisJPG[axis].y = Math.floor(axisJPG[axis].y * gImgH / MaxHeight);
	}
	//console.log("axisJPG: (%s,%s) (%s,%s) (%s,%s) (%s,%s)", axisJPG[0].x, axisJPG[0].y, axisJPG[1].x, axisJPG[1].y, axisJPG[2].x, axisJPG[2].y, axisJPG[3].x, axisJPG[3].y);
	
	gr.drawRedPolygon(pen, axisJPG, drawWin);
}
