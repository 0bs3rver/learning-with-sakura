function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	
	document.title=translator("WPS");	
	loadlanguage();
}

function start_wps()
{
	$.get("/cgi-bin/admin/start_wps.cgi");
	showProgressBar("wpsBar", 120, false);
}

function showProgressBar(barID, waitingTime)
{
	document.getElementById("notification").style.display = "block";
	document.getElementById(barID).style.display = "block";
	wait_time = waitingTime;
	count = 100;
	intervel = wait_time * 1000 / count;
	countdown();
}

function countdown()
{
	var board = document.getElementById("progress_bar");
	count --;
	if (count < 0)
	{
		parent.window.location = location.href;
	}
	else
	{
		board.value = board.value + "|";
		setTimeout("countdown()", intervel);
	}
}