var MAX_PRESET_NAME = 40;
var MAX_3D_PRIVACY_MASK_COUNT = 24;

var TOP_REDUNDANCY_PIXEL = 23;
var LEFT_REDUNDANCY_PIXEL = 2;

var MASK_MIN_WIDTH_PIXEL = 30;
var MASK_MIN_HEIGHT_PIXEL = 30;

var MASK_10XMIN_WIDTH_PIXEL = 80;
var MASK_10XMIN_HEIGHT_PIXEL = 80;

var PLUGIN_SIZE_WIDTH = 320;
var PLUGIN_SIZE_HEIGHT = 180;

var MASK_MODE;
var CENTER_RESIZE = 0;
var ANY_WHERE = 1;

var g_bIs_Up = true; 
var g_bIs_Down = false;

var g_mask_W; 
var g_mask_H;
var g_mask_Left;
var g_mask_Top;

var g_check3dMaskResult = 0;
var g_CurrImageRotate = 0;
var giCH_Curr = 0;
var MAX_RATIO = 30;

//"<PARAM NAME=\"PMSettingData3D\" VALUE=\"Name=IM1&TopLeftX=128&TopLeftY=104&Width=80&Height=48\">";
function loadCurrentSetting()
{
	$("fieldset").addClass("tabs-fieldset");

	InstallPlugin();

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?privacymask3d", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("privacy_mask");
	loadlanguage();

	ShowPresetSelction("builtin");
	ShowMaskSelection();
	//checkImageRotation();
	(privacymask3d_c0_enable == 0) ? $("#maskpanel").slideUp() : $("#maskpanel").slideDown();

	showimage_innerHTML('12', 'showimageBlock', false, true, true, 0);

    	if (bIsWinMSIE || ffversion >= 3)
	{
		gen3DPrivacyMaskWin();
	}

	initSDPtzPannel(); 
	
	if ( privacymask3d_c0_enable == "1" )
	{
		EnablePrivacy(true);
	}
		
	document.getElementById(PLUGIN_ID).ClickEventHandler = 3;

	if (document.delEditPMForm.sel_3dPMList.length > MAX_3D_PRIVACY_MASK_COUNT)
	{
		$("#add_pmbtn").attr("disabled", true);
	}
	
	if(!ParamUndefinedOrZero("maxratio"))
	{
		MAX_RATIO = maxratio;
	}
}

function gen3DPrivacyMaskWin()
{
	$("#StreamContainer").addClass("StreamContainerStyle");
	$("#StreamContainer").append('<div id="3DPMWindow" class="PMW_style" style="display:none"></div>');

	//initial PM Window by jQueryUI, enable resizable and draggable
	$('.PMW_style').resizable({
		containment: "#StreamContainer",
		handles: 'all',
		autoHide: true,
		minWidth: MASK_MIN_WIDTH_PIXEL,
		minHeight: MASK_MIN_HEIGHT_PIXEL,
		maxWidth: PLUGIN_SIZE_WIDTH,
		maxHeight: PLUGIN_SIZE_HEIGHT,
		resize: function(e, ui)
		{
			if (MASK_MODE == CENTER_RESIZE)
			{
				ui.position.left = (PLUGIN_SIZE_WIDTH / 2) - (ui.size.width / 2) + LEFT_REDUNDANCY_PIXEL;
				ui.position.top  = (PLUGIN_SIZE_HEIGHT / 2) - (ui.size.height / 2) + TOP_REDUNDANCY_PIXEL;

				g_mask_W = ui.size.width ;
				g_mask_H = ui.size.height ;
				g_mask_Left = ui.position.left ;
				g_mask_Top = ui.position.top ;	
			}
			else
			{				
				g_mask_W = ui.size.width ;
				g_mask_H = ui.size.height ;		
				if (MAX_RATIO <=10)
				{
					g_mask_W = (g_mask_W < MASK_10XMIN_WIDTH_PIXEL) ? MASK_10XMIN_WIDTH_PIXEL : ui.size.width ;
					g_mask_H = (g_mask_H < MASK_10XMIN_HEIGHT_PIXEL) ? MASK_10XMIN_HEIGHT_PIXEL : ui.size.height ;	
				}
			}

		},
		stop: function(e, ui)
		{
            if ($(this).position().top < 20)
            {
            	$('#3DPMWindow').css("top",20);
            	g_mask_Top = 20;
            }

			$("#PM_width_value").text(g_mask_W);
			$("#PM_height_value").text(g_mask_H);	
			$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
			$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
		}
	})	
	.draggable({          
        	cursor: 'move',  
        	handle: "#StreamContainer",
        	containment: "#StreamContainer",
		//containment: [3,23,320-80,240-48],
		drag: function(e, ui)
		{		
			g_mask_Left = ui.position.left ;
			g_mask_Top = ui.position.top ;	

			$('#3DPMWindow').css("left", ui.position.left);
			$('#3DPMWindow').css("top", ui.position.top);

		},
		stop: function(e, ui)
		{
            if ($(this).position().top < 20)
            {
               	$('#3DPMWindow').css("top",20);
               	g_mask_Top = 20;
            }

			$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
			$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);				
		}
    }).attr("disabled",false);
}

function InitMaskMode()
{
        // Use fixed_in_center mode as default
        $('#sel_mask_mode')[0].selectedIndex = 0;
        MASK_MODE = CENTER_RESIZE;
        initCenterResizeMode();
        document.getElementById(PLUGIN_ID).ClickEventHandler = 3;
}

function EnablePrivacy(bEnable)
{
	InitMaskMode();
	if ( bEnable )
	{
		$('#maskpanel').slideDown();
		$('#3DPMWindow').show();
	}
	else
	{	
		$('#maskpanel').slideUp();
		$('#3DPMWindow').hide();
	} 
}

function submitform(a, b)
{
    updatecheck(a, b);
    document.forms["privacy"].submit();
}

function ShowMaskSelection()
{
	var maskSelObj = $("#sel_3dPMList");
	maskSelObj.removeOption(/./);

	maskSelObj.addOption("-1", translator("select_one"));

	for (var i = 0; i < MAX_3D_PRIVACY_MASK_COUNT; i++)
	{
		var MaskName = eval('privacymask3d_c0_win_i' + i + '_name');

		if (MaskName != "")
		{
			maskSelObj.addOption(MaskName, MaskName, false);
		}	
	}
}

var tidPrivacy3d = null;
var waitRecall3d = 500;
function Recall3dPM(selObj)
{
        if (tidPrivacy3d != null) clearTimeout(tidPrivacy3d);
        tidPrivacy3d = setTimeout(function() {
		for (var i=0; i < selObj.options.length-1; i++)
		{
			if (selObj.options[i].selected) break;
		}

  		if (selObj.options[i].value == -1) return;

  		ret_page.location.href='/cgi-bin/camctrl/recall.cgi?recall3d=' + encodeURIComponent(selObj.options[i].text);
        }, waitRecall3d);
}

function ChangeMaskMode(selObj)
{
	// Select center resize
	if (selObj.options[0].selected)
	{
		MASK_MODE = CENTER_RESIZE;
		$( ".PMW_style" ).resizable( "option", "minWidth", MASK_MIN_WIDTH_PIXEL );
		$( ".PMW_style" ).resizable( "option", "minHeight", MASK_MIN_HEIGHT_PIXEL );
		initCenterResizeMode();
		document.getElementById(PLUGIN_ID).ClickEventHandler = 3;
	}
	else
	{
		MASK_MODE = ANY_WHERE;
		if (MAX_RATIO <= 10)
		{
			ReinitDragToMoveMode();
		}
		$('#3DPMWindow').draggable( 'enable' );
		document.getElementById(PLUGIN_ID).ClickEventHandler = 0;
	}

}
function ReinitDragToMoveMode()
{
	$( ".PMW_style" ).resizable( "option", "minWidth", MASK_10XMIN_WIDTH_PIXEL );
	$( ".PMW_style" ).resizable( "option", "minHeight", MASK_10XMIN_HEIGHT_PIXEL );

	if($("#PM_width_value").text() < MASK_10XMIN_WIDTH_PIXEL)
	{
		var Window_W = MASK_10XMIN_WIDTH_PIXEL;
		var Window_Left = (PLUGIN_SIZE_WIDTH / 2) - (Window_W / 2) + LEFT_REDUNDANCY_PIXEL;
		$('#3DPMWindow').css("width", Window_W);
		$('#3DPMWindow').css("left", Window_Left);
		g_mask_W = Window_W ;
		g_mask_Left = Window_Left ;
		$("#PM_width_value").text(g_mask_W);
		$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);

	}
	if($("#PM_height_value").text() < MASK_10XMIN_HEIGHT_PIXEL)
	{
		var Window_H = MASK_10XMIN_HEIGHT_PIXEL;
		var Window_Top 	= (PLUGIN_SIZE_HEIGHT / 2) - (Window_H / 2) + TOP_REDUNDANCY_PIXEL;
		$('#3DPMWindow').css("height", Window_H);
		$('#3DPMWindow').css("top", Window_Top);
		g_mask_H = Window_H ;
		g_mask_Top = Window_Top ;
		$("#PM_height_value").text(g_mask_H);
		$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
	}

}

function initCenterResizeMode()
{
	var initWindow_W = 80;
	var initWindow_H = 48;
	var initWindow_Top 	= (PLUGIN_SIZE_HEIGHT / 2) - (initWindow_H / 2) + TOP_REDUNDANCY_PIXEL;
	var initWindow_Left = (PLUGIN_SIZE_WIDTH / 2) - (initWindow_W / 2) + LEFT_REDUNDANCY_PIXEL;
	
	$('#3DPMWindow').css("width", initWindow_W);
	$('#3DPMWindow').css("height", initWindow_H);
	$('#3DPMWindow').css("top", initWindow_Top);
	$('#3DPMWindow').css("left", initWindow_Left);
	$('#3DPMWindow').show();
	$('#3DPMWindow').draggable( 'disable' );
	
	g_mask_W = initWindow_W ;
	g_mask_H = initWindow_H ;
	g_mask_Left = initWindow_Left ;
	g_mask_Top = initWindow_Top ;

	$("#PM_width_value").text(g_mask_W);
	$("#PM_height_value").text(g_mask_H);	
	$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
	$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
}

// add,edit,delete privacy mask
function submit3dPM(type)
{
	var addForm = document.addPMForm;
	var delEditForm = document.delEditPMForm;

	var sel3DPM = delEditForm.sel_3dPMList;
	var masknameObj = addForm.maskname;

	switch(type)
	{
		case 'add':
			if (false == modifyCheck_before (sel3DPM, masknameObj, type)) return false;

			var submitBtn = addForm.AddPMBtn;

			// adding preset location by AJAX
			var privacymaskURL;
			if (MASK_MODE == CENTER_RESIZE)
			{
				privacymaskURL =
				"/cgi-bin/admin/setpm3d.cgi?" +
				"method=add"                  +
				"&maskname="                  + encodeURIComponent(masknameObj.value) +
				"&maskheight="                + $("#PM_height_value").text() +
				"&maskwidth="                 + $("#PM_width_value").text() +
				"&videosize=320x180";
			}
			else
			{
				privacymaskURL =
			"/cgi-bin/admin/setpm3d.cgi?" +
			"method=add"                  +
			"&maskname="                  + encodeURIComponent(masknameObj.value) +
			"&maskheight="                + $("#PM_height_value").text() +
				"&maskwidth="                 + $("#PM_width_value").text() +
				"&maskcx="					  + $("#PM_left_value").text() +
				"&maskcy="					  + $("#PM_top_value").text()+
				"&videosize=320x180";
			}
			

			$.ajax({
				cache: false,
				url: privacymaskURL,
				beforeSend: function () {
					$("#ajaxLoadIcon").show();
					$("#maskpanel :input").attr('disabled', true);
				},
				success: function (response) {
					check3dMaskResult(encodeURIComponent(masknameObj.value));
        				if (g_check3dMaskResult <= 0) 
					{
						alert(translator("no_more_privacy_mask_allowed_in_this_region"));
        				}
					else
					{
						$(sel3DPM).addOption(masknameObj.value, masknameObj.value, true);
					}

					masknameObj.value ="";
					$("#ajaxLoadIcon").fadeOut(1000, function() {
						$("#maskpanel :input").attr('disabled', false);
						modifyCheck_after(sel3DPM, type);
					});
				}
			});
			break;

		case 'edit':
		case 'delete':
			var selObj = sel3DPM;
			if (selObj.selectedIndex < 1)
			{
				return;
			}

			if ("edit" == type)
			{
                        	if (false == modifyCheck_before (sel3DPM, masknameObj, type)) return false;
			}

			var maskname = selObj.options[selObj.selectedIndex].text;
			var submitBtn = ("delete" == type) ? delEditForm.DeletePMBtn : delEditForm.EditPMBtn;
			var privacymaskURL;

			if (MASK_MODE == CENTER_RESIZE)
			{
				if (("edit" == type) && CountLength(masknameObj.value) > 0)
				{
                                privacymaskURL =
                                "/cgi-bin/admin/setpm3d.cgi?" +
                                "method="                     + type +
                                "&maskname="                  + encodeURIComponent(maskname) +
				"&maskrename="		      + encodeURIComponent(masknameObj.value) +
                                "&maskheight="                + $("#PM_height_value").text() +
                                "&maskwidth="                 + $("#PM_width_value").text() +
                                "&videosize=320x180";
				}
				else
				{
				privacymaskURL =
				"/cgi-bin/admin/setpm3d.cgi?" +
				"method="                     + type +
				"&maskname="                  + encodeURIComponent(maskname) +
				"&maskheight="                + $("#PM_height_value").text() +
				"&maskwidth="                 + $("#PM_width_value").text() +
				"&videosize=320x180";
				}
			}
			else
			{
                                if (("edit" == type) && CountLength(masknameObj.value) > 0)
                                {
                                privacymaskURL =
                                "/cgi-bin/admin/setpm3d.cgi?" +
                                "method="                     + type +
                                "&maskname="                  + encodeURIComponent(maskname) +
				"&maskrename="                 + encodeURIComponent(masknameObj.value) +
                                "&maskheight="                + $("#PM_height_value").text() +
                                "&maskwidth="                 + $("#PM_width_value").text() +
                                "&maskcx="                    + $("#PM_left_value").text() +
                                "&maskcy="                    + $("#PM_top_value").text() +
                                "&videosize=320x180";
				}
				else
				{
				privacymaskURL =
				"/cgi-bin/admin/setpm3d.cgi?" +
				"method="                     + type +
				"&maskname="                  + encodeURIComponent(maskname) +
				"&maskheight="                + $("#PM_height_value").text() +
				"&maskwidth="                 + $("#PM_width_value").text() +
				"&maskcx="		      + $("#PM_left_value").text() +
				"&maskcy="		      + $("#PM_top_value").text() +
				"&videosize=320x180";
				}
			}


			$.ajax({
				cache: false,
				url: privacymaskURL,
				beforeSend: function () {
					$("#ajaxLoadIcon2").show();
					$("#maskpanel :input").attr('disabled', true);
					selObj.disabled = true;
				},
				success: function (response) {
					if ("delete" == type) 
					{
						$(sel3DPM).removeOption(maskname, true);
						selObj.selectedIndex = 0;
					}
					else
					{
						if (masknameObj.value)
						{
							check3dMaskResult(encodeURIComponent(masknameObj.value));
						}
						else
						{
							check3dMaskResult(encodeURIComponent(maskname));
						}
                                        	if (g_check3dMaskResult <= 0)
                                        	{
                                                	alert(translator("no_more_privacy_mask_allowed_in_this_region"));
                                        	}
						else
						{
							if (masknameObj.value)
							{
								// rename it
								$(sel3DPM).removeOption(maskname, true);
								$(sel3DPM).addOption(masknameObj.value, masknameObj.value, true);
								for (var i = 0; i < sel3DPM.options.length; i++) 
								{
									if (sel3DPM.options[i].text == masknameObj.value) 
									{
										sel3DPM.selectedIndex = i;
									}
								}
								masknameObj.value ="";
							}
						}
					}

					$("#ajaxLoadIcon2").fadeOut(1000, function() {
						selObj.disabled = false;
						$("#maskpanel :input").attr('disabled', false);
						modifyCheck_after(sel3DPM, type);
					});
				}
			});
			break;

		default:
			break;
	}
}
//

function modifyCheck_before(sel3DPM, masknameObj, type)
{
	if ("add" == type)
	{
        	if (CheckEmptyString(masknameObj) == -1) return false;

        	if (sel3DPM.length > MAX_3D_PRIVACY_MASK_COUNT)
        	{
                	$("#add_pmbtn").attr("disabled", true);
                	alert(translator("no_more_location_for_privacy_mask_24"));
                	return false;
        	}
	}

        if (checkInString(masknameObj)) return false;

        if (CountLength(masknameObj.value) > MAX_PRESET_NAME)
        {
                alert(translator("the_length_is_over_40_characters"));
                return false;
        }

        for(var i = 0; i < sel3DPM.length; i++)
        {
                if (masknameObj.value == sel3DPM.options[i].text)
                {
                        alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
                        return false;
                }
        }

	return true;
}

function modifyCheck_after(sel3DPM, type)
{
	if (("add" == type) && (sel3DPM.length > MAX_3D_PRIVACY_MASK_COUNT))
        {
                $("#add_pmbtn").attr("disabled", true);
        }
	
	if (("delete" == type) && (sel3DPM.length <= MAX_3D_PRIVACY_MASK_COUNT))
	{
		$("#add_pmbtn").attr("disabled", false);
	}
}
//

function downcoordinates(event)
{	
	var clickType = event.button;
	
	if ((clickType == 1) && (MASK_MODE == ANY_WHERE))
	{
		g_bIs_Up = false; 
		g_bIs_Down = true;

		g_mask_Left = event.offsetX;
		g_mask_Top = event.offsetY;
		g_mask_W = 0;
		g_mask_H = 0;
		
		$('#3DPMWindow').hide();
	}
	
}

function movecoordinates(event)
{
	var TMP_MASK_MIN_WIDTH_PIXEL = ((MASK_MODE == ANY_WHERE) &&(MAX_RATIO <=10)) ? MASK_10XMIN_WIDTH_PIXEL : MASK_MIN_WIDTH_PIXEL;
	var TMP_MASK_MIN_HEIGHT_PIXEL = ((MASK_MODE == ANY_WHERE) &&(MAX_RATIO <=10)) ? MASK_10XMIN_HEIGHT_PIXEL : MASK_MIN_HEIGHT_PIXEL;

	var clickType = event.button; 
	var clickBoundMinTop	= 20;
	var clickBoundMaxTop	= 200 - TMP_MASK_MIN_HEIGHT_PIXEL;
	var clickBoundMinLeft	= 3;
	var clickBoundMaxLeft	= 323 - TMP_MASK_MIN_WIDTH_PIXEL;
	
	if ((g_bIs_Down) && (clickType == 1)  && (MASK_MODE == ANY_WHERE))
	{
		if (g_mask_Top < clickBoundMinTop)
		{
			$('#3DPMWindow').css("top", clickBoundMinTop);
			g_mask_Top = clickBoundMinTop;
		}
		else if (g_mask_Top > clickBoundMaxTop)
		{
			$('#3DPMWindow').css("top", clickBoundMaxTop);
			g_mask_Top = clickBoundMaxTop;
		}
		
		if (g_mask_Left < clickBoundMinLeft)
		{
			$('#3DPMWindow').css("Left", clickBoundMinLeft);
			g_mask_Left = clickBoundMinLeft;
		}
		else if (g_mask_Left > clickBoundMaxLeft)
		{
			$('#3DPMWindow').css("Left", clickBoundMaxLeft);
			g_mask_Left = clickBoundMaxLeft;
		}

		//boundary check
		var currentX = (event.offsetX > 323) ? 323 : event.offsetX; g_mask_W = currentX - g_mask_Left;
		var currentY = (event.offsetY > 200) ? 200 : event.offsetY; g_mask_H = currentY - g_mask_Top;

		if (g_mask_W < TMP_MASK_MIN_WIDTH_PIXEL)
		{
			g_mask_W = TMP_MASK_MIN_WIDTH_PIXEL;
		}

		if (g_mask_H < TMP_MASK_MIN_HEIGHT_PIXEL)
		{
			g_mask_H = TMP_MASK_MIN_HEIGHT_PIXEL;
		}

		//if (g_mask_W >= 0 && g_mask_H >= 0)
		//{	
			$('#3DPMWindow').css("height", g_mask_H );
			$('#3DPMWindow').css("width",  g_mask_W );
			$('#3DPMWindow').css("top", g_mask_Top );
			$('#3DPMWindow').css("left", g_mask_Left );
			$('#3DPMWindow').show();
			
			
			$("#PM_width_value").text(g_mask_W);
			$("#PM_height_value").text(g_mask_H);	
			$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
			$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
		//}
	}		
}

function upcoordinates(event)
{
	var clickType = event.button;
	
	if ((clickType == 1) && (MASK_MODE == ANY_WHERE))
	{
		g_bIs_Up = true; 
		g_bIs_Down = false;
	}
}


function check3dMaskResult(privacyName) 
{
	g_check3dMaskResult = 0;
	url = "/cgi-bin/camctrl/camctrl.cgi?getmaskaddresult=" + privacyName;
        XMLHttpRequestObject.onreadystatechange = function (){};
        XMLHttpRequestObject.open("GET", url, false);
        XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
        XMLHttpRequestObject.send(null);
        eval(XMLHttpRequestObject.responseText);
	g_check3dMaskResult = parseInt(maskaddresult);
}

function checkImageRotation()
{
	if ( eval("capability_videoin_c"+giCH_Curr+"_rotation") == 1)
	{
		if( eval("videoin_c"+giCH_Curr+"_rotate") == 90 || eval("videoin_c"+giCH_Curr+"_rotate") == 270)
		{	
			g_CurrImageRotate = 1;
			PLUGIN_SIZE_WIDTH = 180;
			PLUGIN_SIZE_HEIGHT = 320;
		}
		else
		{
			g_CurrImageRotate = 0;
		}
	}
}

var tidSubmitPresetPre = null;
var waitSlideLatency = 500;
function SubmitPreset(selObj)
{
        if (tidSubmitPresetPre != null) {
                clearTimeout(tidSubmitPresetPre);
        }
        tidSubmitPresetPre = setTimeout(function() {
                var CGICmd='/cgi-bin/camctrl/recall.cgi?recall=' + encodeURIComponent($(selObj).selectedOptions().text());
                $.ajaxSetup({ cache: false, async: true});
                $.get(CGICmd)
                Log("Send: %s",CGICmd);
        }, waitSlideLatency);
}

function KeyPress(evt)
{
        var code = window.event?evt.keyCode:evt.which;
        if (code == 13)
        {
                return false;
        }
}

