var gMaxPageHeight = 300; //px

var giCH_Curr = 0;
var bBrightness = false;
	var TmpBrightness;
var bContrast = false;
	var TmpContrast;
var bSaturation = false;
	var TmpSaturation;
var bSharpness = false;
	var TmpSharpness;
var bDefog = false;
var bDefogStr = false;
    var	bDefogOnWDRProUnchanged = false;
    var	bDefogOnWDRProDisabled= false;
    var	bDefogOnWDRCUnchanged = false;
    var	bDefogOnContrastHidden = false;
    var	TmpDefog;
    var TmpDefogStr;
    var TmpDefogSupportLevel;
    var TmpDefogStep;
var bDNR = false;
	var TmpDNRMode;
	var TmpDNRStr;
var bWhiteBalance = false;
	var TmpWBMode;
	var TmpWBFixOn;
	var TmpRGain;
	var TmpBGain;
	var WBHttpRequestObject = null;
	var bRefreshGain = false;
var bGammaCurve = false;
	var gaiGammaCurveSteps = [45, 50, 60, 70, 80, 90, 100];
	var giMinGammaCurveIdx = 0;
	var TmpGammaCurve;
	var LastGammaCurve;
var bEIS = false;
	var bEISEnabled = false;
var bISSupport = false;
	var bISOnRotationHidden = false;
var bISStr = false;
    var	TmpISMode;
    var TmpISStr;
    var TmpISSupportLevel;
    var TmpISStep;
var bScene = false;
	var bSceneModeEnabled = false;
	var TmpSceneMode;
	var TmpSceneMaxexposure;
	var TmpSceneMaxgain;
	var bSceneModeOnDefaultMaxexposure = false;
	var bSceneModeOnDefaultMaxgain = false;
	var bSceneModeOn3dnrUnchanged = false;
	var bSceneModeOnMinexposureHidden = false;
	var bSceneModeOnMingainHidden = false;
	var bSceneModeOnFlickerlessHidden = false;
	var bSceneModeOnWdrproUnchanged = false;
var bWDREnhanced = false;
	var bWDRCOnGammaDisabled = false;
var bWDRPro = false;
	var bWDROnGammaDisabled = false;
var bExposureMode = false;
	var TmpExposureMode;
	var bAEImpactDefogDisabled = false;
var bRotate = false;
	var bRotateOnEISHidden = false;

var TmpProfileEnable;
var TmpPolicy;
var TmpBeginTime;
var TmpEndTime;

var TmpNormalLightEnable;
var bExitNormalLight = false;
var giProfileIdx;
var gstrProfile;
var bExitProfile = false;

function setProfileIndex()
{
	giProfileIdx = Number(getCookie("imageprofileindex"));
	
	if (giProfileIdx == 0)
	{
		gstrProfile = "";
	}
	else
	{
		gstrProfile = "_profile_i0";
	}
}

function updateProfileCheck(checked)
{
	document.getElementById("enableprofile").checked = checked;
	if (checked)
	{
		TmpProfileEnable = 1;
		$("#profileDayMode, #profileNightMode, #profileSchedule, #profileScheduleContent1, #profileScheduleContent2").attr("disabled",false);
		$("#enableOpt").show(500);
	}
	else
	{
		TmpProfileEnable = 0;
		$("#profileDayMode, #profileNightMode, #profileSchedule, #profileScheduleContent1, #profileScheduleContent2").attr("disabled",true);
		$("#enableOpt").hide(500);
	}
	
	//$("#enableOpt").slideToggle()
}

function updateProfileScheduleTime(obj)
{
	if (obj.id == "profileScheduleBeginTime")
	{
		TmpBeginTime = obj.value;
	}
	else
	{
		TmpEndTime = obj.value;
	}
}

function checkProfileMode(obj)
{
	if (obj.id == "profileDayMode")
	{
		TmpPolicy = "day";
		//document.getElementById("profileDayMode").checked = true;
		document.getElementById("profileNightMode").checked = false;
		document.getElementById("profileSchedule").checked = false;
		$("#profileScheduleChild").css("display","none");
	}
	else if (obj.id == "profileNightMode")
	{
		TmpPolicy = "night";
		//document.getElementById("profileDayMode").checked = false;
		document.getElementById("profileNightMode").checked = true;
		document.getElementById("profileSchedule").checked = false;
		$("#profileScheduleChild").css("display","none");
	}
	else
	{
		TmpPolicy = "schedule";
		//document.getElementById("profileDayMode").checked = false;
		document.getElementById("profileNightMode").checked = false;
		document.getElementById("profileSchedule").checked = true;
		$("#profileScheduleChild").css("display","inline");
	}
}	

function enterProfileMode()
{
	params = "image_c0_profile_i0_enable=1&" +
		 "image_c0_profile_i0_policy=schedule&" + 
		 "image_c0_profile_i0_begintime=00:00&" + 
		 "image_c0_profile_i0_endtime=23:59"

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: params, 
		cache: false
	});

}

//load data when enter image page
function enterNormalLightMode()
{
	params = "image_c0_profile_i0_enable=0" 
	
 	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: params, 
		cache: false
	});

}

//Called when the Web page is on loading.
function loadCurrentSetting()
{	
	var tmp = location.href.split("?");
	var tmp2 = tmp[1].split("=");

	if (tmp2[0] == 'ch')
	{
		giCH_Curr = parseInt(tmp2[1], 10);
	}

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?capability_daynight_c"+giCH_Curr+"_support&capability_image_c"+giCH_Curr+"&image_c"+giCH_Curr+"&videoin_c"+giCH_Curr+"&capability_videoin_c"+giCH_Curr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();

	setProfileIndex();
}

function findDefogImpact()
{
	if ("-" != eval("capability_image_c"+giCH_Curr+"_defog_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_defog_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("wdrpro:unchanged:"))
			{
				bDefogOnWDRProUnchanged = true;
			}
			else if ( -1 != tmp[i].search("wdrpro:disabled:"))
			{
				bDefogOnWDRProDisabled = true;
			}
			else if ( -1 != tmp[i].search("wdrc:unchanged:"))
			{
				bDefogOnWDRCUnchanged = true;
			}
			else if ( -1 != tmp[i].search("contrast:hidden:"))
			{
				bDefogOnContrastHidden = true;
			}
		}
	}
}

function findISImpact()
{
	if ("-" != eval("capability_image_c"+giCH_Curr+"_is_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_is_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("rotation:hidden:"))
			{
				bISOnRotationHidden = true;
			}
		}
	}
}

function findScenemodeImpact()
{
	//Find Scenemode impact.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_affect"))
	{
		var SceneAffect = eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_affect");
		
		if ( -1 != SceneAffect.search("minexposure:hidden:"))
		{
			bSceneModeOnMinexposureHidden = true;
		}
		else
		{
			bSceneModeOnMinexposureHidden = false;
		}
		
		if ( -1 != SceneAffect.search("mingain:hidden:"))
		{
			bSceneModeOnMingainHidden = true;
		}
		else
		{
			bSceneModeOnMingainHidden = false;
		}
		
		if ( -1 != SceneAffect.search("flickerless:hidden:"))
		{
			bSceneModeOnFlickerlessHidden = true;
		}
		else
		{
			bSceneModeOnFlickerlessHidden = false;
		}
		
		if ( -1 != SceneAffect.search("wdrpro:unchanged:"))
		{
			bSceneModeOnWdrproUnchanged = true;
		}
		else
		{
			bSceneModeOnWdrproUnchanged = false;
		}
		
		if ( -1 != SceneAffect.search("3dnr:unchanged:"))
		{
			bSceneModeOn3dnrUnchanged = true;
		}
		else
		{
			bSceneModeOn3dnrUnchanged = false;
		}
	}
	else
	{
		bSceneModeOnMinexposureHidden = false;
		bSceneModeOnMingainHidden = false;
		bSceneModeOnFlickerlessHidden = false;
		bSceneModeOnWdrproUnchanged = false;
		bSceneModeOn3dnrUnchanged = false;
	}
	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
	
	//Scene mode default value
	if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxexposure"))
	{
		bSceneModeOnDefaultMaxexposure = false;
		TmpSceneMaxexposure = 0;
	}
	else
	{
		bSceneModeOnDefaultMaxexposure = true;
		TmpSceneMaxexposure = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure");
	}
	
	if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxgain"))
	{
		bSceneModeOnDefaultMaxgain = false;
		TmpSceneMaxgain = 0;
	}
	else
	{
		bSceneModeOnDefaultMaxgain = true;
		TmpSceneMaxgain = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain");
	}
}

function findWDRImpact()
{
	//Find WDR impact.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_wdrpro_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_wdrpro_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("gammacurve:disabled:"))
			{
				bWDROnGammaDisabled = true;
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findWDRCImpact()
{
	//Find WDRC impact.
	if ("-" != eval("capability_image_c"+giCH_Curr+"_wdrc_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_wdrc_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("gammacurve:disabled:"))
			{
				bWDRCOnGammaDisabled = true;
			}
		}
	}
	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findAEImpact()
{
	TmpExposureMode = eval("videoin_c"+giCH_Curr+gstrProfile+"_exposuremode");
	//Find AE impact.
	if (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_"+TmpExposureMode+"mode_affect"))
	{
		tmp = eval("capability_image_c"+giCH_Curr+"_exposure_"+TmpExposureMode+"mode_affect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("defog:disabled:"))
			{
				bAEImpactDefogDisabled = true;
			}
		}
	}

	// (disabled)   UI selection is unchecked and can't be changed 
	// (hidden)     UI selection is hidden
	// (fixed)      UI selection/value is fixed  
	// (ranged)     UI selection/value is fixed in a range
	// (unchanged)  UI selection stays the same status and can't be changed
}

function findRotateImpact()
{
	if (!ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_rotationaffect"))
	{
		tmp = eval("capability_videoin_c"+giCH_Curr+"_rotationaffect").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if ( -1 != tmp[i].search("eis:hidden:"))
			{
				bRotateOnEISHidden = true;
			}
		}
	}
}

//Called when the Web page is loaded done.
//Start point of this code.
function receivedone()
{
	var iTmp;

	iTmp = parseInt(eval("capability_image_c"+giCH_Curr+"_basicsetting"), 10);
	if (1 == (iTmp & 0x01))
	{
		bBrightness = true;
		document.getElementById("brightnessControl").style.display = "block";
	}
	iTmp = iTmp >> 1;
	if (1 == (iTmp & 0x01))
	{
		bContrast = true;
		document.getElementById("contrastControl").style.display = "block";
	}
	iTmp = iTmp >> 1;
	if (1 == (iTmp & 0x01))
	{
		bSaturation = true;
		document.getElementById("saturationControl").style.display = "block";
	}
	iTmp = iTmp >> 1;
	if (1 == (iTmp & 0x01))
	{
		bSharpness = true;
		document.getElementById("sharpnessControl").style.display = "block";
	}
	
	//Defog
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_defog_mode"), 10))
	{
		bDefog = true;
		document.getElementById("defogControl").style.display = "block";
		document.getElementById("defog_strength").innerHTML = translator("strength");

		if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_defog_strength"), 10))
		{
			bDefogStr = true;
		}

		TmpDefogSupportLevel = parseInt(eval("capability_image_c"+giCH_Curr+"_defog_supportlevel"));

		if (TmpDefogSupportLevel < 3)
		{
			TmpDefogSupportLevel = 2;
			TmpDefogStep = 99;
		}
		else
		{
			TmpDefogStep = Math.floor(100 / (TmpDefogSupportLevel - 1));
		}

		findDefogImpact();
	}

	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_dnr"), 10))
	{
		bDNR = true;
		document.getElementById("dnrControl").style.display = "block";
	}

	if ("-" != eval("capability_image_c"+giCH_Curr+"_wbmode"))
	{
		document.getElementById("wbControl").style.display = "block";
		bWhiteBalance = true;

		//aWBMode = eval("capability_c"+giCH_Curr+"_wbmode").split(',');
	}

	if (1 == eval("capability_image_c"+giCH_Curr+"_gammacurve"))
	{
		bGammaCurve = true;
		document.getElementById("gammacurveControl").style.display = "block";
	}

	//Rotation
	if (0 != parseInt(eval("capability_videoin_c"+giCH_Curr+"_rotation"), 10) &&  0 != parseInt(eval("videoin_c"+giCH_Curr+"_rotate")))
	{
		bRotate = true;
		findRotateImpact();
	}
	
	if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_is_mode"))
	{
		if (1 == eval("capability_image_c"+giCH_Curr+"_eis"))
		{
			bEIS = true;
			document.getElementById("eisControl").style.display = "block";
		}
	}
	else
	{
		if ("-" != eval("capability_image_c"+giCH_Curr+"_is_mode"))
		{
			bISSupport = true;
			TmpISMode= eval("capability_image_c"+giCH_Curr+"_is_mode");
			
			if (bRotate && bRotateOnEISHidden)
			{
				document.getElementById("ISControl").style.display = "none";
			}
			else
			{
				document.getElementById("ISControl").style.display = "block";
			}
			document.getElementById("IS_enable_mode").innerHTML = translator("enable_image_stablizer");
			document.getElementById("IS_strength").innerHTML = translator("strength");
			
			if ("dis" == TmpISMode)
			{
				document.getElementById("IS_enable_mode").innerHTML = translator("enable_digital_image_stabilizer");
			}
			
			if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_is_strength"), 10))
			{
				bISStr = true;
			}

			TmpISSupportLevel = parseInt(eval("capability_image_c"+giCH_Curr+"_is_supportlevel"));

			if (TmpISSupportLevel < 3)
			{
				TmpISSupportLevel = 2;
				TmpISStep = 99;
			}
			else
			{
				TmpISStep = Math.floor(100 / (TmpISSupportLevel - 1));
			}

			findISImpact();
		}
	}
	
	if (1 == eval("capability_image_c"+giCH_Curr+"_scenemode_support"))
	{
		bScene = true;
		document.getElementById("scenemodeControl").style.display = "block";
		TmpSceneMode = eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode");
		findScenemodeImpact();
	}

	//WDR pro = 1
	//WDR pro & WDR proII = 2
	if (1 <= parseInt(eval("capability_image_c"+giCH_Curr+"_wdrpro_mode"), 10) &&  0 != parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrpro_mode")))
	{
		bWDRPro = true;
		findWDRImpact();
	}
	
	//WDR enhance
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_wdrc_mode"), 10) &&  0 != parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_wdrc_mode")))
	{
		bWDREnhanced = true;
		findWDRCImpact();
	}

	//AE mode
	if (1 == parseInt(eval("capability_image_c"+giCH_Curr+"_exposure_mode"), 10) && (!ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_modetype")))
	{
		bExposureMode = true;
		findAEImpact();
	}
	
	RestoreSettingUI();

	if (true == bIsWinMSIE)
	{
		if (document.body.scrollHeight +18 > gMaxPageHeight)
		{
			parent.document.getElementById("imagepage").height = gMaxPageHeight;
		}
		else
		{
			parent.document.getElementById("imagepage").height = document.body.scrollHeight + 18;
		}
	}
	else
	{
		if (document.body.scrollHeight > gMaxPageHeight)
		{
			parent.document.getElementById("imagepage").height = gMaxPageHeight;
		}
		else
		{
			parent.document.getElementById("imagepage").height = document.body.scrollHeight;
		}
	}

	// In firefox, it has the chance that document.body.scrollHeight return 0
	// if so, we assign height with gMaxPageHeight
	if (parent.document.getElementById("imagepage").height == 0)
	{
		parent.document.getElementById("imagepage").height = gMaxPageHeight;
	}
}

//Called when all objects in Web page is ready.
function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
}

function resetWBSelectColor()
{ 
	$('#wbSelect').css('color', $('#wbSelect option:selected').css('color'));
	$('#wbSelect option[value!="auto"]').css('color','black');
}

function RestoreSettingUI()
{
	//normal light 
	if (giProfileIdx == 0)
	{
		TmpNormalLightEnable = parseInt(eval("image_c"+giCH_Curr+"_profile_i0_enable"));
		enterNormalLightMode();
	}
	// profile
	if (giProfileIdx == 1)
	{
		$("#enableProfileContent").show();

		if ("0" == eval("capability_daynight_c"+giCH_Curr+"_support"))
		{
//            document.getElementById("profileDayMode").style.display = "none";
//            document.getElementById("profileDayModeStr").style.display = "none";
			document.getElementById("profileNightMode").style.display = "none";
			document.getElementById("profileNightModeStr").style.display = "none";
		}
		
		TmpProfileEnable = parseInt(eval("image_c"+giCH_Curr+"_profile_i0_enable"));
	        if(TmpProfileEnable == 0)
		{
			updateProfileCheck(false);
			//$("#enableOpt").hide(500);
		}
	        else
		{
			updateProfileCheck(true);
			//$("#enableOpt").show(500);
		}

		TmpPolicy = eval("image_c"+giCH_Curr+"_profile_i0_policy");
		if (TmpPolicy == "day")
		{
			//document.getElementById("profileDayMode").checked = true;
			document.getElementById("profileNightMode").checked = false;
			document.getElementById("profileSchedule").checked = false;
			$("#profileScheduleChild").css("display","none");
		}
		else if (TmpPolicy == "night")
		{
			//document.getElementById("profileDayMode").checked = false;
			document.getElementById("profileNightMode").checked = true;
			document.getElementById("profileSchedule").checked = false;
			$("#profileScheduleChild").css("display","none");
		}
		else if (TmpPolicy == "schedule")
		{
			//document.getElementById("profileDayMode").checked = false;
			document.getElementById("profileNightMode").checked = false;
			document.getElementById("profileSchedule").checked = true;
			$("#profileScheduleChild").css("display","inline");
		}

		TmpBeginTime = eval("image_c"+giCH_Curr+"_profile_i0_begintime");
		document.getElementById("profileScheduleBeginTime").value = TmpBeginTime;

		TmpEndTime = eval("image_c"+giCH_Curr+"_profile_i0_endtime");
		document.getElementById("profileScheduleEndTime").value = TmpEndTime;
		enterProfileMode();
	}

	//White balance.
	if (bWhiteBalance)
	{
		TmpWBMode = eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance");
		$(document.getElementById("wbSelect")).removeOption(/./);
		document.getElementById("wbSelect").disabled = false;

		WBSupportMode = eval("capability_image_c"+giCH_Curr+"_wbmode").split(",");
		
		
		
		for (i = 0; i < WBSupportMode.length; i++)
		{
			// white balance mode is not manual mode
			if ("rbgain" != WBSupportMode[i])
			{
				// white balance mode is fix current mode
				if ("manual" == WBSupportMode[i])
				{
					$(document.getElementById("wbSelect")).addOption(WBSupportMode[i], translator("fixcurrent"), true);
				}
				else
				{
					$(document.getElementById("wbSelect")).addOption(WBSupportMode[i], translator(WBSupportMode[i]), true);
				}
			}
		   	else
		   	{
				
				TmpRGain = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_rgain"), 10);
			
				
				$("#rgain_curValue").html(TmpRGain + "%");
				$("#rgain_adjust_slider_handle div.ui-slider-handle").attr("title", TmpRGain);
				$("#rgain_adjust_slider_handle").slider(
				{
					min: 0,
					max: 100,
					animate: true,
					value: TmpRGain,
					slide: function(event, ui)
					{
						$("#rgain_curValue").html(ui.value + "%");
					},
					change: function(event, ui)
					{
						$("#rgain_adjust_slider_handle div.ui-slider-handle").attr("title", ui.value);
						TmpRGain = ui.value;
						$.ajax({
							type: "POST",
							url: "/cgi-bin/admin/setparam.cgi",
							data: "videoin_c"+giCH_Curr+gstrProfile+"_rgain=" + TmpRGain,
							cache: false
						});
					}
				});

							
				TmpBGain = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_bgain"), 10);
				
				
				$("#bgain_curValue").html(TmpBGain + "%");
				$("#bgain_adjust_slider_handle div.ui-slider-handle").attr("title", TmpBGain);
				$("#bgain_adjust_slider_handle").slider(
				{
					min: 0,
					max: 100,
					animate: true,
					value: TmpBGain,
					slide: function(event, ui)
					{
						$("#bgain_curValue").html(ui.value + "%");
					},
					change: function(event, ui)
					{
						$("#bgain_adjust_slider_handle div.ui-slider-handle").attr("title", ui.value);
						TmpBGain = ui.value;
						$.ajax({
							type: "POST",
							url: "/cgi-bin/admin/setparam.cgi",
							data: "videoin_c"+giCH_Curr+gstrProfile+"_bgain=" + TmpBGain,
							cache: false
						});
					}
				});
				
				
				
				
				
				if ("rbgain" == eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance"))
				{
					$(document.getElementById("wbSelect")).addOption("rbgain", translator("manual"), true);
					document.getElementById("RGain").style.display = "block";
					document.getElementById("BGain").style.display = "block";
				}
				else
				{
					$(document.getElementById("wbSelect")).addOption("rbgain", translator("manual"), false);
					document.getElementById("RGain").style.display = "none";
					document.getElementById("BGain").style.display = "none";
				}
			}
		}
	
		$(document.getElementById("wbSelect")).children().each(
			function()
			{
				if (eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance") == this.value)
				{	
					
					this.selected = true;
				}
			}
		);

		/*
		if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("auto") != -1)
		{
			if ("auto" == eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance"))
			{
				$(document.getElementById("wbSelect")).addOption("auto", translator("auto"), true);
				TmpWBFixOn = false;

				if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("manual") != -1)
				{
					document.getElementById("wbButton").style.display = "block";
					$('#wbSelect option[value="auto"]').css('color','black');
					$("#on").css("background-position", "0px 0px").hover
					(
						function(){$(this).css("background-position", "0px -20px");},
						function(){$(this).css("background-position", "0px 0px");}
					);
					$("#off").unbind('mouseenter').unbind('mouseleave').css("background-position", "-48px -40px");
				}
			}
			else
			{
				if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("manual") != -1)
				{
					if ("manual" == eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance"))
					{
						TmpWBFixOn = true;
						$(document.getElementById("wbSelect")).addOption("auto", translator("auto"), true);
						document.getElementById("wbButton").style.display = "block";
						//document.getElementById("wbSelect").disabled = true;
						$('#wbSelect option[value="auto"]').css('color','gray');

						$("#on").unbind('mouseenter').unbind('mouseleave').css("background-position", "0px -40px");
						$("#off").css("background-position", "-48px 0px").hover
						(
							function(){$(this).css("background-position", "-48px -20px");},
							function(){$(this).css("background-position", "-48px 0px");}
						);
					}
					else
					{
						TmpWBFixOn = false;
						$(document.getElementById("wbSelect")).addOption("auto", translator("auto"), false);
						document.getElementById("wbButton").style.display = "none";
					}
				}
				else
				{
					$(document.getElementById("wbSelect")).addOption("auto", translator("auto"), false);
					document.getElementById("wbButton").style.display = "none";
				}
			}
			resetWBSelectColor();
		}

		if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("rbgain") != -1)
		{
			TmpRGain = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_rgain"), 10);
			$("#rgain_curValue").html(TmpRGain + "%");
			$("#rgain_adjust_slider_handle div.ui-slider-handle").attr("title", TmpRGain);
			$("#rgain_adjust_slider_handle").slider(
			{
				min: 0,
				max: 100,
				animate: true,
				value: TmpRGain,
				slide: function(event, ui)
				{
					$("#rgain_curValue").html(ui.value + "%");
				},
				change: function(event, ui)
				{
					$("#rgain_adjust_slider_handle div.ui-slider-handle").attr("title", ui.value);
					TmpRGain = ui.value;
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_rgain=" + TmpRGain,
						cache: false
					});
				}
			});

			TmpBGain = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_bgain"), 10);
			$("#bgain_curValue").html(TmpBGain + "%");
			$("#bgain_adjust_slider_handle div.ui-slider-handle").attr("title", TmpBGain);
			$("#bgain_adjust_slider_handle").slider(
			{
				min: 0,
				max: 100,
				animate: true,
				value: TmpBGain,
				slide: function(event, ui)
				{
					$("#bgain_curValue").html(ui.value + "%");
				},
				change: function(event, ui)
				{
					$("#bgain_adjust_slider_handle div.ui-slider-handle").attr("title", ui.value);
					TmpBGain = ui.value;
					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "videoin_c"+giCH_Curr+gstrProfile+"_bgain=" + TmpBGain,
						cache: false
					});
				}
			});

			if ("rbgain" == eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance"))
			{
				$(document.getElementById("wbSelect")).addOption("rbgain", translator("manual"), true);
				document.getElementById("RGain").style.display = "block";
				document.getElementById("BGain").style.display = "block";
			}
			else
			{
				$(document.getElementById("wbSelect")).addOption("rbgain", translator("manual"), false);
				document.getElementById("RGain").style.display = "none";
				document.getElementById("BGain").style.display = "none";
			}

		}
		*/
	}

	//Basic settings.
	if (bBrightness)
	{
		TmpBrightness = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_brightnesspercent"), 10);
		$("#brightnessValue").html(TmpBrightness + "%");
		$("#brightnessSlider div.ui-slider-handle").attr("title", TmpBrightness);
		$("#brightnessSlider").slider(
		{
			min: 0,
			max: 100,
			animate: true,
			value: TmpBrightness,
			slide: function(event, ui)
			{
				$("#brightnessValue").html(ui.value + "%");
			},
			change: function(event, ui)
			{
				$("#brightnessSlider div.ui-slider-handle").attr("title", ui.value);
				TmpBrightness = ui.value;
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "image_c"+giCH_Curr+gstrProfile+"_brightness=100&image_c"+giCH_Curr+gstrProfile+"_brightnesspercent=" + TmpBrightness,
					cache: false
				});
			}
		});
	}

	if (bContrast)
	{
		TmpContrast = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_contrastpercent"), 10);
		$("#contrastValue").html(TmpContrast + "%");
		$("#contrastSlider div.ui-slider-handle").attr("title", TmpContrast);
		$("#contrastSlider").slider(
		{
			min: 0,
			max: 100,
			animate: true,
			value: TmpContrast,
			slide: function(event, ui)
			{
				$("#contrastValue").html(ui.value + "%");
			},
			change: function(event, ui)
			{
				$("#contrastSlider div.ui-slider-handle").attr("title", ui.value);
				TmpContrast = ui.value;
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "image_c"+giCH_Curr+gstrProfile+"_contrast=100&image_c"+giCH_Curr+gstrProfile+"_contrastpercent=" + TmpContrast,
					cache: false
				});
			}
		});
	}

	if (bSaturation)
	{
		TmpSaturation = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_saturationpercent"), 10);
		$("#saturationValue").html(TmpSaturation + "%");
		$("#saturationSlider div.ui-slider-handle").attr("title", TmpSaturation);
		$("#saturationSlider").slider(
		{
			min: 0,
			max: 100,
			animate: true,
			value: TmpSaturation,
			slide: function(event, ui)
			{
				$("#saturationValue").html(ui.value + "%");
			},
			change: function(event, ui)
			{
				$("#saturationSlider div.ui-slider-handle").attr("title", ui.value);
				TmpSaturation = ui.value;
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "image_c"+giCH_Curr+gstrProfile+"_saturation=100&image_c"+giCH_Curr+gstrProfile+"_saturationpercent=" + TmpSaturation,
					cache: false
				});
			}
		});
	}

	if (bSharpness)
	{
		TmpSharpness = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_sharpnesspercent"), 10);
		$("#sharpnessValue").html(TmpSharpness + "%");
		$("#sharpnessSlider div.ui-slider-handle").attr("title", TmpSharpness);
		$("#sharpnessSlider").slider(
		{
			min: 0,
			max: 100,
			animate: true,
			value: TmpSharpness,
			slide: function(event, ui)
			{
				$("#sharpnessValue").html(ui.value + "%");
			},
			change: function(event, ui)
			{
				$("#sharpnessSlider div.ui-slider-handle").attr("title", ui.value);
				TmpSharpness = ui.value;
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "image_c"+giCH_Curr+gstrProfile+"_sharpness=100&image_c"+giCH_Curr+gstrProfile+"_sharpnesspercent=" + TmpSharpness,
					cache: false
				});
			}
		});
	}

	//Gamma curve
	if (bGammaCurve)
	{
		TmpGammaCurve = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_gammacurve"), 10);
		LastGammaCurve = TmpGammaCurve;
		if (gaiGammaCurveSteps[giMinGammaCurveIdx] > LastGammaCurve)
		{
			LastGammaCurve = gaiGammaCurveSteps[giMinGammaCurveIdx];
		}

		$(document.getElementById("gammaSwitch")).children().each(
			function()
			{
				if (0 == TmpGammaCurve && "optimize" == this.value)
				{	
					this.selected = true;
				}
				else if (0 != TmpGammaCurve && "manual" == this.value)
				{
					this.selected = true;
				}
			}
		);

		if (0 == TmpGammaCurve)
		{
			document.getElementById("gammacurveManualBlock").style.display = "none";
		}
		else
		{
			document.getElementById("gammacurveManualBlock").style.display = "table-row";
		}

		$("#gammacurveValue").html(parseFloat(LastGammaCurve)/100);
		$("#gammacurveSlider div.ui-slider-handle").attr("title", LastGammaCurve);
		$("#gammacurveSlider").slider(
		{
			min: giMinGammaCurveIdx,
			max: gaiGammaCurveSteps.length - 1,
			animate: true,
			value: $.inArray(LastGammaCurve, gaiGammaCurveSteps),
			slide: function(event, ui)
			{
				$("#gammacurveValue").html(parseFloat(gaiGammaCurveSteps[ui.value])/100);
			},
			change: function(event, ui)
			{
				$("#gammacurveSlider div.ui-slider-handle").attr("title", gaiGammaCurveSteps[ui.value]);
				if (TmpGammaCurve != 0)
				{
					TmpGammaCurve = gaiGammaCurveSteps[ui.value];
					LastGammaCurve = gaiGammaCurveSteps[ui.value];
				}
				$.ajax({
					type: "POST",
					url: "/cgi-bin/admin/setparam.cgi",
					data: "image_c"+giCH_Curr+gstrProfile+"_gammacurve=" + TmpGammaCurve,
					cache: false
				});

				$("#gammacurveSlider").children().removeAttr('title');
			}
		});

		$("#gammacurveSlider").children().removeAttr('title');

		//WDRPro/WDRC affect
		if (bWDRPro || bWDREnhanced)
		{
			if (bWDROnGammaDisabled || bWDRCOnGammaDisabled)
			{
				document.getElementById("gammacurveControl").disabled = "disabled";
				document.getElementById("gammacurveSlider").disabled = "disabled";
			}

		}
		else
		{
			document.getElementById("gammacurveControl").disabled = "";
			document.getElementById("gammacurveSlider").disabled = "";
		}

	}

	//Defog
	if (bDefog)
	{
		TmpDefog = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_defog_mode"), 10);
		if (TmpDefog == 1)
		{
			document.getElementById("defog_enable").checked = true;
			if (bDefogStr == true)
			{
				document.getElementById("defog_strength_slider").style.display = "block";
			}
			else
			{
				document.getElementById("defog_strength_slider").style.display = "none";
			}
			//switchDefogUI_MsgCheck(true);
			if (bDefogOnContrastHidden)
			{
				document.getElementById("contrastControl").style.display = "none";
			}
		}
		else
		{
			document.getElementById("defog_enable").checked = false;
			document.getElementById("defog_strength_slider").style.display = "none";
			//switchDefogUI_MsgCheck(false);
			if (bDefogOnContrastHidden)
			{
				document.getElementById("contrastControl").style.display = "block";
			}
		}

		if (bDefogStr)
		{
			TmpDefogStr = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_defog_strength"), 10);
			
			var DefogStrUI = mappingStrengthUI(TmpDefogStr, TmpDefogSupportLevel, TmpDefogStep);

			$("#defog_adjust_slider_handle" ).slider({
				min: 1,
				max: 100,
				step: TmpDefogStep,
				animate: true,
				value: DefogStrUI,
				slide: function(event, ui)
				{
					//$("#speedlevel_adjust_fix").html(ui.value);
				},
				change: function(event, ui)
				{
					TmpDefogStr = ui.value;

					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "image_c"+giCH_Curr+gstrProfile+"_defog_strength="+TmpDefogStr,
						async: false,
						cache: false
					});
				}	
			});
		}

		//AE affect
		if (bExposureMode)
		{
			if (bAEImpactDefogDisabled)
			{
				if ($("#defog_enable").is(":checked"))
				{
					$("#defog_enable").attr("checked",false).triggerHandler("click");
				}
				$("#defog_enable").attr('disabled','disabled');
				
				//switchDefogUI_MsgCheck(false);
			}
		}
	}

	//DNR
	if (bDNR)
	{
		TmpDNRMode = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_dnr_mode"), 10);
		if (1 == TmpDNRMode)
		{
			document.getElementById("dnr_enableInput").checked = true;
			document.getElementById("dnr_strengthControl").style.display = "block";
		}
		else
		{
			document.getElementById("dnr_enableInput").checked = false;
			document.getElementById("dnr_strengthControl").style.display = "none";
		}

		TmpDNRStr = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_dnr_strength"), 10);
		if (TmpDNRStr <= 33)
		{
			TmpDNRStr = 1;
		}
		else if (TmpDNRStr <= 66)
		{
			TmpDNRStr = 50;
		}
		else
		{
			TmpDNRStr = 100;
		}

		$(document.getElementById("dnr_strengthSelect")).children().each(
			function()
			{
				if (this.value == TmpDNRStr)
				{	
					this.selected = true;
				}
			}
		);
	}

	//EIS/DIS/OIS
	if (bISSupport)
	{
		TmpISStatus = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_mode"), 10);
		if (TmpISStatus == 1)
		{
			document.getElementById("IS_enable").checked = true;
			if (bISStr == true)
			{
				document.getElementById("IS_strength_slider").style.display = "block";
			}
			else
			{
				document.getElementById("IS_strength_slider").style.display = "none";
			}
			switchISUI(true);
		}
		else
		{
			document.getElementById("IS_enable").checked = false;
			document.getElementById("IS_strength_slider").style.display = "none";
			switchISUI(false);
		}

		if (bISStr)
		{
			TmpISStr = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_strength"), 10);
			
			var ISStrUI = mappingStrengthUI(TmpISStr, TmpISSupportLevel, TmpISStep);

			$("#IS_adjust_slider_handle" ).slider({
				min: 1,
				max: 100,
				step: TmpISStep,
				animate: true,
				value: ISStrUI,
				slide: function(event, ui)
				{
					//$("#speedlevel_adjust_fix").html(ui.value);
				},
				change: function(event, ui)
				{
					TmpISStr = ui.value;

					$.ajax({
						type: "POST",
						url: "/cgi-bin/admin/setparam.cgi",
						data: "image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_strength="+TmpISStr,
						async: false,
						cache: false
					});
				}	
			});
		}
	}

	//EIS
	if (bEIS)
	{
		bEISEnabled = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_eis"), 10);
		if (bEISEnabled)
		{
			document.getElementById("enableeis").checked = true;
		}
		else
		{
			document.getElementById("enableeis").checked = false;
		}
	}

	//Scene mode
	if (bScene)
	{
		bSceneModeEnabled = parseInt(eval("image_c"+giCH_Curr+gstrProfile+"_scene_enable"), 10);
		if (bSceneModeEnabled)
		{
			document.getElementById("scene_enable").checked = true;
			document.getElementById("scene_mode").style.display = "block";
		}
		else
		{
			document.getElementById("scene_enable").checked = false;
			document.getElementById("scene_mode").style.display = "none";
		}
		
		$(document.getElementById("switch_scene_mode")).removeOption(/./);
		
		var supportType = eval("capability_image_c"+giCH_Curr+"_scenemode_supporttype").split(",");
		for (i = 0; i < supportType.length; i++)
		{
			$(document.getElementById("switch_scene_mode")).addOption(supportType[i], translator(supportType[i]), true);
		}
		
		TmpSceneMode = eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode");
		findScenemodeImpact();

		$(document.getElementById("switch_scene_mode")).children().each(
			function()
			{
				if (eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode") == this.value)
				{	
					this.selected = true;
				}
			}
		);
		
		if (bSceneModeEnabled)
		{
			if (bSceneModeOnMinexposureHidden)
			{
				//warning messages
				//waiting for the spec
			}
			if (bSceneModeOnMingainHidden)
			{
				//warning messages
				//waiting for the spec
			}
			if (bSceneModeOnMinexposureHidden && bSceneModeOnMingainHidden)
			{
				//warning messages
				//waiting for the spec
			}
			if (bSceneModeOn3dnrUnchanged)
			{
				document.getElementById("dnrControl").disabled = "disabled";
			}
		}
		else
		{
			if (bSceneModeOn3dnrUnchanged)
			{
				document.getElementById("dnrControl").disabled = "";
			}
		}
	}
}

function gotNewRBGain()
{
	if (WBHttpRequestObject.readyState == 4 && WBHttpRequestObject.status == 200)
	{
		eval(WBHttpRequestObject.responseText);
		TmpRGain = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_rgain"), 10);
		TmpBGain = parseInt(eval("videoin_c"+giCH_Curr+gstrProfile+"_bgain"), 10);

		$("#rgain_adjust_slider_handle").slider('value', TmpRGain);
		$("#rgain_adjust_slider_handle div.ui-slider-handle").attr("title", TmpRGain);
		$("#rgain_curValue").html(TmpRGain + "%");
		$("#bgain_adjust_slider_handle").slider('value', TmpBGain);
		$("#bgain_adjust_slider_handle div.ui-slider-handle").attr("title", TmpBGain);
		$("#bgain_curValue").html(TmpBGain + "%");
		document.getElementById("RGain").style.display = "block";
		document.getElementById("BGain").style.display = "block";

		delete WBHttpRequestObject;
	}

	bRefreshGain = false;
}

function changeWB(mode)
{
	TmpWBMode = mode;

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "videoin_c"+giCH_Curr+gstrProfile+"_whitebalance=" + mode,
		cache: false
	});

	if ("rbgain" == mode)
	{
		if (bRefreshGain)
		{
			if (window.XMLHttpRequest)
			{
				WBHttpRequestObject = new XMLHttpRequest();
			}
			else if (window.ActiveXObject)
			{
				WBHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
			}
			WBHttpRequestObject.onreadystatechange = gotNewRBGain;

			WBHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?videoin_c"+giCH_Curr+gstrProfile+"_rgain&videoin_c"+giCH_Curr+gstrProfile+"_bgain", true);
		        WBHttpRequestObject.setRequestHeader("If-Modified-Since","0");
		        WBHttpRequestObject.send(null);
		}
		else
		{
			document.getElementById("RGain").style.display = "block";
			document.getElementById("BGain").style.display = "block";
		}
		//$('#wbSelect option[value="auto"]').css('color','black');
	}
	else
	{
		document.getElementById("RGain").style.display = "none";
		document.getElementById("BGain").style.display = "none";
	}

	/*
	if ("auto" == mode)
	{
		if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("manual") != -1)
		{
			document.getElementById("wbButton").style.display = "block";
			$('#wbSelect option[value="auto"]').css('color','black');

			$("#on").css("background-position", "0px 0px").hover
			(
				function(){$(this).css("background-position", "0px -20px");},
				function(){$(this).css("background-position", "0px 0px");}
			);
			$("#off").unbind('mouseenter').unbind('mouseleave').css("background-position", "-48px -40px");
		}
	}
	else
	{
		document.getElementById("wbButton").style.display = "none";
	}
	resetWBSelectColor();
	*/
}

function ChangeWBButton(bOn)
{
	if (1 == bOn)
	{
		//document.getElementById("wbSelect").disabled = true;
		$('#wbSelect option[value="auto"]').css('color','grey');
		TmpWBFixOn = true;
		TmpWBMode = "manual";
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/setparam.cgi",
			data: "videoin_c"+giCH_Curr+gstrProfile+"_whitebalance=manual",
			cache: false
		});

		$("#on").unbind('mouseenter').unbind('mouseleave').css("background-position", "0px -40px");
		$("#off").css("background-position", "-48px 0px").hover
		(
			function(){$(this).css("background-position", "-48px -20px");},
			function(){$(this).css("background-position", "-48px 0px");}
		);

		bRefreshGain = true;
	}
	else
	{
		//document.getElementById("wbSelect").disabled = false;
		$('#wbSelect option[value="auto"]').css('color','black');
		TmpWBFixOn = false;
		TmpWBMode = "auto";
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/setparam.cgi",
			data: "videoin_c"+giCH_Curr+gstrProfile+"_whitebalance=auto",
			cache: false
		});

		$("#on").css("background-position", "0px 0px").hover
		(
			function(){$(this).css("background-position", "0px -20px");},
			function(){$(this).css("background-position", "0px 0px");}
		);
		$("#off").unbind('mouseenter').unbind('mouseleave').css("background-position", "-48px -40px");

		bRefreshGain = false;
	}

	resetWBSelectColor();
}

function gammaSwitch(opt)
{
	if ("optimize" == opt)
	{
		document.getElementById("gammacurveManualBlock").style.display = "none";

		TmpGammaCurve = 0;
	}
	else
	{
		document.getElementById("gammacurveManualBlock").style.display = "table-row";

		TmpGammaCurve = LastGammaCurve;
		if (gaiGammaCurveSteps[giMinGammaCurveIdx] > TmpGammaCurve)
		{
			TmpGammaCurve = gaiGammaCurveSteps[giMinGammaCurveIdx];
			LastGammaCurve = gaiGammaCurveSteps[giMinGammaCurveIdx];
		}
		$("#gammacurveSlider").val($.inArray(TmpGammaCurve, gaiGammaCurveSteps));
		$("#gammacurveSlider").slider("refresh");
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_gammacurve=" + TmpGammaCurve,
		cache: false
	});
}

function setLowLightMode(checked)
{
	if (false == checked)
	{
		TmpLowLightMode = 0;
	}
	else
	{
		TmpLowLightMode = 1;
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_lowlightmode="+TmpLowLightMode,
		cache: false
	});
}

function switchDefogUI_MsgCheck(defogOn)
{
	if (defogOn)
	{
		if(bDefogOnWDRProUnchanged && bWDRPro)
		{
			//warning messages
			//waiting for the spec
		}

		if(bDefogOnWDRProDisabled && bWDRPro)
		{
			//warning messages
			//waiting for the spec
		}
		
		if(bDefogOnWDRCUnchanged && bWDREnhanced)
		{
			if(!confirm(translator("wdrc_will_be_gray_warning_message")))
			{
				return false;
			}
		}
		
		if(bDefogOnContrastHidden)
		{
			if(!confirm("Contrast will be disabled. Do you want to continue?"))
			{
				return false;
			}
		}
	}
	else
	{
		if(bDefogOnWDRProUnchanged && bWDRPro)
		{
			//warning messages
			//waiting for the spec
		}

		if(bDefogOnWDRProDisabled && bWDRPro)
		{
			//warning messages
			//waiting for the spec
		}

		if (bAEImpactDefogDisabled && bExposureMode)
		{
			//warning messages
			//waiting for the spec
		}
	}
	return true;
}

function updateDefog(defogOn)
{
	if (false == switchDefogUI_MsgCheck(defogOn))
	{
		if (true == defogOn)
		{
			document.getElementById("defog_enable").checked = false;
		}
		else
		{
			document.getElementById("defog_enable").checked = true;
		}
		return;
	}

	if (defogOn)
	{
		TmpDefog = 1;
		if (bDefogStr == true)
		{
			document.getElementById("defog_strength_slider").style.display = "block";
		}
		
		if (bDefogOnContrastHidden)
		{
			document.getElementById("contrastControl").style.display = "none";
		}
	}
	else
	{
		TmpDefog = 0;
		if (bDefogStr == true)
		{
			document.getElementById("defog_strength_slider").style.display = "none";
		}
		
		if (bDefogOnContrastHidden)
		{
			document.getElementById("contrastControl").style.display = "block";
		}
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_defog_mode="+TmpDefog,
		async: false,
		cache: false
	});
}

function changeDNRMode(checked)
{
	if (false == checked)
	{
		TmpDNRMode = 0;
		document.getElementById("dnr_strengthControl").style.display = "none";
	}
	else
	{
		TmpDNRMode = 1;
		document.getElementById("dnr_strengthControl").style.display = "block";
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_dnr_mode="+TmpDNRMode,
		cache: false
	});
}

function setDNRStr(str)
{
	TmpDNRStr = str;
	
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_dnr_strength="+TmpDNRStr,
		cache: false
	});
}

function switchISUI(ISOn)
{
	if (ISOn)
	{
	}
	else
	{
	}
}

function switchISUI_MsgCheck(ISOn)
{
	if (ISOn)
	{		
		if(bISOnRotationHidden)
		{
			if(!confirm("Video rotation will be disabled after enable EIS. Do you want to continue?"))
			{
				return false;
			}
		}
	}
	return true;
}

function updateIS(ISOn)
{
	if (false == switchISUI_MsgCheck(ISOn))
	{
		if (true == ISOn)
		{
			document.getElementById("IS_enable").checked = false;
		}
		else
		{
			document.getElementById("IS_enable").checked = true;
		}
		return;
	}
	
	if (ISOn)
	{
		TmpISStatus = 1;
		if (bISStr == true)
		{
			document.getElementById("IS_strength_slider").style.display = "block";
		}
	}
	else
	{
		TmpISStatus = 0;
		if (bISStr == true)
		{
			document.getElementById("IS_strength_slider").style.display = "none";
		}
	}

	switchISUI(ISOn);

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_mode="+TmpISStatus,
		async: false,
		cache: false
	});
}

function setEIS(checked)
{
	if (false == checked)
	{
		bEISEnabled = 0;
	}
	else
	{
		bEISEnabled = 1;
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: "image_c"+giCH_Curr+gstrProfile+"_eis="+bEISEnabled,
		cache: false
	});
}

function enableSceneMode(checked)
{
	var SceneParams = "";
	if (false == checked)
	{
		bSceneModeEnabled = 0;
		document.getElementById("scene_mode").style.display = "none";
	}
	else
	{
		bSceneModeEnabled = 1;
		document.getElementById("scene_mode").style.display = "block";
	}

	TmpSceneMode = eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode");
	findScenemodeImpact();
	
	if (bSceneModeOnDefaultMaxexposure)
	{
		if (bSceneModeEnabled)
		{
			SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxexposure=" + eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxexposure") + "&";
			TmpSceneMaxexposure = eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxexposure");
		}
		else
		{
			SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxexposure=" + eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure") + "&";
			TmpSceneMaxexposure = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure");
		}
	}
	
	if (bSceneModeOnDefaultMaxgain)
	{
		if (bSceneModeEnabled)
		{
			SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxgain=" + eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxgain") + "&";
			TmpSceneMaxgain = eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxgain");
		}
		else
		{
			SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxgain=" + eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain") + "&";
			TmpSceneMaxgain = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain");
		}
	}

	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: SceneParams + "image_c"+giCH_Curr+gstrProfile+"_scene_enable="+bSceneModeEnabled,
		cache: false
	});
	
	if (bSceneModeEnabled)
	{
		if (bSceneModeOnMinexposureHidden)
		{
			//warning messages
			//waiting for the spec
		}
		if (bSceneModeOnMingainHidden)
		{
			//warning messages
			//waiting for the spec
		}
		if (bSceneModeOnMinexposureHidden && bSceneModeOnMingainHidden)
		{
			//warning messages
			//waiting for the spec
		}
		if (bSceneModeOn3dnrUnchanged)
		{
			document.getElementById("dnrControl").disabled = "disabled";
		}
	}
	else
	{
		if (bSceneModeOn3dnrUnchanged)
		{
			document.getElementById("dnrControl").disabled = "";
		}
	}
}

function setSceneMode(mode)
{
	var SceneParams = "";
	
	TmpSceneMode = mode;
	findScenemodeImpact();
	
	if (bSceneModeOnDefaultMaxexposure)
	{
		SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxexposure=" + eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxexposure") + "&";
		TmpSceneMaxexposure = eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxexposure");
	}
	else
	{
		SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxexposure=" + eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure") + "&";
		TmpSceneMaxexposure = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure");
	}
	
	if (bSceneModeOnDefaultMaxgain)
	{
		SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxgain=" + eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxgain") + "&";
		TmpSceneMaxgain = eval("capability_image_c"+giCH_Curr+"_scenemode_"+TmpSceneMode+"_defaultmaxgain");
	}
	else
	{
		SceneParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxgain=" + eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain") + "&";
		TmpSceneMaxgain = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain");
	}
	
	$.ajax({
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: SceneParams + "image_c"+giCH_Curr+gstrProfile+"_scene_mode="+TmpSceneMode,
		cache: false
	});
	
	if (bSceneModeOn3dnrUnchanged)
	{
		document.getElementById("dnrControl").disabled = "disabled";
	}
	else
	{
		document.getElementById("dnrControl").disabled = "";
	}
}

function RestoreSettingAPI()
{

	var restoreParams = "";

	if (giProfileIdx == 0 && bExitNormalLight)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+"_profile_i0_enable=" + eval("image_c"+giCH_Curr+"_profile_i0_enable") + "&";
	}
	
	if (giProfileIdx == 1 && bExitProfile)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+"_profile_i0_enable=" + eval("image_c"+giCH_Curr+"_profile_i0_enable") + "&";
		restoreParams = restoreParams + "image_c"+giCH_Curr+"_profile_i0_policy=" + eval("image_c"+giCH_Curr+"_profile_i0_policy") + "&";
		restoreParams = restoreParams + "image_c"+giCH_Curr+"_profile_i0_begintime=" + eval("image_c"+giCH_Curr+"_profile_i0_begintime") + "&";
		restoreParams = restoreParams + "image_c"+giCH_Curr+"_profile_i0_endtime=" + eval("image_c"+giCH_Curr+"_profile_i0_endtime") + "&";
	}

	if (bBrightness)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_brightness=100&image_c"+giCH_Curr+gstrProfile+"_brightnesspercent="+ eval("image_c"+giCH_Curr+gstrProfile+"_brightnesspercent") +"&";
	}

	if (bContrast)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_contrast=100&image_c"+giCH_Curr+gstrProfile+"_contrastpercent="+ eval("image_c"+giCH_Curr+gstrProfile+"_contrastpercent") +"&";
	}

	if (bSaturation)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_saturation=100&image_c"+giCH_Curr+gstrProfile+"_saturationpercent="+ eval("image_c"+giCH_Curr+gstrProfile+"_saturationpercent") +"&";
	}

	if (bSharpness)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_sharpness=100&image_c"+giCH_Curr+gstrProfile+"_sharpnesspercent="+ eval("image_c"+giCH_Curr+gstrProfile+"_sharpnesspercent") +"&";
	}

	if (bDefog)
	{
		restoreParams = restoreParams +"image_c"+giCH_Curr+gstrProfile+"_defog_mode="+eval("image_c"+giCH_Curr+gstrProfile+"_defog_mode")+"&";
		restoreParams = restoreParams +"image_c"+giCH_Curr+gstrProfile+"_defog_strength="+eval("image_c"+giCH_Curr+gstrProfile+"_defog_strength")+"&";
	}

	if (bDNR)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_dnr_mode="+ eval("image_c"+giCH_Curr+gstrProfile+"_dnr_mode") + "&image_c"+giCH_Curr+gstrProfile+"_dnr_strength="+ eval("image_c"+giCH_Curr+gstrProfile+"_dnr_strength") + "&";
	}

	if (bWhiteBalance)
	{
		var wbmode = eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance");
		
		if (wbmode == "manual")
		{
			restoreParams = restoreParams + "image_c"+giCH_Curr+"_restoreatwb=1" + "&";
			// May need to restore rgainkeep, bgainkeep, ggainkeep
		}

		restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_whitebalance="+ wbmode + "&";

		if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("rbgain") != -1)
		{
			if (wbmode != "manual")
			{
				restoreParams = restoreParams + "videoin_c"+giCH_Curr+gstrProfile+"_rgain="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_rgain") + "&videoin_c"+giCH_Curr+gstrProfile+"_bgain="+ eval("videoin_c"+giCH_Curr+gstrProfile+"_bgain") + "&";
			}
		}
		
	}

	if (bGammaCurve)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_gammacurve="+ eval("image_c"+giCH_Curr+gstrProfile+"_gammacurve") + "&";
	}

	if (bISSupport)
	{
		restoreParams = restoreParams +"image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_mode="+eval("image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_mode")+"&";
	}
	
	if (bEIS)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_eis="+ eval("image_c"+giCH_Curr+gstrProfile+"_eis") + "&";
	}

	if (bScene)
	{
		restoreParams = restoreParams + "image_c"+giCH_Curr+gstrProfile+"_scene_enable="+ eval("image_c"+giCH_Curr+gstrProfile+"_scene_enable") + "&image_c"+giCH_Curr+gstrProfile+"_scene_mode="+ eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode") + "&";

		restoreParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxexposure=" + eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure") + "&";
		TmpSceneMaxexposure = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure");
	
		restoreParams += "videoin_c"+giCH_Curr+gstrProfile+"_maxgain=" + eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain") + "&";
		TmpSceneMaxgain = eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain");
	}
	

	$.ajax({
	async: false,
		type: "POST",
		url: "/cgi-bin/admin/setparam.cgi",
		data: restoreParams,
		cache: false
	});

}

function SaveButton()
{
	if(checkvalue())
	{
		return -1;
	}
	if (giProfileIdx == 0)
	{
		eval("image_c"+giCH_Curr+"_profile_i0_enable='"+TmpNormalLightEnable+"'");
	}
	if (giProfileIdx == 1)
	{
		eval("image_c"+giCH_Curr+"_profile_i0_enable='"+TmpProfileEnable+"'");
		eval("image_c"+giCH_Curr+"_profile_i0_policy='"+TmpPolicy+"'");
		eval("image_c"+giCH_Curr+"_profile_i0_begintime='"+TmpBeginTime+"'");
		eval("image_c"+giCH_Curr+"_profile_i0_endtime='"+TmpEndTime+"'");
	}

	if (bBrightness)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_brightnesspercent='"+TmpBrightness+"'");
	}

	if (bContrast)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_contrastpercent='"+TmpContrast+"'");
	}

	if (bSaturation)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_saturationpercent='"+TmpSaturation+"'");
	}

	if (bSharpness)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_sharpnesspercent='"+TmpSharpness+"'");
	}

	if (bDefog)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_defog_mode='"+TmpDefog+"'");
		eval("image_c"+giCH_Curr+gstrProfile+"_defog_strength='"+TmpDefogStr+"'");
	}

	if (bDNR)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_dnr_mode='"+TmpDNRMode+"'");
		eval("image_c"+giCH_Curr+gstrProfile+"_dnr_strength='"+TmpDNRStr+"'");
	}

	if (bWhiteBalance)
	{
		eval("videoin_c"+giCH_Curr+gstrProfile+"_whitebalance='"+TmpWBMode+"'");
		
		if (eval("capability_image_c"+giCH_Curr+"_wbmode").search("rbgain") != -1)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_rgain='"+TmpRGain+"'");
			eval("videoin_c"+giCH_Curr+gstrProfile+"_bgain='"+TmpBGain+"'");
			
			
		}
	}

	if (bGammaCurve)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_gammacurve='"+TmpGammaCurve+"'");
	}

	if (bISSupport)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_"+TmpISMode+"_mode='"+TmpISStatus+"'");
	}
	
	if (bEIS)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_eis='"+bEISEnabled+"'");
	}

	if (bScene)
	{
		eval("image_c"+giCH_Curr+gstrProfile+"_scene_enable='"+bSceneModeEnabled+"'");
		eval("image_c"+giCH_Curr+gstrProfile+"_scene_mode='"+TmpSceneMode+"'");
		
		if (bSceneModeOnDefaultMaxexposure)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_maxexposure='"+TmpSceneMaxexposure+"'");
		}
		
		if (bSceneModeOnDefaultMaxgain)
		{
			eval("videoin_c"+giCH_Curr+gstrProfile+"_maxgain='"+TmpSceneMaxgain+"'");
		}
	}
	
	RestoreSettingAPI();
}

function RestoreButton()
{
	RestoreSettingUI();
	RestoreSettingAPI();
}

function RestoreSetting()
{
	bExitNormalLight = true;
	bExitProfile = true;
	RestoreSettingAPI();
}

