﻿var input_title = new Array(100);

var XMLHttpRequestObject = false;
if (window.XMLHttpRequest)
	XMLHttpRequestObject = new XMLHttpRequest();
else if (window.ActiveXObject)
	XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
XMLHttpRequestObject.onreadystatechange = receiveparam;

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?wireless", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
}

function loadvaluedone()
{

	if(wireless_encrypt == "none")
	{
		wireless_encrypt = 0;
	}
	else if(wireless_encrypt == "wep")
	{
		wireless_encrypt = 1;
	}
	else if(wireless_encrypt == "wpa")
	{
		wireless_encrypt = 2;
	}
	else if(wireless_encrypt == "wpa2")
	{
		wireless_encrypt = 3;
	}

	var form = document.forms[0];
	form.wireless_ssid.value = unescape(wireless_ssid);
	form.wireless_key1.value = unescape(wireless_key1);
	form.wireless_key2.value = unescape(wireless_key2);
	form.wireless_key3.value = unescape(wireless_key3);
	form.wireless_key4.value = unescape(wireless_key4);
	form.wireless_presharedkey.value = unescape(wireless_presharedkey);
	form.wireless_encrypt.selectedIndex = wireless_encrypt;
	form.wireless_keyselect.selectedIndex = unescape(wireless_keyselect) - 1;
	form.wireless_keyselect.value = unescape(wireless_keyselect);
	//showMode();
	showSecuMode(document.forms[0].wireless_encrypt.selectedIndex);
//    showWEPkey(unescape(wireless_keyselect));
	
	// Refresh jQuery Mobile UI elements
	refreshSelMenu()
	refreshRadioBtn();
	
	// Show page after all value are loaded
	$('#wireless_settings').show();
    if ( $('#ssid').val() != "default")
	{
		$('#security').hide();//leslie
		$('#keyformat').hide();//leslie
	}
	else
	{
		$('#site_survey').trigger('click');		
	}
}

function showMode()
{
	showSecuMode(document.forms[0].wireless_encrypt.selectedIndex);
	// Refresh jQuery Mobile UI elements
	refreshSelMenu()
	refreshRadioBtn();
}

function showWEPkey(wepkeyIndex)
{
	if(wepkeyIndex == 1)
	{
			$('#key1').show();	
			$('#key2').hide();	
			$('#key3').hide();	
			$('#key4').hide();	
	}
	else if(wepkeyIndex == 2)
	{
			$('#key1').hide();
			$('#key2').show();
			$('#key3').hide();
			$('#key4').hide();
	}
	else if(wepkeyIndex == 3)
	{
			$('#key1').hide();	
			$('#key2').hide();	
			$('#key3').show();	
			$('#key4').hide();	
	}
	else if(wepkeyIndex == 4)
	{
			$('#key1').hide();	
			$('#key2').hide();	
			$('#key3').hide();	
			$('#key4').show();	
	}
}

function showSecuMode(wlanIndex)
{
	if (wlanIndex == 0)
	{
		$('#wep_mode').hide();	
		$('#wpa_mode').hide();
	}
	else if (wlanIndex == 1)
	{
		$('#wep_mode').show();
		$('#wpa_mode').hide();
		$('#divkeylength').hide();
		$('#divkeyformat').hide();
		showWEPkey(document.forms[0].wireless_keyselect.value);
	}
	else if (wlanIndex >= 2)
	{
		$('#wep_mode').hide();
		$('#wpa_mode').show();
	}
}

function refreshSelMenu()
{
	$('#encrypt').selectmenu('refresh');
	$('#keyselect').selectmenu('refresh');
	//$("#authmode").selectmenu('refresh');
	//$("#keylength").selectmenu('refresh');
	//$("#keyformat").selectmenu('refresh');
	//$("#algorithm").selectmenu('refresh');
}

function refreshRadioBtn()
{
	// Algorithm
	if (wireless_algorithm == 'AES')
		$('input[name="wireless_algorithm"]:nth(0)').attr('checked',true).checkboxradio('refresh');
	else // TKIP
		$('input[name="wireless_algorithm"]:nth(1)').attr('checked',true).checkboxradio('refresh');
	
	// WEP authentication mode
	if (wireless_authmode == 'OPEN')
		$('input[name="wireless_authmode"]:nth(0)').attr('checked',true).checkboxradio('refresh');
	else // 128
		$('input[name="wireless_authmode"]:nth(1)').attr('checked',true).checkboxradio('refresh');
	
	// WEP key length
	if (wireless_keylength == '64')
		$('input[name="wireless_keylength"]:nth(0)').attr('checked',true).checkboxradio('refresh');
	else // 128
		$('input[name="wireless_keylength"]:nth(1)').attr('checked',true).checkboxradio('refresh');
	
	// WEP key format
	if (wireless_keyformat == 'HEX')
		$('input[name="wireless_keyformat"]:nth(0)').attr('checked',true).checkboxradio('refresh');
	else // ASCII
		$('input[name="wireless_keyformat"]:nth(1)').attr('checked',true).checkboxradio('refresh');
	
	
//    $('input[name="wireless_keyselect"]:nth(' + eval(wireless_keyselect - 1) + ')').attr('checked',true).checkboxradio('refresh');
}

function site_survey()
{
	$('#instruction').html('<h5 style="text-align:center">Searching nearby AP, please wait... <img src="/css/images/ajax-loader.gif" width="20px" height="20px"></h5>');
	$('#sitesurvey_result').html('');
	$('#sitesurvey_header').html('');
	
	$.ajax({
		type: 'GET',
		cache: false,
		url: '/cgi-bin/admin/site_survey.cgi',
		//password: "admin",
		success: function(response){
			siteSurveySucceed(response);
		},
		error: function(){
			siteSurveyFail();
		}
	});	
}

function siteSurveySucceed(response)
{
	$('#instruction').html('');
	$('#sitesurvey_header').html('Select your AP');
	
	showResult(response);
}

function siteSurveyFail()
{
	alert('Search failed.');
}

function showResult(sitesurvey_result)
{
	eval(sitesurvey_result);
	sortResult();
	
	var htmlstr = "";
	var tmpSecurity = '';
	
	for (var i = 0; i <= result.length; i++)
	{	
		if ( i == result.length)
		{
			htmlstr += '<li>';
			htmlstr += '<a href="#wireless_settings" onclick="fillUpWLANSettings(-1)"><h3>Others...</h3>';
			htmlstr += '</a></li>'
		}
		else
		{
			if (result[i][1] >= 80)			StrengthColor = '#01B101'; // green
			else if (result[i][1] >= 75)	StrengthColor = '#3AC600';
			else if (result[i][1] >= 70)	StrengthColor = '#74C600';
			else if (result[i][1] >= 65)	StrengthColor = '#86C100';
			else if (result[i][1] >= 60)	StrengthColor = '#A7C601';
			else if (result[i][1] >= 55)	StrengthColor = '#DE9E01';
			else if (result[i][1] >= 50)	StrengthColor = '#DF7401';
			else if (result[i][1] >= 45)	StrengthColor = '#DF3A01';
			else 					StrengthColor = '#DF0101'; // red

			if (result[i][2] == 'None')
			{
				tmpSecurity = 'No security';
			}
			else
			{
				tmpSecurity = result[i][2];
			}
			htmlstr += '<li>';
			htmlstr += '<a href="#wireless_settings" onclick="fillUpWLANSettings(' + i + ')"><h3>' + result[i][0] + '</h3>';
			htmlstr += '<span class="ui-li-count"><font color='+StrengthColor+'>' + result[i][1] + '%</font></span>';
			htmlstr += '<p>' + tmpSecurity + '</p>';
			htmlstr += '</a></li>'
		}
	}
	$('#sitesurvey_result').html(htmlstr);
	$('#sitesurvey_result').listview('refresh');	
}

function sortResult()
{
	// Sort by SSID for removing duplicated SSIDs
	result.sort(function(a,b) {
		a = a[0];
		b = b[0];

		return (a.toLowerCase() == b.toLowerCase() ? 0 : (a.toLowerCase() < b.toLowerCase() ? -1 : 1))
	});
	
	// Remove duplicated SSIDs (the one with smaller signal level will be removed)
	for (var i = 0; i < result.length - 1; i++)
	{
		if (result[i][0] == result[i+1][0])
		{
			var tmp = result[i][1] < result[i+1][1] ? i : i + 1;
			result.splice(tmp, 1);
		}
	}
	
	// Sort by signal strength
	result.sort(function(a,b) {
		return parseInt(b[1],10) - parseInt(a[1],10);
	});
}

function fillUpWLANSettings(APIndex)
{
	if (APIndex == -1)
	{
		$('#ssid').val("");
		$('#encrypt').val(3); //WPA2
		$('input[name="wireless_algorithm"]:nth(0)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_algorithm"]:nth(1)').prop('checked',false).checkboxradio('refresh');
		$('#presharedkey').val("");
		$('#security').show();
		$('#keyformat').show();
		return ;
	}
	var encryptionStr = result[APIndex][2];
	var encryptionValue;
	var algorithm;
	
	var algorithmSelIndex;
	
	if (encryptionStr.match('WPA2'))
	{
		encryptionValue = 3;
	}
	else if (encryptionStr.match('WPA'))
	{
		encryptionValue = 2;
	}
	else if (encryptionStr.match('WEP'))
	{
		encryptionValue = 1;
	}
	else
	{
		encryptionValue = 0;
	}
	
	if (encryptionStr.match('TKIP'))
	{
		algorithm = 'TKIP';
		//algorithmSelIndex = 1;
	}
	else if (encryptionStr.match('AES'))
	{
		algorithm = 'AES';
		//algorithmSelIndex = 0;
	}
	
	// Fill up settings
	$('#ssid').val(result[APIndex][0]);
	$('#encrypt').val(encryptionValue);
	$('#security').hide();//leslie
	$('#keyformat').hide();//leslie

	
	if (algorithm == 'AES')
	{
		$('input[name="wireless_algorithm"]:nth(0)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_algorithm"]:nth(1)').prop('checked',false).checkboxradio('refresh');
	}
	else // TKIP
	{
		$('input[name="wireless_algorithm"]:nth(1)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_algorithm"]:nth(0)').prop('checked',false).checkboxradio('refresh');
	}
	
	// Refresh UI
	showSecuMode(document.forms[0].wireless_encrypt.selectedIndex);
	refreshSelMenu();
}

function receiveparam()
{	
	if (XMLHttpRequestObject.readyState == 4 && XMLHttpRequestObject.status == 200)
	{
		eval(XMLHttpRequestObject.responseText);
		if(typeof(receivedone)=="function")
			receivedone();
		loadvalue();
		if(typeof(loadvaluedone)=="function")
			loadvaluedone();

	}
}

function loadvalue()
{
	var input = document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
	{
		input_title[i]=input[i].title;
		title = input[i].title.split(",");
		if(title[0]=="param")
		{			
			if(input[i].type=="text" || input[i].type=="password")
				eval("input["+i+"].value="+input[i].name);
			else if(input[i].type=="hidden")
			{
				eval("input["+i+"].value="+input[i].name);
				if(eval("typeof(input["+(i+1)+"])")!="undefined")
				{
					if(input[i+1].type=="checkbox")
					{
						if(input[i].value=="0")
							input[i+1].checked=0;
						else
							input[i+1].checked=1;
					}
				}
			}
			else if(input[i].type=="radio")
			{
				eval("value="+input[i].name);
				if (input[i].value == value)
				{
					input[i].checked = true;
				}
			}
			input[i].title="";
		}
		else if(title[0]=="param_chk")
		{
			input[i].title="";
		}
	}
	
	var input = document.getElementsByTagName("select");
	for (var i = 0; i < input.length; i++)
	{
		title = input[i].title.split(",");
		if(title[0]=="param")
		{
			eval("value="+input[i].name);
			for (j = 0; j < input[i].length; j ++)
			{			
				if (input[i].options[j].value == value)
				{
					input[i].options[j].selected = true;
					break;
				}
			}
			input[i].title="";
		}
	}

	var input = document.getElementsByTagName("span");
	for (var i = 0; i < input.length; i++)
	{	
		title = input[i].title.split(",");
		if(title[0]=="param")
		{
			if(eval("typeof("+input[i].innerHTML+")")!="undefined")
			{
				eval("value="+input[i].innerHTML);
				input[i].innerHTML=value;
				input[i].innerHTML=unescape(input[i].innerHTML);
			}
			input[i].title="";
		}
	}
	return 0;
}

function submitform()
{
	if (checkvalue())
	{
		return -1;
	}
	else if (NetConfirm())
	{
		return -1;
	}
	else
	{
		document.wireless.wireless_ssid.value = escape(document.wireless.wireless_ssid.value);
		document.wireless.wireless_key1.value = escape(document.wireless.wireless_key1.value);
		document.wireless.wireless_key2.value = escape(document.wireless.wireless_key2.value);
		document.wireless.wireless_key3.value = escape(document.wireless.wireless_key3.value);
		document.wireless.wireless_key4.value = escape(document.wireless.wireless_key4.value);
		document.wireless.wireless_presharedkey.value = escape(document.wireless.wireless_presharedkey.value);
		window.open("/setup/wireless/wireless_guide.html", "","scrollbars=yes, status=yes");
		document.forms[0].submit();
		setTimeout('connect_ap()', 1000);
		
	}
}

function connect_ap()
{
	$.get("/cgi-bin/admin/connect_ap.cgi");
//    alert("Connecting to your AP....please refer to your quick installation guide to proceed with the next step.");
//    showNotificationAP(80);
}

function NetConfirm()
{
	var wl = document.wireless;

	if (wl.wireless_encrypt.selectedIndex == 1)
	{
		if(checkkey(eval("wl.wireless_key"+wl.wireless_keyselect.value)) < 0)
		{
			return -1;
		}
	}
	else if (wl.wireless_encrypt.selectedIndex > 1)
	{
		if (checkWPAKey() < 0)
			return -1;
	}
}

function checkHex(instr)
{
	for(i=0; i<instr.value.length; i++)
	{
		var c = instr.value.charAt(i);
		if (!((c>='0'&& c<='9')||(c>='A' && c<='F')||(c>='a' && c<='f')))
		{
			alert("Invalid hex");
			instr.focus();
			instr.select();
			return -1;
		}
	}
}
function checkkey(instr)
{
	var i;
  	var iKeyBytes = getKeyLength();
	
	if (instr.value.length == 10) //HEX 64bit
	{ 
		if (checkHex(instr) < 0)
		{
			return -1;
		}
		$('input[name="wireless_keylength"]:nth(0)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_keylength"]:nth(1)').prop('checked',false).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(0)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(1)').prop('checked',false).checkboxradio('refresh');
	}
	else if (instr.value.length == 26) //HEX 128bit
	{
		if (checkHex(instr) < 0)
		{
			return -1;
		}
		$('input[name="wireless_keylength"]:nth(0)').prop('checked',false).checkboxradio('refresh');
		$('input[name="wireless_keylength"]:nth(1)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(0)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(1)').prop('checked',false).checkboxradio('refresh');
	}
	else if (instr.value.length == 5) //ASCII, 64bit
	{
		$('input[name="wireless_keylength"]:nth(0)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_keylength"]:nth(1)').prop('checked',false).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(0)').prop('checked',false).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(1)').prop('checked',true).checkboxradio('refresh');
	}
	else if (instr.value.length == 13) //ASCII, 128bit
	{
		$('input[name="wireless_keylength"]:nth(0)').prop('checked',false).checkboxradio('refresh');
		$('input[name="wireless_keylength"]:nth(1)').prop('checked',true).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(0)').prop('checked',false).checkboxradio('refresh');
		$('input[name="wireless_keyformat"]:nth(1)').prop('checked',true).checkboxradio('refresh');
	}
	else
	{
  		alert("Please enter exactly 5 or 10 or 13 or 26 characters");
   		instr.focus();
        instr.select();  		
  		return -1;
	}
}

function checkWPAKey()
{
	var wpak = document.wireless.wireless_presharedkey;
	if (wpak.value.length < 8)
	{
	    alert("Pre-shared key must be 8~63 characters or 64 hex-characters.");
		wpak.focus();
		wpak.select();
		return -1;
	}
	if (wpak.value.length == 64)
	{
		for (i=0; i<wpak.value.length; i++)
		{
	    	var c = wpak.value.charAt(i);
	    	if (!((c>='0'&& c<='9')||(c>='A' && c<='F')||(c>='a' && c<='f')))
	    	{
	    		alert("Invalid hex");
		   		wpak.focus();
		        wpak.select();
	      		return -1;
	      	}
		}
	}
}
/*
// For select menu 
function getKeyLength()
{
	var index = document.forms[0].wireless_keylength.selectedIndex;

	if (index == 0)	return 5;
	if (index == 1)	return 13;
	if (index == 2)	return 29;
}
*/

// For radio button
function getKeyLength()
{
	
	var radioButtons = document.getElementsByName("wireless_keylength");

	for (var i = 0; i < radioButtons.length; i++)
	{
		if (radioButtons[i].checked)
		{
			index = i;
			break;
		}
	}
	
	if (index == 0)	return 5;
	if (index == 1)	return 13;
	if (index == 2)	return 29;
}

function CheckEmptyString(input)
{
	if(input.value=="")
	{
		alert("This field cannot be empty");
		input.focus();
		input.select();
		return -1;
	}
	return 0;
}

function checkvalue()
{
	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
	{	
		if (input_title[i] == undefined)
		{
			continue;
		}
		title = input_title[i].split(",");
		if(title[0]=="param" || title[0]=="param_chk")
		{
			if(input[i].type=="text" || input[i].type=="password")
			{
				if(title[1]=="empty")
				{
					if(CheckEmptyString(input[i]))
						return -1;	
				}
			}
		}
	}
	return 0;
}

//function countdownAP(bTimeuUpRenew)
//{
//    var board = document.getElementById("progress_bar");
//    count --;
//    $.ajax({
//        url: "/cgi-bin/admin/check_ap_connect.cgi",
//        async: false,
//        cache: false,
//        success: function(data){
//            console.log("data="+data);
//            if ( !isNaN(data) )
//            {
//                if (parseInt(data) > percent_temp)
//                {
//                    for (var i =0; i < (parseInt(data) - percent_temp); i++)
//                    {
//                        board.value = board.value + "|";
//                    }
//                    percent_temp = parseInt(data);
//                }	
//            }
//            else
//            {
//                alert(translator(data));
//                bFormatErr = true;	
//            }
//            return;
//        }
//    });
//    if ((count < 0) && (true == bTimeuUpRenew))
//    {
//        parent.location.reload();
//    }
//    else
//    {
//        board.value = board.value + "|";
//        setTimeout("countdownAP(" + bTimeuUpRenew + ")", intervel);
//    }
//}

//function showNotificationAP(wait_time)
//{
//    var bTimeuUpRenew = true;

//    document.getElementById("notification").style.display = "block";
//    count = 100;
//    intervel = wait_time * 1000 / count;
//    countdownAP(bTimeuUpRenew);
//}
