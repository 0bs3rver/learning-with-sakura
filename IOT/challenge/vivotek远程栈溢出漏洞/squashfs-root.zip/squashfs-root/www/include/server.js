added=0;
var g_onlyNas = false;
function loadCurrentSetting()
{
	bSaved = false;
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?event&server&recording", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("server");
	loadlanguage();
	
	var lan=getCookie("lan");
	var Russian_index=9;
	//Russian languages's special case
	if (lan==Russian_index)
	{
		$("#save_server").css("width","130px");
	}
	
	/* Get index, g_onlyNas variables by following statement
	 * This page called by application or recording page */
	eval(location.search.toString().slice(1));
	
	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	var input=document.getElementsByTagName("select");
	for (var i = 0; i < input.length; i++)
		input[i].name=input[i].name.toString().replace("index", "i"+index);	
}

function receivedone()
{
	eval("using=(event_i0_enable==1?eval(event_i0_action_server_i" + index + "_enable):0) \
	||(event_i1_enable==1?eval(event_i1_action_server_i" + index + "_enable):0) \
	||(event_i2_enable==1?eval(event_i2_action_server_i" + index + "_enable):0) \
	||(recording_i0_enable==1&&recording_i0_dest=="+ index +") \
	||(recording_i1_enable==1&&recording_i1_dest=="+ index +")");
	var input = document.getElementsByTagName("input");
	if (using != 0) {
		for (var i = 0; i < input.length; i++) 
			input[i].disabled = true;
		$("#btn_close").attr("disabled",false);	
	}
}

function initPage(newServer)
{
	var hideArray = new Array("emailChild", "httpChild", "ftpChild", "nsChild");
	var openArray = new Array();
	var serverType = eval('server_i' + index + '_type');

	if (g_onlyNas)
	{
		document.getElementById("ns").checked = true;
		openArray.push("nsChild");
		
		//document.getElementById("email").disabled = true;
		//document.getElementById("http").disabled = true;
		//document.getElementById("ftp").disabled = true;
		$("#emailParent").css("display", "none");
		$("#httpParent").css("display", "none");
		$("#ftpParent").css("display", "none");
	}
	else
	{
		if (newServer)
		{
			openArray.push("emailChild");
		}
		else
		{
			openArray.push(serverType + "Child");
		}
	}
    
    
   jQuery.each(hideArray, function(i) { 
     $("#" + hideArray[i]).css("display","none");
   });
   jQuery.each(openArray, function(i) { 
     $("#" + openArray[i]).css("display","block");
   });       
}

function loadvaluedone()
{
	if(document.getElementsByTagName("input")[0].value=="")
	{
		document.forms[0].reset();	
		added=1;
	}
	ns=0;
	if(server_i0_type=="ns"&&server_i0_name!="")
		ns++;
	if(server_i1_type=="ns"&&server_i1_name!="")
		ns++;
	if(server_i2_type=="ns"&&server_i2_name!="")
		ns++;
	if(server_i3_type=="ns"&&server_i3_name!="")
		ns++;
	if(server_i4_type=="ns"&&server_i4_name!="")
		ns++;
		
	var serverType = eval('server_i'+index+'_type');
	
	if(ns>0 && serverType!="ns")
	{
		document.getElementById("ns").disabled=true;
	}
	
	var serverName = eval('server_i'+index+'_name');
	
	if (serverName != "")
	{
		document.getElementById("serverName").disabled=true;
	}

	var aServerType = initServerType();
	for (i = 0; i < aServerType.length; i++)
	{
		if (document.getElementById(aServerType[i] + "_username").value != "")
		{
			document.getElementById(aServerType[i] + "_passwd").value = getDefaultPassword();
		}
	}
	
	initPage(added);
}

function checkname()
{
	if(CheckEmptyString(document.getElementsByTagName("input")[0]) == -1)
	{
        	return -1;
    	}

	if (checkEmptyServer() == -1)
	{
		return -1;
	}

	if((document.getElementsByTagName("input")[0].value==server_i0_name ||
		document.getElementsByTagName("input")[0].value==server_i1_name ||
		document.getElementsByTagName("input")[0].value==server_i2_name ||
		document.getElementsByTagName("input")[0].value==server_i3_name ||
		document.getElementsByTagName("input")[0].value==server_i4_name) && added==1)
	{
		alert(translator("the_name_has_already_existed"));
		return -1;
	}

	return 0;
}

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	else
	{
		if(checkname())
			return -1;

		if(checkPasswordVal() != 0)
			return -1;

		bSaved = true;
		$.post(document.forms[0].action, $(document.forms[0]).serialize(), function(){
			parent.location += '&step=3';
			parent.location.reload();
		});
	}
}

function testserver()
{
	form0=document.forms[0];
	form1=document.forms[1];
	if(checkvalue())
	{
		return -1;
	}
	else
	{
		form1.groupidx.value=index;
		if(document.getElementById("email").checked)
		{
			form1.type.value="email";
			form1.senderemail.value=document.getElementById("email_senderemail").value;
			form1.recipientemail.value=document.getElementById("email_recipientemail").value;
			form1.address.value=document.getElementById("email_address").value;
			form1.sslmode.value=document.getElementById("email_sslmode").value;
			form1.port.value=document.getElementById("email_port").value;
			form1.username.value=document.getElementById("email_username").value;
			form1.passwd.value=document.getElementById("email_passwd").value;
		}
		else if(document.getElementById("ftp").checked)
		{
			form1.type.value="ftp";
			form1.address.value=document.getElementById("ftp_address").value;
			form1.port.value=document.getElementById("ftp_port").value;
			form1.username.value=document.getElementById("ftp_username").value;
			form1.passwd.value=document.getElementById("ftp_passwd").value;
			form1.location.value=document.getElementById("ftp_location").value;
			form1.passive.value=document.getElementById("ftp_passive").value;
		}
		else if(document.getElementById("http").checked)
		{
			form1.type.value="http";
			form1.url.value=document.getElementById("http_url").value;
			form1.username.value=document.getElementById("http_username").value;
			form1.passwd.value=document.getElementById("http_passwd").value;
		}
		else
		{
			form1.type.value="ns";
			form1.location.value=document.getElementById("ns_location").value;
			form1.workgroup.value=document.getElementById("ns_workgroup").value;
			form1.username.value=document.getElementById("ns_username").value;
			form1.passwd.value=document.getElementById("ns_passwd").value;
		}
			
		if (checkEmptyServer() == -1)
		{
			return -1;
		}
		var passwordval = form1.passwd.value;
		form1.passwd.disabled = false;
		if(checkDefaultPassword(passwordval) != 0)
		{
			form1.passwd.disabled = true;
		}
		window.open("", "testserver", "height=100,width=400");
		form1.target="testserver";
		document.forms[1].submit();
	}
}
function checkEmptyServer()
{
	form1=document.forms[1]; 
    
    	if(document.getElementById("email").checked)
    	{
		if ((document.getElementById("email_address").value == "") || (document.getElementById("email_recipientemail").value == ""))
		{
			alert(translator("field_cannot_be_empty"));
			return -1;
		}

		if (checkInString(document.getElementById("email_senderemail")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("email_recipientemail")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("email_address")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("email_username")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("email_passwd")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("email_port")))
		{
			return -1;
		}

	    	return 0;
	}
	else if(document.getElementById("ftp").checked)  
	{
		if (document.getElementById("ftp_address").value == "")
	    	{
	        	alert(translator("field_cannot_be_empty"));
	        	return -1;
	    	}

		if (checkInString(document.getElementById("ftp_address")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ftp_port")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ftp_username")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ftp_passwd")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ftp_location")))
		{
			return -1;
		}

	    	return 0;
	}
    	else if(document.getElementById("http").checked)
    	{
		if (document.getElementById("http_url").value == "")
	    	{
	        	alert(translator("field_cannot_be_empty"));
	        	return -1;
	    	}

		if (checkInString(document.getElementById("http_url")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("http_username")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("http_passwd")))
		{
			return -1;
		}

	    	return 0;
	}
    	else
	{
		if (document.getElementById("ns_location").value == "")
	    	{
	        	alert(translator("field_cannot_be_empty"));
	        	return -1;
	    	}

		if (checkInString(document.getElementById("ns_location")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ns_workgroup")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ns_username")))
		{
			return -1;
		}
		if (checkInString(document.getElementById("ns_passwd")))
		{
			return -1;
		}

		return 0;
	}
}

function checkPasswordVal()
{
	var passwordval;
	var aServerType = initServerType();
	for (i = 0; i < aServerType.length; i++)
	{
		passwordval = document.getElementById(aServerType[i] + "_passwd").value;

		if(checkDefaultPassword(passwordval) != 0)
		{
			document.getElementById(aServerType[i] + "_passwd").disabled = true;
		}
	}
	return 0;
}

function initServerType()
{
	var aServerType = new Array("email", "ftp", "http", "ns");
	return aServerType;
}

