var MAX_PRESET_NAME = 40;
var MAX_3D_PRIVACY_MASK_COUNT = 24;

var TOP_REDUNDANCY_PIXEL = 20 //23;
var LEFT_REDUNDANCY_PIXEL = 3 //2;

var PLUGIN_SIZE_WIDTH = 320;
var PLUGIN_SIZE_HEIGHT = 180;

var MASK_MODE;
var CENTER_RESIZE = 0;
var ANY_WHERE = 1;

var g_bIs_Up = true; 
var g_bIs_Down = false;

var g_mask_W; 
var g_mask_H;
var g_mask_Left;
var g_mask_Top;

var g_check3dMaskResult = 0;
var g_CurrImageRotate = 0;
var giCH_Curr = 0;

function loadCurrentSetting()
{
	$("fieldset").addClass("tabs-fieldset");

	InstallPlugin();

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?privacymask3d", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("privacy_mask");
	loadlanguage();

	// Hide the pan, tilt button
	$('.btn_ptz_move').hide();
	document.getElementById("span_pan_speed").style.display = 'none';
	document.getElementById("span_tilt_speed").style.display = 'none';
	$('select[name="camctrl_c0_panspeed"]').hide();
	$('select[name="camctrl_c0_tiltspeed"]').hide();
	
	ShowPresetSelction("optical_zoom");
	ShowMaskSelection();
	checkImageRotation();
	(privacymask3d_c0_enable == 0) ? $("#maskpanel").slideUp() : $("#maskpanel").slideDown();

	showimage_innerHTML('12', 'showimageBlock', false, true, true, 0);
	
	setCookie('activatedmode', 'optical_zoom');

    if (bIsWinMSIE || ffversion >= 3)
	{
		gen3DPrivacyMaskWin();
    }

	initIZPtzPannel();
	
	if ( privacymask3d_c0_enable == "1" )
		EnablePrivacy(true);
		
	document.getElementById(PLUGIN_ID).ClickEventHandler = 0;

	if (document.delEditPMForm.sel_3dPMList.length > MAX_3D_PRIVACY_MASK_COUNT)
	{
		$("#add_pmbtn").attr("disabled", true);
	}
}

function gen3DPrivacyMaskWin()
{
	if (g_CurrImageRotate == 1)
	{
		$("#StreamContainer").addClass("StreamContainerStyleRotation");
	}
	else
	{
		$("#StreamContainer").addClass("StreamContainerStyle");
	}
	$("#StreamContainer").append('<div id="3DPMWindow" class="PMW_style" style="display:none"></div>');

	//initial PM Window by jQueryUI, enable resizable and draggable
	$('.PMW_style').resizable({
		containment: "#StreamContainer",
		handles: 'all',
		autoHide: true,
		minWidth: 30,
		minHeight: 30,
		maxWidth: PLUGIN_SIZE_WIDTH,
		maxHeight: PLUGIN_SIZE_HEIGHT,
		resize: function(e, ui)
		{
			if (MASK_MODE == CENTER_RESIZE)
			{
				ui.position.left = (PLUGIN_SIZE_WIDTH / 2) - (ui.size.width / 2) + LEFT_REDUNDANCY_PIXEL;
				ui.position.top  = (PLUGIN_SIZE_HEIGHT / 2) - (ui.size.height / 2) + TOP_REDUNDANCY_PIXEL;

				g_mask_W = ui.size.width ;
				g_mask_H = ui.size.height ;
				g_mask_Left = ui.position.left ;
				g_mask_Top = ui.position.top ;	
			}
			else
			{
				g_mask_W = ui.size.width ;
				g_mask_H = ui.size.height ;		
			}

		},
		stop: function(e, ui)
		{
            if ($(this).position().top < 20)
            {
            	$('#3DPMWindow').css("top",20);
            	g_mask_Top = 20;
            }
		
			// handle rotate
			if (g_CurrImageRotate == 1)
			{
				$("#PM_width_value").text(g_mask_H);
				$("#PM_height_value").text(g_mask_W);
				
				if ( eval("videoin_c"+giCH_Curr+"_rotate") == 90)
				{
					$("#PM_left_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
					$("#PM_top_value").text(PLUGIN_SIZE_WIDTH -(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2));
				}
				else if (eval("videoin_c"+giCH_Curr+"_rotate") == 270)
				{
					$("#PM_left_value").text(PLUGIN_SIZE_HEIGHT - (g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2));
					$("#PM_top_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
				}
			}
			else
			{	
				$("#PM_width_value").text(g_mask_W);
				$("#PM_height_value").text(g_mask_H);	
				$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
				$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
			}

		}
	})	
	.draggable({          
        cursor: 'move',  
        handle: "#StreamContainer",
        containment: "#StreamContainer",
		//containment: [3,23,320-80,240-48],
		drag: function(e, ui)
		{		
			g_mask_Left = ui.position.left ;
			g_mask_Top = ui.position.top ;	
			g_mask_W = ui.helper.width();
			g_mask_H = ui.helper.height();

			$('#3DPMWindow').css("left", ui.position.left);
			$('#3DPMWindow').css("top", ui.position.top);

		},
		stop: function(e, ui)
		{
            if ($(this).position().top < 20)
            {
               $('#3DPMWindow').css("top",20);
               g_mask_Top = 20;
			}

			if (g_CurrImageRotate == 1)
			{
				
				if ( eval("videoin_c"+giCH_Curr+"_rotate") == 90)
				{
					$("#PM_left_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
					$("#PM_top_value").text(PLUGIN_SIZE_WIDTH -(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2));
				}
				else if (eval("videoin_c"+giCH_Curr+"_rotate") == 270)
				{
					$("#PM_left_value").text(PLUGIN_SIZE_HEIGHT - (g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2));
					$("#PM_top_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
				}
			}
			else
			{
				$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
				$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);				
			}
		}
    }).attr("disabled",false);
}

function InitMaskMode()
{
	// IZ does not have CENTER_RESIZE mode
	MASK_MODE = ANY_WHERE;
	initCenterPMWindow();
}

function EnablePrivacy(bEnable)
{
	InitMaskMode();
	if ( bEnable )
	{
		$('#maskpanel').slideDown();
		//$('#3DPMWindow').show();
	}
	else
	{	
		$('#maskpanel').slideUp();
		$('#3DPMWindow').hide();
	} 
}

function submitform(a, b)
{
    updatecheck(a, b);
    document.forms["privacy"].submit();
}

function ShowMaskSelection()
{
	var maskSelObj = $("#sel_3dPMList");
	maskSelObj.removeOption(/./);

	maskSelObj.addOption("-1", translator("select_one"));

	for (var i = 0; i < MAX_3D_PRIVACY_MASK_COUNT; i++)
	{
		var MaskName = eval('privacymask3d_c0_win_i' + i + '_name');

		if (MaskName != "")
		{
			maskSelObj.addOption(MaskName, MaskName, false);
		}		
	}
}

function ShowSelectedPMWindow(selObj)		
{
	for (var i=0; i < selObj.options.length-1; i++)
	{
		if (selObj.options[i].selected) break;
	}

  	if (selObj.options[i].value == -1) return;

	// getmaskinfo: width, height, cx, cy	
	var getmaskinfoURL="/cgi-bin/admin/getpm3d.cgi?getmaskinfo=" + encodeURIComponent(selObj.options[i].text);

	$.ajax({
			cache: false,
			url: getmaskinfoURL,
			beforeSend: function () 
			{
				$('#3DPMWindow').hide();
			},
			success: function (response) 		
			{
				eval(response);

				// Store PM info			
				$("#PM_width_value").text(maskwidth);
				$("#PM_height_value").text(maskheight);	
				$("#PM_left_value").text(maskcx);
				$("#PM_top_value").text(maskcy);
				
				// Caculate coordinate of 3D privacy mask window 
				if (g_CurrImageRotate == 1)
				{
					g_mask_W = maskheight;
					g_mask_H = maskwidth;
					if ( eval("videoin_c"+giCH_Curr+"_rotate") == 90)
					{
						 g_mask_Left = PLUGIN_SIZE_WIDTH - maskcy - (maskheight/2) + LEFT_REDUNDANCY_PIXEL;
						 g_mask_Top = maskcx - (maskwidth/2) + TOP_REDUNDANCY_PIXEL;
					}
					else if ( eval("videoin_c"+giCH_Curr+"_rotate") == 270)
					{
						g_mask_Left = maskcy - (maskheight/2) + LEFT_REDUNDANCY_PIXEL;
						g_mask_Top = PLUGIN_SIZE_HEIGHT - maskcx - (maskwidth/2) + TOP_REDUNDANCY_PIXEL;
					}
				}
				else
				{
					g_mask_W = maskwidth;
					g_mask_H = maskheight;
					g_mask_Left = maskcx - (maskwidth/2) + LEFT_REDUNDANCY_PIXEL;
					g_mask_Top = maskcy - (maskheight/2) + TOP_REDUNDANCY_PIXEL;
				}

				// Generate 3DPMWindow
				$('#3DPMWindow').css("width", g_mask_W);
				$('#3DPMWindow').css("height",g_mask_H);
				$('#3DPMWindow').css("top", g_mask_Top);
				$('#3DPMWindow').css("left", g_mask_Left)
				$('#3DPMWindow').show();
				$('#3DPMWindow').draggable( 'enable' );
			}
	});
}

var tidPrivacy3d = null;
var waitRecall3d = 500;
function Recall3dPM(selObj)
{	
	ShowSelectedPMWindow(selObj);

	if (tidPrivacy3d != null) clearTimeout(tidPrivacy3d);
	tidPrivacy3d = setTimeout(function() 
	{
		for (var i=0; i < selObj.options.length-1; i++)
		{
			if (selObj.options[i].selected) break;
		}

  		if (selObj.options[i].value == -1) return;

  		ret_page.location.href='/cgi-bin/camctrl/recall.cgi?recall3d=' + encodeURIComponent(selObj.options[i].text);
	}, waitRecall3d);

}
/*
function ChangeMaskMode(selObj)
{
	// Select center resize
	if (selObj.options[0].selected)
	{
		MASK_MODE = CENTER_RESIZE;
		initCenterResizeMode();
		document.getElementById(PLUGIN_ID).ClickEventHandler=3;
	}
	else
	{
		MASK_MODE = ANY_WHERE;
		$('#3DPMWindow').draggable( 'enable' );
		document.getElementById(PLUGIN_ID).ClickEventHandler=0;
	}

}
*/
function initCenterPMWindow()
{
	var initWindow_W = 80;
	var initWindow_H = 48; 
	var initWindow_Top 	= (PLUGIN_SIZE_HEIGHT / 2) - (initWindow_H / 2) + TOP_REDUNDANCY_PIXEL;
	var initWindow_Left = (PLUGIN_SIZE_WIDTH / 2) - (initWindow_W / 2) + LEFT_REDUNDANCY_PIXEL;
	
	// Show center PMWindow
	$('#3DPMWindow').css("width", initWindow_W);
	$('#3DPMWindow').css("height", initWindow_H);
	$('#3DPMWindow').css("top", initWindow_Top);
	$('#3DPMWindow').css("left", initWindow_Left);
	$('#3DPMWindow').show();
	$('#3DPMWindow').draggable( 'enable' );
	
	g_mask_W = initWindow_W ;
	g_mask_H = initWindow_H ;
	g_mask_Left = initWindow_Left ;
	g_mask_Top = initWindow_Top ;

	// Because of center pmask window, not consider PLUGIN_SIZE_WIDTH and PLUGIN_SIZE_HEIGHT for image rotation
	if (g_CurrImageRotate == 1)
	{
		$("#PM_width_value").text(g_mask_H);
		$("#PM_height_value").text(g_mask_W);
		$("#PM_left_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
		$("#PM_top_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
	}
	else
	{
		$("#PM_width_value").text(g_mask_W);
		$("#PM_height_value").text(g_mask_H);	
		$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
		$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
	}
}

// add,edit,delete privacy mask
function submit3dPM(type)
{
	var addForm = document.addPMForm;
	var delEditForm = document.delEditPMForm;

	var sel3DPM = delEditForm.sel_3dPMList;
	var masknameObj = addForm.maskname;

	switch(type)
	{
		case 'add':
			if (false == modifyCheck_before (sel3DPM, masknameObj, type)) return false;

			var submitBtn = addForm.AddPMBtn;

			// adding preset location by AJAX
			var privacymaskURL;
			if (MASK_MODE == CENTER_RESIZE)
			{
				privacymaskURL =
				"/cgi-bin/admin/setpm3d.cgi?" +
				"method=add"                  +
				"&maskname="                  + encodeURIComponent(masknameObj.value) +
				"&maskheight="                + $("#PM_height_value").text() +
				"&maskwidth="                 + $("#PM_width_value").text() +
				"&videosize=320x180";
			}
			else
			{
				privacymaskURL =
				"/cgi-bin/admin/setpm3d.cgi?" +
				"method=add"                  +
				"&maskname="                  + encodeURIComponent(masknameObj.value) +
				"&maskheight="                + $("#PM_height_value").text() +
				"&maskwidth="                 + $("#PM_width_value").text() +
				"&maskcx="					  + $("#PM_left_value").text() +
				"&maskcy="					  + $("#PM_top_value").text()+
				"&videosize=320x180";
			}
			

			$.ajax({
				cache: false,
				url: privacymaskURL,
				beforeSend: function () 
				{
					$("#ajaxLoadIcon").show();
					$("#maskpanel :input").attr('disabled', true);
				},
				success: function (response) 
				{	
					check3dMaskResult(encodeURIComponent(masknameObj.value));
        			if (g_check3dMaskResult <= 0) 
					{
						alert(translator("no_more_privacy_mask_allowed_in_this_region"));
        			}
					else
					{
						$(sel3DPM).addOption(masknameObj.value, masknameObj.value, true);
					}

					masknameObj.value ="";
					$("#ajaxLoadIcon").fadeOut(1000, function() {
						$("#maskpanel :input").attr('disabled', false);
						modifyCheck_after(sel3DPM, type);
					});
				}
			});
			break;

		case 'edit':
		case 'delete':
			var selObj = sel3DPM;
			if (selObj.selectedIndex < 1)
			{
				return;
			}

			if ("edit" == type)
			{
                        	if (false == modifyCheck_before (sel3DPM, masknameObj, type)) return false;
			}

			var maskname = selObj.options[selObj.selectedIndex].text;
			var submitBtn = ("delete" == type) ? delEditForm.DeletePMBtn : delEditForm.EditPMBtn;
			var privacymaskURL;

			if (MASK_MODE == CENTER_RESIZE)
			{
				if (("edit" == type) && CountLength(masknameObj.value) > 0)
				{
                	privacymaskURL =
                	"/cgi-bin/admin/setpm3d.cgi?" +
                	"method="                     + type +
                	"&maskname="                  + encodeURIComponent(maskname) +
					"&maskrename="				  + encodeURIComponent(masknameObj.value) +
                	"&maskheight="                + $("#PM_height_value").text() +
                	"&maskwidth="                 + $("#PM_width_value").text() +
                	"&videosize=320x180";
				}
				else
				{
					privacymaskURL =
					"/cgi-bin/admin/setpm3d.cgi?" +
					"method="                     + type +
					"&maskname="                  + encodeURIComponent(maskname) +
					"&maskheight="                + $("#PM_height_value").text() +
					"&maskwidth="                 + $("#PM_width_value").text() +
					"&videosize=320x180";
				}
			}
			else
			{
            	if (("edit" == type) && CountLength(masknameObj.value) > 0)
               	{
                	privacymaskURL =
                	"/cgi-bin/admin/setpm3d.cgi?" +
                	"method="                     + type +
                	"&maskname="                  + encodeURIComponent(maskname) +
					"&maskrename="                + encodeURIComponent(masknameObj.value) +
                	"&maskheight="                + $("#PM_height_value").text() +
                	"&maskwidth="                 + $("#PM_width_value").text() +
                	"&maskcx="                    + $("#PM_left_value").text() +
                	"&maskcy="                    + $("#PM_top_value").text() +
                	"&videosize=320x180";
				}
				else
				{
					privacymaskURL =
					"/cgi-bin/admin/setpm3d.cgi?" +
					"method="                     + type +
					"&maskname="                  + encodeURIComponent(maskname) +
					"&maskheight="                + $("#PM_height_value").text() +
					"&maskwidth="                 + $("#PM_width_value").text() +
					"&maskcx="		      		  + $("#PM_left_value").text() +
					"&maskcy="		      		  + $("#PM_top_value").text() +
					"&videosize=320x180";
				}
			}


			$.ajax({
				cache: false,
				url: privacymaskURL,
				beforeSend: function () 
				{
					$("#ajaxLoadIcon2").show();
					$("#maskpanel :input").attr('disabled', true);
					selObj.disabled = true;
				},
				success: function (response) 
				{
					if ("delete" == type) 
					{
						$(sel3DPM).removeOption(maskname, true);
						selObj.selectedIndex = 0;
					}
					else
					{
							
						if (masknameObj.value)
						{
							check3dMaskResult(encodeURIComponent(masknameObj.value));
						}
						else
						{
							check3dMaskResult(encodeURIComponent(maskname));
						}

                        if (g_check3dMaskResult <= 0)
                        {
                        	alert(translator("no_more_privacy_mask_allowed_in_this_region"));
                        }
						else
						{
						
							if (masknameObj.value)
							{
								// rename it
								$(sel3DPM).removeOption(maskname, true);
								$(sel3DPM).addOption(masknameObj.value, masknameObj.value, true);
								for (var i = 0; i < sel3DPM.options.length; i++) 
								{
									if (sel3DPM.options[i].text == masknameObj.value) 
									{
										sel3DPM.selectedIndex = i;
									}
								}
								masknameObj.value ="";
							}
							
						}
					}

					$("#ajaxLoadIcon2").fadeOut(1000, function() {
						selObj.disabled = false;
						$("#maskpanel :input").attr('disabled', false);
						modifyCheck_after(sel3DPM, type);
					});
				}
			});
			break;

		default:
			break;
	}
}
//

function modifyCheck_before(sel3DPM, masknameObj, type)
{
	if ("add" == type)
	{
        if (CheckEmptyString(masknameObj) == -1) return false;

        if (sel3DPM.length > MAX_3D_PRIVACY_MASK_COUNT)
        {
        	$("#add_pmbtn").attr("disabled", true);
        	alert(translator("no_more_location_for_privacy_mask_24"));
        	return false;
        }
	}

    if (checkInString(masknameObj)) return false;

    if (CountLength(masknameObj.value) > MAX_PRESET_NAME)
    {
    	alert(translator("the_length_is_over_40_characters"));
    	return false;
    }

    for(var i = 0; i < sel3DPM.length; i++)
    {
    	if (masknameObj.value == sel3DPM.options[i].text)
    	{
        	alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
        	return false;
    	}
    }

	return true;
}

function modifyCheck_after(sel3DPM, type)
{
	if (("add" == type) && (sel3DPM.length > MAX_3D_PRIVACY_MASK_COUNT))
    {
    	$("#add_pmbtn").attr("disabled", true);
    }
	
	if (("delete" == type) && (sel3DPM.length <= MAX_3D_PRIVACY_MASK_COUNT))
	{
		$("#add_pmbtn").attr("disabled", false);
	}
}
//

function downcoordinates(event)
{	
	var clickType = event.button;
	
	if ((clickType == 1) && (MASK_MODE == ANY_WHERE))
	{
		g_bIs_Up = false; 
		g_bIs_Down = true;

		g_mask_Left = event.offsetX;
		g_mask_Top = event.offsetY;
		g_mask_W = 0;
		g_mask_H = 0;
		
		//$('#3DPMWindow').hide();
	}
	
}

function movecoordinates(event)
{
	var clickType = event.button; 
	
	if ((g_bIs_Down) && (clickType == 1)  && (MASK_MODE == ANY_WHERE))
	{
		if (g_CurrImageRotate == 1)
		{
			
			if (g_mask_Top < 20)
			{
				$('#3DPMWindow').css("top",20);
				g_mask_Top = 20;
			}
			else if (g_mask_Top > 340)
			{
				$('#3DPMWindow').css("top",340);
				g_mask_Top = 340;
			}
		
			if (g_mask_Left < 3)
			{
				$('#3DPMWindow').css("Left",3);
				g_mask_Left = 3;
			}
			else if (g_mask_Left > 183)
			{
				$('#3DPMWindow').css("Left",183);
				g_mask_Left = 183;	
			}
			
			var currentX = (event.offsetX > 183) ? 183 : event.offsetX;
			var currentY = (event.offsetY > 340) ? 340 : event.offsetY;
		}
		else 
		{
			if (g_mask_Top < 20)
			{
				$('#3DPMWindow').css("top",20);
				g_mask_Top = 20;
			}
			else if (g_mask_Top > 200)
			{
				$('#3DPMWindow').css("top",200);
				g_mask_Top = 200;
			}
		
			if (g_mask_Left < 3)
			{
				$('#3DPMWindow').css("Left",3);
				g_mask_Left = 3;
			}
			else if (g_mask_Left > 323)
			{
				$('#3DPMWindow').css("Left",323);
				g_mask_Left = 323;
			}

			//boundary check
			var currentX = (event.offsetX > 323) ? 323 : event.offsetX;
			var currentY = (event.offsetY > 200) ? 200 : event.offsetY;
		}

		g_mask_W = currentX - g_mask_Left ;
		g_mask_H = currentY - g_mask_Top ;
		if (g_mask_W >= 0 && g_mask_H >= 0)
		{	
			$('#3DPMWindow').css("height", g_mask_H );
			$('#3DPMWindow').css("width",  g_mask_W );
			$('#3DPMWindow').css("top", g_mask_Top );
			$('#3DPMWindow').css("left", g_mask_Left );
			$('#3DPMWindow').show();
			

			if (g_CurrImageRotate == 1)
			{
				// Exchange width and height
				$("#PM_width_value").text(g_mask_H);
				$("#PM_height_value").text(g_mask_W);
				
				if ( eval("videoin_c"+giCH_Curr+"_rotate") == 90)
				{
					$("#PM_left_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
					$("#PM_top_value").text(PLUGIN_SIZE_WIDTH -(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2));
				}
				else if (eval("videoin_c"+giCH_Curr+"_rotate") == 270)
				{
					$("#PM_left_value").text(PLUGIN_SIZE_HEIGHT - (g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2));
					$("#PM_top_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
				}
			}
			else
			{
				$("#PM_width_value").text(g_mask_W);
				$("#PM_height_value").text(g_mask_H);	
				$("#PM_left_value").text(g_mask_Left - LEFT_REDUNDANCY_PIXEL + g_mask_W / 2);
				$("#PM_top_value").text(g_mask_Top - TOP_REDUNDANCY_PIXEL + g_mask_H / 2);
			}
		}
	}		
}

function upcoordinates(event)
{
	var clickType = event.button;
	
	if ((clickType == 1) && (MASK_MODE == ANY_WHERE))
	{
		g_bIs_Up = true; 
		g_bIs_Down = false;
	}
}


function check3dMaskResult(privacyName) 
{
	g_check3dMaskResult = 0;
	url = "/cgi-bin/admin/getpm3d.cgi?getmaskaddresult=" + privacyName;
        XMLHttpRequestObject.onreadystatechange = function (){};
        XMLHttpRequestObject.open("GET", url, false);
        XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
        XMLHttpRequestObject.send(null);
        eval(XMLHttpRequestObject.responseText);
	g_check3dMaskResult = parseInt(maskaddresult);
}

function checkImageRotation()
{
	if ( eval("capability_videoin_c"+giCH_Curr+"_rotation") == 1)
	{
		if( eval("videoin_c"+giCH_Curr+"_rotate") == 90 || eval("videoin_c"+giCH_Curr+"_rotate") == 270)
		{	
			g_CurrImageRotate = 1;
			PLUGIN_SIZE_WIDTH = 180;
			PLUGIN_SIZE_HEIGHT = 320;
		}
		else
		{
			g_CurrImageRotate = 0;
		}
	}
}

var tidSubmitPresetPre = null;
var waitSlideLatency = 500;
function SubmitPreset(selObj)
{
	if (tidSubmitPresetPre != null) 
	{
		clearTimeout(tidSubmitPresetPre);
	}
       
	var ChannelNo = 0;
	tidSubmitPresetPre = setTimeout(function() 
	{
        var CGICmd='/cgi-bin/camctrl/recall.cgi?channel=' + ChannelNo + '&recall=' + encodeURIComponent($(selObj).selectedOptions().text());
        $.ajaxSetup({ cache: false, async: true});
        $.get(CGICmd)
        Log("Send: %s",CGICmd);
	}, waitSlideLatency);
}

function KeyPress(evt)
{
        var code = window.event?evt.keyCode:evt.which;
        if (code == 13)
        {
                return false;
        }
}

