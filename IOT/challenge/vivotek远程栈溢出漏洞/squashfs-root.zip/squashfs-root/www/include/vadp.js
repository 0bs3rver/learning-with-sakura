var VADP_MODULE_NUM = 10;
var stack_bottomright = {"dir1": "up", "dir2": "left", "firstpos1": 15, "firstpos2": 15};
var szNotifyTitle = "";
var avMLLangStr = "";
var command = "";
var webserver = "http://www.vivotek.com/VADP.aspx";
var bForceSaveSD = 0;
var VadpScheduleFlag = 0;
var smartsd_lifetime_rate = "";
var smartsd_spare_block_rate = "";

function UpdateCPULoading()
{
	var cpustring;
	var cpuparsestring = [];
	var xmlhttpcpu;

	if (document.getElementById("CpuloadChild").style.display == "none")
		return;

	if (window.XMLHttpRequest)
	{
		xmlhttpcpu = new XMLHttpRequest();
	}
	else
	{
		xmlhttpcpu = new ActiveXObject("Microsoft.XMLHTTP");
	}

	// execute the cgi to get the return value, using sync. mode
	xmlhttpcpu.open("GET", "/cgi-bin/admin/vadpctrl.cgi?cmd=cpuusage", false);
	xmlhttpcpu.setRequestHeader("If-Modified-Since", "0");
	xmlhttpcpu.send(null);
	cpustring = xmlhttpcpu.responseText;
	// $('#te').html(cpustring);

	cpuparsestring = cpustring.split("=");
	$('#cpuloading').text(cpuparsestring[1] + ' %');
}

function GetVadpVersion()
{
	var iRet;

	iRet = check4bit_verison(vadp_version, "1.3.2.0");

	// alert (iRet);
	if (ParamUndefinedOrZero(vadp_version)==false || iRet < 0)
	{
		//hide the schedule
		$("#button_schedule").hide();
	}

}

function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&capability_supportsd&capability_localstorage_smartsd&system_info_customlanguage", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	var cpustring;
	var cpuparsestring = [];
	var xmlhttpcpu;

	if (window.XMLHttpRequest)
	{
		xmlhttpcpu = new XMLHttpRequest();
	}
	else
	{
		xmlhttpcpu = new ActiveXObject("Microsoft.XMLHTTP");
	}

	// execute the cgi to get the return value, using sync. mode
	xmlhttpcpu.open("GET", "/cgi-bin/admin/vadpctrl.cgi?cmd=cpuusage", false);
	xmlhttpcpu.setRequestHeader("If-Modified-Since", "0");
	xmlhttpcpu.send(null);
	cpustring = xmlhttpcpu.responseText;
	// $('#te').html(cpustring);

	cpuparsestring = cpustring.split("=");
	$('#cpuloading').text(cpuparsestring[1] + ' %');


	if (bForceSaveSD)
	{
		$("#save2sd").attr("checked", true);
		$("#save2sd").hide();
		$("#save2title").hide();
		$("#StorageParent").hide();
		submitform(document.getElementsByName('vadp_module_save2sd')[0], document.getElementById('save2sd'));
	}

	GetVadpVersion();

	document.title = "Package management";
	loadlanguage();
	$("#vadp_schedule").hide(500);
}

// automatic to refresh the data
$(document).ready
(
	function()
	{
		setInterval
		(
			function()
			{
				UpdateCPULoading();
			}
			, 5000
		);
	}
);

function emptyFunc(){}

function handleXmlReturn(returnText)
{
	var searchTarget = command + "=ok";
	var bOK = returnText.search(searchTarget);
	var noSupportKeyWord = "does not support";
	var bNoSupport = returnText.search(noSupportKeyWord);

	if (bNoSupport < 0)
	{
		if (bOK < 0)
		{
			avMLLangStr = avMLLangStr + "failed";
		}
		else
		{
			avMLLangStr = avMLLangStr + "OK";
		}
	}
	else
	{
		avMLLangStr = "This operation is fail.<br>The function may not been implemented.<br>Please contact package provider.";
	}
}

function SendHttpRequest(queryStr, async)
{
	var xmlhttp;

	if (window.XMLHttpRequest)
	{
		xmlhttp = new XMLHttpRequest();
	}
	else
	{
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	if (xmlhttp.overrideMimeType)
	{
		xmlhttp.overrideMimeType('text/xml');
	}

	xmlhttp.onreadystatechange = function()
	{
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
		{
			switch (command)
			{
				case 'backup':
				case 'reload':
				case 'restore':
					handleXmlReturn(xmlhttp.responseText);
					break;
				case 'getparam':
					eval(xmlhttp.responseText);
					break;
				default:
					break;
			}
		}
	}

	xmlhttp.open("GET", queryStr, async);
	xmlhttp.setRequestHeader("If-Modified-Since","0");
	xmlhttp.send(null);
}

function deleteModule(getIndex)
{
	command = "remove";
	if (confirm(translator("do_you_want_del_vadp_module")))
	{
		var queryStr = "/cgi-bin/admin/vadpctrl.cgi?cmd=remove&idx=" + getIndex;
		SendHttpRequest(queryStr, false);
	}

	location.reload();
}

function updateRunStat(getIndex)
{
	command = "getparam";
	var queryStr = "/cgi-bin/admin/getparam.cgi?vadp_module_i" + getIndex + "_status";
	SendHttpRequest(queryStr, false);

	var new_status = eval('vadp_module_i' + getIndex + '_status');
	$("#vadp_module_i" + getIndex + "_status").text(translator(new_status));
}

function updateModuleList()
{
	var url_hostname = location.hostname;
	var url_host = location.host;
	var url_protocol = location.protocol;

	for (i = 0; i < VADP_MODULE_NUM; i++) 
	{
		var display_name = "";
		var module_name = eval('vadp_module_i' + i + '_name');
		var alias_name = eval('vadp_module_i' + i + '_extendedname');
		if (alias_name)
		{
			display_name = alias_name;
		}
		else
		{
			display_name = module_name;
		}

		if (module_name)
		{
			var module_url = eval('vadp_module_i' + i + '_url');
			var vendor_name = eval('vadp_module_i' + i + '_vendor');
			var vendor_url = eval('vadp_module_i' + i + '_vendorurl');
			var module_ver = eval('vadp_module_i' + i + '_version');
			var mod_status = eval('vadp_module_i' + i + '_status');
			var statmsg = eval('vadp_module_i' + i + '_statmsg');
			var license = eval('vadp_module_i' + i + '_license');
			var licmsg = eval('vadp_module_i' + i + '_licmsg');
			var path = eval('vadp_module_i' + i + '_path');
			var vvtklicensemec = eval('vadp_module_i' + i + '_vvtklicensemec');

			$('#module_list').append(""
				+ '<tr class="center" id="module_i' + i + '">'
				+ '<td width="15px"><div id="radio_i' + i + '"></div></td>'
				+ '<td width="192px"><div id="name_i' + i + '"></div></td>'
				+ '<td width="132px"><div id="vendor_i' + i + '"></div></td>'
				+ '<td width="80px"><span>' + module_ver + '</span></td>'
				+ '<td width="60px"><div id="status_i' + i + '"></div></td>'
				+ '<td width="65px"><div id="license_i' + i + '"></div></td>'
				+ '<td width="16px"><div id="path_i' + i + '"></div></td>'
				+ '<td width="15px"><div id="delete_i' + i + '"></div></td>'
				+ '</tr>');

			$('#radio_i'+ i).append('<input  name="module_select" onclick ="updateVadpSchedule()" type="radio" value="'+ i +'"/>');

			if (vvtklicensemec == "yes")
			{
				$('#vvtklicense_module_list').append($("<option></option>").attr("value", i).text(module_name));
			}

			if (module_url)
			{
				// Check the 1st char of string
				if (module_url.substring(0, 1) != ':')
				{
					module_url = url_protocol + "//" + url_host + "/" + module_url;
				}
				else
				{
					// Ex. http://192.168.1.1:5566
					module_url = url_protocol + "//" + url_hostname + module_url;
				}
				$('#name_i'+ i).append(""
					+ '<div><a href="' 
					+ module_url
					+ '"><span id="vadp_module_i' + i + '_name" title="'
					+ module_url
					+ '">'
					+ display_name
					+ '</span></a></div>');
			}
			else
			{
				$('#name_i'+ i).append(""
					+ '<div><span id="vadp_module_i' + i + '_name">'
					+ display_name
					+ '</span></div>');
			}

			if (vendor_url)
			{
				$('#vendor_i'+ i).append(""
					+ '<div><a href="'
					+ vendor_url
					+ '"><span id="vadp_module_i' + i + '_vendor" title="'
					+ vendor_url
					+ '">'
					+ vendor_name
					+ '</span></a></div>');
			}
			else
			{
				$('#vendor_i'+ i).append(""
					+ '<div><span id="vadp_module_i' + i + '_vendor">'
					+ vendor_name
					+ '</span></div>');
			}

			$('#status_i'+ i).append(""
				+ '<div><span id="vadp_module_i' + i + '_status" title="'
				+ statmsg
				+ '">'
				+ translator(mod_status)
				+ '</span></div>');

			if (license == "")
			{
				license = "N/A";
			}
			$('#license_i'+ i).append(""
				+ '<div style="width:65px"><span id="vadp_module_i' + i + '_license" title="'
				+ licmsg
				+ '">'
				+ license
				+ '</span></div>');

			if (path.indexOf("flash") >= 0)
			{
				$('#path_i'+ i).append('<img   src="/css/images/store_in_camera.png" style="margin-left:0px" title="Internal storage">');
			}
			else
			{
				$('#path_i'+ i).append('<img   src="/css/images/store_in_sd.png" style="margin-left:0px" title="SD card">');
			}

			$('#delete_i'+ i).append('<div><a class="ui-dialog-titlebar-vadp-close" style="margin-left:3px" href="javascript:deleteModule(' + i + ')" title="Delete '+ display_name +'"></a></div>');
		}
	}

	var listTotal = $('#vvtklicense_module_list > option').length;
	if (listTotal == 1)
	{
		$('#vvtklicense_module_list').prop('disabled', 'disabled');
		$('#email_usermail').prop('disabled', 'disabled');
		$('#email_passwd').prop('disabled', 'disabled');
		$('#country_list').prop('disabled', 'disabled');
		$('#vertical_list').prop('disabled', 'disabled');
		$('#confirmation_code').prop('disabled', 'disabled');
		$('#auto-install-btn').prop('disabled', 'disabled');
	}
}

function showVadpNumber()
{
	var vadpnum_string;

	if (vadp_number.length > 0)
	{
		vadpnum_string = vadp_number;
	}
	else
	{
		vadpnum_string = "<font color=red>An error occured with VADP number. Please reset the camera.</font>";
	}
	$('#vadpnumber').append("<input type=\"text\" id=\"vadpnum\" title=\"Press CTRL+C to copy\" size=\"48\" readonly=\"readonly\" style=\"text-align:center;margin:10px 0px 14px 0px;border:none;background-color:#E8E8E8 \" value=" + vadpnum_string + " />");

	$("#vadpnum").tooltip({  
		position: "center right",  
		//offset: [3, -13], 
		opacity: 0.85
	});

	$("#vadpnum").select(function(){
		var tooltip=$("#vadpnum").tooltip();
		tooltip.show();
	});

	// When press license tab, it will select vadp number automatically
	$(".tabs li").eq(1).click(function(){
		$("#vadpnum").trigger("select");
	});

	$("#vadpnum").click(function(){
		$("#vadpnum").select();
	}); 

	//Chrome's behavior is different from IE and Firefox
	if (navigator.userAgent.match("Chrome") != null)
	{
		$("#adv_vadp").click(function(){
			var tooltip=$("#vadpnum").tooltip();
			tooltip.hide();
		});
	}
}

function checkNetwork()
{
	var request_str = "vadpnumber=";
	var request_URL = webserver + "?" + request_str + "&callback=?";

	$.ajax({
		type: "GET",
		dataType: "jsonp",
		url: request_URL,
		timeout: 2000,
		error: function(jqXHR, textStatus, errorThrown) {
			$("#no-internet").show();
			$("#vvtklicense_module_list").attr('disabled', 'disabled');
			$("#email_usermail").attr('disabled', 'disabled');
			$("#email_passwd").attr('disabled', 'disabled');
			$("#country_list").attr('disabled', 'disabled');
			$("#vertical_list").attr('disabled', 'disabled');
			$("#auto-install-btn").attr('disabled', 'disabled');
		}
	});
}

function countryList()
{
	var countryfile = "country.html";

	var filecontent = $.ajax({
		url: countryfile,
		async: false
	}).responseText;

	var country_array = filecontent.split("\n");
	for(i = 0; i < country_array.length; i++)
	{
		$('#country_list').append($("<option></option>").attr("value", country_array[i]).text(country_array[i]));
	}
}

function verticalList()
{
	var verticalfile = "vertical.html";

	var filecontent = $.ajax({
		url: verticalfile,
		async: false
	}).responseText;

	var vertical_array = filecontent.split("\n");
	for(i = 0; i < vertical_array.length; i++)
	{
		$('#vertical_list').append($("<option></option>").attr("value", vertical_array[i]).text(vertical_array[i]));
	}
}

function loadvaluedone()
{
	if (0 == bForceSaveSD)
	{
		if (checkSupportSD() == false || disk_i0_cond != "ready")
		{
			$("#save2sd").hide();
			$("#save2title").hide();
			$("#save2sd").attr("checked", false);
			submitform(document.getElementsByName('vadp_module_save2sd')[0], document.getElementById('save2sd'));
			document.getElementById("Save2SDCard").style.display = "none";
			document.getElementById("SdStatParent").style.display = "none";
			document.getElementById("SdStatChild").style.display = "none";
			document.getElementById("SdUsageParent").style.display = "none";
			document.getElementById("SdUsageChild").style.display = "none";
		}
		else
		{
			$("#save2sd").show();
			eval("enabled=vadp_module_save2sd");
			if (enabled == '1')
			{
				$("#save2sd").attr("checked", true);
			}
			else
			{
				$("#save2sd").attr("checked", false);
			}
		}
	}
	
	if (ParamUndefinedOrZero("capability_localstorage_smartsd"))
	{
		document.getElementById("SdUsageParent").style.display = "none";
		document.getElementById("SdUsageChild").style.display = "none";
	}
	else
	{
		if( ParamUndefinedOrZero("smartsd_attached"))
		{
			document.getElementById("SdUsageParent").style.display = "none";
			document.getElementById("SdUsageChild").style.display = "none";
		}
	}

	updateModuleList();
	showVadpNumber();
	checkNetwork();
	countryList();
	verticalList();
}

function submitform(a, b)
{
	updatecheck(a, b);
	document.forms[0].submit();
}

var have_submit = false;

function checkUploadVadpFile()
{
	var form = document.uploadVadpFile;

	if (have_submit)
	{
		return -1;
	}

	if (bForceSaveSD)
	{
		if (checkSupportSD() == false || disk_i0_cond != "ready")
		{
			alert(translator("In this product, please insert SD card for package storage."));
			return -1;
		}
	}

	if (form.uploadVadp.value == "")
	{
		alert(translator("select_a_file_before_click_on_upload"));
		return -1;
	}

	have_submit = true;

	window.open("/setup/null.html", "testvadp", "height=220, width=500, scrollbars=yes");
	form.target="testvadp";

	form.submit();
}

function checkUploadVadpLicense()
{
	var form = document.VadpLicense;

	if (form.uploadVadpLicense.value == "") 
	{
		alert(translator("select_a_file_before_click_on_upload"));
		return -1;
	}

	form.submit();
}

function switchProcess(setAction)
{
	var bPNOTIFY = false;
	var modIndex = getCheckedValue(document.getElementsByName('module_select'));

	if (modIndex == "")
	{
		return -1;
	}

	var CurrentState = eval('vadp_module_i' + modIndex + '_status');
	var ModuleName = eval('vadp_module_i' + modIndex + '_name');

	command = setAction;
	switch (setAction)
	{
		case 'start':
			async = false;
			if (CurrentState == "off")
			{
				//command = 'start';
			}
			else if (CurrentState == "abnormal")
			{
				command = 'restart';
			}
			else if (CurrentState == "on")
			{
				command = "";
			}
			break;

		case 'stop':
			async = false;
			break;

		case 'backup':
			bPNOTIFY = true;
			async = false;
			szNotifyTitle = 'Backup module';
			avMLLangStr = 'Backup "' + ModuleName + '" ';
			break;

		case 'reload':
			bPNOTIFY = true;
			async = false;
			szNotifyTitle = 'Reload module';
			avMLLangStr = 'Reload "' + ModuleName + '" ';
			break;

		case 'restore':
			bPNOTIFY = true;
			async = false;
			command = 'restore';
			szNotifyTitle = 'Restore module';
			avMLLangStr = 'Restore "' + ModuleName + '" ';
			break;

		default:
			break;
	}

	if (command)
	{
		var queryStr = "/cgi-bin/admin/vadpctrl.cgi?cmd=" + command + "&idx=" + modIndex;
		SendHttpRequest(queryStr, async);
	}

	if (bPNOTIFY)
	{
		$.pnotify({
			pnotify_title: szNotifyTitle,
			pnotify_text: avMLLangStr,
			pnotify_notice_icon: 'ui-vadp-icon ui-vadp-icon-signal',
			pnotify_opacity: .8,
			pnotify_addclass: "stack-bottomright",
			pnotify_history: false,
			pnotify_stack: stack_bottomright
		});
	}

	switch (command)
	{
		case 'start':
			$("#vadp_module_i" + modIndex + "_status").text(translator("on"));
			setInterval(function() {
				updateRunStat(modIndex);
			}, 10000);
			break;
		case 'stop':
		case 'restart':
			location.reload();
			break;
		default:
			break;
	}
}

function listOrder(runOrder)
{
	var mod, module_name, orderList = "";

	if (runOrder.length == 0)
	{
		return translator("none");
	}

	mod = runOrder.split(',');

	for (i = 0; i < mod.length; i++)
	{
		module_name = eval('vadp_module_i' + mod[i] + '_name');
		orderList = orderList + '(' + mod[i] + ') ' + module_name + '<br>';
	}

	return orderList;
}

function updateSDStatus(param)
{
	if ("status" == param)
	{
		document.write("<span title=\"symbol\">"+ disk_i0_cond +"</span>");
	}
}

function checkSupportSD()
{
	var has_SD = true;
	if (typeof(capability_supportsd) == "undefined")
	{
		has_SD = true;
	}
	else if (capability_supportsd == "1")
	{
		has_SD = true;
	}
	else if (capability_supportsd == "0")
	{
		has_SD = false;
	}

	return has_SD;
}

function jsonp_callback(data)
{
	var result = data.Result;
	var output = data.Output;

	if(result == "Success" && output.length > 0)
	{
		licensekey = output;

		$.ajax({
			url: "/cgi-bin/admin/vadpctrl.cgi",
			data: {cmd: "uploadlicense", key: licensekey},
			async: false,
			cache: false,
			dataType: "html",
			error: function() {
				alert(translator("install_license_failed"));
			},
			success: function(returnData) {
				var searchinstallicense = "uploadlicense=ok";
				var searchupdatelicensestatus = "updatelicensestatus=ok";
				var retVal_searchinstallicense = returnData.search(searchinstallicense);
				var retVal_searchupdatelicensestatus = returnData.search(searchupdatelicensestatus);

				$( "#waiting" ).hide();
				if (retVal_searchinstallicense < 0)
				{
					alert("install_license_failed");
				}
				else
				{
					if (retVal_searchupdatelicensestatus < 0)
					{
						alert("Install license successfully, but update license status failed.");
					}
					else
					{
						alert(translator("install_license_successfully"));
					}
					location.reload();
				}
			}
		});
	}
	else if(result == "Failed" && output.length > 0)
	{
		var errormsg = output;
		$( "#waiting" ).hide();
		alert(errormsg);
		return -1
	}
	else
	{
		$( "#waiting" ).hide();
		alert(translator("install_license_failed"));
		return -1
	}
}

function checkAutoInstall()
{
	var vadpnum_string, module_name, module_vendor, module_version, user_email, email_pass, select_country, select_vertical;

	if (vadp_number.length > 0)
	{
		vadpnum_string = vadp_number;
	}
	else
	{
		alert(translator("error_with_vadp_number_please_reset_camera"));
		return -1;
	}

	var module_index = $("#vvtklicense_module_list").find(":selected").val();
	if(module_index == "default")
	{
		//alert(translator("select_an_application"));
		alert("Please select a package");
		return -1;
	}
	else
	{
		module_name = $("#vvtklicense_module_list").find(":selected").text();
		module_vendor = eval('vadp_module_i' + module_index + '_vendor');
		module_version = eval('vadp_module_i' + module_index + '_version');
	}

	user_email = $("#email_usermail").val();
	if(user_email.length <= 0)
	{
		alert(translator("fill_out_email"));
		$("#email_usermail").focus();
		return -1;
	}

	email_pass = $("#email_passwd").val();
	if(email_pass.length <= 0)
	{
		alert(translator("fill_out_password"));
		$("#email_passwd").focus();
		return -1;
	}

	select_country = $("#country_list").find(":selected").val();
	if(select_country == "default")
	{
		alert(translator("select_country"));
		return -1;
	}

	select_vertical = $("#vertical_list").find(":selected").val();
	if(select_vertical == "default")
	{
		alert(translator("select_vertical"));
		return -1;
	}

	confirmation_code = $("#confirmation_code").val();

	var request_str = "vadpnumber=" + vadpnum_string + "&application=" +  module_name + "&vendor=" + module_vendor + "&appversion=" + module_version
					+ "&email=" + user_email + "&password=" + email_pass + "&country=" + select_country + "&vertical=" + select_vertical
					+ "&confirmation_code=" + confirmation_code;
	var request_URL = webserver + "?" + request_str + "&callback=?";

	$( "#waiting" ).show();

	$.getJSON(request_URL, jsonp_callback);
}

function btnShowVadpSchedule()
{
	var modIndex = getCheckedValue(document.getElementsByName('module_select'));

	if (modIndex == "")
	{
		return -1;
	}
	if (VadpScheduleFlag==0)
	{
		VadpScheduleFlag = 1;
		$("#vadp_schedule").show(500);
	}
	else
	{
		VadpScheduleFlag = 0;
		$("#vadp_schedule").hide(500);
	}
}

function saveVadpSchedule()
{
	var modIndex = getCheckedValue(document.getElementsByName('module_select'));

	if (modIndex == "")
	{
		return -1;
	}

	if (checkHHMM(document.getElementById("vadp_begintime"))== -1 || checkHHMM(document.getElementById("vadp_endtime"))== -1)
	{
		return -1;
	}
	
	if (CheckEmptyString(document.getElementById("vadp_begintime") ))
	{
		return -1;
	}

	if (CheckEmptyString(document.getElementById("vadp_endtime") ))
	{
		return -1;
	}

	var params = "";

	var enable_schedule = document.getElementById('enable-vadp-schedule').checked;

	if (enable_schedule == true)
	{
		params +=  "vadp_schedule_i" + modIndex + "_enable=1" + "&" ;
	}
	else
	{
		params +="vadp_schedule_i" + modIndex + "_enable=0" + "&" ;
	}
	
	params += "vadp_schedule_i" + modIndex + "_begintime=" + $("input[name=vadp_index_begintime]").val() +"&"+
                  "vadp_schedule_i" + modIndex + "_endtime=" + $("input[name=vadp_index_endtime]").val() ;

	$.ajax({
			async: false,
			type: "POST",
			cache: false,
			url: "/cgi-bin/admin/setparam.cgi",
			data: params,
			success: function(){
			//alert("Success!!");
			},
			error: function(){
			//alert("Fail!!")
			}
		});

	location.reload() ;    
}

function updateVadpSchedule()
{
	var modIndex = getCheckedValue(document.getElementsByName('module_select')) ;		
	var tmpFlag = eval("vadp_schedule_i"+modIndex+"_enable") ;

	if (tmpFlag == "1")
	{
		document.getElementById("enable-vadp-schedule").checked = true ;
	}
	else
	{			
		document.getElementById("enable-vadp-schedule").checked = false ;
	}
		
	document.getElementById("vadp_begintime").value = eval("vadp_schedule_i"+modIndex+"_begintime") ;
	document.getElementById("vadp_endtime").value = eval("vadp_schedule_i"+modIndex+"_endtime") ;


	document.getElementById("button_start").disabled = false;
	document.getElementById("button_stop").disabled = false;
	document.getElementById("button_schedule").disabled = false;

	if(!ParamUndefinedOrZero("vadp_module_i"+modIndex+"_disablebtn"))
	{
		var disablebtn = eval("vadp_module_i"+modIndex+"_disablebtn");
		if(disablebtn.match("start"))
		{
			document.getElementById("button_start").disabled = true;
		}
		else
		{
			document.getElementById("button_start").disabled = false;
		}	
		
		if(disablebtn.match("stop"))
		{
			document.getElementById("button_stop").disabled = true;
		}
		else
		{
			document.getElementById("button_stop").disabled = false;
		}	

		if(disablebtn.match("schedule"))
		{
			document.getElementById("button_schedule").disabled = true;
		}
		else
		{
			document.getElementById("button_schedule").disabled = false;
		}	

	}
}
