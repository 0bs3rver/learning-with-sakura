//Version: 1.0.0.0
//Date: 2013/12/18
//Auther: Dave Tsai (Tsai, C-P)
//Main related files: video.html, video.js, common.js, jquery.Jcrop.js
//Brief: This UI provides control interface for "Video mode", stream settings and ROI settings.
	//The control methods follows the definitions described in VivotekCameraWebAPI_Video&Streaming_v0.5.doc
	//This UI shows a feature if and only if the feature is supported by the product.
	//The information about supported features is got from WebAPI: group: capability.

//Designer's notes:
// 1. In UI, we start the number from 1. However, in WebAPI, the number is started from 0.
	//In the code, we start from 0 except some strings and comments.
// 2. After "capability_api_httpversion" >= '0301a', FPS can be set from 1~999 in WebAPI for easy integration.
	//Setting FPS more than the maximum value just means applying no restriction on FPS. Products do best effort for FPS.
	//However, we force set FPS to current maximum FPS in WebUI for good-looking.
		//This correction will not applied to the product until user enters "Save" button.
// 3. If user does not enter "Save" or "OK" button, nothing is applied to the product.
	//Entering "Close" button, or changing between tabs will not save anything.

//v0.2:
//1. Fixed wrong word: desciption -> description
//2. Add saving effect on Stream tab.

//v0.3
//1. Fixed some missing chars.
//2. Fixed: Viewing window doesn't work well if getting snapshot takes too much time.
//3. In this version, setting viewing window can still be done even if no snapshot is available.

//v0.4
//1. capability_videoin_c<n>_<codec>_maxframerate should be used to generate FPS options.
	//This API provides the maximum FPS with 1 streaming in current status.
		//The maximum FPS is affected by videon_c<n>_comsfreq, etc.
	//capability_videoin_c<n>_mode<m>_maxfps_<codec> only lists the maximum FPS in 60 Hz or NTSC environment.

//v0.5
//1. Fixed saving stream setting error if any codec of H.264, MPEG4, MJPEG is not supported by the product.
//2. Fixed some errors on video server.

//v0.6
//1. Fixed wrong initial value of customized bitrates.
//2. For someone's unknown reason, I split gaBitrateTbl to 2 tables, one for CBR, and one for VBR.
	//Then, CBR and VBR can have different bit rate options in UI as she want.

//v0.7
//1. Fixed custom input won't be hidden after selecting as option which value is just the same with custom value.
//2. Add custom variable: gbCheckROILink to force disable viewing window link for special models.

//V0.8
//1. Change frame size options order to small to large.
//2. Change tab name: Mode to FOV by PP's request.

//V1.0
//1. Fix bugs on changing channel.
//2. For multi-channel, video mode tab is always displayed, even there is only one mode.
//3. Put version to V1.0


//Customsizeable variable:
	//The options may show in frame rate list. If the value <= The max FPS.
	//The max FPS depends on current video mode and codec.
	//Note1: The maximum FPS may not in this array, and it won't be showed as an option in list.
		//However, user can still set it by customized option.
	//Note2: 0 means customized option.
	var gaFramerateTbl = new Array(0, 1, 2, 3, 5, 8, 10, 12, 15, 20, 24, 25, 30, 35, 40, 45, 50, 55, 60);

	//The options may show in bit rate list. If the value <= the max bitrates of the product.
	//Note: Like FPS, the maximum bitrates may not in this array nor be showed as an option.
		//However, user can still set it by customized option.
/*	var gaBitrateTblCBR = [[0, "customized"], [20000, "20 Kbps"], [40000, "40 Kbps"], [50000, "50 Kbps"], [64000, "64 Kbps"],
		[96000, "96 Kbps"], [128000, "128 Kbps"], [256000, "256 Kbps"], [512000, "512 Kbps"], [768000, "768 Kbps"],
		[1000000, "1 Mbps"], [1500000, "1.5 Mbps"], [2000000, "2 Mbps"], [3000000, "3 Mbps"], [4000000, "4 Mbps"],
		[6000000, "6 Mbps"], [8000000, "8 Mbps"], [10000000, "10 Mbps"], [12000000, "12 Mbps"], [16000000, "16 Mbps"],
		[20000000, "20 Mbps"], [24000000, "24 Mbps"], [28000000, "28 Mbps"], [32000000, "32 Mbps"], [36000000, "36 Mbps"],
		[40000000, "40 Mbps"]];*/
	var gaBitrateTblCBR = [[0, "customized"], [20000, "20 Kbps"], [30000, "30 Kbps"], [40000, "40 Kbps"], [50000, "50 Kbps"],
        [64000, "64 Kbps"], [128000, "128 Kbps"], [256000, "256 Kbps"], [512000, "512 Kbps"], [768000, "768 Kbps"],
		[1000000, "1 Mbps"], [2000000, "2 Mbps"], [3000000, "3 Mbps"], [4000000, "4 Mbps"], [6000000, "6 Mbps"],
        [8000000, "8 Mbps"], [10000000, "10 Mbps"], [12000000, "12 Mbps"], [14000000, "14 Mbps"], [16000000, "16 Mbps"], 
		[18000000, "18 Mbps"], [20000000, "20 Mbps"], [24000000, "24 Mbps"], [28000000, "28 Mbps"], [32000000, "32 Mbps"], 
		[36000000, "36 Mbps"], [40000000, "40 Mbps"]];

/*	var gaBitrateTblVBR = [[0, "customized"], [20000, "20 Kbps"], [40000, "40 Kbps"], [50000, "50 Kbps"], [64000, "64 Kbps"],
		[96000, "96 Kbps"], [128000, "128 Kbps"], [256000, "256 Kbps"], [512000, "512 Kbps"], [768000, "768 Kbps"],
		[1000000, "1 Mbps"], [1500000, "1.5 Mbps"], [2000000, "2 Mbps"], [3000000, "3 Mbps"], [4000000, "4 Mbps"],
		[6000000, "6 Mbps"], [8000000, "8 Mbps"], [10000000, "10 Mbps"], [12000000, "12 Mbps"], [16000000, "16 Mbps"],
		[20000000, "20 Mbps"], [24000000, "24 Mbps"], [28000000, "28 Mbps"], [32000000, "32 Mbps"], [36000000, "36 Mbps"],
		[40000000, "40 Mbps"], [50000000, "50 Mbps"], [60000000, "60 Mbps"]];*/
	var gaBitrateTblVBR = [[0, "customized"], [1000000, "1 Mbps"], [2000000, "2 Mbps"], [4000000, "4 Mbps"], [6000000, "6 Mbps"], 
        [8000000, "8 Mbps"], [10000000, "10 Mbps"], [20000000, "20 Mbps"], [30000000, "30 Mbps"], [40000000, "40 Mbps"]];

	//This array provides the standard resolutions as options for ROI setting.
	//Note: The last one: "custom" must exist in array.
	var gaROITbl = [["4320x2432", "10M"], ["4096x2160", "4K"], ["3840x2160", "QFHD"], ["2688x1520", "4M"], ["2560x1920", "5M"],
			["2560x1600", "4M WQXGA"], ["2560x1440", "WQHD"], ["2048x1536", "3M QXGA"],
			["1920x1200", "WUXGA"], ["1920x1080", "HD 1080"], ["1600x1200", "UXGA"], ["1280x1024", "SXGA"],
			["1280x960", "SXGA-"], ["1280x800", "WXGA"], ["1280x720", "HD 720"], ["1024x768", "XGA"],
			["800x600", "SVGA"], ["720x576", "PAL D1"], ["720x480", "NTSC D1"], ["704x576", "PAL 4CIF"],
			["704x480", "NTSC 4CIF"], ["640x480", "VGA"], ["352x288", "PAL CIF"], ["352x240", "NTSC CIF"],
			["320x240", "QVGA"], ["176x144", "QCIF"], ["custom", "custom"]];


	// This option provides the mode select for smart stream setting.
	var gaSmartMode = [["autotracking", "auto_tracking"], ["manual", "manual"], ["hybrid", "hybrid"]];

	var gaSmartQualityTable = [[99, "customized"], [0, "low"], [1, "medium"], [2, "standard"], [3, "good"], [4, "detailed"], [5, "excellent"]];
			
	//The time interval between updating image in viewing window setting page.
	var guiROIRefreshImgTime_ms = 2000;

	//I don't appreciate meaningless UI effects.
	var bFastUI = true;

	//Check and show viewing window link or not.
	var gbCheckROILink = showViewingWindowLink();

//End of Customsizeable variable


//Constant all the time:
	//capability_nvideoin, capability_nmediastream
	//capability_videoin_c<n>_nmode
	//capability_videoin_type
	var gUIStreamObjNum = 4; //Available stream objects in UI. Easy to extend.
	var gMinW           = 176;
	var gMinH           = 144;
	var gWAlign         = 16;
	var gHAlign         = 8;
	var g_bSmooth       = 0;
	var gJcropMaxSizeW  = 400;
	var gJcropMaxSizeH  = 800;
	var gJcropBoxW      = 400;
	var gJcropBoxH      = 300;
//End of Constant all the time

//Global variable:
	var giCH_Curr = 0;
	var gbModeLock = false;
	var gImg = null;
	var gbSupportMaxResPerStream = false;
	var gbSupportMinResPerStream = false;
//End of Global variable:

//Channel-based variable:
	var gciModeNum;
	var gciMode_Curr;
	var gciTargetMode;
	var gciStreamEPTZSupport = new Array(parseInt(capability_nmediastream, 10));
	var gciStreamCodecSupport = new Array(parseInt(capability_nmediastream, 10));
		//2D array[n][3]: [n][0] for MPEG4, [n][1] for MJPEG, [n][2] for H.264, [0][3] for H.265, n = stream index.
//End of Channel-based variable:

//Stream-based variable:
	var giS_Curr = 0;
	var gImgSrc;
	var bUpdateImg = false;
	var gJcropObj = null;
	var gFullSceneW;
	var gFullSceneH;
	var giROIx;
	var giROIy;
	var giROIw;
	var giROIh;
	var gfROIRatioX;
	var gfROIRatioY;
	var giROIunitH;
	var gbROIChanged;
	var gbFirstCoord;
	var gROITimer;
//End of Stream-based variable:

//IE7 version checking, cause we need to do workaround on IE7
	var IsMSIE7;

//Called when the Web page is on loading.
function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&capability_eptz", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("video");
	
	$("div.tabs").css("display","block");

	loadlanguage();
	checkMSIE7();
}

//Called when the Web page is loaded done.
//Start point of this code.
function receivedone()
{
	if( parseInt(lan, 10) < eval("system_info_language_count")) //The number of embedded languages.
	{
		//By Kent, for Deutsch	
		if (eval('system_info_language_i'+lan) == "Deutsch")
		{
			$("table.dl_dt2 td").css("width","210px");
			$(".position").css("left","325px");
		}	
	}
	
	//Handle channel select.
	if (parseInt(capability_nvideoin, 10) == 1)
	{
		document.getElementById("content").removeChild(document.getElementById("ch_ctrlblk"));
	}
	else
	{
		document.getElementById("ch_sel").length = capability_nvideoin;
		document.getElementById("ch_sel").selectedIndex = giCH_Curr;
	}

	//Prepare Web UI for default CH0.
	setupCtrlEnvbyChannel(giCH_Curr);

	//Prepare DGOP UI
	if (!ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_dintraperiod_support"))
	{
		displayDGOP(true);
	}
	else
	{
		displayDGOP(false);
	}

}

//Called when all objects in Web page is ready.
function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
}

//---Basic functions for adding Web objects---
function addDD(id)
{
	var newDD = document.createElement("dd");
	newDD.id = id;
	return newDD;
}

function addImg(id, src, w, h, display)
{
	var newImg = document.createElement("img");
	newImg.id = id;
	newImg.src = src;
	newImg.style.width = w;
	newImg.style.height = h;
	newImg.style.display = display;
	return newImg;
}

function addInput(id, type, value)
{
	var newInput = document.createElement("input");
	newInput.id = id;
	newInput.type = type;
	newInput.value = value;
	return newInput;
}

function addSpan(id)
{
	var newSpan = document.createElement("span");
	newSpan.id = id;
	return newSpan;
}
//---End of Basic functions for adding Web objects---

//---Channal-based functions---
function setupCtrlEnvbyChannel(ch)
{
	var iCH;	

	giCH_Curr = ch;
	updateNewCHPrm(ch);

	//Show video mode tab if and only if the number of video modes > 1.
	gciModeNum = parseInt(eval("capability_videoin_c"+ch+"_nmode"), 10);
	if (gciModeNum == 1 && parseInt(capability_nvideoin, 10) == 1)
	{
		document.getElementById("tab_videomode").style.display = "none";
		document.getElementById("tab_videomodeROI").style.display = "none";
		tabsUI(1);
		document.getElementById("submitBtn").style.display = "block";
		gciMode_Curr = 0;
	}
	else
	{
		document.getElementById("submitBtn").style.display = "none";
		tabsUI(0);
		$("a[href=#tabs-1]").parent().click(function(){$("#submitBtn").hide();});	
		$("a[href=#tabs-2]").parent().click(function(){$("#submitBtn").show();});	

		gciMode_Curr = parseInt(eval("videoin_c"+ch+"_mode"), 10);

		//Update radio options for video mode.
		addModeOptionObjs();
	}

	var iEPTZ;
	for (iEPTZ = 0; iEPTZ < parseInt(capability_nmediastream, 10); iEPTZ++)
	{
		gciStreamEPTZSupport[iEPTZ] = ePTZStreamSupport(ch, iEPTZ);
	}

	//Find supported codec types by streams.
	var tmpCodexTypes = eval("capability_videoin_c"+ch+"_streamcodec").split(',');
	for (iCODEC = 0; iCODEC < parseInt(capability_nmediastream, 10); iCODEC++)
	{
		//MPEG4(bit 0), MJPEG(bit 1), H.264(bit 2), H.265(bit 3)
		if (parseInt(tmpCodexTypes[iCODEC],10) == 15)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 1, 1, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 14)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 1, 1, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 13)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 0, 1, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 12)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 0, 1, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 11)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 1, 0, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 10)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 1, 0, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 9)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 1, 0, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 8)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 0, 0, 1);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 7)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 1, 1, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 3)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 1, 0, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 6)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 1, 1, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 4)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 0, 1, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 1)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 0, 0, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 2)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 1, 0, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 5)
		{
			gciStreamCodecSupport[iCODEC] = new Array(1, 0, 1, 0);
		}
		else if (parseInt(tmpCodexTypes[iCODEC],10) == 0)
		{
			gciStreamCodecSupport[iCODEC] = new Array(0, 0, 0, 0);
		}

	}

	//Setup UI for streams.
	for (iCH = 0; iCH < gUIStreamObjNum; iCH++)
	{
		if (iCH < parseInt(capability_nmediastream, 10))
		{
			document.getElementById("stream"+iCH+"Parent").style.display = "block";
			setupCtrlUIbyStream(iCH);
		}
		else
		{
			document.getElementById("stream"+iCH+"Parent").style.display = "none";
		}
		//document.getElementById("stream"+iCH+"Child").style.display = "none";
		//If user want to unfold it, no need fold it again after changing channel or changing mode.
	}

}

function updateNewCHPrm(ch)
{
	$.ajax
	({
		async: false,
		url: "/cgi-bin/admin/getparam.cgi?capability_videoin_c"+ch+"&videoin_c"+ch+"&roi_c"+ch+"&status_videomode_c"+ch,
		success: function(data)
		{
			eval(data);
		}
	});

}

function addModeOptionObjs()
{
	var objDD;
	var objImg;
	var objInput;
	var objSpan;
	var bFreq;

	if (parseInt(capability_videoin_type, 10) == 2)
	{
		bFreq = eval("videoin_c"+giCH_Curr+"_cmosfreq");
	}
	else
	{
		bFreq = eval("status_videomode_c"+giCH_Curr);
	}

	$(document.getElementById("mode_blk")).children().each(
		function()
		{
			$(this).remove();
		}
	);

	for (iMode = 0; iMode < gciModeNum; iMode++)
	{
		objDD = addDD("mode"+iMode+"dd");
		document.getElementById("mode_blk").appendChild(objDD);

		objImg = addImg("SavingIconMode"+iMode, "/pic/ajax-loader.gif", "20px", "20px", "none");
		objDD.appendChild(objImg);

		objInput = addInput("mode"+iMode, "radio", iMode);
		objInput.onclick = function() {setVideoMode(this.value);}
		if (gciMode_Curr == iMode)
		{
			objInput.checked = true;
		}
		else
		{
			objInput.checked = false;
		}
		objDD.appendChild(objInput);

		objSpan = addSpan("mode"+iMode+"desc");
		objSpan.innerHTML = eval("capability_videoin_c"+giCH_Curr+"_mode"+iMode+"_description");
		//desciption stores the FPS in 60 Hz or NTSC environment.
		if (bFreq == "50" || bFreq == "pal")
		{
			objSpan.innerHTML = objSpan.innerHTML.replace(/60fps/g, "50fps");
			objSpan.innerHTML = objSpan.innerHTML.replace(/5[1-9]fps/g, "50fps");
			objSpan.innerHTML = objSpan.innerHTML.replace(/30fps/g, "25fps");
			objSpan.innerHTML = objSpan.innerHTML.replace(/2[6-9]fps/g, "25fps");
			objSpan.innerHTML = objSpan.innerHTML.replace(/24fps/g, "25fps"); //amba spec
		}
		objDD.appendChild(objSpan);

	}

	//workaround for IE7
	if (IsMSIE7 == "1")
	{
		document.getElementById("mode"+gciMode_Curr).checked = true;
	}

}

function setVideoMode(value)
{
	if (gbModeLock)
	{
		document.getElementById("mode"+value).checked = false;
		return;
	}

	if (gciMode_Curr == value)
	{
		//No change, no handle.
		return;
	}
	else
	{
		//Show visible checked effect.
		document.getElementById("mode"+value).checked = true;
		document.getElementById("mode"+gciMode_Curr).checked = false;
	}

	//Confirm change action.
	var msgContent = composeWarningMsg();

  	if(confirm(msgContent))
	{
		gbModeLock = true;
		if (value < gciModeNum)
		{
			blockUI();
			$("#SavingIconMode"+value).show();

			//tackle the rotation
			if (eval("capability_videoin_c"+giCH_Curr+"_rotation") == 1) 
			{
				$.ajax({
					url: "/cgi-bin/admin/setparam.cgi",
					async: true,
					cache: false,
					data: "videoin_c" + giCH_Curr + "_mode=" + value
				});

				gciTargetMode = value; 
				// FIXME! Wait 40 seconds for the reboot work-around
				// dynamic change video mode under 7 seconds
				setTimeout("waitToUnblockUI(" + giCH_Curr + ");", 7000);
			}
			else
			{
				var XMLHttpRequestObject = null;

				if (window.XMLHttpRequest)
				{
					XMLHttpRequestObject = new XMLHttpRequest();
				}
				else if (window.ActiveXObject)
				{
					XMLHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
				}

				var commitlist = "/cgi-bin/admin/setparam.cgi?videoin_c"+giCH_Curr+"_mode="+value;

				XMLHttpRequestObject.open("GET", commitlist);
				XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
				XMLHttpRequestObject.send(null);

				gciTargetMode = value;
				if (translator("videomode_switch_warning_20s_message") == msgContent)
				{
					setTimeout("checkModeDone()", 20000); //20000ms = 20s
				}
				else
				{
					checkModeDone();
				}
			}
		}
		else
		{
			//Entering here means a bug here.
		}
	}
	else
	{
		//Restore visible checked status.
		document.getElementById("mode"+value).checked = false;
		document.getElementById("mode"+gciMode_Curr).checked = true;
		return;
	}

}

function checkModeDone()
{
	$.ajax({
		async: false,
		url: "/cgi-bin/admin/getparam.cgi?capability_videoin_c"+giCH_Curr+"_mode",
		success: function(data)
		{
			eval(data);
			if (gciTargetMode != eval("capability_videoin_c"+giCH_Curr+"_mode"))
			{
				setTimeout("checkModeDone('More')", 1000);
			}
			else
			{
				setupCtrlEnvbyChannel(giCH_Curr);
				gciMode_Curr = gciTargetMode;
				gbModeLock = false;
				$('body').unblock();
				$("#SavingIconMode"+gciTargetMode).hide();
			}
		}
	});
}

function changeChannel(ch)
{
	var iCH;	
	var aIcon;

	$(".tab-page").css("display","none");
	$(".tabs li").css({"z-index":"0", "background-color":"#C4EAFF"});
	$(".tabs li a").css({"color":"#666"});

	for (iCH = 0; iCH < gUIStreamObjNum; iCH++)
	{
		document.getElementById("stream"+iCH+"Parent").style.display = "none";
		document.getElementById("stream"+iCH+"Child").style.display = "none";
		aIcon = document.getElementById("stream"+iCH+"Icon");
		aIcon.src = "/pic/rightArrow.gif";
	}
	setupCtrlEnvbyChannel(ch);
}
//---End of Channal-based functions---

//---Stream-based functions---
//These functions may called when initializing UI, changing channel, video mode, or ROI (Viewing window).
//Channel-based parameters, like giCH_Curr, gciMode_Curr are kept during these functions.

function setupCtrlUIbyStream(s)
{
//Handle ROI (Viewing window) link.
	if (gbCheckROILink && gciStreamEPTZSupport[s] == 1)
	{
		document.getElementById("s"+s+"ROI").style.display = "inline";
	}
	else
	{
		document.getElementById("s"+s+"ROI").style.display = "none";
	}

//Handle H.265:
	if (gciStreamCodecSupport[s][3] == 1)
	{
		document.getElementById("s"+s+"h265Parent").style.display = "block";
		document.getElementById("s"+s+"h265Child").style.display = "none";
		setupCtrlUIforCodec(s, "h265");
	}
	else
	{
		document.getElementById("s"+s+"h265Parent").style.display = "none";
		document.getElementById("s"+s+"h265Child").style.display = "none";
	}

//Handle H.264:
	if (gciStreamCodecSupport[s][2] == 1)
	{
		document.getElementById("s"+s+"h264Parent").style.display = "block";
		document.getElementById("s"+s+"h264Child").style.display = "none";
		setupCtrlUIforCodec(s, "h264");
	}
	else
	{
		document.getElementById("s"+s+"h264Parent").style.display = "none";
		document.getElementById("s"+s+"h264Child").style.display = "none";
	}

//Handle MPEG4:
	if (gciStreamCodecSupport[s][0] == 1)
	{
		document.getElementById("s"+s+"mpeg4Parent").style.display = "block";
		document.getElementById("s"+s+"mpeg4Child").style.display = "none";
		setupCtrlUIforCodec(s, "mpeg4");
	}
	else
	{
		document.getElementById("s"+s+"mpeg4Parent").style.display = "none";
		document.getElementById("s"+s+"mpeg4Child").style.display = "none";
	}

//Handle MJPEG:
	if (gciStreamCodecSupport[s][1] == 1)
	{
		document.getElementById("s"+s+"mjpegParent").style.display = "block";
		document.getElementById("s"+s+"mjpegChild").style.display = "none";
		setupCtrlUIforCodec(s, "mjpeg");
	}
	else
	{
		document.getElementById("s"+s+"mjpegParent").style.display = "none";
		document.getElementById("s"+s+"mjpegChild").style.display = "none";
	}


//Update UI
	if (eval("videoin_c"+giCH_Curr+"_s"+s+"_codectype") == "h265")
	{
		document.getElementById("s"+s+"h265radio").checked = true;
		document.getElementById("s"+s+"h265Child").style.display = "block";
	}
	else
	{
		document.getElementById("s"+s+"h265radio").checked = false;
		document.getElementById("s"+s+"h265Child").style.display = "none";
	}

	if (eval("videoin_c"+giCH_Curr+"_s"+s+"_codectype") == "h264")
	{
		document.getElementById("s"+s+"h264radio").checked = true;
		document.getElementById("s"+s+"h264Child").style.display = "block";
	}
	else
	{
		document.getElementById("s"+s+"h264radio").checked = false;
		document.getElementById("s"+s+"h264Child").style.display = "none";
	}

	if (eval("videoin_c"+giCH_Curr+"_s"+s+"_codectype") == "mpeg4")
	{
		document.getElementById("s"+s+"mpeg4radio").checked = true;
		document.getElementById("s"+s+"mpeg4Child").style.display = "block";
	}
	else
	{
		document.getElementById("s"+s+"mpeg4radio").checked = false;
		document.getElementById("s"+s+"mpeg4Child").style.display = "none";
	}

	if (eval("videoin_c"+giCH_Curr+"_s"+s+"_codectype") == "mjpeg")
	{
		document.getElementById("s"+s+"mjpegradio").checked = true;
		document.getElementById("s"+s+"mjpegChild").style.display = "block";
	}
	else
	{
		document.getElementById("s"+s+"mjpegradio").checked = false;
		document.getElementById("s"+s+"mjpegChild").style.display = "none";
	}
}

function setupCtrlUIforCodec(s, codec)
{
	//Resolution
	if (parseInt(capability_videoin_type, 10) == 2)
	{
		//For CMOS products with real pixels, like 1920x1080, 2048x1536, as resolution options.
		generateResolutionOptions(s, codec);
	}
	else
	{
		//For CCD products with D1, 4CIF, CIF, QCIF as resolution options.
		generateResolutionOptionsCCD(s, codec);
	}

	//FPS
	generateFPSOptions("s"+s+"_"+codec+"_fps", s, codec, eval("videoin_c"+giCH_Curr+"_s"+s+"_resolution"));

	//I-frame period
	if (codec != "mjpeg")
	{
		$(document.getElementById("s"+s+"_"+codec+"_intraperiod")).children().each(function()
		{
			if (this.value == eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_intraperiod"))
			{
				this.selected = true;
			}
		})

		changeDGOPsecond(s, codec, eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_intraperiod"));
	}

	//Bitrate, quality control
	setupQB_Ctrl(s, codec);
}

function generateResolutionOptions(s, codec)
{
	var bROIed = false;
	var sizeTable;
	var fpsTable;
	var curRes = eval("videoin_c"+giCH_Curr+"_s"+s+"_resolution");
	var id = "s"+s+"_"+codec+"_resolution";
	var bFound = false;
	var maxRes = "-";
	var roiW, roiH;
	var roiSizeTable = [];

	//Clean options first.
	$(document.getElementById(id)).removeOption(/./);

	if (gciStreamEPTZSupport[s] == 1)
	{
		if (eval("roi_c"+giCH_Curr+"_s"+s+"_size") != eval("capability_videoin_c"+giCH_Curr+"_mode"+gciMode_Curr+"_outputsize") || eval("roi_c"+giCH_Curr+"_s"+s+"_home") != "0,0")
		{
			//Generate resolution options for ROIed view.
			bROIed = true;
		}
	}

	sizeTable = eval("capability_videoin_c"+giCH_Curr+"_resolution");
	sizeTable = sizeTable.split(",");
	fpsTable = eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxframerate");
	fpsTable = fpsTable.split(",");

	//Find the maximum resolution.
	for (iRes = 0; iRes < eval("capability_videoin_c"+giCH_Curr+"_nresolution"); iRes++)
	{
		if (fpsTable[iRes] != "-")
		{
			if (maxRes == "-")
			{
				maxRes = sizeTable[iRes];
			}
			else if (parseInt(sizeTable[iRes].split("x")[0], 10) > parseInt(maxRes.split("x")[0], 10))
			{
				maxRes = sizeTable[iRes];
			}
		}
	}

	gbSupportMaxResPerStream = !(ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_maxresolution"));
	if (gbSupportMaxResPerStream)
	{
		maxsizeTable = eval("capability_videoin_c"+giCH_Curr+"_maxresolution");
		maxsizeTable = maxsizeTable.split(",");
		maxRes = maxsizeTable[s];
	}
	
	gbSupportMinResPerStream = !(ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_minresolution"));
	if (gbSupportMinResPerStream)
	{
		minsizeTable = eval("capability_videoin_c"+giCH_Curr+"_minresolution");
		minsizeTable = minsizeTable.split(",");
		minRes = minsizeTable[s];
	}
	else
	{
		sizeTable = eval("capability_videoin_c"+giCH_Curr+"_resolution");
		sizeTable = sizeTable.split(",");
		minRes = sizeTable[0];
	}

	//Generate resolution options.
	if (bROIed == true)
	{
		roiW = parseInt(eval("roi_c"+giCH_Curr+"_s"+s+"_size").split("x")[0], 10);
		roiH = parseInt(eval("roi_c"+giCH_Curr+"_s"+s+"_size").split("x")[1], 10);
		while (roiW >= gMinW && roiH >= gMinH)
		{
			roiSizeTable.push(""+roiW+"x"+roiH);
	
			roiW = parseInt(roiW/ 2 / gWAlign, 10) * gWAlign;
			roiH = parseInt(roiH/ 2 / gHAlign, 10) * gHAlign;
		}
		roiSizeTable.reverse();

		for (i = 0; i < roiSizeTable.length; i++)
		{
			roiW = roiSizeTable[i].split("x")[0];
			roiH = roiSizeTable[i].split("x")[1];
			//Normally, codec has limitaion on width.
			//Height also has limitation, but we don't beyond it currently.
			if (roiW <= parseInt(maxRes.split("x")[0], 10) 
			&& roiH <= parseInt(maxRes.split("x")[1], 10)
			&& roiW >= parseInt(minRes.split("x")[0], 10)
			&& roiH >= parseInt(minRes.split("x")[1], 10))
			{
				if (roiW == parseInt(curRes.split("x")[0], 10) && roiH == parseInt(curRes.split("x")[1], 10))
				{
					$(document.getElementById(id)).addOption(""+roiW+"x"+roiH, ""+roiW+"x"+roiH, true);
					bFound = true;
				}
				else
				{
					$(document.getElementById(id)).addOption(""+roiW+"x"+roiH, ""+roiW+"x"+roiH, false);
				}
			}
		}

		if (!bFound)
		{
			//Operations on WebUI only won't meet this condition, but user can do whatever legal operations on WebAPI.
			//In this case, I add the current resolution to the list as the last option.
			$(document.getElementById(id)).addOption(curRes, curRes, true);
		}
	}
	else
	{

		for (iRes = 0; iRes < eval("capability_videoin_c"+giCH_Curr+"_nresolution"); iRes++)
		{
			if (fpsTable[iRes] != "-")
			{
				if (sizeTable[iRes] == curRes)
				{
					$(document.getElementById(id)).addOption(sizeTable[iRes], sizeTable[iRes], true);
					bFound = true;
				}
				else
				{
					$(document.getElementById(id)).addOption(sizeTable[iRes], sizeTable[iRes], false);
				}

				if (gbSupportMaxResPerStream && sizeTable[iRes] == maxsizeTable[s])
				{
					break;
				}
			}
		}

		//Handle if current resolution is not supported by this codec.
		if (!bFound)
		{
			//Take the maximum resolution of this codec.
			eval("videoin_c"+giCH_Curr+"_s"+s+"_resolution='"+maxRes+"'");
			document.getElementById(id).selectedIndex = 0;
		}
	}

}

function getCorrectedResolution(opt)
{
	switch(opt)
	{
		case "D1":
		case "4CIF":
			return ((eval("status_videomode_c"+giCH_Curr) == "pal")? "768x576":"640x480");
			break;
		case "CIF":
			return ((eval("status_videomode_c"+giCH_Curr) == "pal")? "384x288":"320x240");
			break;
		case "QCIF":
			return ((eval("status_videomode_c"+giCH_Curr) == "pal")? "176x144":"176x120");
			break;
		default:
			return opt;
	}
}

function generateResolutionOptionsCCD(s, codec)
{
	var sizeTable;
	var fpsTable;
	var curRes = eval("videoin_c"+giCH_Curr+"_s"+s+"_resolution");
	var id = "s"+s+"_"+codec+"_resolution";
	var bRatioCorrect = !ParamUndefinedOrZero("videoin_c"+giCH_Curr+"_s"+s+"_ratiocorrect");

	sizeTable = eval("capability_videoin_c"+giCH_Curr+"_resolution");
	sizeTable = sizeTable.split(",");
	fpsTable = eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxframerate");
	fpsTable = fpsTable.split(",");

	//Clean options first.
	$(document.getElementById(id)).removeOption(/./);

	//Generate resolution options.
	for (iRes = 0; iRes < eval("capability_videoin_c"+giCH_Curr+"_nresolution"); iRes++)
	{
		if (fpsTable[iRes] != "-")
		{
			if (bRatioCorrect)
			{
				if (sizeTable[iRes] == curRes)
				{
					$(document.getElementById(id)).addOption(sizeTable[iRes],
						""+sizeTable[iRes]+" -> "+getCorrectedResolution(sizeTable[iRes]), true);
				}
				else
				{
					$(document.getElementById(id)).addOption(sizeTable[iRes],
						""+sizeTable[iRes]+" -> "+getCorrectedResolution(sizeTable[iRes]), false);
				}
			}
			else
			{
				if (sizeTable[iRes] == curRes)
				{
					$(document.getElementById(id)).addOption(sizeTable[iRes], sizeTable[iRes], true);
				}
				else
				{
					$(document.getElementById(id)).addOption(sizeTable[iRes], sizeTable[iRes], false);
				}
			}
		}
	}
}

function generateFPSOptions(id, s, codec, selectedRes)
{
	var sizeTable;
	var fpsTable;
	var curPixels;
	var tmpPixels;
	var bFound = false;
	var curMaxFPS = 30;
	var curFPS = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxframe");
    var curMode = eval("videoin_c"+giCH_Curr+"_mode");

	//Clean options first.
	$(document.getElementById(id)).removeOption(/./);

	//Find max fps in current selected resolution. For CMOS sensor only.
	sizeTable = eval("capability_videoin_c"+giCH_Curr+"_resolution");
	sizeTable = sizeTable.split(",").reverse();
	fpsTable = eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxframerate");
	fpsTable = fpsTable.split(",").reverse();
	if (parseInt(capability_videoin_type, 10) == 2)
	{
		curPixels = parseInt(selectedRes.split("x")[0], 10) * parseInt(selectedRes.split("x")[1], 10);
		for (iFPS = sizeTable.length - 1; iFPS >= 0 ; iFPS--)
		{
			tmpPixels = parseInt(sizeTable[iFPS].split("x")[0], 10) * parseInt(sizeTable[iFPS].split("x")[1], 10);
			if (curPixels <= tmpPixels && fpsTable[iFPS] != "-")
			{
				curMaxFPS = fpsTable[iFPS];
				eval("gciMaxFps_"+codec+"_"+s+"='"+curMaxFPS+"'");
				break;
			}
		}
	}
	else
	{
		//CCD case.
		for (iFPS = sizeTable.length - 1; iFPS >= 0 ; iFPS--)
		{
			if (fpsTable[iFPS] != "-" && sizeTable[iFPS] == selectedRes)
			{
				curMaxFPS = fpsTable[iFPS];
				eval("gciMaxFps_"+codec+"_"+s+"='"+curMaxFPS+"'");
				break;
			}
		}
	}

	if (parseInt(curFPS, 10) > parseInt(curMaxFPS, 10))
	{
		curFPS = curMaxFPS;
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxframe="+curMaxFPS);
	}

	//Generate FPS options.
    if(curMode == 1 && codec == "mpeg4")
    {
        curMaxFPS = 50; 
    }
	for (iFPS = 0; iFPS < gaFramerateTbl.length; iFPS++)
	{
		if (gaFramerateTbl[iFPS] == 0)
		{
			$(document.getElementById(id)).addOption(0, translator("customized"), true);
		}
		else
		{
			if (gaFramerateTbl[iFPS] <= curMaxFPS)
			{
				if (gaFramerateTbl[iFPS] == curFPS)
				{
					$(document.getElementById(id)).addOption(gaFramerateTbl[iFPS], "" + gaFramerateTbl[iFPS] + " fps", true);
					bFound = true;
				}
				else
				{
					$(document.getElementById(id)).addOption(gaFramerateTbl[iFPS], "" + gaFramerateTbl[iFPS] + " fps", false);
				}
			}
		}
	}

	//Handle custom FPS.
	document.getElementById("s"+s+"_"+codec+"_fps_customDesc").innerHTML = "fps [1~"+curMaxFPS+"]";
	document.getElementById("s"+s+"_"+codec+"_fps_customInput").value = curFPS;
	if (bFound)
	{
		document.getElementById("s"+s+"_"+codec+"_fps_customBlk").style.display = "none";
	}
	else
	{
		document.getElementById("s"+s+"_"+codec+"_fps_customBlk").style.display = "block";
	}
	
}


function handleSmartStream2(s, codec)
{
	var isupMaxStream;
	var isupMaxSmartMode;
	var bsupSmartAuto;
	var bsupSmartManual;
	var bsupSmartHybrid;
	var bsupMaxBitRate;	
	var maxBr;
	var curBrVBR;
	
	//Handle smart codec.
	if (codec == "h265")
	{
		isupMaxSmartMode = 0;
		isupMaxStream =  parseInt(eval("capability_smartstream_nstream")) - 1;
		bsupSmartAuto = !ParamUndefinedOrZero("capability_smartstream_mode_autotracking");
		bsupSmartManual = !ParamUndefinedOrZero("capability_smartstream_mode_manual");
		bsupSmartHybrid = !ParamUndefinedOrZero("capability_smartstream_mode_hybrid");
		//maxBr = eval("capability_videoin_c"+giCH_Curr+"_h265_maxbitrate");
		
		if (s > isupMaxStream) 
		{
			document.getElementById("smartstream2_"+s+"Blk"+"_"+codec).style.display = "none";
			return;
		}
		else
		{
			// Support Smart Codec
			document.getElementById("smartstream2_"+s+"Blk"+"_"+codec).style.display = "block";
			 
			$(document.getElementById("s"+s+"_h265_smart2_mode")).removeOption(/./);
			
			if (bsupSmartAuto)		// Support auto mode
			{	
				$(document.getElementById("s"+s+"_h265_smart2_mode")).addOption(gaSmartMode[0][0], translator(gaSmartMode[0][1]), true);
				isupMaxSmartMode = isupMaxSmartMode + 1;
			}
			if (bsupSmartManual)	// Support manual mode
			{
				$(document.getElementById("s"+s+"_h265_smart2_mode")).addOption(gaSmartMode[1][0], translator(gaSmartMode[1][1]), true);			
				isupMaxSmartMode = isupMaxSmartMode + 1;
			}
			if (bsupSmartHybrid)	// Support hybrid mode
			{
				$(document.getElementById("s"+s+"_h265_smart2_mode")).addOption(gaSmartMode[2][0], translator(gaSmartMode[2][1]), true);
				isupMaxSmartMode = isupMaxSmartMode + 1;
			}
		
			if (isupMaxSmartMode <= 1)
			{
				document.getElementById("s"+s+"_h265_smart2_mode").disabled = true;
				//document.getElementById("s"+s+"_"+codec+"_smart_mode_blk").style.display = "none";
			}

			//init checkbox
			if (eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_enable") == 1)
			{
				document.getElementById("enable_smart2_s"+s+"_"+codec).checked = true;
				document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "table-row";
			}
			else
			{
				document.getElementById("enable_smart2_s"+s+"_"+codec).checked = false;
				document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "none";
			}
			
			//init slider
			//The UI direction is opposite from parameter , left=5 and right=-5 
			TmpH265QualityPriority = parseInt(eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_qualitypriority"), 10);
			$("#s"+s+"_"+codec+"_smart2_Qslider").slider(
			{
				min: -4,
				max: 5,
				animate: true,
				value: covertToSmartSliderValue(TmpH265QualityPriority),
				change: function(event, ui)
				{
					if (ui.value < 1)
					{
						TmpH265QualityPriority = ui.value - 1;
						eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_qualitypriority="+TmpH265QualityPriority);
					}
					else
					{
						TmpH265QualityPriority = ui.value;
						eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_qualitypriority="+TmpH265QualityPriority);
					}
				},
//                slide: function(event, ui) {
//                    $(ui.handle).text(ui.value);
//                },
//                start: function( event, ui ) {
//                    if($(ui.handle).hasClass('stay'))
//                    return false;
//                }
			});
//            var value = $("#s"+s+"_"+codec+"_smart2_Qslider").slider("values",1);
//            $("#s"+s+"_"+codec+"_smart2_Qslider").find(".ui-slider-handle:last").text(value); 
//            $("#s"+s+"_"+codec+"_smart2_Qslider .ui-slider-handle:first").addClass('stay');
//            $("#s0_h265_smart2_Qslider .ui-slider-handle").eq(0).css("background", "transparent url(/pic/slidericon_left.png)");
//            $("#s"+s+"_"+codec+"_smart2_Qslider .ui-slider-handle").eq(1).css("background", "transparent url(/pic/sort_desc.jpg)");
		}
	}
	
	//Handle smart codec.
	if (codec == "h264")
	{
		isupMaxSmartMode = 0;
		isupMaxStream =  parseInt(eval("capability_smartstream_nstream")) - 1;
		bsupSmartAuto = !ParamUndefinedOrZero("capability_smartstream_mode_autotracking");
		bsupSmartManual = !ParamUndefinedOrZero("capability_smartstream_mode_manual");
		bsupSmartHybrid = !ParamUndefinedOrZero("capability_smartstream_mode_hybrid");
		//maxBr = eval("capability_videoin_c"+giCH_Curr+"_h264_maxbitrate");
		
		if (s > isupMaxStream) 
		{
			document.getElementById("smartstream2_"+s+"Blk"+"_"+codec).style.display = "none";
			return;
		}
		else
		{
			// Support Smart Codec
			document.getElementById("smartstream2_"+s+"Blk"+"_"+codec).style.display = "block";
			 
			$(document.getElementById("s"+s+"_h264_smart2_mode")).removeOption(/./);
			
			if (bsupSmartAuto)		// Support auto mode
			{	
				$(document.getElementById("s"+s+"_h264_smart2_mode")).addOption(gaSmartMode[0][0], translator(gaSmartMode[0][1]), true);
				isupMaxSmartMode = isupMaxSmartMode + 1;
			}
			if (bsupSmartManual)	// Support manual mode
			{
				$(document.getElementById("s"+s+"_h264_smart2_mode")).addOption(gaSmartMode[1][0], translator(gaSmartMode[1][1]), true);			
				isupMaxSmartMode = isupMaxSmartMode + 1;
			}
			if (bsupSmartHybrid)	// Support hybrid mode
			{
				$(document.getElementById("s"+s+"_h264_smart2_mode")).addOption(gaSmartMode[2][0], translator(gaSmartMode[2][1]), true);
				isupMaxSmartMode = isupMaxSmartMode + 1;
			}

			if (isupMaxSmartMode <= 1)
			{
				document.getElementById("s"+s+"_h264_smart2_mode").disabled = true;
				//document.getElementById("s"+s+"_"+codec+"_smart_mode_blk").style.display = "none";
			}
			
			//init checkbox
			if (eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_enable") == 1)
			{
				document.getElementById("enable_smart2_s"+s+"_"+codec).checked = true;
				document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "table-row";
			}
			else
			{
				document.getElementById("enable_smart2_s"+s+"_"+codec).checked = false;
				document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "none";
			}
			//init slider
			//The UI direction is opposite from parameter , left=5 and right=-5 
			TmpH264QualityPriority = parseInt(eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_qualitypriority"), 10);
			$("#s"+s+"_"+codec+"_smart2_Qslider").slider(
			{
				min: -4,
				max: 5,
				animate: true,
				value: covertToSmartSliderValue(TmpH264QualityPriority),
				change: function(event, ui)
				{
					if (ui.value < 1)
					{
						TmpH264QualityPriority = ui.value - 1;
						eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_qualitypriority="+TmpH264QualityPriority);
					}
					else
					{
						TmpH264QualityPriority = ui.value;
						eval("videoin_c0_s"+s+"_"+codec+"_smartstream2_qualitypriority="+TmpH264QualityPriority);
					}
				},
//                slide: function(event, ui) {
//                    $(ui.handle).text(ui.value);
//                },
//                start: function( event, ui ) {
//                    if($(ui.handle).hasClass('stay'))
//                    return false;
//                }
			});
//            var value = $("#s"+s+"_"+codec+"_smart2_Qslider").slider("values",1);
//            $("#s"+s+"_"+codec+"_smart2_Qslider").find(".ui-slider-handle:last").text(value); 
//            $("#s"+s+"_"+codec+"_smart2_Qslider .ui-slider-handle:first").addClass('stay');
//            $("#s0_h265_smart2_Qslider .ui-slider-handle").eq(0).css("background", "transparent url(/pic/slidericon.png)");
//            $("#s"+s+"_"+codec+"_smart2_Qslider .ui-slider-handle").eq(1).css("background", "transparent url(/pic/sort_desc.jpg)");
		}
	}
}

function setupQB_Ctrl(s, codec)
{
	var curQB_Ctrl;
	var bMatch;
	var maxBr;
	var curBrCBR;
	var curBrVBR;
    var curQuant;
    var curSmartFgQuant;
    var curSmartBgQuant;
    var curSmartMaxBitrate;
    var curSmartMaxBitrateMode;
    var curSmartMode;
    var iSmartMaxBitrateIndex;

	if (codec != "mjpeg")
	{
		//handle smart stream
		iMaxSmartStream = parseInt(eval("capability_smartstream_nstream"));

		if (!ParamUndefinedOrZero("capability_smartstream_support"))
		{
			if (!ParamUndefinedOrZero("capability_smartstream_version")&&capability_smartstream_version == "2.0")
			{
				handleSmartStream2(s, codec);
				
				//smart stream default value
				curSmartMode = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream2_mode");
				
				document.getElementById("s"+s+"_"+codec+"_smart2_mode").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream2_mode");
				
				if(curSmartMode == gaSmartMode[1][0] || curSmartMode == gaSmartMode[2][0] )
				{
					$("#"+"c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream2_manual_window_setting").fadeIn().attr("disabled",false);
				}
				else
				{
					$("#"+"c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream2_manual_window_setting").fadeOut().attr("disabled",true);
				}
			}
		}
		else
		{
			document.getElementById("smartstream2_"+s+"Blk"+"_"+codec).style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "none";
		}
		//end of handle smart stream
		
		curQB_Ctrl = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_ratecontrolmode");
		maxBr = eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxbitrate");
		curBrCBR = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate");

		//First, handle new features by flexible bit rate control.
		if (!ParamUndefinedOrZero("capability_videoin_flexiblebitrate"))
		{
			//CBR:
			//IE7 didn't support "table-row" in css display, so use default value
			if (IsMSIE7 == "1")
			{
				document.getElementById("s"+s+"_"+codec+"_flexible_cbr_Blk").style.display = "";
			}
			else
			{
			document.getElementById("s"+s+"_"+codec+"_flexible_cbr_Blk").style.display = "table-row";
			}
			$(document.getElementById("s"+s+"_"+codec+"_prioritypolicy")).children().each(
				function()
				{
					if (this.value == eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_prioritypolicy"))
					{	
						this.selected = true;
					}
				}
			);

			//VBR:
			curBrVBR = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxvbrbitrate");
			//IE7 didn't support "table-row" in css display, so use default value
			if (IsMSIE7 == "1")
			{
				document.getElementById("s"+s+"_"+codec+"_flexible_vbr_Blk").style.display = "";
			}
			else
			{
			document.getElementById("s"+s+"_"+codec+"_flexible_vbr_Blk").style.display = "table-row";
			}
			$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).removeOption(/./);
			bMatch = false;
			for (iQB = 0; iQB < gaBitrateTblVBR.length; iQB++)
			{
				if (gaBitrateTblVBR[iQB][0] == 0)
				{
					$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).addOption(0, translator("customized"), true);
				}
				else
				{
					if (gaBitrateTblVBR[iQB][0] <= maxBr)
					{
						if (gaBitrateTblVBR[iQB][0] == curBrVBR)
						{
							$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).addOption(gaBitrateTblVBR[iQB][0], gaBitrateTblVBR[iQB][1], true);
							bMatch = true;
						}
						else
						{
							$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).addOption(gaBitrateTblVBR[iQB][0], gaBitrateTblVBR[iQB][1], false);
						}
					}
				}
			}

			//Handle VBR customize:
			document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customInput").value = curBrVBR /1000;
			document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customDesc").innerHTML = "Kbps [20~"+parseInt(maxBr, 10)/1000+"]";
			if (bMatch)
			{
				document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customBlk").style.display = "none";
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customBlk").style.display = "block";
			}
		
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_flexible_cbr_Blk").style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_flexible_vbr_Blk").style.display = "none";
		}

		//Handle CBR
		$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).removeOption(/./);
		bMatch = false;
		for (iQB = 0; iQB < gaBitrateTblCBR.length; iQB++)
		{
			if (gaBitrateTblCBR[iQB][0] == 0)
			{
				$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).addOption(0, translator("customized"), true);
			}
			else
			{
				if (gaBitrateTblCBR[iQB][0] <= maxBr)
				{
					if (gaBitrateTblCBR[iQB][0] == curBrCBR)
					{
						$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).addOption(gaBitrateTblCBR[iQB][0], gaBitrateTblCBR[iQB][1], true);
						bMatch = true;
					}
					else
					{
						$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).addOption(gaBitrateTblCBR[iQB][0], gaBitrateTblCBR[iQB][1], false);
					}
				}
			}
		}

		//Handle CBR customize
		document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customInput").value = curBrCBR /1000;
        if( (codec != "h264"))
        {
		    document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customDesc").innerHTML = "Kbps [20~"+parseInt(maxBr, 10)/1000+"]";
        }
        else
        {
		    document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customDesc").innerHTML = "Kbps [20~"+parseInt(maxBr, 10)/1000+"]";
        }
        if (bMatch)
		{
			document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customBlk").style.display = "none";
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customBlk").style.display = "block";
		}
		
		//Handle CBR quality
		if (!ParamUndefinedOrZero("capability_smartstream_version")&&capability_smartstream_version == "2.0")
		{
			curCbrQuant = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_quant");
			if (curCbrQuant == 99)
			{
				eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_quant=100");
				curCbrQuant = 100;
			}

			bMatch = false;
			$(document.getElementById("s"+s+"_"+codec+"_cbr_quant")).children().each(
				function()
				{
					if (this.value == curCbrQuant)
					{	
						this.selected = true;
						if (this.value != 100)
						{
							bMatch = true;
						}
					}
				}
			);
			//Handle CBR quality customize
			document.getElementById("s"+s+"_"+codec+"_cbr_qpercent").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_qpercent");;
			if (bMatch)
			{
				document.getElementById("s"+s+"_"+codec+"_cbr_qpercentBlk").style.display = "none";
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_cbr_qpercentBlk").style.display = "block";
			}
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_cbr_quality_option").style.display = "none";
		}


		//Handle VBR
		curQuant = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant");
		if (curQuant == 99)
		{
			eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant=100");
			curQuant = 100;
		}

		bMatch = false;
		$(document.getElementById("s"+s+"_"+codec+"_quant")).children().each(
			function()
			{
				if (this.value == curQuant)
				{	
					this.selected = true;
					if (this.value != 100)
					{
						bMatch = true;
					}
				}
			}
		);
		
		//Handle VBR customize
		document.getElementById("s"+s+"_"+codec+"_qpercent").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent");;
		if (bMatch)
		{
			document.getElementById("s"+s+"_"+codec+"_qpercentBlk").style.display = "none";
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_qpercentBlk").style.display = "block";
		}


		//Select & show current control mode.
		document.getElementById("s"+s+"_"+codec+"_QB_Child_cbr").style.display = "none";
		document.getElementById("s"+s+"_"+codec+"_QB_Child_vbr").style.display = "none";

		//IE7 didn't support "table-row" in css display, so use default value
		if (IsMSIE7 == "1")
		{
			document.getElementById("s"+s+"_"+codec+"_QB_Child_"+curQB_Ctrl).style.display = "";
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_QB_Child_"+curQB_Ctrl).style.display = "table-row";
		}

		document.getElementById("s"+s+"_"+codec+"_QB_Radio_cbr").checked = false;
		document.getElementById("s"+s+"_"+codec+"_QB_Radio_vbr").checked = false;
		document.getElementById("s"+s+"_"+codec+"_QB_Radio_"+curQB_Ctrl).checked = true;
	}

	if (codec == "mjpeg")
	{
		//First, handle new features by flexible bit rate control.
		if (!ParamUndefinedOrZero("capability_videoin_flexiblebitrate"))
		{
			curQB_Ctrl = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_ratecontrolmode");
			maxBr = eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxbitrate");
			curBrCBR = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate");
			curBrVBR = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxvbrbitrate");

			//CBR:
			document.getElementById("s"+s+"_mjpeg_flexible_cbr_Title").style.display = "block";
			$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).removeOption(/./);
			bMatch = false;
			for (iQB = 0; iQB < gaBitrateTblCBR.length; iQB++)
			{
				if (gaBitrateTblCBR[iQB][0] == 0)
				{
					$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).addOption(0, translator("customized"), true);
				}
				else
				{
					if (gaBitrateTblCBR[iQB][0] <= maxBr)
					{
						if (gaBitrateTblCBR[iQB][0] == curBrCBR)
						{
							$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).addOption(gaBitrateTblCBR[iQB][0], gaBitrateTblCBR[iQB][1], true);
							bMatch = true;
						}
						else
						{
							$(document.getElementById("s"+s+"_"+codec+"_bitrate_cbr")).addOption(gaBitrateTblCBR[iQB][0], gaBitrateTblCBR[iQB][1], false);
						}
					}
				}
			}

			//Handle CBR customize.
			document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customInput").value = curBrCBR/1000;
            if((codec != "h264"))
            {
			    document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customDesc").innerHTML = "Kbps [20~"+parseInt(maxBr, 10)/1000+"]";
            }
            else
            {
			    document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customDesc").innerHTML = "Kbps [20~"+parseInt(maxBr, 10)/1000+"]";
            }
			if (bMatch)
			{
				document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customBlk").style.display = "none";
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customBlk").style.display = "block";
			}
		
			//Handle CBR priority.
			$(document.getElementById("s"+s+"_"+codec+"_prioritypolicy")).children().each(
				function()
				{
					if (this.value == eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_prioritypolicy"))
					{	
						this.selected = true;
					}
				}
			);

			//Handle CBR quant.
			if (!ParamUndefinedOrZero("capability_smartstream_version")&&capability_smartstream_version == "2.0")
			{
				curCbrQuant = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_quant");
				if (curCbrQuant == 99)
				{
					eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_quant=100");
					curCbrQuant = 100;
				}

				bMatch = false;
				$(document.getElementById("s"+s+"_"+codec+"_cbr_quant")).children().each(
					function()
					{
						if (this.value == curCbrQuant)
						{	
							this.selected = true;
							if (this.value != 100)
							{
								bMatch = true;
							}
						}
					}
				);
			
				//Handle CBR quant customize.
				document.getElementById("s"+s+"_"+codec+"_cbr_qpercent").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_qpercent");;
				if (bMatch)
				{
					document.getElementById("s"+s+"_"+codec+"_cbr_qpercentBlk").style.display = "none";
				}
				else
				{
					document.getElementById("s"+s+"_"+codec+"_cbr_qpercentBlk").style.display = "block";
				}
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_cbr_quality_option").style.display = "none";
			}


			//VBR:
			//IE7 didn't support "table-row" in css display, so use default value
			if ( IsMSIE7 == "1")
			{
				document.getElementById("s"+s+"_"+codec+"_flexible_vbr_Blk").style.display = "";
			}
			else
			{
			document.getElementById("s"+s+"_"+codec+"_flexible_vbr_Blk").style.display = "table-row";
			}
			$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).removeOption(/./);
			bMatch = false;
			for (iQB = 0; iQB < gaBitrateTblVBR.length; iQB++)
			{
				if (gaBitrateTblVBR[iQB][0] == 0)
				{
					$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).addOption(0, translator("customized"), true);
				}
				else
				{
					if (gaBitrateTblVBR[iQB][0] <= maxBr)
					{
						if (gaBitrateTblVBR[iQB][0] == curBrVBR)
						{
							$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).addOption(gaBitrateTblVBR[iQB][0], gaBitrateTblVBR[iQB][1], true);
							bMatch = true;
						}
						else
						{
							$(document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate")).addOption(gaBitrateTblVBR[iQB][0], gaBitrateTblVBR[iQB][1], false);
						}
					}
				}
			}

			//Handle VBR bit rate customize:
			document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customInput").value = curBrVBR /1000;
			document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customDesc").innerHTML = "Kbps [20~"+parseInt(maxBr, 10)/1000+"]";
			if (bMatch)
			{
				document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customBlk").style.display = "none";
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customBlk").style.display = "block";
			}
		
			//Handle VBR quant.
			curQuant = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant");
			if (curQuant == 99)
			{
				eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant=100");
				curQuant = 100;
			}

			bMatch = false;
			$(document.getElementById("s"+s+"_"+codec+"_quant")).children().each(
				function()
				{
					if (this.value == curQuant)
					{	
						this.selected = true;
						if (this.value != 100)
						{
							bMatch = true;
						}
					}
				}
			);
		
			//Handle VBR quant customize.
			document.getElementById("s"+s+"_"+codec+"_qpercent").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent");;
			if (bMatch)
			{
				document.getElementById("s"+s+"_"+codec+"_qpercentBlk").style.display = "none";
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_qpercentBlk").style.display = "block";
			}


			//Select & show current control mode.
			document.getElementById("s"+s+"_mjpeg_quantOldBlk").style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_QB_Child_cbr").style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_QB_Child_vbr").style.display = "none";
			//IE7 didn't support "table-row" in css display, so use default value
			if ( IsMSIE7 == "1")
			{
				document.getElementById("s"+s+"_"+codec+"_QB_Child_"+curQB_Ctrl).style.display = "";
			}
			else
			{
			document.getElementById("s"+s+"_"+codec+"_QB_Child_"+curQB_Ctrl).style.display = "table-row";
			}

			document.getElementById("s"+s+"_"+codec+"_QB_Radio_cbr").checked = false;
			document.getElementById("s"+s+"_"+codec+"_QB_Radio_vbr").checked = false;
			document.getElementById("s"+s+"_"+codec+"_QB_Radio_"+curQB_Ctrl).checked = true;
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_QB_Child_cbr").style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_QB_Child_vbr").style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_QB_Title_vbr").style.display = "none";
			document.getElementById("s"+s+"_mjpeg_flexible_cbr_Title").style.display = "none";
			document.getElementById("s"+s+"_"+codec+"_flexible_vbr_Blk").style.display = "none";
			document.getElementById("s"+s+"_mjpeg_quantOldBlk").style.display = "block";

			//Handle VBR. Take slightly UI adjust.
			curQuant = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant");
			if (curQuant == 99)
			{
				eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant=100");
				curQuant = 100;
			}

			bMatch = false;
			$(document.getElementById("s"+s+"_"+codec+"_quantOld")).children().each(
				function()
				{
					if (this.value == curQuant)
					{	
						this.selected = true;
						if (this.value != 100)
						{
							bMatch = true;
						}
					}
				}
			);
		
			//Handle VBR customize
			document.getElementById("s"+s+"_"+codec+"_qpercentOld").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent");;
			if (bMatch)
			{
				document.getElementById("s"+s+"_"+codec+"_qpercentOldBlk").style.display = "none";
			}
			else
			{
				document.getElementById("s"+s+"_"+codec+"_qpercentOldBlk").style.display = "block";
			}
		}

	}

}

function changeCodecType(s, codec)
{
	document.getElementById("s"+s+"h265radio").checked = false;
	document.getElementById("s"+s+"h264radio").checked = false;
	document.getElementById("s"+s+"mpeg4radio").checked = false;
	document.getElementById("s"+s+"mjpegradio").checked = false;
	document.getElementById("s"+s+codec+"radio").checked = true;

	if (bFastUI)
	{
		document.getElementById("s"+s+"h265Child").style.display = "none";
		document.getElementById("s"+s+"h264Child").style.display = "none";
		document.getElementById("s"+s+"mpeg4Child").style.display = "none";
		document.getElementById("s"+s+"mjpegChild").style.display = "none";
		document.getElementById("s"+s+codec+"Child").style.display = "block";
	}
	else
	{
		$(document.getElementById("s"+s+"h265Child")).slideUp();
		$(document.getElementById("s"+s+"h264Child")).slideUp();
		$(document.getElementById("s"+s+"mpeg4Child")).slideUp();
		$(document.getElementById("s"+s+"mjpegChild")).slideUp();
		$(document.getElementById("s"+s+codec+"Child")).slideDown();
	}

	eval("videoin_c"+giCH_Curr+"_s"+s+"_codectype='"+codec+"'");

	//This is necessary due to the maximum resolutions of each codec may be different.
	generateResolutionOptions(s, codec);
}

function changeResolution(s, codec, obj)
{
	var res = obj.options[obj.selectedIndex].value;
	if (res == eval("videoin_c"+giCH_Curr+"_s"+s+"_resolution"))
	{
		return;
	}

	eval("videoin_c"+giCH_Curr+"_s"+s+"_resolution='"+res+"'");

	//This is necessary due to the maximum encoded FPS depends on codec type and resolution.
	generateFPSOptions("s"+s+"_"+codec+"_fps", s, codec, res);
}

function changeFPS(s, codec, obj)
{
	var fps = obj.options[obj.selectedIndex].value;

	if (fps == 0)
	{
		document.getElementById("s"+s+"_"+codec+"_fps_customInput").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxframe");
		document.getElementById("s"+s+"_"+codec+"_fps_customBlk").style.display = "block";
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxframe='"+fps+"'");
		document.getElementById("s"+s+"_"+codec+"_fps_customBlk").style.display = "none";
	}
}

function setCustomFPS(s, codec, obj)
{
	if (checkNumRange(obj, parseInt(eval("gciMaxFps_"+codec+"_"+s+""), 10), 1) == -1)
	{
		obj.value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxframe");
		return;
	}
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxframe='"+obj.value+"'");
}

function changeIPeriod(s, codec, obj)
{
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_intraperiod='"+obj.value+"'");
	changeDGOPsecond(s, codec, obj.value);
}

function changeRateCtrlMode(s, codec, obj)
{
	iMaxSmartStream = parseInt(eval("capability_smartstream_nstream"));
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_ratecontrolmode='"+obj.value+"'");

	document.getElementById("s"+s+"_"+codec+"_QB_Radio_cbr").checked = false;
	document.getElementById("s"+s+"_"+codec+"_QB_Radio_vbr").checked = false;
	document.getElementById("s"+s+"_"+codec+"_QB_Radio_"+obj.value).checked = true;

	document.getElementById("s"+s+"_"+codec+"_QB_Child_cbr").style.display = "none";
	document.getElementById("s"+s+"_"+codec+"_QB_Child_vbr").style.display = "none";
	//IE7 didn't support "table-row" in css display, so use default value
	if ( IsMSIE7 == "1")
	{
		document.getElementById("s"+s+"_"+codec+"_QB_Child_"+obj.value).style.display = "";
	}
	else
	{
		document.getElementById("s"+s+"_"+codec+"_QB_Child_"+obj.value).style.display = "table-row";
	}

}

function enableSmart2(s, codec, checked)
{
	if (false == checked)
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream2_enable='0'");
		document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "none";
		document.getElementById("s"+s+"_"+codec+"_qualitypriority_help").style.display = "none";
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream2_enable='1'");
		document.getElementById("s"+s+"_"+codec+"_QB_Child_smart2").style.display = "table-row";
	}
}

function changeCBRbitrate(s, codec, obj)
{
	var Br = obj.options[obj.selectedIndex].value;

	if (Br == 0)
	{
		document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customInput").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate")/1000;
		document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customBlk").style.display = "block";
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate='"+Br+"'");
		document.getElementById("s"+s+"_"+codec+"_bitrate_cbr_customBlk").style.display = "none";
	}
}

function setCustomBitrateCBR(s, codec, obj)
{
	var Br = 1000 * obj.value;
	if((codec != "h264"))
    {
        if (checkNumRange(obj, parseInt(eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxbitrate"), 10)/1000, 20) == -1)
	    {
		    obj.value = parseInt(eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate"), 10)/1000;
		    return;
	    }
    }
    else
    {
        if (checkNumRange(obj, parseInt(eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxbitrate"), 10)/1000, 20) == -1)
	    {
		    obj.value = parseInt(eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate"), 10)/1000;
		    return;
	    }
    }
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_bitrate='"+Br+"'");
}

function changeCBRPolicy(s, codec, obj)
{
	var Po = obj.options[obj.selectedIndex].value;
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_prioritypolicy='"+Po+"'");
}

function changeQuant(s, codec, obj)
{
	var Quant = obj.options[obj.selectedIndex].value;

	if(eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_ratecontrolmode") == "cbr")
	{
		if (Quant == eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_quant"))
		{
			return;
		}

		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_quant='"+Quant+"'");
		if (Quant == 100)
		{
			document.getElementById("s"+s+"_"+codec+"_cbr_qpercent").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_qpercent");
			document.getElementById("s"+s+"_"+codec+"_cbr_qpercentBlk").style.display = "block";
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_cbr_qpercentBlk").style.display = "none";
		}

	}
	else
	{
		if (Quant == eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant"))
		{
			return;
		}

		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant='"+Quant+"'");
		if (Quant == 100)
		{
			document.getElementById("s"+s+"_"+codec+"_qpercent").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent");
			document.getElementById("s"+s+"_"+codec+"_qpercentBlk").style.display = "block";
		}
		else
		{
			document.getElementById("s"+s+"_"+codec+"_qpercentBlk").style.display = "none";
		}
	}
}

function changeQuantOld(s, codec, obj)
{
	var Quant = obj.options[obj.selectedIndex].value;
	if (Quant == eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant"))
	{
		return;
	}

	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_quant='"+Quant+"'");
	if (Quant == 100)
	{
		document.getElementById("s"+s+"_"+codec+"_qpercentOld").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent");
		document.getElementById("s"+s+"_"+codec+"_qpercentOldBlk").style.display = "block";
	}
	else
	{
		document.getElementById("s"+s+"_"+codec+"_qpercentOldBlk").style.display = "none";
	}
}

function setQpercent(s, codec, obj)
{
	if(eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_ratecontrolmode") == "cbr")
	{
		if (checkNumRange(obj, 100, 1) == -1)
		{
			obj.value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_qpercent");
			return;
		}
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_cbr_qpercent='"+obj.value+"'");
	}
	else
	{
		if (checkNumRange(obj, 100, 1) == -1)
		{
			obj.value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent");
			return;
		}
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_qpercent='"+obj.value+"'");
	}
}

function changeVBRbitrate(s, codec, obj)
{
	var Br = obj.options[obj.selectedIndex].value;

	if (Br == 0)
	{
		document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customInput").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxvbrbitrate")/1000;
		document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customBlk").style.display = "block";
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxvbrbitrate='"+Br+"'");
		document.getElementById("s"+s+"_"+codec+"_maxvbrbitrate_customBlk").style.display = "none";
	}
}

function setCustomBitrateVBR(s, codec, obj)
{
	var Br = 1000 * obj.value;
	if (checkNumRange(obj, parseInt(eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxbitrate"), 10)/1000, 20) == -1)
	{
		obj.value = parseInt(eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxvbrbitrate"), 10)/1000;
		return;
	}
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_maxvbrbitrate='"+Br+"'");
}

function saveStreamSettings()
{
	var XMLHttpRequestObject = null;
	var commitList = "";
	var commonList = "";
	var h265List = "";
	var h264List = "";
	var mpeg4List = "";
	var mjpegList = "";
	var h265FlexList = "";
	var h264FlexList = "";
	var mpeg4FlexList = "";
	var mjpegFlexList = "";
	var tmp = "";
    var tmp_smart_fg = "";
	var tmp_smart_bg = "";
	var h265dintraperiod_enable = "";
	var h264dintraperiod_enable = "";
	var h265smartstream2List = "";
	var h264smartstream2List = "";

    iMaxSmartStream = parseInt(eval("capability_smartstream_nstream"));

	$("#submitBtn").attr("disabled", true);
	$("#SavingIcon").show();

	for (iSave = 0; iSave < parseInt(capability_nmediastream, 10); iSave++)
	{
		tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_";
		commonList = tmp+"codectype="+eval(tmp+"codectype")+"&"+
				tmp+"resolution="+eval(tmp+"resolution")+"&";
		
		if (capability_videoin_codec.search("h265") != -1)
		{
			tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h265_";
            if(iSave < iMaxSmartStream)
            {
		    	h265List = tmp+"intraperiod="+eval(tmp+"intraperiod")+"&"+
			    	tmp+"ratecontrolmode="+eval(tmp+"ratecontrolmode")+"&"+
				    tmp+"quant="+eval(tmp+"quant")+"&"+
				    tmp+"qpercent="+eval(tmp+"qpercent")+"&"+
				    tmp+"bitrate="+eval(tmp+"bitrate")+"&"+
				    tmp+"maxframe="+eval(tmp+"maxframe")+"&";
            }
            else
            {
                h265List = tmp+"intraperiod="+eval(tmp+"intraperiod")+"&"+
			    	tmp+"ratecontrolmode="+eval(tmp+"ratecontrolmode")+"&"+
    				tmp+"quant="+eval(tmp+"quant")+"&"+
    				tmp+"qpercent="+eval(tmp+"qpercent")+"&"+
    				tmp+"bitrate="+eval(tmp+"bitrate")+"&"+
    				tmp+"maxframe="+eval(tmp+"maxframe")+"&";
            }
			
			if (!ParamUndefinedOrZero("capability_smartstream_version") && capability_smartstream_version == "2.0")
			{
				h265List = h265List + tmp+"cbr_quant="+eval(tmp+"cbr_quant")+"&"+
				    tmp+"cbr_qpercent="+eval(tmp+"cbr_qpercent")+"&";
			}
		}

		if (capability_videoin_codec.search("h264") != -1)
		{
			tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h264_";
            if(iSave < iMaxSmartStream)
            {
		    	h264List = tmp+"intraperiod="+eval(tmp+"intraperiod")+"&"+
			    	tmp+"ratecontrolmode="+eval(tmp+"ratecontrolmode")+"&"+
				    tmp+"quant="+eval(tmp+"quant")+"&"+
				    tmp+"qpercent="+eval(tmp+"qpercent")+"&"+
				    tmp+"bitrate="+eval(tmp+"bitrate")+"&"+
				    tmp+"maxframe="+eval(tmp+"maxframe")+"&";
            }
            else
            {
                h264List = tmp+"intraperiod="+eval(tmp+"intraperiod")+"&"+
			    	tmp+"ratecontrolmode="+eval(tmp+"ratecontrolmode")+"&"+
    				tmp+"quant="+eval(tmp+"quant")+"&"+
    				tmp+"qpercent="+eval(tmp+"qpercent")+"&"+
    				tmp+"bitrate="+eval(tmp+"bitrate")+"&"+
    				tmp+"maxframe="+eval(tmp+"maxframe")+"&";
            }
			
			if (!ParamUndefinedOrZero("capability_smartstream_version") && capability_smartstream_version == "2.0")
			{
				h264List = h264List + tmp+"cbr_quant="+eval(tmp+"cbr_quant")+"&"+
				    tmp+"cbr_qpercent="+eval(tmp+"cbr_qpercent")+"&";
			}
		}

		if (capability_videoin_codec.search("mpeg4") != -1)
		{
			tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_mpeg4_";
			mpeg4List = tmp+"intraperiod="+eval(tmp+"intraperiod")+"&"+
				tmp+"ratecontrolmode="+eval(tmp+"ratecontrolmode")+"&"+
				tmp+"quant="+eval(tmp+"quant")+"&"+
				tmp+"qpercent="+eval(tmp+"qpercent")+"&"+
				tmp+"bitrate="+eval(tmp+"bitrate")+"&"+
				tmp+"maxframe="+eval(tmp+"maxframe")+"&";
			
			if (!ParamUndefinedOrZero("capability_smartstream_version") && capability_smartstream_version == "2.0")
			{
				mpeg4List = mpeg4List + tmp+"cbr_quant="+eval(tmp+"cbr_quant")+"&"+
				    tmp+"cbr_qpercent="+eval(tmp+"cbr_qpercent")+"&";
			}
		}

		if (capability_videoin_codec.search("mjpeg") != -1)
		{
			tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_mjpeg_";
			mjpegList = tmp+"quant="+eval(tmp+"quant")+"&"+
				tmp+"qpercent="+eval(tmp+"qpercent")+"&"+
				tmp+"maxframe="+eval(tmp+"maxframe")+"&";
			
			if (!ParamUndefinedOrZero("capability_smartstream_version") && capability_smartstream_version == "2.0")
			{
				mjpegList = mjpegList + tmp+"cbr_quant="+eval(tmp+"cbr_quant")+"&"+
				    tmp+"cbr_qpercent="+eval(tmp+"cbr_qpercent")+"&";
			}
		}

		commitList = "/cgi-bin/admin/setparam.cgi?"+ commonList + h265List + h264List + mpeg4List + mjpegList;
		$.ajax 
		({
			async: false,
			url: commitList,
			success: function(data)
			{
				eval(data);
			}
                });

                commitList = "/cgi-bin/admin/setparam.cgi?";
		if (!ParamUndefinedOrZero("capability_videoin_flexiblebitrate"))
		{
			if (capability_videoin_codec.search("h265") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h265_";
				h265FlexList =	tmp+"prioritypolicy="+eval(tmp+"prioritypolicy")+"&"+
					tmp+"maxvbrbitrate="+eval(tmp+"maxvbrbitrate")+"&";
			}

			if (capability_videoin_codec.search("h264") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h264_";
				h264FlexList =	tmp+"prioritypolicy="+eval(tmp+"prioritypolicy")+"&"+
					tmp+"maxvbrbitrate="+eval(tmp+"maxvbrbitrate")+"&";
			}

			if (capability_videoin_codec.search("mpeg4") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_mpeg4_";
				mpeg4FlexList = tmp+"prioritypolicy="+eval(tmp+"prioritypolicy")+"&"+
					tmp+"maxvbrbitrate="+eval(tmp+"maxvbrbitrate")+"&";
			}

			if (capability_videoin_codec.search("mjpeg") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_mjpeg_";
				mjpegFlexList = tmp+"prioritypolicy="+eval(tmp+"prioritypolicy")+"&"+
					tmp+"ratecontrolmode="+eval(tmp+"ratecontrolmode")+"&"+
					tmp+"bitrate="+eval(tmp+"bitrate")+"&"+
					tmp+"maxvbrbitrate="+eval(tmp+"maxvbrbitrate")+"&";
			}

			commitList = commitList + h265FlexList + h264FlexList + mpeg4FlexList + mjpegFlexList;
		}

		if (!ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_dintraperiod_support"))
		{
			if (capability_videoin_codec.search("h265") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h265_";
				h265dintraperiod_enable =	tmp+"dintraperiod_enable="+eval(tmp+"dintraperiod_enable")+"&";
			}

			if (capability_videoin_codec.search("h264") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h264_";
				h264dintraperiod_enable =	tmp+"dintraperiod_enable="+eval(tmp+"dintraperiod_enable")+"&";
			}

			commitList = commitList + h265dintraperiod_enable + h264dintraperiod_enable;
		}
		
		if (!ParamUndefinedOrZero("capability_smartstream_version") && capability_smartstream_version == "2.0")
		{
			if (capability_videoin_codec.search("h265") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h265_";
				h265smartstream2List =	
					tmp+"smartstream2_enable="+eval(tmp+"smartstream2_enable")+"&"+
					tmp+"smartstream2_mode="+eval(tmp+"smartstream2_mode")+"&"+
					tmp+"smartstream2_qualitypriority="+eval(tmp+"smartstream2_qualitypriority")+"&";
			}

			if (capability_videoin_codec.search("h264") != -1)
			{
				tmp = "videoin_c"+giCH_Curr+"_s"+iSave+"_h264_";
				h264smartstream2List =	
					tmp+"smartstream2_enable="+eval(tmp+"smartstream2_enable")+"&"+
					tmp+"smartstream2_mode="+eval(tmp+"smartstream2_mode")+"&"+
					tmp+"smartstream2_qualitypriority="+eval(tmp+"smartstream2_qualitypriority")+"&";
			}

			commitList = commitList + h265smartstream2List + h264smartstream2List;
		}

		$.ajax 
		({
			async: false,
			url: commitList,
			success: function(data)
			{
				eval(data);
			}
                });
		//XMLHttpRequestObject.open("GET", commitList);
		//XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
		//XMLHttpRequestObject.send(null);
	}

	setTimeout('$("#submitBtn").attr("disabled", false)', 500);
	setTimeout('$("#SavingIcon").hide()', 500);
}

//---ROI functions---
function showROISetting(s)
{
	var sNum = 0;

	giS_Curr = s;
	gFullSceneW = parseInt(eval("capability_videoin_c"+giCH_Curr+"_mode"+gciMode_Curr+"_outputsize").split("x")[0], 10);
	gFullSceneH = parseInt(eval("capability_videoin_c"+giCH_Curr+"_mode"+gciMode_Curr+"_outputsize").split("x")[1], 10);

	//Get full scene image.
	giROIunitW = 400;
	giROIunitH = parseInt(400 * gFullSceneH / gFullSceneW, 10); //4:3 300, 16:9 225
	giROIJpgW = giROIunitW;
	giROIJpgH = giROIunitH;
	gfROIRatioX = gFullSceneW/giROIunitW;
	gfROIRatioY = gFullSceneH/giROIunitH;

	//swap the value of these variables if rotated
	if (checkIsRotate(giCH_Curr)) 
	{
		eval(swap('gFullSceneW'   , 'gFullSceneH'   ));
		eval(swap('giROIunitW'    , 'giROIunitH'    ));
		eval(swap('gfROIRatioX'   , 'gfROIRatioY'   ));
		eval(swap('gMinW'         , 'gMinH'         ));
		eval(swap('gJcropMaxSizeW', 'gJcropMaxSizeH'));
	}

	gImgSrc = "/cgi-bin/viewer/video.jpg?channel="+giCH_Curr+"&streamid=" + FullviewStreamIndex() + "&resolution="+giROIJpgW+"x"+giROIJpgH+"&quality=5";

	//Get coordinate infos.
	giROIx = parseInt(eval("roi_c"+giCH_Curr+"_s"+s+"_home").split(",")[0], 10);
	giROIy = parseInt(eval("roi_c"+giCH_Curr+"_s"+s+"_home").split(",")[1], 10);
	giROIw = parseInt(eval("roi_c"+giCH_Curr+"_s"+s+"_size").split("x")[0], 10);
	giROIh = parseInt(eval("roi_c"+giCH_Curr+"_s"+s+"_size").split("x")[1], 10);

	//Alignment and check.
	if (checkIsRotate(giCH_Curr)) 
	{
		eval(swap('giROIw', 'giROIh'));
		eval(swap('giROIx', 'giROIy'));
		// temporary change the alignment to be loose (need to be discussed)
		giROIx = parseInt(giROIx/gHAlign, 10) * gHAlign; 
		giROIy = parseInt(giROIy/gHAlign, 10) * gHAlign;
		giROIw = parseInt(giROIw/gHAlign, 10) * gHAlign;
		giROIh = parseInt(giROIh/gHAlign, 10) * gHAlign;
	}
	else
	{
		giROIx = parseInt(giROIx/gWAlign, 10) * gWAlign;
		giROIy = parseInt(giROIy/gHAlign, 10) * gHAlign;
		giROIw = parseInt(giROIw/gWAlign, 10) * gWAlign;
		giROIh = parseInt(giROIh/gHAlign, 10) * gHAlign;
	}
	
	if (giROIx + giROIw > gFullSceneW)
	{
		giROIw = gFullSceneW - giROIx;
	}
	if (giROIy + giROIh > gFullSceneH)
	{
		giROIh = gFullSceneH - giROIy;
	}

	//Setup ROI options
	$(document.getElementById("roi_select")).removeOption(/./);
	for (iROI = 0; iROI < gaROITbl.length; iROI++)
	{
		if (checkIsRotate(giCH_Curr)) 
		{
			if (gaROITbl[iROI][0] == "custom")
			{
				$(document.getElementById("roi_select")).addOption(""+giROIh+"x"+giROIw,
					"("+giROIx+","+giROIy+") "+giROIh+"x"+giROIw+" custom", true);
			}
			else if (gFullSceneW >= parseInt(gaROITbl[iROI][0].split("x")[1], 10) &&
				gFullSceneH >= parseInt(gaROITbl[iROI][0].split("x")[0], 10))
			{
				$(document.getElementById("roi_select")).addOption(gaROITbl[iROI][0],
					"(0,0) "+gaROITbl[iROI][0]+" ("+gaROITbl[iROI][1]+")", false);
			}
		}
		else
		{
			if (gaROITbl[iROI][0] == "custom")
			{
				$(document.getElementById("roi_select")).addOption(""+giROIw+"x"+giROIh,
					"("+giROIx+","+giROIy+") "+giROIw+"x"+giROIh+" custom", true);
			}
			else if (gFullSceneW >= parseInt(gaROITbl[iROI][0].split("x")[0], 10) &&
				gFullSceneH >= parseInt(gaROITbl[iROI][0].split("x")[1], 10))
			{
				$(document.getElementById("roi_select")).addOption(gaROITbl[iROI][0],
					"(0,0) "+gaROITbl[iROI][0]+" ("+gaROITbl[iROI][1]+")", false);
			}
		}
	}

	//Show UI.
	if (parseInt(capability_nvideoin, 10) == 1)
	{
		document.getElementById("roi_chblk").style.display = "none";
	}
	else
	{
		document.getElementById("roi_chblk").style.display = "block";
		document.getElementById("roi_chcel").selectedIndex = giCH_Curr;
	}

	$(document.getElementById("roi_streamselect")).removeOption(/./);
	for (iROINum = 0; iROINum < parseInt(capability_nmediastream, 10); iROINum++)
	{
		if (gciStreamEPTZSupport[iROINum] == 1)
		{
			if(iROINum == s)
			{
				$(document.getElementById("roi_streamselect")).addOption(iROINum, "stream"+(iROINum+1), true);
			}
			else
			{
				$(document.getElementById("roi_streamselect")).addOption(iROINum, "stream"+(iROINum+1), false);
			}
		}
	}

	//Dirty, but work.
	$(document.getElementById("ROI_bl")).remove();
	$(document.getElementById("ROI_Tab")).append("<div class='tab-bottom-line' id='ROI_bl'></div>");
	$(document.getElementById("tab_ROIblk")).css({"padding":"5px 5px 6px"});
	$(document.getElementById("tab_ROIblk")).children("li").css(
	{
		"margin-left":"2px", "padding":"5px", "border":"1px solid #BFBAB0",
		"border-width":"1px 1px 0px 1px", "background":"#C4EAFF",
		"text-align":"center", "position":"relative", "z-index":"0"
	});
	$(document.getElementById("tab_videomodeROI")).hover(
		function()
		{
			$(this).css({"background":"#fff9d7"});
		}, function()
		{
			$(this).css({"background":"#C4EAFF"});
	 	}
	);
	$(document.getElementById("tab_streamROI")).hover(
		function()
		{
			$(this).css({"background":"#fff9d7"});
		}, function()
		{
			$(this).css({"background":"#C4EAFF"});
	 	}
	);
	$(document.getElementById("tab_ROIblk")).children("li").children("a").css({"text-decoration":"none", "color":"#666"});
	$(document.getElementById("tab_ROIblk")).children("li").children("a").click(function(e)
	{
   		e.preventDefault();
    });
	$(document.getElementById("tab_roi")).css({"z-index":"2", "background-color":"#fff"});
	$(document.getElementById("tab_roi")).children("a").css("color" , "#0186d1");

	document.getElementById("roi_fullscene").innerHTML = "" + translator("full_view") +
		": "+eval("capability_videoin_c"+giCH_Curr+"_mode"+gciMode_Curr+"_outputsize");
	document.getElementById("content").style.display = "none";
	document.getElementById("roiBlk").style.display = "block";


	gbROIChanged = false;
	document.getElementById("roi_savenote").style.display = "none";
	document.getElementById("roi_savebutton").disabled = true;

	//Start refreah image peridically.
	if (gImg == null)
	{
		gImg = new Image();
		gImg.onload = function()
		{
			$("#JcropBG").attr("src", gImg.src);
			$("#JcropFG").attr("src", gImg.src);
			gROITimer = setTimeout("updateROIImg()", guiROIRefreshImgTime_ms);
		};

		gImg.onerror = function()
		{
			gROITimer = setTimeout("updateROIImg()", guiROIRefreshImgTime_ms);
		};

		gImg.onerror = function()
		{
			gROITimer = setTimeout("updateROIImg()", guiROIRefreshImgTime_ms);
		};
	}

	if (bUpdateImg == false)
	{
		bUpdateImg = true;
		gROITimer = setTimeout("updateROIImg()", 100);
	}

	//Use JQuery:Crop
	gbFirstCoord = true;
	gJcropObj = $(document.getElementById("roi_area")).Jcrop(
	{
		onSelect: updateROICoord,
		onChange: updateROICoord,
		maxSize: [gJcropMaxSizeW, gJcropMaxSizeH],
		minSize: [gMinW/gfROIRatioX, gMinH/gfROIRatioY],
		boxWidth: giROIunitW,
		boxHeight: giROIunitH,
		trueSize: [gFullSceneW, gFullSceneH],
		setSelect: [giROIx/gfROIRatioX, giROIy/gfROIRatioY, (giROIw+giROIx)/gfROIRatioX, (giROIh+giROIy)/gfROIRatioY]
	});
}

function updateROIImg()
{
	var da;

	if (bUpdateImg == false)
	{
		return;
	}

	da = new Date();
	gImg.src = ""+gImgSrc +"&date="+da.getTime();;

}

function closeROI(m)
{
	var objImg;

	bUpdateImg = false;
	clearTimeout(gROITimer);

	objImg = addImg("roi_area2", "/pic/noimg.jpg", "400px", "300px", "none");
	document.getElementById("roi_areaParent").appendChild(objImg);
	$(".jcrop-holder #cropbox").remove();
	$(".jcrop-holder").remove();
	$(document.getElementById("roi_area")).remove();
	document.getElementById("roi_area2").id = "roi_area";
	gJCropFirstLoadImg = true;


	document.getElementById("content").style.display = "block";
	document.getElementById("roiBlk").style.display = "none";

	if (m == 0)
	{
		document.getElementById("tab_videomode").click();
	}
	else
	{
		document.getElementById("tab_stream").click();
	}
}

function changeROIOption(roiSize)
{
	var customIdx;

	if (roiSize == "custom")
	{
		return;
	}

	gbROIChanged = true;
	document.getElementById("roi_savenote").style.display = "block";
	document.getElementById("roi_savebutton").disabled = false;

	customIdx = parseInt(document.getElementById("roi_select").length, 10) - 1;

	giROIx = 0;
	giROIy = 0;
	if (checkIsRotate(giCH_Curr)) 
	{
		giROIw = parseInt(roiSize.split("x")[1], 10);
		giROIh = parseInt(roiSize.split("x")[0], 10);
	}
	else
	{
		giROIw = parseInt(roiSize.split("x")[0], 10);
		giROIh = parseInt(roiSize.split("x")[1], 10);
	}

	$(document.getElementById("roi_area")).Jcrop(
	{
		setSelect: [giROIx/gfROIRatioX, giROIy/gfROIRatioY, (giROIw+giROIx)/gfROIRatioX, (giROIh+giROIy)/gfROIRatioY]
	});

	//Do again due to axis values in Jcrop may differ from these ones slightly.
	if (checkIsRotate(giCH_Curr)) 
	{
		giROIw = parseInt(roiSize.split("x")[1], 10);
		giROIh = parseInt(roiSize.split("x")[0], 10);
	}
	else
	{
		giROIw = parseInt(roiSize.split("x")[0], 10);
		giROIh = parseInt(roiSize.split("x")[1], 10);
	}
	document.getElementById("roi_select")[customIdx].text = "(0,0) "+roiSize+" custom";
	document.getElementById("roi_select").selectedIndex = customIdx;
}

function updateROICoord(c)
{
	var customIdx = parseInt(document.getElementById("roi_select").length, 10) - 1;

	if (gbFirstCoord)
	{
		if (checkIsRotate(giCH_Curr)) 
		{
			document.getElementById("roi_select")[customIdx].text = "("+giROIy+","+giROIx+") "+giROIh+"x"+giROIw+" custom";
		}
		else
		{
			document.getElementById("roi_select")[customIdx].text = "("+giROIx+","+giROIy+") "+giROIw+"x"+giROIh+" custom";
		}
		gbFirstCoord = false;
		return;
	}
	else
	{
		gbROIChanged = true;

		if (checkIsRotate(giCH_Curr))
		{
			// temporary change the alignment to be loose (need to be discussed)
			giROIx = parseInt(c.x/gHAlign, 10) * gHAlign;
			giROIy = parseInt(c.y/gHAlign, 10) * gHAlign;
			giROIw = parseInt((c.w + gHAlign/2)/gHAlign, 10) * gHAlign;
			giROIh = parseInt((c.h + gHAlign/2)/gHAlign, 10) * gHAlign;
			
			if (giROIw < 144)
			{
				giROIw = 144;
			}
			if (giROIh < 176)
			{
				giROIh = 176;
			}

			document.getElementById("roi_select")[customIdx].text = "("+giROIy+","+giROIx+") "+giROIh+"x"+giROIw+" custom";

		}
		else
		{
			giROIx = parseInt(c.x/gWAlign, 10) * gWAlign;
			giROIy = parseInt(c.y/gHAlign, 10) * gHAlign;
			giROIw = parseInt((c.w + gWAlign/2)/gWAlign, 10) * gWAlign;
			giROIh = parseInt((c.h + gHAlign/2)/gHAlign, 10) * gHAlign;
			if (giROIw < 176)
			{
				giROIw = 176;
			}
			if (giROIh < 144)
			{
				giROIh = 144;
			}

			document.getElementById("roi_select")[customIdx].text = "("+giROIx+","+giROIy+") "+giROIw+"x"+giROIh+" custom";

		}
		
		document.getElementById("roi_savenote").style.display = "block";
		document.getElementById("roi_savebutton").disabled = false;
	}
}

function saveROI()
{
	var XMLHttpRequestObject = null;
	var commitList = "/cgi-bin/admin/setparam.cgi?";
	var tmp;
	var curROIRes;

	if (window.XMLHttpRequest)
	{
		XMLHttpRequestObject = new XMLHttpRequest();
	}
	else if (window.ActiveXObject)
	{
		XMLHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
	}
	
	if (checkIsRotate(giCH_Curr)) 
	{
		eval(swap('giROIw', 'giROIh'));
		eval(swap('giROIx', 'giROIy'));
	}

	curROIRes = +giROIw+"x"+giROIh;
	
	gbSupportMaxResPerStream = !(ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_maxresolution"));
	gbSupportMinResPerStream = !(ParamUndefinedOrZero("capability_videoin_c"+giCH_Curr+"_minresolution"));

	if (gbSupportMaxResPerStream)
	{
		maxsizeTable = eval("capability_videoin_c"+giCH_Curr+"_maxresolution");
		maxsizeTable = maxsizeTable.split(",");
		maxRes = maxsizeTable[giS_Curr];
		
		if (gbSupportMinResPerStream)
		{
			minsizeTable = eval("capability_videoin_c"+giCH_Curr+"_minresolution");
			minsizeTable = minsizeTable.split(",");
			minRes = minsizeTable[giS_Curr];
		}
		else
		{
			sizeTable = eval("capability_videoin_c"+giCH_Curr+"_resolution");
			sizeTable = sizeTable.split(",");
			minRes = sizeTable[0];
		}

		//If the ROI resolution is larger than the max. resolution of current stream, 
		//then /2 until the ROI resolution is smaller than the max. resolution and larger than the min. resolution
		if (curROIRes == eval("capability_videoin_c"+giCH_Curr+"_mode"+gciMode_Curr+"_outputsize"))
		{
			curROIRes = maxRes;
		}
		else if ((parseInt(giROIw,10) > parseInt(maxRes.split("x")[0], 10)) 
		|| (parseInt(giROIh,10) > parseInt(maxRes.split("x")[1], 10)))		
		{
			giROIwTemp = giROIw;
			giROIhTemp = giROIh;
			while ((parseInt(giROIwTemp,10) >= parseInt(minRes.split("x")[0], 10))
			|| (parseInt(giROIhTemp,10) >= parseInt(minRes.split("x")[1], 10)))
			{
				giROIwTemp = parseInt(giROIwTemp/ 2 / gWAlign, 10) * gWAlign;
				giROIhTemp = parseInt(giROIhTemp/ 2 / gHAlign, 10) * gHAlign;
				if ((parseInt(giROIwTemp,10) <= parseInt(maxRes.split("x")[0], 10)) 
				&& (parseInt(giROIhTemp,10) <= parseInt(maxRes.split("x")[1], 10))
				&& (parseInt(giROIwTemp,10) >= parseInt(minRes.split("x")[0], 10))
				&& (parseInt(giROIhTemp,10) >= parseInt(minRes.split("x")[1], 10)))
				{
					curROIRes = +giROIwTemp+"x"+giROIhTemp;
					break;
				}
				curROIRes = minRes;
			}
		}
		else if ((parseInt(giROIw,10) < parseInt(minRes.split("x")[0], 10))
		|| (parseInt(giROIh,10) < parseInt(minRes.split("x")[1], 10)))	
		{
			curROIRes = minRes;
		}
	}
	
	tmp = "roi_c"+giCH_Curr+"_s"+giS_Curr+"_home="+giROIx+","+giROIy+
		"&roi_c"+giCH_Curr+"_s"+giS_Curr+"_size="+giROIw+"x"+giROIh+
		"&videoin_c"+giCH_Curr+"_s"+giS_Curr+"_resolution="+curROIRes;
	commitList = commitList + tmp;

	tmp = "roi_c"+giCH_Curr+"_s"+giS_Curr+"_home='"+giROIx+","+giROIy+"'";
	eval(tmp);
	tmp = "roi_c"+giCH_Curr+"_s"+giS_Curr+"_size='"+giROIw+"x"+giROIh+"'";
	eval(tmp);
	tmp = "videoin_c"+giCH_Curr+"_s"+giS_Curr+"_resolution='"+curROIRes+"'";
	eval(tmp);

	XMLHttpRequestObject.open("GET", commitList);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	setupCtrlUIbyStream(giS_Curr);

	gbROIChanged = false;
	document.getElementById("roi_savenote").style.display = "none";
	document.getElementById("roi_savebutton").disabled = true;
}
//---End of ROI functions---
//---End of Stream-based functions---

//--- Other functions---
function switchBlockFast(block, icon)
{

	var aBlock = document.getElementById(block);
	var aIcon = document.getElementById(icon);

	if (aIcon.src.indexOf("/pic/rightArrow.gif") != -1)
	{
		if (bFastUI)
		{
			aBlock.style.display = "block";
		}
		else
		{
			$('#'+block).slideToggle("slow" ,function(){
				$('#'+block).css("zoom", "1"); 
			});
		}
		aIcon.src = "/pic/downArrow.gif";
	}
	else
	{
		if (bFastUI)
		{
			aBlock.style.display = "none";
		}
		else
		{
			$('#'+block).slideToggle("slow",function(){
				$('#'+block).css("zoom", "1");
			});
		}
		aIcon.src = "/pic/rightArrow.gif";
	}
	
}
//--- End of Other functions---

//--- smart stream functions ---
function showSmartStream2ManualWindowSetting(obj, chan, s, codec)//for smart stream
{
	var mode = obj.options[obj.selectedIndex].value;

    if(obj.selectedIndex == 1 || obj.selectedIndex == 2)
    {
        $("#"+"c"+chan+"_s"+s+"_"+codec+"_smartstream2_manual_window_setting").fadeIn().attr("disabled",false);
    }
    else
    {
        $("#"+"c"+chan+"_s"+s+"_"+codec+"_smartstream2_manual_window_setting").fadeOut().attr("disabled",true);
    }
    eval("videoin_c"+chan+"_s"+s+"_"+codec+"_smartstream2_mode='"+mode+"'");
}

function changeSmartQuant(s, usage, obj, codec)
{
	var Quant = obj.options[obj.selectedIndex].value;
/*	if (Quant == eval("videoin_c"+giCH_Curr+"_s"+s+"_h264_smartstream_"+usage+"_quant"))
	{
		return;
	}*/

	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_"+usage+"_quant='"+Quant+"'");
//    if (Quant == 99)
//    {
//        document.getElementById("s"+s+"_"+codec+"_smart_"+usage+"_quant_customInput").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_"+usage+"_qvalue");
//        document.getElementById("s"+s+"_"+codec+"_smart_"+usage+"_quant_customBlk").style.display = "block";
//    }
//    else
//    {
//        document.getElementById("s"+s+"_"+codec+"_smart_"+usage+"_quant_customBlk").style.display = "none";
//    }
}

//function setSmartQuantCustom(s, usage, obj, codec)
//{
//    if (checkNumRange(obj, 51, 0) == -1)
//    {
//        obj.value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_"+usage+"_qvalue");
//        return;
//    }
//    eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_"+usage+"_qvalue='"+obj.value+"'");
//}

function changeSmartBitrate(s, obj, codec)
{
	var Br = obj.options[obj.selectedIndex].value;
    var t = 0;
	if (Br == 0)
	{
		document.getElementById("s"+s+"_"+codec+"_smart_maxbitrate_customInput").value = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_maxbitrate")/1000;
		t = eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_maxbitrate")/1000;
		document.getElementById("s"+s+"_"+codec+"_smart_maxbitrate_customBlk").style.display = "block";
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_maxbitrate='"+Br+"'");
		document.getElementById("s"+s+"_"+codec+"_smart_maxbitrate_customBlk").style.display = "none";
	}
}

function setSmartBitrate(s, obj, codec)
{
	var Br = 1000 * obj.value;
	if (checkNumRange(obj, parseInt(eval("capability_videoin_c"+giCH_Curr+"_"+codec+"_maxbitrate"), 10)/1000, 20) == -1)
	{
		obj.value = parseInt(eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_maxbitrate"), 10)/1000;
		return;
	}
	eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_smartstream_maxbitrate='"+Br+"'");
}
//--- End of smart stream functions---

function checkMSIE7()
{
	if(navigator.appVersion.indexOf("MSIE 7.") != -1)
	{
		//IE 7
		IsMSIE7 = 1;
	}
	else
	{
		//not IE 7
		IsMSIE7 = 0;
	}
}

function showViewingWindowLink()
{
	if (capability_eptz != 0) 
	{
		return true;
	}
	else
	{
		return false;
	}
}

function waitToUnblockUI(chNumber)
{
	$.ajax({
		url: "/cgi-bin/admin/getparam.cgi?capability_videoin_c" + chNumber + "_mode&videoin_c" + chNumber + "_mode",
		cache: false,
		async: false,
		error: function(){
			setTimeout("waitToUnblockUI(" + chNumber + ");", 500);
		},
		success: function(data){
			eval(data);
			if (eval("capability_videoin_c" + chNumber + "_mode") != eval("videoin_c" + chNumber + "_mode"))
			{
			   setTimeout("waitToUnblockUI(" + chNumber + ");", 500);
	        }
	        else
			{
				$.unblockUI();
				$("#SavingIconMode"+gciTargetMode).hide();
				location.reload();
			}
		}
	});
}

function composeWarningMsg()
{
	var bEPTZ = (ParamUndefinedOrZero("capability_eptz") == false)? true : false;
	if (true == bEPTZ)
	{
		var msgStart = "Changing mode will clear following settings:\n"
		var msgEnd   = "\nDo you want to continue?"
	
		// general features
		var msgClearItems = translator("motion") + "\n" + translator("privacy_mask") + "\n" + translator("exposure_window") + "\n"; 

		// optional features
		if (gbCheckROILink) 
		{
			msgClearItems += translator("viewing_window");
			msgClearItems += "\n";
		}
		if (capability_npreset != 0) 
		{
			msgClearItems += translator("preset_position");
			msgClearItems += "\n";
		}
		if (parseInt(eval("capability_image_c"+giCH_Curr+"_remotefocus")) == 1 || parseInt(eval("capability_image_c"+giCH_Curr+"_remotefocus")) == 4) 
		{
			msgClearItems += translator("focus_window");
			msgClearItems += "\n";
		}
	
		return msgStart + msgClearItems + msgEnd;
	}
	else
	{
		msg = translator("videomode_switch_warning_20s_message");
		return msg;
	}
}

function displayDGOP(isDisplay)
{
	if (isDisplay == true)
	{
		for (i = 0 ; i < parseInt(capability_nmediastream, 10); i++ )
		{
			if (capability_videoin_codec.search("h265") != -1)
			{
				document.getElementById("s"+i+"_h265_dintraperiod_checkbox").style.display = "inline-block";

				if ( 1 == parseInt(eval("videoin_c"+giCH_Curr+"_s"+ i +"_h265_dintraperiod_enable"), 10))
				{
					document.getElementById("s"+i+"_h265_dintraperiod_enable").checked = true;
				}
				else
				{
					document.getElementById("s"+i+"_h265_dintraperiod_enable").checked = false;
				}
			}

			if (capability_videoin_codec.search("h264") != -1)
			{
				document.getElementById("s"+i+"_h264_dintraperiod_checkbox").style.display = "inline-block";

				if ( 1 == parseInt(eval("videoin_c"+giCH_Curr+"_s"+ i +"_h264_dintraperiod_enable"), 10))
				{
					document.getElementById("s"+i+"_h264_dintraperiod_enable").checked = true;
				}
				else
				{
					document.getElementById("s"+i+"_h264_dintraperiod_enable").checked = false;
				}
			}
		}
	}
	else
	{
		for (i = 0 ; i < parseInt(capability_nmediastream, 10); i++ )
		{
			if (capability_videoin_codec.search("h265") != -1)
			{
				document.getElementById("s"+i+"_h265_dintraperiod_checkbox").style.display = "none";	
			}

			if (capability_videoin_codec.search("h264") != -1)
			{
				document.getElementById("s"+i+"_h264_dintraperiod_checkbox").style.display = "none";	
			}
		}
	}

}

function enableDGOP(s, codec, isEnable)
{
	if (isEnable == true)
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_"+"dintraperiod_enable=1");
	}
	else
	{
		eval("videoin_c"+giCH_Curr+"_s"+s+"_"+codec+"_"+"dintraperiod_enable=0");
	}
}

function changeDGOPsecond(s, codec, second)
{
	iSecond = parseInt(second, 10);
	switch(iSecond)
	{
		case 250:
			$("#s"+s+"_"+codec+"_dintraperiod_note").html("1/4");
			break;
		case 500:
			$("#s"+s+"_"+codec+"_dintraperiod_note").html("1/2");
			break;
		case 1000:
			$("#s"+s+"_"+codec+"_dintraperiod_note").html("1");
			break;
		case 2000:
			$("#s"+s+"_"+codec+"_dintraperiod_note").html("2");
			break;
		case 3000:
			$("#s"+s+"_"+codec+"_dintraperiod_note").html("3");
			break;
		case 4000:
			$("#s"+s+"_"+codec+"_dintraperiod_note").html("4");
			break;
		default:
	}
}

function covertToSmartSliderValue(ori_value)
{
	if (ori_value < 1)
	{
		return ori_value + 1;
	}
	else
	{
		return ori_value;
	}
}

function smartCodecHelpDisplay(help_id)
{
	if($("#"+help_id).css('display') == 'none')
	{
		$("#"+help_id).fadeIn();
	} 
	else
	{
		$("#"+help_id).fadeOut();
	}
}
