var EVENT_MAX_NUM = 3;
var EVTMGR_TRIG_NUM;

var	gTopics = new Array();
var gTriggerNames = new Array();
var	gTopicNum = 0;
var	gSelectedTrigNum = 0;
var gbLoadFinish = false;

function loadCurrentSetting()
{
	var i;
	bSaved = false;

	OnvifGetEventProperties();

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?vadp_event&event_i0_vadp&event_i1_vadp&event_i2_vadp", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	loadlanguage();
}

function loadvaluedone()
{
	while (!gbLoadFinish)
	{
	}

	UpdateTrigList();
	$('#toRight').click(function(){
		$('#Left :selected').each(function (){
			if (gSelectedTrigNum < EVTMGR_TRIG_NUM)
		{
			$(this).appendTo($('#Right'));
			gSelectedTrigNum++;
		}
		});
	});
	$('#toLeft').click(function(){
		$('#Right :selected').each(function (){
			$(this).appendTo($('#Left'));
			gSelectedTrigNum--;
		});
	});
}

// Note: if there is some error in soap communication, gTopicNum = 0.
// The left select box will be left empty.
function UpdateTrigList()
{
	var selected_topic, selected_trigger_name;
	var select_flag = new Array(), event_used_flag = 0;
	var topic_split;
	var selected_topic_valid;
	var	invalid_topic_num = 0;
	var	invalid_topics = new Array();

	for (i = 0; i < EVENT_MAX_NUM; i++)
	{
		event_used_flag |= eval('event_i' + i + '_vadp');
	}
	for (i = 0; i < gTopicNum; i++)
	{
		select_flag[i] = 0;
	}

	invalid_topic_num = 0;
	for (i = 0; i < EVTMGR_TRIG_NUM; i++)
	{
		selected_topic = eval('vadp_event_triggerlist_i' + i + '_topic');

		if (selected_topic == '')
		{
			continue;
		}

		topic_split = selected_topic.split("/");
		selected_trigger_name = topic_split[topic_split.length - 1];

		selected_topic_valid = false;
		for (j = 0; j < gTopicNum; j++)
		{
			if (selected_topic == gTopics[j])
			{
				select_flag[j] = 1;
				selected_topic_valid = true;
			}
		}
		if (!selected_topic_valid)
		{
			//add invalid topics in warning.
			invalid_topics[invalid_topic_num] = selected_topic;
			invalid_topic_num++;
		}
		if ((event_used_flag & (1 << i)) == 0)
		{
			$('#Right').append('<option value="-1" title="' + selected_topic + '">' + selected_trigger_name + '</option>');
			$('#i' + i + '_topic')[0].value = ""; 
		}
		else
		{
			$('#Right').append('<option value="' + i + '" title="' + selected_topic + '" disabled>' + selected_trigger_name + '</option>');
			$('#i' + i + '_topic')[0].value = selected_topic;
		}
		gSelectedTrigNum++;
	}

	for (i = 0; i < gTopicNum; i++)
	{
		if (select_flag[i] == 0)
		{
			$('#Left').append('<option value="-1" title="' + gTopics[i] + '">' + gTriggerNames[i] + '</option>');
		}
	}

	if (invalid_topic_num != 0)
	{

		var invalid_topic_str = "";
		for (i = 0; i < invalid_topic_num; i++)
		{
			invalid_topic_str = invalid_topic_str + '<br/>' + invalid_topics[i];
		}

		$('#vadptrigger_warning').append('<p class="note">Warning: The following triggers are invalid due to some error in the system.' + invalid_topic_str + '</p>');
		$('#vadptrigger_warning').show();
	}
}

function handleXmlReturn(returnText)
{
	var searchTarget = "ParentTopic=";
	var aTopic = returnText.split("ParentTopic=");
	var idxOfName = 0;

	gTopicNum = 0;
	for (var i = 1; i < aTopic.length; i++)
	{
		// Remove the space char
		gTopics[gTopicNum] = aTopic[i].replace(/\s/g, "");
		// Parse the latest string as name
		idxOfName = aTopic[i].lastIndexOf("/") + 1;
		gTriggerNames[gTopicNum] = aTopic[i].substr(idxOfName);
		gTopicNum++;
	}

	gbLoadFinish = true;
}

function OnvifGetEventProperties()
{
	var xmlhttp;

	if (window.XMLHttpRequest)
	{
		xmlhttp = new XMLHttpRequest();
	}
	else
	{
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	if (xmlhttp.overrideMimeType)
	{
		xmlhttp.overrideMimeType('text/xml');
	}

	xmlhttp.onreadystatechange = function()
	{
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
		{
			handleXmlReturn(xmlhttp.responseText);
		}
	}
	xmlhttp.open("GET", "/cgi-bin/admin/vadpctrl.cgi?cmd=triggerlist", false);
	xmlhttp.setRequestHeader("If-Modified-Since","0");
	xmlhttp.send(null);
}

function receivedone()
{
	EVTMGR_TRIG_NUM = eval('vadp_event_ntrigger');

	for (i = 0; i < EVTMGR_TRIG_NUM; i++)
	{
		$('#hidden_input').append('<input name="vadp_event_triggerlist_i' + i + '_topic" type="hidden" id="i' + i +'_topic" title="param" value=""/>');
	}
}

function submitform()
{
	var TrigCursor = 0;
	var	CurTrigIdx;

	$('#Right').children().each(function(){
		if (TrigCursor >= EVTMGR_TRIG_NUM)
		{
			return;
		}

		CurTrigIdx = $(this)[0].value;

		if (CurTrigIdx < 0)
		{
			while ($('#i' + TrigCursor + '_topic')[0].value != '')
			{
				TrigCursor++;
				if (TrigCursor >= EVTMGR_TRIG_NUM)
				{
					return;
				}
			}
			$('#i' + TrigCursor + '_topic')[0].value = $(this)[0].title;
			TrigCursor++;
		}
		else
		{
			if ($('#i' + CurTrigIdx + '_topic')[0].value != $(this)[0].title)
			{
				//shouldn't be here. 
			}
		}
	});

	if (checkvalue())
	{
		return -1;
	}
	else
	{
		bSaved = true;

		$.post(document.forms[0].action, $(document.forms[0]).serialize(), function(){ 
			parent.location += '&step=2';
			parent.location.href = parent.location.href;
			set_vadp_trigger_close();
			//parent.location.reload();	// which will results in the reload warning in the firefox
		});
	}

}

function set_vadp_trigger_close(elem)
{
	if (bSaved == true)
	{
		if (parent.location.href.search("event.html") > 0)
		{
			parent.location += '&step=2';
			parent.location.reload();
		}
		else
		{
			parent.location.reload();
			self.parent.tb_remove();
		}
	}
	else 
	{
		if(typeof(elem) != "undefined" && elem.id == "btn_close")
		{
			//parent.location.reload();
			if (parent.location.href.search("event.html") > 0)
			{
				$(parent.document.getElementById('vadp-trig-menu')).children('ul').children('li').css({"background":"#C4EAFF url('/pic/action-down-arrow.png') no-repeat right center", "border-bottom":"1px solid #BFBAB0", "padding-bottom":"5px"});
				$(parent.document.getElementById('trigger-list')).slideUp(500);
			}
			else
			{	
				parent.location.reload();
				self.parent.tb_remove();
			}
		}
	}	
}

