function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&pir", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("pir");
	loadlanguage();
}

function submitform()
{
    form = document.forms[0];
    
	if(checkvalue())
	{
		return -1;	
	}
	else
	{
		form.submit();
	}
}
