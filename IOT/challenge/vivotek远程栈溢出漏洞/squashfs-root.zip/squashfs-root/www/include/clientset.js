var WinLessPluginCtrl;
var giCH_Curr = 0;

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

function OnBrowse()
{
	var vTemp;
	var ClientForm = document.ClientsetForm;
	
    //try
    //{
        vTemp = WinLessPluginCtrl.BrowsePath(ClientForm.OutputPath.value);
	
	if (vTemp != "")
	{
        if (vTemp.length > ClientForm.OutputPath.maxLength)
        {
            alert("The length of the folder path is too long");
            return -1;
        }
		ClientForm.OutputPath.value = vTemp;
	}
    //}
    //catch (err)
    //{
    //	alert("Browse error");
    //}
}

function OnSave()
{
	var ClientForm = document.ClientsetForm;
	
	streaming_record_output = document.getElementById("OutputPath");
	streaming_record_prefix = document.getElementById("Prefix");
	streaming_buffer_time = document.getElementById("StreamingBufferTime");
	
	if(checkInString(streaming_record_output))
	{
		return -1;
	}

	if(checkInString(streaming_record_prefix))
	{
		return -1;
	}

	if(checkNumRange(streaming_buffer_time, 5000, 0))
	{
		return -1;
	}
	
	var expires = new Date();
	expires.setTime (expires.getTime() + (10 * 365 * 24 * 60 * 60 * 1000));
	setCookie("streamingbuffertime", streaming_buffer_time.value, expires);	

	if (1 == ClientForm.duplexmode_switch.value)
	{
		setDuplexMode(EDuplexMode.half);
	}
	else if (2 == ClientForm.duplexmode_switch.value)
	{
		setDuplexMode(EDuplexMode.full);
	}

	if (bIsWinMSIE || ffversion >= 3 ||bIsChrome)
	{
		var vMedia = parseInt(ClientForm.mediaopt_switch.value);
		var vProtocol = parseInt(ClientForm.protocolopt_switch.value);
		WinLessPluginCtrl.SaveSettingsEX(vMedia, vProtocol, ClientForm.Prefix.value, ClientForm.OutputPath.value, ClientForm.chkFileNameOption.checked);
	}
}

function OnSelJoystick()
{
	WinLessPluginCtrl.CurrentJoystickIndex = document.getElementById("selJoystick").selectedIndex;
}

function onCalibrate()
{
	WinLessPluginCtrl.JoystickCalibrate();
}

function loadCurrentSetting() 
{ 
	XMLHttpRequestObject.open("GET", "/cgi-bin/viewer/getparam_cache.cgi?system_info_language&system_info_customlanguage&capability_peripheral&capability_thermal", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	
	$("body").css("visibility","visible")


    //Install FF plugin
    if (navigator.userAgent.match("Firefox") != null)
    {
        var xpi = undefined;

        var version = function(name)
        {
            var pos = name.search(" v");
            if(pos == -1)
            {
                return [];
            }
            return name.substr(pos + 2).split(".");
        };

        var compare = function(cur, src)
        {
            var cur = version(cur);
            var src = version(src);
            for(var i = 0; i < 4; ++i)
            {
                if(src[i] > cur[i])
                {
                    return true;
                }
                else if(src[i] < cur[i])
                {
                    return false;
                }
            }
        };

        var plugin = $.Installer.plugins;
        var type = window.navigator.mimeTypes[plugin.mime];

        if(!type || compare(type.description, plugin.description))
        {
            xpi = plugin.xpi;
        }

        if(xpi)
        {
            window.InstallTrigger.install(xpi);
        }
    }
    else if (bIsChrome)
    {
        var crx = undefined;
        var plugin = $.Installer.plugins;
        var type = window.navigator.mimeTypes[plugin.mime];

        if(!type || compare(type.description, plugin.description))
        {
            // update chrome extension : crx
            $("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="../npVivotekInstallerMgt.crx"></iframe>');
        }																					   //
    }

    if (bIsFireFox || bIsChrome)
    {
        $('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"><param name="InstallerPath" value="http://'+window.location.hostname+'/VVTK_Plugin_Installer.exe" /></object>');
    }
    $('#InstallerArea').hide();




	document.getElementById("notie").style.visibility = "visible";
	var ClientForm = document.ClientsetForm;
	
			updateLogoInfo();
			resizeLogo();
			
			Nifty("div#outter-wrapper","small","nonShadow");		
			Nifty("div#case","normal","nonShadow");
			document.getElementsByTagName("b")[5].style.position = "relative"			


//	streamsource=getCookie("streamsource");

	streaming_buffer_time=getCookie("streamingbuffertime");
	document.getElementById("StreamingBufferTime").value = streaming_buffer_time;
	
	var eDuplexMode = getDuplexMode();
	switch (eDuplexMode) 
	{
		case EDuplexMode.half:
			ClientForm.duplexmode_switch.value = 1;
			break;
		case EDuplexMode.full:
		default:
			ClientForm.duplexmode_switch.value = 2;
			break;
	}
	
	loadlanguage();
	
    try
    {
        if (bIsWinMSIE || ffversion >= 3||bIsChrome)
        {
        	WinLessPluginCtrl = document.getElementById("WinLessPluginCtrl0");
        	
            // set the language if needed, must include the javascript in the page
            //SetPluginString(WinLessPluginCtrl);

            switch (parseInt(WinLessPluginCtrl.GetSettings(0)))
            {            	
                case 3:                    
			ClientForm.mediaopt_switch.value = 3;
                    	break;
                case 2:                    
			ClientForm.mediaopt_switch.value = 2;
                    	break;
		case 1:
                default:                    
			ClientForm.mediaopt_switch.value = 1;
                    	break;
            }

            switch (parseInt(WinLessPluginCtrl.GetSettings(1)))
            {
                case 4:
			ClientForm.protocolopt_switch.value = 4;
                   	break;
                case 3:
			ClientForm.protocolopt_switch.value = 3;
                    	break;
                case 2:
			ClientForm.protocolopt_switch.value = 2;
                    	break;
		case 1:
                default:
			ClientForm.protocolopt_switch.value = 1;
                    	break;
            }

            ClientForm.Prefix.value=WinLessPluginCtrl.GetSettings(2);
            ClientForm.OutputPath.value=WinLessPluginCtrl.GetSettings(3);


            if(parseInt(WinLessPluginCtrl.GetSettings(4)))
            {            	
            	ClientForm.chkFileNameOption.checked = true;
            }
            else
            {            	
            	ClientForm.chkFileNameOption.checked = false;
            }

	    	// If user is not in administrator mode, disable setting recording folder. Otherwise, the setting will fail when using Win 7
		if (!WinLessPluginCtrl.IsPermissionSufficient)
		{
			$("#OutputPath").attr("disabled", true);
			$("#BrowseButton").attr("disabled", true);
		}
        }
        // code for Mozilla, Firefox, Opera, etc.
        else if (document.implementation && document.implementation.createDocument)
        {
            document.getElementById("notie").style.display = "none";
            document.getElementById("saveButton").style.display = "none";
        }
    }
    catch (err)
    {
    	alert("load error");
    }

	if(parent.layout_theme_option == "4")
	{
		parent.createCSS(".optNormal","background-color: " + parent.layout_theme_color_configbackground,"0");	
		parent.createCSS(".optOver","background-color : " + parent.layout_theme_color_controlbackground,"0");	
	}
	
	if(bIsWinMSIE)
	{
		document.getElementById("BrowseButton").style.display = "inline";
	}

	var nJoystickNum = WinLessPluginCtrl.GetAttachedJoystickNumber();

    	for (idx = 0; idx < nJoystickNum; idx++)
    	{
        	// Get joystick product name
        	strProductName = WinLessPluginCtrl.GetJoystickProductName(idx);
        	var varItem = new Option(strProductName, idx);
        	document.getElementById("selJoystick").options.add(varItem);
    	}
	
    	if (nJoystickNum > 0)
    	{
        	document.getElementById("selJoystick").options[WinLessPluginCtrl.CurrentJoystickIndex].selected = true;
    	}
    	else
    	{
        	document.getElementById("CalibrateButton").disabled = true;
        	document.getElementById("ConfigureButton").disabled = true;
    	}

    	if(bIsWinMSIE)
    	{
		$("#PluginContainer").hide();
    	}

	GenerateStreamCodec();
	GenerateTwoWayAudio();
	GenerateJoystick();
	//GeneratePeripheralCtrl();
} 



function ActivXplugin() 
{ 
    var PluginObj = '';

	if (bIsWinMSIE)
	{
        PluginObj += '<object Id="WinLessPluginCtrl0" CLASSID="CLSID:64865E5A-E8D7-44C1-89E1-99A84F6E56D0" width=10 height=10>';
		PluginObj += ' codebase=\"/" + PLUGIN_NAME + "\" #version=\"" + PLUGIN_VER + "\"';
    }
	else
	{
        PluginObj += '<div style="position:absolute; width:10; height:10; overflow:hidden;">';
        PluginObj += '<object class=CropZone ID="WinLessPluginCtrl0"  type="application/x-streamctrl" width=10 height=10>';
	}
	
    PluginObj += '<param name="Stretch" value=1>';
    PluginObj += '<param name="EnableJoystick" value=1>';  // Enable joystick
    PluginObj += '<param name="JoystickBtnTriggerStyle" value=1>'; //<!-- style 0: release,  style 1: press release
    PluginObj += '</object>';

    if (!bIsWinMSIE)
        PluginObj += '</div>';

    document.getElementById('PluginContainer').innerHTML = PluginObj;
	//document.write(PluginObj);

}


function mouseSelect(self, hyperlink)
{
	window.parent.location = hyperlink;
}

function mouseOver(self)
{
	self.className = "optOver";
}

function mouseOut(self)
{
	self.className = "optNormal";
}

function GenerateStreamCodec()
{

	var streamcodec = eval("capability_videoin_c"+giCH_Curr+"_streamcodec").split(',')[0];

	if ((streamcodec & 0x08) && (streamcodec & 0x04) && (streamcodec & 0x01))
	{
		$(document.getElementById("media_options")).before('H.265/H.264/MPEG-4 ');
		$(document.getElementById("protocol_options")).before('H.265/H.264/MPEG-4 ');
	}
	else if ((streamcodec & 0x08) && (streamcodec & 0x04))
	{
		$(document.getElementById("media_options")).before('H.265/H.264 ');
		$(document.getElementById("protocol_options")).before('H.265/H.264 ');
	}
	else if ((streamcodec & 0x08) && (streamcodec & 0x01))
	{
		$(document.getElementById("media_options")).before('H.265/MPEG-4 ');
		$(document.getElementById("protocol_options")).before('H.265/MPEG-4 ');
	}
	else if ((streamcodec & 0x04) && (streamcodec & 0x01))
	{
		$(document.getElementById("media_options")).before('H.264/MPEG-4 ');
		$(document.getElementById("protocol_options")).before('H.264/MPEG-4 ');
	}
	else if (streamcodec & 0x08)
	{
		$(document.getElementById("media_options")).before('H.265 ');
		$(document.getElementById("protocol_options")).before('H.265 ');
	}
	else if (streamcodec & 0x04)
	{
		$(document.getElementById("media_options")).before('H.264 ');
		$(document.getElementById("protocol_options")).before('H.264 ');
	}

	if(ParamUndefinedOrZero("capability_naudioin"))
	{
		$("#media_options_group").hide();
	}
}

function GenerateTwoWayAudio()
{
	if(ParamUndefinedOrZero("capability_naudioin") || ParamUndefinedOrZero("capability_naudioout"))
	{
		$("#two_way_audio").hide();
	}
}

function GenerateJoystick()
{
	if(ParamUndefinedOrZero("capability_joystick"))
	{
		$("#joystick_settings").hide();
	}
}

function GeneratePeripheralCtrl()
{
	var followedID = "joystick_settings";
	var bSupportWiper = !ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_wiper_support");
	var bSupportWaterspray = !ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_waterspray_support");
	var bSupportCustomHeater = false;
	
	if (!ParamUndefinedOrZero("capability_thermal_controlmode"))
	{
		tmp = eval("capability_thermal_controlmode").split(",");
		for (i = 0; i < tmp.length; i++)
		{
			if (-1 != tmp[i].search("customheater"))
			{
				bSupportCustomHeater = true;
			}
		}
	}

	if (true == bSupportWiper)
	{
		$(document.getElementById(followedID)).after(""
		+' <fieldset id="wiper_control">'
		+'   <legend><strong><span title="symbol">'+translator("wiper_control")+'</span></strong></legend>'
		+'   <table><tr>'
		+'   <td width="200"><span title="symbol">wiper_control</span></td>'
		+'   <td><input id="WiperTriggerButton" type="button" title="symbol" style="width:150px" value="On" onclick="triggerWiper(this)"/></td>'
		+'   <td><input id="WiperSwitchButton" type="button" title="symbol" style="width:150px" value="continuous" onclick="switchWiper(this)"/></td>'
		+'   </tr></table>'
		+' </fieldset>'
		);
		followedID = "wiper_control";
	}
	
	if (true == bSupportWaterspray)
	{
		$(document.getElementById(followedID)).after(""
		+' <fieldset id="water_spray">'
		+'   <legend><strong><span title="symbol">'+translator("water_spray")+'</span></strong></legend>'
		+'   <table><tr>'
		+'   <td width="200"><span title="symbol">water_spray</span></td>'
		+'   <td><input id="WaterSprayButton" type="button" title="symbol" style="width:150px" value="On" onclick="sprayWater(this)"/></td>'
		+'   </tr></table>'
		+' </fieldset>'
		);
		followedID = "water_spray"	
	}

	if (true == bSupportCustomHeater)
	{
		var heater=""
		var get_heater_state = function() {
			$.ajax({
				url: "/cgi-bin/admin/peripheralctrl.cgi",
				cache: false,
				async: false,
				type: "GET",
				dataType: "script",
				data: "get_heater_state",
				success: function(result) {
					heater = eval(result);
					if ("on" == heater)
					{
						heater = "Off";
					}
					else
					{
						heater = "On";
					}
				},
				error: function() {
					// Do nothing
				}
			});
		}

		get_heater_state();
		$(document.getElementById(followedID)).after(""
		+' <fieldset id="heater_control">'
		+'   <legend><strong><span title="symbol">'+translator("heater_control")+'</span></strong></legend>'
		+'   <table><tr>'
		+'   <td width="200"><span title="symbol">'+translator("heater_control")+'</span></td>'
		+'   <td><input id="HeaterSwitchButton" type="button" title="symbol" style="width:150px" value="'+heater+'" onclick="switchHeater(this)"/></td>'
		+'   </tr></table>'
		+' </fieldset>'
		);
		followedID = "heater_control"	
	}
}
