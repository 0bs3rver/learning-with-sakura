function loadCurrentSetting()
{	
	giCH_Curr = Number(getCookie("channelsource"));

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&audioin&capability_daynight_c" + giCH_Curr + "_support", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("audio_detection");
	//document.title="Audio Ddetection";
	loadlanguage();

	//morse code: "audio"
	konami(function(){
		$("#debug").toggle();
	}, [65, 85, 68, 73, 79]);
}

function receivedone() 
{
	if ("1" == audioin_c0_mute)
	{
		$("#warningBlk").show();
		$("#enable_c0_audiodetect + input").attr("disabled", true);
	}

	if ("1" == eval("capability_daynight_c" + giCH_Curr + "_support"))
	{
	//	document.getElementById("daymodeControl").style.display = "block";
		document.getElementById("nightmodeControl").style.display = "block";
	}
    initAudioVolumeSlider();
	document.getElementById("content").style.visibility = "visible";
}

function checkDayNightMode()
{
	if (getCheckedValue(document.forms[0].audioin_c0_profile_i0_policy) == "schedule")
	{
		$("#scheduleModeChild").slideDown("fast");
	}
	else
	{
		$("#scheduleModeChild").slideUp("fast");
	}
}

function loadvaluedone()
{
	checkDayNightMode();
	profileEnable = (audioin_c0_profile_i0_enable == 1) ? false : true;
	disableProfileOption(profileEnable);
}

function submitform()
{
    form = document.forms[0];
    
	if(checkvalue())
	{
		return -1;	
	}
	else
	{
        form.audioin_c0_profile_i0_alarm_level.value = $("#audioVolumeBlock").slider("value");
		form.submit();
	}
}

function SetVolumeNotify(codectype)
{
    // +-------------------------------------------------------+
    // |               Interval       SampleCount              |
    // | AAC     :      200              500                   |
    // | GSM-AMR :      100               10                   |
    // | G.711   :      200              200                   |
    // +-------------------------------------------------------+
    
    switch(codectype) 
    {
        case 'aac4':
            iInterval  = 500;
            iSampleCnt = 500;
            break;
        case 'gamr':
            iInterval  = 500;
            iSampleCnt = 10;
            break;
        case 'g711':
            iInterval  = 500;
            iSampleCnt = 200;
            break;

        default:
            iSampleCnt = 50;
			break;
    }
}

var g_Alarm_level = audioin_c0_profile_i0_alarm_level;

function initAudioVolumeSlider()
{
    $("#audioVolumeBlock").slider({
        orientation: "vertical",
        min: 0,
        max: 100,
        value: audioin_c0_profile_i0_alarm_level,
        animate: true,
        slide: function(event, ui) {
            Log("Set volume = %s", ui.value);
            $("#alarmLevel").val(ui.value);
            
			if (bIsWinMSIE || bIsFireFox || bIsChrome)
            {
                var tmpAlarmArray = [];
                for (var i = 0; i <= 60; i += 1) tmpAlarmArray.push([i, ui.value]);
                var tmpCan = frames[0].canvasHandle.getData();
                tmpCan[0].data = tmpAlarmArray;
                frames[0].canvasHandle.setData(tmpCan);
                frames[0].canvasHandle.draw();
            }
        }
    });
    
    $("#audioVolumeBlock.ui-widget-content").css("background", "#EF2929 url(/pic/audioLevelV.png) repeat-y 0 0")
                                            .css("border", "1px solid #545454")
                                            .css("-moz-border-radius", "0px");

    $(".ui-slider-handle").css("height", "7px")
	                      .css("cursor", "pointer")
	                      .before('<div class="ui-slider-range ui-widget-header" style="_font-size:1px; width:100%; height: 100%; background: #eee;)"/>');

	$(".ui-slider-range").css("MozBorderRadius", 0);
    
    $("#alarmLevel").val(audioin_c0_profile_i0_alarm_level);
}

function disableProfileOption(input)
{
	if ( input )
	{
		$("#day_night_policy").slideUp("slow");
	}
	else
	{
		$("#day_night_policy").slideDown("slow");
	}
}

function updateProfileCheck(inputName, checkbox)
{
	disableProfileOption(!checkbox.checked);
	updatecheck(inputName, checkbox);
}
