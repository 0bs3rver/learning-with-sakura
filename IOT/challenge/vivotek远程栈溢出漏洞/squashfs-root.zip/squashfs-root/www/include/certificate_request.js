function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?https", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("https");
	loadlanguage();	
}

function submitform(a, b)
{
	updatecheck(a, b);
	document.forms[0].submit();
}