function loadCurrentSetting()
{
		document.title=translator("calibrate");
		updateLogoInfo();
		resizeLogo();
		loadvalue();
		loadlanguage();
		document.getElementById("content").style.visibility = "visible";
	
}

