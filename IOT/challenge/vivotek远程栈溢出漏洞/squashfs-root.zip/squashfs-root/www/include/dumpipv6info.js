function loadCurrentSetting()
{
	loadlanguage();
}

