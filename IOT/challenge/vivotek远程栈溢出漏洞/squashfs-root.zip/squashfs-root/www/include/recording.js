media_index=1;
var dest0, dest1, recording_i0_show_dest, recording_i1_show_dest;

var g_serverCount = 0;
var g_haveNas = false;
var g_haveSD = true;
var g_existNasIndex = -1;
var g_newNasIndex = -1;

function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&recording&server&capability_supportsd", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("recording_settings");
	loadlanguage();	
}

function receivedone()
{
	form=document.forms[0];
	if(recording_i0_name=="")
		document.getElementById("recording_i0").style.display="none";

	if(recording_i1_name=="")
		document.getElementById("recording_i1").style.display="none";
	
	if(recording_i0_dest!='cf')
	{
		dest0="/setup/recording/recording_network.html?index="+recording_i0_dest;
		eval("recording_i0_show_dest=server_i"+recording_i0_dest+"_name");
	}
	else
	{
		dest0="/setup/localstorage/storage_searching_view.html";
		recording_i0_dest='cf';	
		recording_i0_show_dest = 'SD';
	}
	if(recording_i1_dest!='cf')
	{
		dest1="/setup/recording/recording_network.html?index="+recording_i1_dest;
		eval("recording_i1_show_dest=server_i"+recording_i1_dest+"_name");
	}
	else
	{
		dest1="/setup/localstorage/storage_searching_view.html";
		recording_i1_dest='cf';
		recording_i1_show_dest = 'SD';
	}
	document.getElementById("content").style.visibility = "visible";
	
	initServerLink();
	configureAddButton();	
	configureServerLink();
}

function loadvaluedone()
{
	if ( capability_supportsd == "0" )
	{
		document.getElementById("testsd_link").style.display = "none";
	}
}

function initServerLink()
{
	var serverName = "";
	var serverType = "";
	
	for (var i = 4; i >= 0; --i)
	{
		eval("serverName = server_i" + i + "_name");
		eval("serverType = server_i" + i + "_type");
		if (serverName.length == 0)
		{
			g_newNasIndex = i;
		}
		else
		{
			g_serverCount++;
			if (serverType == "ns")
			{
				g_haveNas = true;
				g_existNasIndex = i;
			}
		}
	}
	
	if ((!g_haveNas) && (!g_haveSD))
	{
		document.getElementById("addButton").disabled = true;
	}
	if (!g_haveNas)
	{
		document.getElementById("recording_note").style.display = "";
	}
	else
	{
		document.getElementById("recording_note").style.display = "none";
	}
}

function configureAddButton()
{
	var thick_box_param = "TB_iframe=true&height=480&width=700&modal=true";
	
	if (recording_i0_name == "")
	{
		$("#addButton").attr("alt", "recording_entry.html?index=0" + thick_box_param);
	}
	else if (recording_i1_name == "")
	{
		$("#addButton").attr("alt", "recording_entry.html?index=1" + thick_box_param);
	}
	else
	{
		// Unbind ThickBox click
		$("#addButton").unbind("click");
		$("#addButton").click(function(){
			alert(translator("no_more_list_for_recording_to_enter"));
			return false;
		});
	}
}

function configureServerLink()
{
	var thick_box_param = ";g_onlyNas=trueTB_=savedValues&TB_iframe=true&height=300&width=500&modal=true";

	if (g_haveNas)
	{
		$("a#server_link").attr("href","/setup/event/server.html?index=" + g_existNasIndex + thick_box_param);
	}
	else
	{
		if (g_serverCount >= 5)
		{
			// Unbind ThickBox click
			$("a#server_link").unbind("click");
			$("a#server_link").click(function(){
				alert(translator("no_more_list_for_server_to_enter"));
				return false;
			});
		}
		else
		{
			$("a#server_link").attr("href","/setup/event/server.html?index=" + g_newNasIndex + thick_box_param);
		}
	}
}

function submitform()
{
	if(!checkvalue())
	{
		return -1;
	}
	else
		document.forms[0].submit();
}

function delrecording(idx)
{
	params  = "recording_i" + idx + "_name=" + "&";
	params += "recording_i" + idx + "_enable=0" + "&";
	params += "recording_i" + idx + "_trigger=schedule" + "&";
	params += "recording_i" + idx + "_priority=1" + "&";
	params += "recording_i" + idx + "_source=0" + "&";
	params += "recording_i" + idx + "_limitsize=0" + "&";
	params += "recording_i" + idx + "_cyclic=0" + "&";
	params += "recording_i" + idx + "_notify=1" + "&";
	params += "recording_i" + idx + "_notifyserver=0" + "&";
	params += "recording_i" + idx + "_weekday=127" + "&";
	params += "recording_i" + idx + "_begintime=00:00" + "&";
	params += "recording_i" + idx + "_endtime=24:00" + "&";
	params += "recording_i" + idx + "_prefix=" + "&";
	params += "recording_i" + idx + "_cyclesize=100" + "&";
	params += "recording_i" + idx + "_reserveamount=100" + "&";
	params += "recording_i" + idx + "_dest=cf" + "&";
	params += "recording_i" + idx + "_cffolder=" + "&";
	params += "recording_i" + idx + "_adaptive_enable=0" + "&";
	params += "recording_i" + idx + "_adaptive_preevent=1" + "&";
	params += "recording_i" + idx + "_adaptive_postevent=1" + "&";
	params += "recording_i" + idx + "_maxduration=60" + "&";
	params += "recording_i" + idx + "_maxsize=100" + "&";

	location.replace("/cgi-bin/admin/setparam.cgi?" + params + "return=/setup/recording/recording.html");
}

function switchEvent(param)
{	
	var newValue;

	document.getElementById("recording_index_enable").name = param;
	if (document.getElementById(param + "_value").firstChild.nodeValue == "OFF")
	{	
		newValue = 1;
	}
	else
	{
		newValue = 0;
	}
	document.getElementById("recording_index_enable").value = newValue;
	document.recording.submit();
	document.getElementById(param + "_value").firstChild.nodeValue = (newValue == 1? "ON" : "OFF");
}

function testsd()
{
	sdform=document.sd_test;
	
	window.open("", "testsd", "height=100,width=400");
	sdform.target="testsd";
	sdform.submit();
}

function fnSetValues()
{
	var sFeatures="dialogHeight: 480px;";
	sFeatures += "dialogWidth: 640px;";
//	sFeatures += "scroll: on;";
	sFeatures += "status: no;";
	return sFeatures;
}

function fnOpen(showModalDialog_html)
{
	var sFeatures=fnSetValues();
//	window.showModalDialog(showModalDialog_html, "", sFeatures)

	var subWindow = window.open(showModalDialog_html, "", 'modal=yes, width=800, height=900, resizable=no, scrollbars=yes');
	subWindow.focus();
}
