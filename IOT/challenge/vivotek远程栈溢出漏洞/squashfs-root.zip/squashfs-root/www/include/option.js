var g_selected = "";
var g_advBlocks = new Array(
		"adv_system_log", "adv_view_parameters", "adv_homepage_layout", //system
		"adv_https", "adv_access_list", "adv_802_1x",//security 
		"adv_streaming_protocol", "adv_service_priority", "adv_snmp", "adv_ftp", //network
		"adv_image_profile", "adv_stream_profile", "adv_motion_profile",//profile
		"adv_imaging", "adv_audio", "adv_video",//media
		"adv_camera_control", //ptz
		"adv_calibrate", "adv_auto_tracking", //for speed dome
		"adv_application", "adv_event_receiver", "adv_event_media",//event
		"adv_dido", "adv_audio_alert","adv_vadp","adv_audio_detection","adv_gsensor_detection" ,"adv_pir",//application
		"adv_recording",  //recording
		"adv_sd_card_management", "adv_storage_searching" //storage
);
var g_basicBlocks = new Array(
		"basic_system", "basic_maintenance", //system
		"basic_security", //security
		"basic_network", "basic_express_link", "basic_ddns", //network
		"basic_wireless", "basic_wps", //wireless
		//"basic_imaging", "basic_audio",//media
		"basic_media",//media
		"basic_motion_detection", "basic_tampering_detection", "basic_temperature_detection", //application
		"rol"
);

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?capability_supportsd&capability_naudioin&capability_npir&capability_thermal_temperaturedetection&capability_ndi&capability_ndo&capability_fisheye&capability_ptzenabled&capability_remotecamctrl&capability_tampering&capability_network_wireless&capability_protocol_ieee8021x&capability_protocol_qos_cos&capability_protocol_qos_dscp&capability_supporttriggertypes", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	var g_mode = 1;//remove baseic mode // parent.getCookie("g_mode");
	parent.setCookie("g_mode", 1);

	// basic mode
	if (g_mode == "0")
	{
		$(".adv").css("display", "none");
		$(".adv").next("div").css("display", "none");
		
		for (var i = 0; i < g_advBlocks.length; ++i)
		{
			$("#" + g_advBlocks[i]).css("display", "none");
		}
		//parent.$(".confOption").css("height","550px");
	}
	else if (g_mode == "1")// advanced mode
	{
		$("#basic_media").css("display", "none");
	}
	//remove basic mode
	//document.getElementById("g_mode").firstChild.nodeValue = (g_mode == "1" ? "basic_mode" : "advanced_mode");
	
	g_selected = window.parent.document.getElementsByTagName("body")[0].id;
	document.getElementById(g_selected).className = "optSelected";

	//accordion
	$("body").css("display", "block");
	var num = $("#side_area ul").index($('.optSelected').parent("ul"));
	$("#side_area").accordion({
			active: num,
			autoHeight: false,
			clearStyle: true,
			navigation: true,
			collapsible: true
	});

	var tran=document.getElementsByTagName("span");
	
	for (var i = 0; i < tran.length; i++)
	{	
		if (tran[i].title == "symbol")
		{
			tran[i].innerHTML=parent.xmlDoc.getElementsByTagName(tran[i].innerHTML)[(parent.lan >= 100)?0:parent.lan].childNodes[0].nodeValue;
			tran[i].title="";
		}
	}

	ReadCSSFromParent();	
	if(parent.layout_theme_option == "4")
	{
		parent.createCSS(".optSelected","color: " + parent.layout_theme_color_configbackground,"1");
		parent.createCSS("body#option","background-color: " + parent.layout_theme_color_configbackground,"1");
		parent.createCSS(".optNormal","background-color: " + parent.layout_theme_color_configbackground,"1");	
		parent.createCSS(".optNormal","color: " + parent.layout_theme_color_configfont,"1");
		parent.createCSS(".optOver","color: " + parent.layout_theme_color_configbackground,"1");
		parent.createCSS(".optOver","background-color : " + parent.layout_theme_color_controlbackground,"1");	
		
		$(".optContent ul li").css("color", parent.layout_theme_color_font);
		$("body#option,.optNormal").css("background-color", parent.layout_theme_color_configbackground);
		$(".optContent ul").css("background-color", parent.layout_theme_color_controlbackground);				
		$(".optOver").css({"background-color": parent.layout_theme_color_controlbackground, "color":"#000"});
		$(".optNormal").css({"color":parent.layout_theme_color_configfont});
	}
}

function loadvaluedone()
{
	GenerateDiDoPage();
	if (ParamUndefinedOrZero("capability_supportsd"))
	{
		$("#adv_local_storage").hide();
		$("#adv_sd_card_management").hide();
		$("#adv_storage_searching").hide();
	}

	if (ParamUndefinedOrZero("capability_ndi") && ParamUndefinedOrZero("capability_ndo"))
	{
		$("#adv_dido").hide();
	}
	if (ParamUndefinedOrZero("capability_naudioin"))
	{
		$("#adv_audio").hide()
		$("#adv_audio_detection").hide();
	}
	if (capability_supporttriggertypes.search("shockalarm") < 0)
	{
		$("#adv_gsensor_detection").hide();
	}	
	if (ParamUndefinedOrZero("capability_tampering"))
	{
		$("#basic_tampering_detection").hide();
	}
	if (ParamUndefinedOrZero("capability_thermal_temperaturedetection"))
	{
		$("#basic_temperature_detection").hide();
	}
	if (ParamUndefinedOrZero("capability_npir"))
	{
		$("#adv_pir").hide();
	}
	if(capability_fisheye != 0)
	{
		//$("#adv_camera_control").onmouseup="mouseSelect(this,'/setup/ptz/cameracontrol_fisheye.html')";
		document.getElementById("adv_camera_control").onmouseup = function(){mouseSelect(this,'/setup/ptz/cameracontrol_fisheye.html');};
	}

	if (isIZ(capability_ptzenabled) == 1)
	{
		document.getElementById("adv_camera_control").onmouseup = function(){mouseSelect(this,'/setup/ptz/cameracontrol_iz.html');};	
	}
	
	if(isSpeedDome(capability_ptzenabled) == 1)
	{
		document.getElementById("adv_camera_control").onmouseup = function(){mouseSelect(this,'/setup/ptz/cameracontrol_speeddome.html');};
		document.getElementById("adv_calibrate").onmouseup = function(){mouseSelect(this,'/setup/ptz/calibrate.html');};
		document.getElementById("adv_auto_tracking").onmouseup = function(){mouseSelect(this,'/setup/ptz/autotrack.html');};
	}
	else
	{
		$("#adv_calibrate").hide();
		$("#adv_auto_tracking").hide();
	}

	//PPTZ support
	if(ParamUndefinedOrZero("capability_remotecamctrl_master"))
	{
		$("#adv_panoramic_ptz").hide();
	}

	if (ParamUndefinedOrZero("capability_network_wireless"))
	{
		$("#basic_wireless").hide();
		$("#basic_wireless_opt").hide();
		$("#basic_wps").hide();

	}

	if (ParamUndefinedOrZero("capability_protocol_ieee8021x"))
	{
		$("#adv_802_1x").hide();
		
	}

	if (ParamUndefinedOrZero("capability_protocol_qos_cos")||ParamUndefinedOrZero("capability_protocol_qos_dscp"))
	{
		$("#adv_service_priority").hide();
	}
	
}

function changeMode()
{
	var g_mode = parent.getCookie("g_mode");
	var nextMode = (g_mode == "1" ? 0 : 1);	
	parent.setCookie("g_mode", nextMode);
	
	var currentPage = window.parent.document.getElementsByTagName("body")[0].id;	
	if (currentPage == "basic_media")
	{
		window.parent.location = "/setup/system/system.html";
		return;
	}
	for (var i = 0; i < g_basicBlocks.length; ++i)
	{
		if (g_basicBlocks[i] == currentPage)
		{
			window.parent.location.reload();
			return;
		}
	}
	window.parent.location = "/setup/system/system.html";
	
}

function mouseSelect(self, hyperlink)
{
	if (self.id != g_selected) 
	{
		window.parent.location = hyperlink;
	}
}

function mouseOver(self)
{
	if (self.id != g_selected)
	{
		self.className = "optOver";
	}
}

function mouseOut(self)
{
	if (self.id != g_selected)
	{
		self.className = "optNormal";
	}
}

function ReadCSSFromParent()
{
    if (window.top && window.top.location.href != document.location.href) 
    {
        var linkrels = window.top.document.getElementsByTagName('link');
        var small_head = document.getElementsByTagName('head').item(0);
        
        for (var i = 0, max = linkrels.length; i < max; i++) 
        {
            if (linkrels[i].rel && linkrels[i].rel == 'stylesheet') 
            {
                var thestyle = document.createElement('link');
				var attrib = linkrels[i].attributes;
                for (var j = 0, attribmax = attrib.length; j < attribmax; j++) 
                {
                	if (attrib[j].nodeName == "href")
				    {
				        thestyle.setAttribute(attrib[j].nodeName, attrib[j].nodeValue + "?inner");
				    }
					else
					{
						thestyle.setAttribute(attrib[j].nodeName, attrib[j].nodeValue);
                	}
                }
				// Add if condition to fix the CSS format problem of "Audio Detection" page
				if (thestyle.href.match("ui-lightness") == null) small_head.appendChild(thestyle);
			}
		}    
		$(small_head).append('<link rel="stylesheet" type="text/css" href="/css/option.css" />');
        // maybe, only maybe, here we should remove the kid's own styles?
    }
}

function GenerateDiDoPage()
{
	if(ParamUndefinedOrZero("capability_ndi") && !ParamUndefinedOrZero("capability_ndo")) // only DO
	{
		$(document.getElementById("adv_dido")).append(""
		+'<span title="symbol">'+translator("do")+'</span>');
	}
	else if(!ParamUndefinedOrZero("capability_ndi") && ParamUndefinedOrZero("capability_ndo")) // only DI
	{
		$(document.getElementById("adv_dido")).append(""
		+'<span title="symbol">'+translator("di")+'</span>');
	}
	else // show di_and do (if it does not support both di and do, it will be hide) 
	{
		$(document.getElementById("adv_dido")).append(""
		+'<span title="symbol">'+translator("di_and_do")+'</span>');
	}
}
