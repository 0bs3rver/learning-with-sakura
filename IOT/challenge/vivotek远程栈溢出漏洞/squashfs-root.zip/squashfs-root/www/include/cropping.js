var CUSTOMINDEX = 99;
var g_bS2FullScene = true;
var FULL_RATIO_X = 6.4;
var FULL_RATIO_Y = 6.4;
var FULL_BOXWIDTH = 400;
var FULL_BOXHEIGHT = 300;

var bInCropMode = ("#crop" == location.hash) ? true : false;
function loadCurrentSetting()
{
	if (bInCropMode)
	{
		blockUI();
		setTimeout("GetCropStatus()", 3000);
	}
	bSaved = false;
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?roi&videoin_c0_crop", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("cropping_setting");
	loadlanguage(); 
	//sleep(3000);
}

var FULL_VIEW_CROP_SIZE= "2560x1920";
var query_counter = 0;
//To check if crop size has been restore to fullview to ensure that we will get fullview snapshot for crop setting.
function GetCropStatus()
{
    $.ajax({ 
        async: false,
        //cache: false,
        url: "/cgi-bin/admin/getcropstatus.cgi?_=" + (new Date()).getMilliseconds() + "&cropsize=" + FULL_VIEW_CROP_SIZE,
        complete: function (XMLHttpRequest, textStatus) {
            if (XMLHttpRequest.status == 400)
            {
                setTimeout("GetCropStatus(FULL_VIEW_CROP_SIZE)", 1000);
            }
        },
        success: function(data) { 
            if (data == "Done")
            {
                $('body').unblock();
            }
            else if (data == "Proceeding")
            {
                query_counter++; 
                if (query_counter <= 7)
                {
                    setTimeout("GetCropStatus(FULL_VIEW_CROP_SIZE)", 1000);
                    Log("%s","Proceeding...");
                }
                else //more than 10 seconds
                {
                    $('body').unblock();
                    query_counter = 0;
                }
            }
        }
    });
} 

function receivedone()
{
    initEPTZParams("cropping_setting");
    g_bSmooth = true;

    initROI();
    setInterval("refreshImage(VIDEO_JPG)", INTERVAL_snapshot);
}

function loadvaluedone()
{
	if (bInCropMode) 
	{
		eval("crop_x=opener.pre_videoin_c0_crop_position.split(',')[0]");
		eval("crop_y=opener.pre_videoin_c0_crop_position.split(',')[1]");
		eval("crop_w=opener.pre_videoin_c0_crop_size.split('x')[0]");
		eval("crop_h=opener.pre_videoin_c0_crop_size.split('x')[1]");
		$("select[name='cropArea']").addOption(CUSTOMINDEX,'(' + crop_x + ',' + crop_y + ') ' + crop_w + 'x' + crop_h + ' '+ translator("custom"));
	}
	else
	{
		eval("crop_x=videoin_c0_crop_position.split(',')[0]");
		eval("crop_y=videoin_c0_crop_position.split(',')[1]");
		eval("crop_w=videoin_c0_crop_size.split('x')[0]");
		eval("crop_h=videoin_c0_crop_size.split('x')[1]");
		$("select[name='cropArea']").addOption(CUSTOMINDEX,'(' + crop_x + ',' + crop_y + ') ' + crop_w + 'x' + crop_h + ' '+ translator("custom"));
	}
	changeCropping(CUSTOMINDEX);
}

var current_ROI_W = parseInt(opener.video_crop_sizp.split("x")[0]);
var current_ROI_H = parseInt(opener.video_crop_sizp.split("x")[1]);
function initROI()
{//alert(video_crop_sizp);
	if ( opener.video_crop_sizp == "1280x720" )
	{
		//according to sensor lib 720p default size ratio
		ROI_W = 2560;
		ROI_H = 1440;
	}
	else
	{
		ROI_W = current_ROI_W;
	    ROI_H = current_ROI_H;
	}
	
    JcropObj = $.Jcrop($('#cropbox'),{
        onChange: showCoords,
        onSelect: showCoords,
        boxWidth: FULL_BOXWIDTH, 
        boxHeight: FULL_BOXHEIGHT,
        minSize: [ ROI_W/FULL_RATIO_X, ROI_H/FULL_RATIO_Y ],
		maxSize: [ ROI_W/FULL_RATIO_X, ROI_H/FULL_RATIO_Y ],
        trueSize: [TRUEWIDTH, TRUEHEIGHT]
    });

   // $("select[name=cropArea]").selectOptions(eval("opener.pre_videoin_c0_crop_size"));

}

function showCoords(c)
{
    //$('#x').val(Normalize(c.x, 16));
    //$('#y').val(Normalize(c.y,  8));
	$('#x').val(c.x);
    $('#y').val(c.y);

    if (c.h >= DM365_MPEG4_HEIGHT_LIMIT) {
        $('#w').val(Normalize(c.w, 32));
    } else {
        $('#w').val(Normalize(c.w, 16));
    }

    $('#h').val(Normalize(c.h,  8));

    $("select[name='cropArea']")[0].selectedIndex = $("select[name='cropArea'] option[value='"+CUSTOMINDEX+"']")[0].index;
    $("select[name='cropArea'] option[value='" + CUSTOMINDEX +"']")[0].text = '(' + $('#x').val() + ',' + $('#y').val() + ') ' + $('#w').val() + 'x' + $('#h').val() + ' custom';
}

function changeCropping(value)
{
    //Example: "(640,480) MOBILE_WIDTHxMOBILE_HEIGHT" <--> "(X,Y) WxH"
    var coordsContent = $("select[name='cropArea'] option[value='" + value + "']")[0].text.split(" ")[0];
    var regionContent = $("select[name='cropArea'] option[value='" + value + "']")[0].text.split(" ")[1];
    //var X = parseInt(coordsContent.split(',')[0].split('(')[1]);
    //var Y = parseInt(coordsContent.split(',')[1].split(')')[0]);

	var X;
	var Y;
	// default crop position (-1, -1)
	if (videoin_c0_crop_position.split(',')[0] == -1) 
	{
		if (opener.video_crop_sizp == "2048x1536")
		{
			X = 262;  //272
			Y = 185;  //204
		}
		else if (opener.video_crop_sizp == "1920x1080")
		{
			X = 326;  // 336
			Y = 416;  // 432
		}
		else if (opener.video_crop_sizp == "1600x1200")
		{
			X = 486;  //486
			Y = 371;  //372
		}
		else // 720P
		{
			X = 16;
			Y = 236; //240
		}
	}
	else
	{
	var X = crop_x;
    var Y = crop_y;
	}
	

    //var W = parseInt(regionContent.split("x")[0]);
    //var H = parseInt(regionContent.split("x")[1]);
	var W =  current_ROI_W;
    var H =  current_ROI_H;

    JcropObj.setOptions({
        setSelect:   [X/FULL_RATIO_X, Y/FULL_RATIO_Y, (X + W)/FULL_RATIO_X, (Y + H)/FULL_RATIO_Y ]
    });
}

var position_param;
var size_param;
function fakeSubmitform()
{
	var submit_x = $('#x').val();
	var submit_y = $('#y').val();
	
	bSaved = true;
	position_param = "videoin_c0_crop_position=" + submit_x + "," + submit_y;
	size_param = "videoin_c0_crop_size=" + opener.video_crop_sizp;
	opener.targetCropSize = $('#w').val() + "x" + $('#h').val();

	if (bInCropMode) 
		alert(translator("cropping_saved_warning_message")); 
	else
		alert(translator("cropping_saved_warning_message_noncropmode")); 
		
	opener.showmode(opener.video_crop_sizp);
}

function checkOnClose_Crop()
{
	blockUI();
	$.ajaxSetup({ async: false, cache: false});
	if (bInCropMode) 
	{
		if (bSaved)
		{
			$.get("/cgi-bin/admin/setparam.cgi?videoin_c0_crop_preview=0");  //set back to 0 to enable update_eptzsetting
			if (size_param != "videoin_c0_crop_size=2560x1920")
			{
				$.get("/cgi-bin/admin/setparam.cgi?" +  position_param + "&" + size_param);
			}
			else
			{
				$.get("/cgi-bin/admin/update_eptzsetting.cgi");  // size_param = 2560x1920, force execute update_eptzsetting!
			}

			opener.preGetCropStatusAfterSetting();
			window.close();
		}
		else //restore to previous value!
		{
			tmpParam = "videoin_c0_crop_position=" + opener.pre_videoin_c0_crop_position + 
				"&videoin_c0_crop_size=" + opener.pre_videoin_c0_crop_size +
				"&videoin_c0_s3_resolution=" + opener.pre_videoin_c0_s3_resolution;

			$.get("/cgi-bin/admin/setparam.cgi?" + tmpParam, function(){
				sleep(3000);  // sleep a while 
                // add below ajax process to ensure that we set videoin_c0_crop_preview=0 after update_eptzsetting is terminated!
                $.ajax({
                    url: "/cgi-bin/admin/getProcStatus.cgi",
                    type: "GET",
                    async: false,
                    data: "update_eptzsetting",
                    success: function(data) {
                        $.get("/cgi-bin/admin/setparam.cgi?videoin_c0_crop_preview=0");  //set back to 0 to enable update_eptzsetting
                        //alert(data);
                        window.opener.$('body').unblock();
                    }
                });
			});

			opener.preGetCropStatusAfterSetting();
		}
    }
	else
	{
		if (bSaved)
		{
			$.get("/cgi-bin/admin/setparam.cgi?" +  position_param + "&" + size_param);
		}
		window.opener.$('body').unblock();
	}
}
