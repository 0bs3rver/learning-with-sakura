var snapshotMaxSize=0;
added=0;
function loadCurrentSetting()
{
	bSaved = false;	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?event&media&timeshift_enable&capability_nmediastream", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("media");
	snapshotMaxSize=capability_media_snapshot_maxsize;
	generateMaxVideoClipSize();
	loadlanguage();
	eval(location.search.toString().slice(1));
	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	var input=document.getElementsByTagName("select");
	for (var i = 0; i < input.length; i++)
		input[i].name=input[i].name.toString().replace("index", "i"+index);	
}
function receivedone()
{
	using = 0;
	if(event_i0_enable == 1)
	{
		for (j = 0; j < 5; j++)
		{
			if (eval("event_i0_action_server_i"+j+"_media==index&&event_i0_action_server_i"+j+"_media!=\"\""))
				using++;
		}
		if ((event_i0_action_cf_media == index) && (event_i0_action_cf_media != ""))
			using++;
	}
	if (event_i1_enable == 1)
	{
		for(j = 0; j < 5; j++)
		{
			if (eval("event_i1_action_server_i"+j+"_media==index&&event_i1_action_server_i"+j+"_media!=\"\""))
				using++;
		}
		if ((event_i1_action_cf_media == index) && (event_i1_action_cf_media != ""))
			using++;
	}
	if (event_i2_enable == 1)
	{
		for (j = 0; j < 5; j++)
		{
			if (eval("event_i2_action_server_i"+j+"_media==index&&event_i2_action_server_i"+j+"_media!=\"\""))
				using++;
		}
		if ((event_i2_action_cf_media == index) && (event_i2_action_cf_media != ""))
			using++;
	}
	if (timeshift_enable == 0)
	{
		document.getElementById("media_index_videoclip_source").disabled = false;
	}
	if (using != 0)
	{
		$("input, select").attr("disabled",true);
		$("#btn_close").attr("disabled",false);
	}
	generateStreamIndexSource(capability_nmediastream);
}

function initPage(newMedia)
{
	var hideArray = new Array();
	var mediaType = eval('media_i' + index + '_type');
	
	if (newMedia)
	{
		hideArray.push("snapshotChild", "videoclipChild");
	}
	else
	{
		switch (mediaType) {
			case "snapshot":
				hideArray.push("videoclipChild");
				break;
			case "videoclip":
				hideArray.push("snapshotChild");
				break;
			case "systemlog":
				hideArray.push("snapshotChild", "videoclipChild");
				break;
		}
	}

   jQuery.each(hideArray, function(i) { 
     $("#" + hideArray[i]).css("display","none");
   });    
}

function loadvaluedone()
{
	if(document.getElementsByTagName("input")[0].value=="")
	{
		document.forms[0].reset();	
		added=1;
		org_media_size=0;
		//workaround for append element videoclip_maxsize default value will be cleard after form reset
		document.getElementById("videoclip_maxsize").value = eval('media_i'+index+'_videoclip_maxsize');
	}
	else
	{
		if(document.getElementById("snapshot_type").checked==1)
			org_media_size=snapshotMaxSize*(parseInt(document.getElementById("snapshot_preevent").value)+parseInt(document.getElementById("snapshot_postevent").value)+1);
		else if(document.getElementById("videoclip_type").checked==1)
			org_media_size=parseInt(document.getElementById("videoclip_maxsize").value);
		else
			org_media_size=0;	
	}
	
	var mediaName = eval('media_i'+index+'_name');
	
	if (mediaName != "")
	{
		document.getElementById("mediaName").disabled=true;
	}
	initPage(added);
	if (capability_nmediastream == "1")
	{
		$(document.getElementById("media_index_snapshot_source")).removeOption("1");
		$(document.getElementById("media_index_videoclip_source")).removeOption("1");
	}
}

function checkname()
{
	if (CheckEmptyString(document.getElementsByTagName("input")[0]) == -1)
	{
		return -1;
	}
	if((document.getElementsByTagName("input")[0].value==media_i0_name ||
		document.getElementsByTagName("input")[0].value==media_i1_name ||
		document.getElementsByTagName("input")[0].value==media_i2_name ||
		document.getElementsByTagName("input")[0].value==media_i3_name ||
		document.getElementsByTagName("input")[0].value==media_i4_name) && added==1)
	{
		alert(translator("the_name_has_already_existed"));
		return -1;
	}
	else
		return 0;
}

function checkduration()
{
	if((parseInt(document.getElementById("videoclip_preevent").value,10)) > (parseInt(document.getElementById("videoclip_maxduration").value,10)))
		return -1;
}

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	else
	{
		if(checkname())
			return -1;
			
		if (CheckEmptyString(document.getElementById("snapshot_preevent")) ||
			CheckEmptyString(document.getElementById("snapshot_postevent")) ||
			CheckEmptyString(document.getElementById("videoclip_preevent")) ||
			CheckEmptyString(document.getElementById("videoclip_maxduration")) ||
			CheckEmptyString(document.getElementById("videoclip_maxsize")))
		{
			return -1;
		}

		if(checkduration())
		{
			alert(translator("pre_event_seconds_can_not_be_larger_than_max_duration"));
			return -1;
		}
				
		if(document.getElementById("snapshot_type").checked==1)
			media_size=snapshotMaxSize*(parseInt(document.getElementById("snapshot_preevent").value)+parseInt(document.getElementById("snapshot_postevent").value)+1);
		else if(document.getElementById("videoclip_type").checked==1)
			media_size=parseInt(document.getElementById("videoclip_maxsize").value);
		else
			media_size=0;
		if((media_size-org_media_size)>media_freespace)
		{
			alert(translator("media_size_is_over_free_space"));
			return -1;
		}

		bSaved = true;
		$.post(document.forms[0].action, $(document.forms[0]).serialize(), function(){
			parent.location += '&step=3';
			parent.location.reload();
		});
	}
}

function generateStreamIndexSource(capability_nmediastream)
{
	for (var i = 0; i < capability_nmediastream; i++) 
	{
		var symbolIndex = i + 1;
		var symbolName= "stream" + symbolIndex;
		if (i == 0)
		{
			$(document.getElementById("media_index_snapshot_source")).append(""
			+'<option value="'+ i +'" selected="selected" title="symbol">' + translator(symbolName) +'</option>'
			);
			
			$(document.getElementById("media_index_videoclip_source")).append(""
			+'<option value="'+ i +'" selected="selected" title="symbol">' + translator(symbolName) +'</option>'
			);
		}
		else
		{
			$(document.getElementById("media_index_snapshot_source")).append(""
			+'<option value="' + i + '" title="symbol">' + translator(symbolName) + '</option>'
			);
			
			$(document.getElementById("media_index_videoclip_source")).append(""
			+'<option value="' + i + '" title="symbol">' + translator(symbolName) + '</option>'
			);
		}
	}
}
function generateMaxVideoClipSize()
{
	$(document.getElementById("maxvideoclipsize")).append(""
	+'<input name="media_index_videoclip_maxsize" type="text" id="videoclip_maxsize" title="param,num,'+capability_media_videoclip_maxsize+',50" value="500" size="4" maxlength="4"/>'
	+'<span title="symbol">kbytes</span> [50~'+capability_media_videoclip_maxsize+']'
	);
}
