function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&snmp", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
        document.title=translator("snmp");
	loadlanguage();
}

function receivedone()
{
	document.getElementById("snmpv2Child").style.display="none";
	document.getElementById("snmpv3Child").style.display="none";
}

function loadvaluedone()
{
	if (snmp_v2 == 1)
	{
		$("#snmpv2Child").slideDown("slow");
	}

	if (snmp_v3 == 1)
	{
		$("#snmpv3Child").slideDown("slow");
		var aSecurityType = initSecurityType();
		for (i = 0; i < aSecurityType.length; i++)
		{
			document.getElementById("v3_" + aSecurityType[i]).value = getDefaultPassword();
		}
	}
	
	document.getElementById("content").style.visibility = "visible";
}

function checksnmp(a,b)
{
	updatecheck(a,b);
	if (document.snmpForm.snmp_v2.value == 1)
	{
		$("#snmpv2Child").slideDown("slow");
	}
	else
	{
		$("#snmpv2Child").slideUp("slow");
	}

	if (document.snmpForm.snmp_v3.value == 1)
	{
		$("#snmpv3Child").slideDown("slow");
	}
	else
	{
		$("#snmpv3Child").slideUp("slow");
	}
}

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	
	if (document.snmpForm.v2_rwcommunity.value == "" || document.snmpForm.v2_rocommunity.value == "")
	{
		alert(translator("community_can_not_be_an_empty_string"));
		return -1
	}	

	if (document.snmpForm.snmp_v3.value == 1)
	{
		if (document.snmpForm.v3_secnamerw.value == "" || document.snmpForm.v3_secnamero.value == "")
		{
			alert(translator("security_name_can_not_be_an_empty_string"));
			return -1
		}

		if (document.snmpForm.v3_authpwrw.value.length < 8 || document.snmpForm.v3_encryptpwrw.value.length < 8
		|| document.snmpForm.v3_authpwro.value.length < 8 || document.snmpForm.v3_encryptpwro.value.length < 8)
		{
			alert(translator("the_pw_should_contain_at_least_8_chars"));
			return -1
		}
	}

	if(checkPasswordVal() != 0)
	{
		return -1;
	}
	document.forms[0].submit();
}

function checkPasswordVal()
{
	var passwordval;
	var aSecurityType = initSecurityType();
	for (i = 0; i < aSecurityType.length; i++)
	{	
		passwordval = document.getElementById("v3_" + aSecurityType[i]).value;
		if(checkDefaultPassword(passwordval) != 0)
		{
			document.getElementById("v3_" + aSecurityType[i]).disabled = true;
		}
	}

	return 0;
}
function initSecurityType()
{
	var aSecurityType = new Array("authpwrw", "authpwro", "encryptpwrw", "encryptpwro");
	return aSecurityType;
}