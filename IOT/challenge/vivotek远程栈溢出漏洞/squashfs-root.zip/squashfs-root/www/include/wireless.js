function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?wireless&network&system_info_language&system_info_customlanguage", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("wireless");
	loadlanguage();
	$('#notification').bgiframe();
}
	
function loadvaluedone()
{

	if(wireless_encrypt == "none")
	{
		wireless_encrypt = 0;
	}	
	else if(wireless_encrypt == "wep")
	{
		wireless_encrypt = 1;
	}
	else if(wireless_encrypt == "wpa")
	{
		wireless_encrypt = 2;
	}	
	else if(wireless_encrypt == "wpa2")
	{
		wireless_encrypt = 3;
	}	

	var form = document.forms[0];
	form.wireless_ssid.value = unescape(wireless_ssid);
	form.wireless_key1.value = unescape(wireless_key1);
	form.wireless_key2.value = unescape(wireless_key2);
	form.wireless_key3.value = unescape(wireless_key3);
	form.wireless_key4.value = unescape(wireless_key4);
	form.wireless_presharedkey.value = unescape(wireless_presharedkey);
	GenWlanEncryptList();
	form.wireless_encrypt.options[wireless_encrypt].selected = true;
	showSecumode(form.wireless_encrypt.selectedIndex);
	showwlanchannel();
	//save orgvalue
	var nh = document.NetworkHidden;
	//WPA
	nh.wireless_orgalgorithm.value = form.wireless_algorithm.value
	nh.wireless_orgpresharedkey.value = form.wireless_presharedkey.value
	//WEP
	nh.wireless_orgauthmode.value = form.wireless_authmode.value
	nh.wireless_orgkeylength.value = form.wireless_keylength.value
	nh.wireless_orgkeyformat.value = form.wireless_keyformat.value
	nh.wireless_orgkeyselect.value = form.wireless_keyselect.value
	//alert(form.wireless_keyformat.value);
	if (form.wireless_keyformat.value == "HEX")
	{
		nh.wireless_orgkey1.value = form.wireless_key1.value;
		nh.wireless_orgkey2.value = form.wireless_key2.value;
		nh.wireless_orgkey3.value = form.wireless_key3.value;
		nh.wireless_orgkey4.value = form.wireless_key4.value;
	} else {
		nh.wireless_orgkey1.value = Ascii2Hex(form.wireless_key1.value);
		nh.wireless_orgkey2.value = Ascii2Hex(form.wireless_key2.value);
		nh.wireless_orgkey3.value = Ascii2Hex(form.wireless_key3.value);
		nh.wireless_orgkey4.value = Ascii2Hex(form.wireless_key4.value);
	}
//	resetWPA();
//	resetWEP();
	document.getElementById("content").style.visibility = "visible";
	firstload = 0;
}

function showmode()
{
	GenWlanEncryptList();
	showSecumode(document.forms[0].wireless_encrypt.selectedIndex);
}

function GenWlanEncryptList()
{
	var form = document.forms[0];
	
	document.getElementById("wep_mode").style.display = "none";
	document.getElementById("wpa_mode").style.display = "none";

	if (form.wireless_wlmode.selectedIndex == 0)
	{
		form.wireless_channel.disabled = 1;

		//IE can't use style.display on option elements
		if (form.wireless_encrypt.length < 4)
		{
			form.wireless_encrypt.length = 4;
			form.wireless_encrypt.options[2].text = "WPA-PSK";
			form.wireless_encrypt.options[2].value = "2";
			form.wireless_encrypt.options[3].text = "WPA2-PSK";
			form.wireless_encrypt.options[3].value = "3";
		}
	}
	else
	{
		form.wireless_channel.disabled = 0;
		
		form.wireless_encrypt.options[3] = null;
		form.wireless_encrypt.options[2] = null;
		
		if (form.wireless_encrypt.length > 2)
		{
			form.wireless_encrypt.length = 2;
		}
	}
}

function showSecumode(wlanIndex)
{
	if (wlanIndex == 1)
		{
			//document.getElementById("wep_mode").style.display = "block";
			//document.getElementById("wpa_mode").style.display = "none";
			$("#wep_mode").slideDown("slow");						
			$("#wpa_mode").slideUp("slow");
		}
	else if (wlanIndex >= 2)
		{
			//document.getElementById("wep_mode").style.display = "none";
			//document.getElementById("wpa_mode").style.display = "block";
			$("#wep_mode").slideUp("slow");
			$("#wpa_mode").slideDown("slow");									
			
	}
}

function resetWPA()
{
	var form = document.forms[0];
	var nh = document.NetworkHidden;
	selectTheDropdownEnt(form.wireless_algorithm, nh.wireless_orgalgorithm.value);
	form.wireless_presharedkey.value = nh.wireless_orgpresharedkey.value;
}

function resetWEP()
{
	var form = document.forms[0];
	var nh = document.NetworkHidden;
	selectTheDropdownEnt(form.wireless_authmode, nh.wireless_orgauthmode.value);
	selectTheDropdownEnt(form.wireless_keylength, nh.wireless_orgkeylength.value);
	selectTheDropdownEnt(form.wireless_keyformat, nh.wireless_orgkeyformat.value);
	selectTheRadioButton(form.wireless_keyselect, 4, nh.wireless_orgkeyselect.value);
	form.wireless_key1.value = nh.wireless_orgkey1.value;
	form.wireless_key2.value = nh.wireless_orgkey2.value;
	form.wireless_key3.value = nh.wireless_orgkey3.value;
	form.wireless_key4.value = nh.wireless_orgkey4.value;
}
  	
function selectTheDropdownEnt(selObj, targetVal) 
{
	for (i = 0; i < selObj.length; i ++)
  	{
	    if (isNaN(targetVal))
		{
			if (selObj.options[i].value.toLowerCase() == targetVal.toLowerCase())
	    	{
				selObj.options[i].selected = true;
				break;
	      	}
		}
		else
  	{
			if (selObj.options[i].value == targetVal)
			{
				selObj.options[i].selected = true;
				break;
			}
		}
  	}
}

function selectTheRadioButton(radioName, radioNum, targetVal)
{
	for (i=0; i<radioNum; i++)
	{
		if (radioName[i].value == targetVal)
	    	{
			//radioName[i].defaultChecked = true;
			radioName[i].checked = true;
		}
	}
}

function getKeyLength()
{
	var index = document.forms[0].wireless_keylength.selectedIndex;

	if (index == 0)	return 5;
	if (index == 1)	return 13;
	if (index == 2)	return 29;
}

function ChangeKeyLengthFormat()
{
	var i;
	var szAddKey;
	var iKeyBytes;
	var tmp;
	var form = document.forms[0];
	var nh = document.NetworkHidden;
	iKeyBytes = getKeyLength();
	
	if (nh.wireless_orgkeylength.value == form.wireless_keylength.value)
	{ 
		if (form.wireless_keyformat.value == "HEX")
		{
			form.wireless_key1.value = nh.wireless_orgkey1.value;
			form.wireless_key2.value = nh.wireless_orgkey2.value;
			form.wireless_key3.value = nh.wireless_orgkey3.value;
			form.wireless_key4.value = nh.wireless_orgkey4.value;
		}
		else
		{
			tmp = Hex2Ascii(nh.wireless_orgkey1.value);
			form.wireless_key1.value = tmp;
			tmp = Hex2Ascii(nh.wireless_orgkey2.value);
			form.wireless_key2.value = tmp;
			tmp = Hex2Ascii(nh.wireless_orgkey3.value);
			form.wireless_key3.value = tmp;
			tmp = Hex2Ascii(nh.wireless_orgkey4.value);
			form.wireless_key4.value = tmp;
		}
	}
	else
	{
		if (form.wireless_keyformat.value == "HEX")
		{
				form.wireless_key1.value = "";
				form.wireless_key2.value = "";
				form.wireless_key3.value = "";
				form.wireless_key4.value = "";
			for (i=0;i<iKeyBytes*2;i++)
			{
				form.wireless_key1.value += "0";
				form.wireless_key2.value += "0";
				form.wireless_key3.value += "0";
				form.wireless_key4.value += "0";
			}
		}
		else
		{
			form.wireless_key1.value = "";
			form.wireless_key2.value = "";
			form.wireless_key3.value = "";
			form.wireless_key4.value = "";
		}
	}
}

function checkKey(instr){
	var i;
  	var iKeyBytes = getKeyLength();
  	
  	if (document.forms[0].wireless_keyformat.selectedIndex == 0)
  	{
		for(i=0; i<instr.value.length; i++)
		{
	    	var c = instr.value.charAt(i);
	    	if (!((c>='0'&& c<='9')||(c>='A' && c<='F')||(c>='a' && c<='f')))
	    	{
	    		alert(translator("invalid_hex"));
		   		instr.focus();
		        instr.select();
	      		return -1;
	      	}
		}
		iKeyBytes = iKeyBytes * 2;
  	}
  	if (instr.value.length != iKeyBytes)
  	{
  		alert(translator("please_enter_exactly") +' '+ iKeyBytes +' '+ translator("characters"));
   		instr.focus();
        instr.select();  		
  		return -1;
  	}
}

function checkWPAKey()
{
	var wpak = document.wireless.wireless_presharedkey;
	if (wpak.value.length < 8)
	{
	    alert(translator("preshared_key_limitation"));
		wpak.focus();
		wpak.select();
		return -1;
	}
	if (wpak.value.length == 64)
	{
		for (i=0; i<wpak.value.length; i++)
		{
	    	var c = wpak.value.charAt(i);
	    	if (!((c>='0'&& c<='9')||(c>='A' && c<='F')||(c>='a' && c<='f')))
	    	{
	    		alert(translator("invalid_hex"));
		   		wpak.focus();
		        wpak.select();
	      		return -1;
	      	}
		}
	}
}

function Ascii2Hex(in_str)
{
    var atr = "";
	for (i = 0; i < in_str.length; i ++)
	{
	    tmp = in_str.charCodeAt(i).toString(16);
		if (tmp.length == 1)	tmp = "0" + tmp;
		atr = atr + tmp;
	}
	return atr;
}

function Hex2Ascii(in_str)
{
	var astr = "";
	var asub = "";
	var i;	
	var tmp = in_str.toUpperCase();
	
	if ((tmp.length & 1) > 0)	tmp = tmp + "0";
		
	for (i=0; i<tmp.length; i+=2) 
	{
		var c = tmp.charAt(i);
		if (!((c>='0'&& c<='9')||(c>='A' && c<='F')))
			return -2;
		asub = tmp.substring(i, i+2);
		var code = parseInt(asub, 16);
		if (code == 34 || code == 60 || code == 62 || code < 32 || code >= 127)
			astr = astr + " ";
		else if (code > 255) 
			return -2;
		else
			astr = astr + String.fromCharCode(code);
	}
	return astr;
}

function submitform()
{
	if (checkvalue())
	{
		return -1;
	}
	else if (NetConfirm())
	{
		return -1;
	}
	else
	{
		document.wireless.wireless_ssid.value = escape(document.wireless.wireless_ssid.value);
		document.wireless.wireless_key1.value = escape(document.wireless.wireless_key1.value);
		document.wireless.wireless_key2.value = escape(document.wireless.wireless_key2.value);
		document.wireless.wireless_key3.value = escape(document.wireless.wireless_key3.value);
		document.wireless.wireless_key4.value = escape(document.wireless.wireless_key4.value);
		document.wireless.wireless_presharedkey.value = escape(document.wireless.wireless_presharedkey.value);
	document.forms[0].submit();
		setTimeout('connect_ap()', 1000);
	}
	
	//network_ipaddress = document.forms[0].network_ipaddress.value;
	//network_http_port = document.forms[0].network_http_port.value;
	//showNotification(60);
	//DivSetVisible();
}

function connect_ap()
{
	$.get("/cgi-bin/admin/connect_ap.cgi");
	alert("Connecting to your AP....please refer to your quick installation guide to proceed with the next step.");
}

function DivSetVisible()
{
	
	document.getElementById("DivShim").style.width = document.getElementById("notification").offsetWidth; 
	document.getElementById("DivShim").style.height = document.getElementById("notification").offsetHeight; 
	
	document.getElementById("DivShim").style.zIndex = document.getElementById("notification").style.zIndex - 1; 
	
	document.getElementById("DivShim").style.zIndex = 99;
	document.getElementById("DivShim").style.visibility = "visible";
}

function showwlanchannel()
{
	var form = document.forms[0];
	var wlannum = capability_wireless_endchannel - capability_wireless_beginchannel + 1;
	form.wireless_channel.length = wlannum;
	
	for (i = 0; i < wlannum ; i++)
	{
		form.wireless_channel.options[i].text = capability_wireless_beginchannel;
		form.wireless_channel.options[i].value = capability_wireless_beginchannel;
		if (form.wireless_channel.options[i].value == wireless_channel)
		{
			form.wireless_channel.options[i].selected = true;
		}
		capability_wireless_beginchannel++;
	}
	
}

function NetConfirm()
{
	var wl = document.wireless;

	if (wl.wireless_encrypt.selectedIndex == 1)
	{
		if(checkKey(wl.wireless_key1) < 0 ||
		   checkKey(wl.wireless_key2) < 0 ||
		   checkKey(wl.wireless_key3) < 0 ||
		   checkKey(wl.wireless_key4) < 0)
		{
			return -1;
		}
	}
	else if (wl.wireless_encrypt.selectedIndex > 1)
	{
		if (checkWPAKey() < 0)
			return -1;
	}
}
