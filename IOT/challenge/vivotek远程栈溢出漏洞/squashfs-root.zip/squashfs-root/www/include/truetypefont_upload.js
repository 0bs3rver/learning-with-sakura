	

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?videoin_c0_texontvideo", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title="Upload TrueTypeFont File";
	loadlanguage();
	eval(location.search.toString().slice(1));
	//alert(location.search.toString().slice(1));
	var input=document.getElementsByTagName("input");
	for (var i = 0; i < input.length; i++)
	{
		input[i].name=input[i].name.toString().replace("index", "i"+index);
	}
	
}

var have_submit = false;

function checkUploadTrueTypeFontFile()
{
	var form = document.uploadTrueTypeFontFile;

	if (have_submit) 
		return -1;

	if (form.uploadTrueTypeFont.value == "") 
	{
    	alert(translator("select_a_file_before_click_on_upload"));
    	return -1;
  	}
  	
	var suffix = form.uploadTrueTypeFont.value.split(".");
	var filename = form.uploadTrueTypeFont.value.split("\\");

//  $.ajax({
//    type: "POST",
//    url: "/cgi-bin/admin/setparam.cgi",
//    data: "videoin_c0_textonvideo_customizedfilename=" + filename[filename.length-1],
//    cache: false
//  });
	form.action="/cgi-bin/admin/upload_ttf.cgi?"+encodeURIComponent(filename[filename.length-1]);
	if (suffix[suffix.length-1] != 'ttf')
	{
		alert(translator("the_file_must_have_a_ttf_file_suffix"));
		
		return -1;
	}

	have_submit = true;
	
	// Connect with ie8 and https will result in error, add null.html to avoid the issue, suck.
	window.open("/setup/null.html", "testlan", "height=180,width=500");
//    window.open("/setup/null.html", "testlan");
	form.target="testlan";
	
	form.submit();
}
