function loadCurrentSetting()
{
	paramIndex1 = location.search.toString().indexOf("&");
//	alert(location.search.toString().slice(paramIndex1 + 1));
	if (paramIndex1 != -1)
	{
		eval(location.search.toString().slice(1, paramIndex1));
//		alert("index=" + index);
		eval(unescape(location.search.toString().slice(paramIndex1 + 1)));
//		alert("folder=" + folder);
	}
	else
	{
		eval(location.search.toString().slice(1));
//		page = 1;
	}
	if (typeof(folder) != "undefined")
	{
		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/fileoptr.cgi?_j=file_list&_s=" + folder + "&_l=network"+index, true);
		document.getElementById("foldername").value = folder;
		document.title = translator("file_list") + " of " + folder;
	}
	else
	{
		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/fileoptr.cgi?_j=file_list&_l=network"+index, true);
		document.getElementById("prebutton").style.display = "none";
		document.title = translator("file_list");
	}
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.getElementById("network").value = "network" + index;
	document.getElementById("returnpage").value = "setup/recording/recording_network.html?index=" + index;
}
function loadvaluedone()
{
	//document.getElementById("filelist").innerHTML="<table border=1>"+file_list+"</table>";
	document.getElementById("filelist").innerHTML = "<br>" + file_list;
	loadlanguage();

	$("a").each(function(index){
		this.href = this.href.replace(/\#/ig,"%23");
	});
}


function deleteall()
{
	if (typeof(folder) != "undefined")
	{
		var cgiList = "/cgi-bin/admin/fileoptr.cgi?_s=" + folder + "&_a=network" + index + "&_m=setup/recording/recording_network.html?index=" + index;
	}
	else
	{
		var cgiList = "/cgi-bin/admin/fileoptr.cgi?_a=network" + index + "&_m=setup/recording/recording_network.html?index=" + index;
	}
	location.replace(cgiList);
}

function PreviousPage()
{
	var url = "recording_network.html?index=" + index;
	window.open(url, "_self", "width=800, height=600, scrollbars=yes, status=yes");
}
