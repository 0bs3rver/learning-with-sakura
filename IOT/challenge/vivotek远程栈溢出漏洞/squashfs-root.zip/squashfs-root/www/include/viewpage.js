//Plugin constant.
var PLUGIN_ID = "WinLessPluginCtrl";
var PLUGIN_NAME = "VVTK_Plugin_Installer.exe";
var PLUGIN_VER = "1,0,0,114";
var CLASS_ID = "64865E5A-E8D7-44C1-89E1-99A84F6E56D0";
var FFTYPE = "application/x-streamctrl";
var FF_VER = "1.0.0.88";
var VNDPWRAPPER_VER = "1,0,0,69";
var FF_XPI_DESCRIPTION = "Installer Management v" + FF_VER;
var PLUGIN_LANG="EN";
var BUFFERTIME=getCookie("streamingbuffertime");
var HTTP_METHOD = document.URL.split(":");


//Customized constant.
var gbForceStream = -1;
var giTargetHeight = 320; //px
var giWidthLimit = 532; //px
var giNonIERefreshImgPeriod = 1000; //ms, MIN is 1000.
var giMagicWidth = 558; //px, so magic!
var giMagicTop = 22; //px, so magic!


//Global variable.
var giCH_Curr = 0;
var giTargetStream = 0;
var Res;
var gImgW, gImgH;
var gImg = null;;
var gImgUrl;
var gTimer;
var gQuality = 3;
var gInitscrollHeight;
var gCurrSize = "auto"
var gProfileIdx;
var gStrProfile;

var bExposure = false;
var gCustom = false;
	var giCusWinNum = 1;
	var giCurWinIdx = 0;
	var gbDomainPX = false;
	var gbDomainSTD = false;
	var gbDomainQVGA = false;
	var gPrmTail = "";
	var giCurDomainSizeW;
	var giCurViewSizeY;
	var gaiCusWinW;
	var gaiCusWinH;
	var gaiCusWinX;
	var gaiCusWinY;
	var gaiCusWinEnable;
	var gaiCusWinPolicy;
var gBLC = false;
var bRotate = false;

function checkRotate()
{
	if (eval("capability_videoin_c" + giCH_Curr + "_rotation") == 1)
	{
		if (eval("videoin_c" + giCH_Curr + "_rotate") == 90 || eval("videoin_c" + giCH_Curr + "_rotate") == 270)
		{
			bRotate = true;
		}
	}
}

function setProfileIndex()
{
	gProfileIdx = Number(getCookie("sensorprofileindex"))
	
	if (gProfileIdx == 0)
	{
		gStrProfile = ""
	}
	else
	{
		gStrProfile = "_profile_i0"
	}
}

function loadCurrentSetting()
{	
	var tmp = location.href.split("?");
	var tmp2;
	var TmpStr = "";

	tmp = tmp[1].split("&");
	tmp2 = tmp[0].split("=");

	if (tmp2[0] == 'ch')
	{
		giCH_Curr = parseInt(tmp2[1], 10);
		if (giCH_Curr >= parseInt(capability_nvideoin, 10))
		{
			giCH_Curr = 0;
		}
	}

	if (parseInt(capability_nmediastream, 10) >= 2)
	{
		giTargetStream = FullviewStreamIndex();
	}

	if (-1 != gbForceStream && gbForceStream < parseInt(capability_nmediastream, 10))
	{
		giTargetStream = gbForceStream;
	}

	TmpStr = "/cgi-bin/admin/getparam_cache.cgi?videoin_c"+giCH_Curr+"_s"+giTargetStream+"_codectype&videoin_c"+giCH_Curr+"_s"+giTargetStream+"_resolution&network_rtsp_s"+giTargetStream+"_accessname&network_http_s"+giTargetStream+"_accessname&network_http_port&network_https_port&network_rtsp_port&videoin_c"+giCH_Curr+"_rotate&capability_videoin_c"+giCH_Curr+"_rotation";

	if (-1 != tmp[1].search("exposure"))
	{
		bExposure = true;
		TmpStr = TmpStr + "&capability_image_c"+giCH_Curr+"&capability_videoin_c"+giCH_Curr+"&exposurewin_c"+giCH_Curr;
	}


	XMLHttpRequestObject.open("GET", TmpStr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	loadlanguage();

	setProfileIndex();

}

function loadvaluedone()
{
	var strPlugin = "";
	var Tmp;
	var bHLCSupportWin = false;
	
	bHLCSupportWin = !ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_hlcmode_supportwindow");

	checkRotate();
	eval("VideoSize=videoin_c"+giCH_Curr+"_s"+giTargetStream+"_resolution");
	eval("CodecType=videoin_c"+giCH_Curr+"_s"+giTargetStream+"_codectype");
	if ("h264" == CodecType || "mpeg4" == CodecType || "svc" == CodecType)
	{
		eval("AccessName=network_rtsp_s"+giTargetStream+"_accessname");
	}
	else
	{
		eval("AccessName=network_http_s"+giTargetStream+"_accessname");
	}

	//Default use auto-size.
	Res = eval("videoin_c"+giCH_Curr+"_s"+giTargetStream+"_resolution");
	gImgW = parseInt(Res.split("x")[0], 10) * giTargetHeight / parseInt(Res.split("x")[1], 10);
	if (gImgW < giWidthLimit)
	{
		gImgH = giTargetHeight;
	}
	else
	{
		gImgH = parseInt(Res.split("x")[1], 10) * giWidthLimit / parseInt(Res.split("x")[0], 10);
		gImgW = giWidthLimit;
	}

	if (bRotate)
	{
		tmpgImgW = gImgW;
		gImgW = gImgH;
		gImgH = tmpgImgW;
	}

	if (true == bIsWinMSIE)
	{
		strPlugin = "<object class=CropZone id=\"" + PLUGIN_ID + "\" width=" + gImgW + " height=" + gImgH;
		strPlugin += " standby=\"Loading plug-in...\" classid=CLSID:" + CLASS_ID;
		strPlugin += " codebase=\"/" + PLUGIN_NAME + "#version=" + PLUGIN_VER + "\">";
		if ("https" == HTTP_METHOD[0])
		{
			strPlugin += "<param name=\"HttpPort\" VALUE=\"" +  network_https_port + "\" >";
		}
		else
		{
			strPlugin += "<param name=\"HttpPort\" VALUE=\"" +  network_http_port + "\" >";
		}
		strPlugin += '<param name="ReadSettingByParam " VALUE="1">';
		strPlugin += '<param name="MediaType" VALUE="2">';
		strPlugin += '<param name="DisplayErrorMsg" value="true">';
		strPlugin += '<param name="IgnoreCaption" value="true">';
		strPlugin += '<param name="IgnoreBorder" value="true">';
		strPlugin += "<param name=\"ViewStream\" VALUE=\"" + giTargetStream + "\">";
		strPlugin += "<param name=\"ViewChannel\" VALUE=\"" + (giCH_Curr+1) + "\">";
		strPlugin += '<param name="VSize" VALUE="CMS">';
	 	strPlugin += '<param name="Stretch" VALUE="true">';
		strPlugin += '<param NAME="StretchFullScreen" VALUE="false">';
		strPlugin += '<param NAME="PluginCtrlID" VALUE="">';
		strPlugin += "<PARAM NAME=\"Url\" VALUE=" + document.URL + ">";
		strPlugin += "<PARAM NAME=\"ControlPort\" VALUE="+network_rtsp_port+">";
		strPlugin += '<PARAM NAME="EnableJoystick" VALUE="false">';
		strPlugin += '<PARAM NAME="UpdateJoystickInterval" VALUE="100">';
		strPlugin += '<PARAM NAME="JoystickSpeedLvs" VALUE="5">';
		strPlugin += "<param name=\"Language\" VALUE=\"" + PLUGIN_LANG + "\">";
		strPlugin += '<param name="MP4Conversion" VALUE="true">';
		strPlugin += '<param name="EnableFullScreen" VALUE="false">';
		strPlugin += '<param name="AutoStartConnection" VALUE="true">';
		strPlugin += '<param name="ClickEventHandler" VALUE="3">';
		strPlugin += "<param name=\"StreamingBufferTime\" VALUE=\"" + BUFFERTIME + "\">";
		strPlugin += '<PARAM NAME="BeRightClickEventHandler" VALUE="false">';
		strPlugin += '<param name="ClientOptions" value="122">';
		strPlugin += '<param name="PlayMute" value="true">';
		strPlugin += '<param name="MicMute" value="true">';
		strPlugin += '<param name="BeAspectRatio" value="true">';
		strPlugin += '<param name="AspectRatioSection" value="0">';
		strPlugin += "</object>";

		$("#showimageBlock").append(strPlugin);
		
		//original code
		//gInitscrollHeight = document.body.scrollHeight + 18;

	}
	else
	{
		document.getElementById("snapshotstream").src = "/pic/noimg.jpg";
		gImgUrl = "/cgi-bin/viewer/video.jpg?channel="+giCH_Curr+"&streamid="+giTargetStream+"&resolution="+gImgW+"x"+gImgH;
		document.getElementById("snapshotstream").width = gImgW;
		document.getElementById("snapshotstream").height = gImgH;
		document.getElementById("snapshotstream").style.display = "block";
		document.getElementById("qualityTitle").innerHTML = translator("quality") + ":";
		document.getElementById("qualityTitle").style.display = "inline";
		document.getElementById("imagequality").style.display = "inline";

		//original code
		//gInitscrollHeight = document.body.scrollHeight;

		if (gImg == null)
		{
			gImg = new Image();
			gImg.onload = function()
			{
				document.getElementById("snapshotstream").src = gImg.src;
				gTimer = setTimeout("updateImg()", giNonIERefreshImgPeriod);
			}

			gImg.onerror = function()
			{
				gROITimer = setTimeout("updateROIImg()", guiROIRefreshImgTime_ms);
			};
		}
		gTimer = setTimeout("updateImg()", 100);
	}

	// In IE11 or firefox, 
	// the height return from document.body.scrollHeight would be smaller than we expect (original code)
	// here we calculate the scrollHeight directly to avoid overflow
	// 22 is the external table margin width
	gInitscrollHeight = gImgH + 18 + 22;

	parent.document.getElementById("viewpage").height = gInitscrollHeight;

	if (bExposure)
	{
		if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("custom") != -1)
		{
			giCusWinNum = parseInt(eval("capability_image_c"+giCH_Curr+"_exposure_winnum"), 10);
			gaiCusWinW = new Array(giCusWinNum);
			gaiCusWinH = new Array(giCusWinNum);
			gaiCusWinX = new Array(giCusWinNum);
			gaiCusWinY = new Array(giCusWinNum);
			gaiCusWinEnable = new Array(giCusWinNum);
			gaiCusWinPolicy = new Array(giCusWinNum);

			if (eval("capability_image_c"+giCH_Curr+"_exposure_windomain").search("px") != -1)
			{
				gbDomainPX = true;
				gPrmTail = "px";
				Tmp = eval("capability_videoin_c"+giCH_Curr+"_mode");
				Tmp = eval("capability_videoin_c"+giCH_Curr+"_mode"+Tmp+"_outputsize").split("x");
				giCurDomainSizeW = parseInt(Tmp[0], 10);
				giCurDomainSizeH = parseInt(Tmp[1], 10);
			}
			else if (eval("capability_image_c"+giCH_Curr+"_exposure_windomain").search("std") != -1)
			{
				gbDomainSTD = true;
				gPrmTail = "std";
				giCurDomainSizeW = 9999;
				giCurDomainSizeH = 9999;
			}
			else
			{
				gbDomainQVGA = true;
				gPrmTail = "";
				giCurDomainSizeW = 320;
				giCurDomainSizeH = 240;
			}

			if (bRotate)
			{
				tmpgImg = giCurDomainSizeW;
				giCurDomainSizeW = giCurDomainSizeH;
				giCurDomainSizeH = tmpgImg;
			}

			for (i = 0; i < giCusWinNum; i++)
			{

				// gaiCusWinW, gaiCusWinH, gaiCuswinX and gaiCuswinY is equivalent to exposurewin_xxxx_size, exposurewin_xxxx_home
				// whether rotate or not, it remains the same
				Tmp = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_size"+gPrmTail).split("x");
				gaiCusWinW[i] = parseInt(Tmp[0], 10);
				gaiCusWinH[i] = parseInt(Tmp[1], 10);
				Tmp = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_home"+gPrmTail).split(",");
				gaiCusWinX[i] = parseInt(Tmp[0], 10);
				gaiCusWinY[i] = parseInt(Tmp[1], 10);

				gaiCusWinEnable[i] = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_enable");
				gaiCusWinPolicy[i] = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_policy");
			}

		}

		if (gProfileIdx == 0)
		{
			if ("custom" == eval("exposurewin_c"+giCH_Curr+"_mode")
			|| ("hlc" == eval("exposurewin_c"+giCH_Curr+"_mode") && bHLCSupportWin))
			{
				gCustom = true;

			}
			else if ("blc" == eval("exposurewin_c"+giCH_Curr+"_mode"))
			{
				gBLC = true;
			}
		}
		else
		{
			if ("custom" == eval("exposurewin_c"+giCH_Curr+"_profile_i0_mode")
			|| ("hlc" == eval("exposurewin_c"+giCH_Curr+"_profile_i0_mode") && bHLCSupportWin))
			{
				gCustom = true;

			}
			else if ("blc" == eval("exposurewin_c"+giCH_Curr+"_profile_i0_mode"))
			{
				gBLC = true;
			}
		}
	}

	setTimeout('startView()',200);
	
}

function startView()
{
	switchView($("button.viewstyle:[title*='Auto-Fit']")[0], "Auto");
}

function switchView(obj, param)
{

	// Reset default state, except "4:3" btn
	$(".viewstyle").attr("disabled", false).each(function(){
		posObj = $(this).css("backgroundPosition").split(" ");
		$(this).css("backgroundPosition", posObj[0] + " 0px");
	});
	// set selected button state
	var posObj = $(obj).css("backgroundPosition").split(" ");
	$(obj).css("backgroundPosition", posObj[0] + " -36px").attr("disabled", true);

	if (param == "100")
	{
		gCurrSize = "100";
		gImgW = parseInt(Res.split("x")[0], 10);
		gImgH = parseInt(Res.split("x")[1], 10);
	}
	else// if (param == "auto")
	{
		gCurrSize = "auto";

		gImgW = parseInt(Res.split("x")[0], 10) * giTargetHeight / parseInt(Res.split("x")[1], 10);
		if (gImgW < giWidthLimit)
		{
			gImgH = giTargetHeight;
		}
		else
		{
			gImgH = parseInt(Res.split("x")[1], 10) * giWidthLimit / parseInt(Res.split("x")[0], 10);
			gImgW = giWidthLimit;
		}
	}

	if (bRotate)
	{
		tmpgImgW = gImgW;
		gImgW = gImgH;
		gImgH = tmpgImgW;
	}

	if (true == bIsWinMSIE)
	{
		$("#"+PLUGIN_ID).attr("width", gImgW).width(gImgW);	
		$("#"+PLUGIN_ID).attr("height", gImgH).height(gImgH);
	}
	else
	{
		clearTimeout(gTimer);

		document.getElementById("snapshotstream").width = gImgW;
		document.getElementById("snapshotstream").height = gImgH;
		gImgUrl = "/cgi-bin/viewer/video.jpg?channel="+giCH_Curr+"&streamid="+giTargetStream+"&resolution="+gImgW+"x"+gImgH;

		gTimer = setTimeout("updateImg()", 100);
	}

	if (gBLC)
	{
		createBLCBlock();
	}

	if (gCustom)
	{
		createCustomBlock();
	}
}

function updateImg()
{
	var da;

	da = new Date();
	gImg.src = ""+gImgUrl+"&quality="+gQuality+"&date="+da.getTime();
}

function changeimageQuality(obj)
{
	gQuality = obj.options[obj.selectedIndex].value;
}

function createBLCBlock()
{
	var w, h, x, y;

	$("#BLCWindow").remove();

	// BLC window is comparative with custom window. If it does not support custom window, we might hide the BLC window.
	if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("custom") == -1)
	{
		return;
	}

	$("#showimageBlock").append(""
		+ '<div id="BLCWindow" class="BLC_style">'
		+ '<div style="text-align: center;">'
		+ '<span class="BLC_title">BLC</span>'
		+ '</div></div>');

	$('#BLCWindow').css("display", "block");
	$('#BLCWindow').css("filter","alpha(Opacity=75)").css("opacity","0.75").css("-moz-opacity","0.75");
	$('#BLCWindow').css("borderColor","#CCCCCC");
	$('#BLCWindow').css("backgroundColor","transparent");

	w = gImgW / 2;
	h = gImgH / 2;
	
	// different broswer zoom ratio may have different giMagicWidth
	// so we need to use document.getElementById(xxx).offsetLeft instead of giMagicWidth to determine css left property
	if (true == bIsWinMSIE)
	{
		x = document.getElementById(PLUGIN_ID).offsetLeft + w / 2 
		y = giMagicTop + h / 2;
	}
	else
	{
		x = document.getElementById("snapshotstream").offsetLeft + w / 2
		y = giMagicTop + h / 2;
	}


	$('#BLCWindow').css({
		width:	''+w+'px',
		height:	''+h+'px',
		left:	''+x+'px',
		top:	''+y+'px'
	})
}

function createCustomBlock()
{
	var Tmp;
	var x;
	var ew, eh, ex, ey;

	$("#CustomWinBlk").remove();
	$("#showimageBlock").append("<div id='CustomWinBlk'></div>");

	$("#CustomWinBlk").height(gImgH + 2 + 18 + 2 + 2); //Upper border, window Title's height, middle border, under border.
	//Custom exposure window is composed with 3 parts: title bar, selecting area, and borders.
	//Title bar is fixed to 18px height. Each border is 2px width.
	//The origin of custom window is start with title bar and borders, but the selecting area is only we want.
	//Therefore, I increase CustomWinBlk to let title bar and borders can be outside the view,
		//then the origin of custom window will be the one in view's coordinate system.
	$("#CustomWinBlk").width(gImgW + 2 + 2); //The same reason as hight.

	if (true == bIsWinMSIE)
	{
		x = document.getElementById(PLUGIN_ID).offsetLeft;
	}
	else
	{
		x = document.getElementById("snapshotstream").offsetLeft;
	}

	$('#CustomWinBlk').css({
		left:	''+(x-2)+'px', //Left border.
		top:	''+(giMagicTop - 18 - 2 - 2)+'px' //Window Title's height, border size.
	})

	for (i = 0; i < giCusWinNum; i++)
	{
		if (1 == gaiCusWinPolicy[i])
		{
			Tmp = translator("include");
		}
		else
		{
			Tmp = translator("exclude");
		}

		$("#CustomWinBlk").append(""
			+ '<div id="CusWin' + i + '" class="EPW_style">'
			+ '<div class="EPW_drag">'
			+ '<span title="" class="EPW_title">' + Tmp + '</span>'
			+ '<a class="ui-dialog-titlebar-close" href="#"><span>X</span></a>'
			+ '</div>'
			+ '</div>');

		if (bRotate)
		{
			ew = parseInt(gaiCusWinH[i] * gImgW / giCurDomainSizeW, 10);
			eh = parseInt(gaiCusWinW[i] * gImgH / giCurDomainSizeH, 10);
			ex = parseInt(gaiCusWinY[i] * gImgW / giCurDomainSizeW, 10);
			ey = parseInt(gaiCusWinX[i] * gImgH / giCurDomainSizeH, 10);
		}
		else
		{
			ew = parseInt(gaiCusWinW[i] * gImgW / giCurDomainSizeW, 10);
			eh = parseInt(gaiCusWinH[i] * gImgH / giCurDomainSizeH, 10);
			ex = parseInt(gaiCusWinX[i] * gImgW / giCurDomainSizeW, 10);
			ey = parseInt(gaiCusWinY[i] * gImgH / giCurDomainSizeH, 10);
		}

		if (1 == gaiCusWinPolicy[i])
		{
			$('#CusWin'+i).css({
				width: ''+ew+'px',
				height: ''+(eh+18+2)+'px', //Title bar height, middle border.
				left: ''+ex+'px',
				top: ''+ey+'px',
				opacity: '0.9',
				display: 'none'
			});
		}
		else
		{
			$('#CusWin'+i).css({
				width: ''+ew+'px',
				height: ''+(eh+18+2)+'px', //Title bar height, middle border.
				left: ''+ex+'px',
				top: ''+ey+'px',
				backgroundColor: '#999',
				opacity: '0.75',
				display: 'none'
			});

			$('#CusWin'+i).find(".EPW_drag").css("backgroundColor","#0066FF");
		}

		if (1 == gaiCusWinEnable[i])
		{
			$('#CusWin'+i).css({
				display: 'block'
			});
		}
	}


	$('.EPW_style').mousedown(function(e){
		giCurWinIdx = $(this).attr("id").charAt(6); //Caution: this limits maximum window number to 9;
		$(this).siblings(".EPW_style").css("z-index", 50);
		$(this).css("z-index", 90);
		$(this).find(".EPW_title").css("font-weight","bolder");
	});


	$('.EPW_style').resizable({
		containment: "#CustomWinBlk",
		handles: 'all',
		autoHide: true,
		minWidth: 50,
		minHeight: 50,
		resize: function(e, ui)
		{
			//Do nothing.
		},
		stop: function(e, ui)
		{
/*
			alert(""+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("left")))+
			","+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("top")))+
			" "+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("width")))+
			"x"+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("height"))));
*/

			if (bRotate)
			{
				gaiCusWinH[giCurWinIdx] = Math.round(parseInt($("#CusWin" + giCurWinIdx).css("width"), 10) * giCurDomainSizeW / gImgW);
				gaiCusWinW[giCurWinIdx] = Math.round((parseInt($("#CusWin" + giCurWinIdx).css("height"), 10) - 18 - 2) * giCurDomainSizeH / gImgH);
			}
			else
			{
				gaiCusWinW[giCurWinIdx] = Math.round(parseInt($("#CusWin" + giCurWinIdx).css("width"), 10) * giCurDomainSizeW / gImgW);
				gaiCusWinH[giCurWinIdx] = Math.round((parseInt($("#CusWin" + giCurWinIdx).css("height"), 10) - 18 - 2) * giCurDomainSizeH / gImgH);
			}
			//alert(""+gaiCusWinX[giCurWinIdx]+","+gaiCusWinY[giCurWinIdx]+" "+gaiCusWinW[giCurWinIdx]+"x"+gaiCusWinH[giCurWinIdx]);
		
			params = "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+giCurWinIdx+"_size"+gPrmTail+"="+gaiCusWinW[giCurWinIdx]+"x"+gaiCusWinH[giCurWinIdx]

			$.ajax({
				type: "POST",
				cache: false,
				url: "/cgi-bin/admin/setparam.cgi",
				data: params 
			});
		}
	});

	$('.EPW_style').draggable({
		cursor: 'move',
		handle: 'div',
		containment: "#CustomWinBlk",
		drag: function(e, ui)
		{
			//Do nothing.
		},
		stop: function()
		{
/*
			alert(""+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("left")))+
			","+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("top")))+
			" "+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("width")))+
			"x"+Math.round(parseInt($("#CusWin" + giCurWinIdx).css("height"))));
*/
			if (bRotate)
			{
				gaiCusWinY[giCurWinIdx] = Math.round(parseInt($("#CusWin" + giCurWinIdx).css("left"), 10) * giCurDomainSizeW / gImgW);
				gaiCusWinX[giCurWinIdx] = Math.round(parseInt($("#CusWin" + giCurWinIdx).css("top"), 10) * giCurDomainSizeH / gImgH);
			}
			else
			{
				gaiCusWinX[giCurWinIdx] = Math.round(parseInt($("#CusWin" + giCurWinIdx).css("left"), 10) * giCurDomainSizeW / gImgW);
				gaiCusWinY[giCurWinIdx] = Math.round(parseInt($("#CusWin" + giCurWinIdx).css("top"), 10) * giCurDomainSizeH / gImgH);
			}
			//alert(""+gaiCusWinX[giCurWinIdx]+","+gaiCusWinY[giCurWinIdx]+" "+gaiCusWinW[giCurWinIdx]+"x"+gaiCusWinH[giCurWinIdx]);

			params = "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+giCurWinIdx+"_home"+gPrmTail+"="+gaiCusWinX[giCurWinIdx]+","+gaiCusWinY[giCurWinIdx]

			$.ajax({
				type: "POST",
				cache: false,
				url: "/cgi-bin/admin/setparam.cgi",
				data: params 
			});
		}

	});

	$('.ui-dialog-titlebar-close').click(function(){
		if (1 == giCusWinNum)
		{
			//return;
		}

		giCurWinIdx = $(this).parent().parent().attr("id").charAt(6); //Caution: this limits maximum window number to 9;
		$(this).parent().parent().hide();

		gaiCusWinEnable[giCurWinIdx] = 0;

		params = "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+giCurWinIdx+"_enable=0"

		$.ajax({
			type: "POST",
			cache: false,
			url: "/cgi-bin/admin/setparam.cgi",
			data: params 
		});

		if (-1 != findFreeWindow())
		{
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addIncludeButton").disabled = false;
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addExcludeButton").disabled = false;
			getIframeDocumentById("expwinbutton").getElementById("addIncludeButton").disabled = false;
			getIframeDocumentById("expwinbutton").getElementById("addExcludeButton").disabled = false;
		}
	});

	if (-1 == findFreeWindow())
	{
		disableWinButton();
	}
	else
	{
		getIframeDocumentById("expwinbutton").getElementById("addIncludeButton").disabled = false;
		getIframeDocumentById("expwinbutton").getElementById("addExcludeButton").disabled = false;
	}
}

function restore()
{
	var Tmp, Tmp2;

	if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("custom") != -1)
	{
		for (i = 0; i < giCusWinNum; i++)
		{
			Tmp = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_size"+gPrmTail).split("x");
			gaiCusWinW[i] = parseInt(Tmp[0], 10);
			gaiCusWinH[i] = parseInt(Tmp[1], 10);
			Tmp = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_home"+gPrmTail).split(",");
			gaiCusWinX[i] = parseInt(Tmp[0], 10);
			gaiCusWinY[i] = parseInt(Tmp[1], 10);

			gaiCusWinEnable[i] = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_enable");
			gaiCusWinPolicy[i] = eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_policy");
		}

		//Tmp = eval("capability_videoin_c"+giCH_Curr+"_mode");
		//Tmp = eval("capability_videoin_c"+giCH_Curr+"_mode"+Tmp+"_outputsize").split("x");
		//giCurDomainSizeW = parseInt(Tmp[0], 10);
		//giCurDomainSizeH = parseInt(Tmp[1], 10);
	}

	gBLC = false;
	gCustom = false;
	$("#BLCWindow").remove();
	$("#CustomWinBlk").remove();

}

function save()
{
	if (gCustom)
	{
		for (i = 0; i < giCusWinNum; i++)
		{
			eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_size"+gPrmTail+"='"+gaiCusWinW[i]+"x"+gaiCusWinH[i]+"'");
			eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_home"+gPrmTail+"='"+gaiCusWinX[i]+","+gaiCusWinY[i]+"'");
			eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_enable='"+gaiCusWinEnable[i]+"'");
			eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_policy='"+gaiCusWinPolicy[i]+"'");
		}
	}

}

function RestoreSettingAPI()
{
	var XMLHttpRequestObject = null;
	var restoreURL = "/cgi-bin/admin/setparam.cgi?";

	if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_winmode"))
	{
		return;
	}
	else if (eval("capability_image_c"+giCH_Curr+"_exposure_winmode").search("custom") != -1)
	{

		if (window.XMLHttpRequest)
		{
			XMLHttpRequestObject = new XMLHttpRequest();
		}
		else if (window.ActiveXObject)
		{
			XMLHttpRequestObject = new ActiveXObject('Microsoft.XMLHTTP');
		}

		for (i = 0; i < giCusWinNum; i++)
		{
			restoreURL = restoreURL + "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_size"+gPrmTail+"="+eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_size"+gPrmTail)+"&";
			restoreURL = restoreURL + "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_home"+gPrmTail+"="+eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_home"+gPrmTail)+"&";
			restoreURL = restoreURL + "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_enable="+eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_enable")+"&";
			restoreURL = restoreURL + "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_policy="+eval("exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+i+"_policy");
		}

		XMLHttpRequestObject.open("GET", restoreURL);
        	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	        XMLHttpRequestObject.send(null);
	}

}

function findFreeWindow()
{
	for (i = 0; i < giCusWinNum; i++)
	{
		if (0 == gaiCusWinEnable[i])
		{
			return i;
		}
	}

	return -1;
}

function disableWinButton()
{
		getIframeDocumentById("expwinbutton").getElementById("addIncludeButton").disabled = true;
		getIframeDocumentById("expwinbutton").getElementById("addExcludeButton").disabled = true;
}

function crossReceiver(text)
{
	var iTmp;
	var bHLCSupportWin = false;
	
	bHLCSupportWin = !ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_exposure_hlcmode_supportwindow");

	if ("custom" == text || ("hlc" == text && bHLCSupportWin))
	{
		gBLC = false;
		gCustom = true;

		$("#BLCWindow").remove();
		createCustomBlock();

		if (-1 == findFreeWindow())
		{
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addIncludeButton").disabled = true;
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addExcludeButton").disabled = true;
			disableWinButton();
		}
	}
	else if ("blc" == text)
	{
		gBLC = true;
		gCustom = false;

		$("#CustomWinBlk").remove();
		createBLCBlock();
	}
	else if ("auto" == text || ("hlc" == text && !bHLCSupportWin))
	{
		gBLC = false;
		gCustom = false;

		$("#BLCWindow").remove();
		$("#CustomWinBlk").remove();
	}
	else if ("addIncludeWin" == text)
	{
		iTmp = findFreeWindow();

		if (-1 != iTmp)
		{
			gaiCusWinEnable[iTmp] = 1;
			gaiCusWinPolicy[iTmp] = 1;

			if (gbDomainPX)
			{
				gaiCusWinW[iTmp] = parseInt(giCurDomainSizeW / 3, 10);
				gaiCusWinH[iTmp] = parseInt(giCurDomainSizeH / 3, 10);
				gaiCusWinX[iTmp] = parseInt((giCurDomainSizeW - gaiCusWinW[iTmp])/ 2, 10);
				gaiCusWinY[iTmp] = parseInt((giCurDomainSizeH - gaiCusWinH[iTmp])/ 2, 10);
			}
			else if (gbDomainSTD)
			{
				gaiCusWinX[iTmp] = 2499;
				gaiCusWinY[iTmp] = 2499;
				gaiCusWinW[iTmp] = 3333;
				gaiCusWinH[iTmp] = 3333;
			}
			else
			{
				gaiCusWinX[iTmp] = 106;
				gaiCusWinY[iTmp] = 80;
				gaiCusWinW[iTmp] = 80;
				gaiCusWinH[iTmp] = 60;
			}

			params = "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_enable=1&exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_home"+gPrmTail+"="+gaiCusWinX[iTmp]+","+gaiCusWinY[iTmp]+"&exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_size"+gPrmTail+"="+gaiCusWinW[iTmp]+"x"+gaiCusWinH[iTmp]+"&exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_policy=1"

			$.ajax({
				type: "POST",
				cache: false,
				url: "/cgi-bin/admin/setparam.cgi",
				data: params
			});
		}

		createCustomBlock();

		if (-1 == findFreeWindow())
		{
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addIncludeButton").disabled = true;
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addExcludeButton").disabled = true;

			disableWinButton();
		}
	}
	else if ("addExcludeWin" == text)
	{
		iTmp = findFreeWindow();

		if (-1 != iTmp)
		{
			gaiCusWinEnable[iTmp] = 1;
			gaiCusWinPolicy[iTmp] = 0;

			if (gbDomainPX)
			{
				gaiCusWinW[iTmp] = parseInt(giCurDomainSizeW / 3, 10);
				gaiCusWinH[iTmp] = parseInt(giCurDomainSizeH / 3, 10);
				gaiCusWinX[iTmp] = parseInt((giCurDomainSizeW - gaiCusWinW[iTmp])/ 2, 10);
				gaiCusWinY[iTmp] = parseInt((giCurDomainSizeH - gaiCusWinH[iTmp])/ 2, 10);
			}
			else if (gbDomainSTD)
			{
				gaiCusWinX[iTmp] = 2499;
				gaiCusWinY[iTmp] = 2499;
				gaiCusWinW[iTmp] = 3333;
				gaiCusWinH[iTmp] = 3333;
			}
			else
			{
				gaiCusWinX[iTmp] = 106;
				gaiCusWinY[iTmp] = 80;
				gaiCusWinW[iTmp] = 80;
				gaiCusWinH[iTmp] = 60;
			}

			params = "exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_enable=1&exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_home"+gPrmTail+"="+gaiCusWinX[iTmp]+","+gaiCusWinY[iTmp]+"&exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_size"+gPrmTail+"="+gaiCusWinW[iTmp]+"x"+gaiCusWinH[iTmp]+"&exposurewin_c"+giCH_Curr+gStrProfile+"_win_i"+iTmp+"_policy=0"

			$.ajax({
				type: "POST",
				cache: false,
				url: "/cgi-bin/admin/setparam.cgi",
				data: params
			});
		}

		createCustomBlock();

		if (-1 == findFreeWindow())
		{
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addIncludeButton").disabled = true;
			//parent.document.getElementById("exposurepage").contentDocument.getElementById("addExcludeButton").disabled = true;

			disableWinButton();
		}
	}
	else if ("restore" == text)
	{
		restore();
		RestoreSettingAPI();

		$("#BLCWindow").remove();
		$("#CustomWinBlk").remove();
	}
	else if ("save" == text)
	{
		save();
		RestoreSettingAPI();
	}

}

function RestoreSetting()
{
	RestoreSettingAPI();
}
