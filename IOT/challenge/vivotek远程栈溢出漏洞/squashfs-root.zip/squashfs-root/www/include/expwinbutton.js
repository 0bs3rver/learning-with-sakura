var giCH_Curr = 0;
var giTab_Curr = 0;

function loadCurrentSetting()
{	
	loadlanguage();
	//parent.document.getElementById("expwinbutton").height = document.body.scrollHeight;
	//document.getElementById("content").style.visibility = "visible";

	//giCH_Curr = Number(getCookie("channelsource"));
}

function addIncludeWindow()
{
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "addIncludeWin";
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();
}

function addExcludeWindow()
{
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").value = "addExcludeWin";
	getIframeDocumentById("viewpage").getElementById("CrossFrameReceiver").click();
}
