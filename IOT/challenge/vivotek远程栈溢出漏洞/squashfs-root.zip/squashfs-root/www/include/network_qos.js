/*
 *
 * QoS/DSCP, CoS related procedures
 *
 */
function updateCoScheck (inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		$("#qos_cos_conf_table").slideDown("slow");
	}
	else
	{
		$("#qos_cos_conf_table").slideUp("slow");
	}
}

function updateDSCPcheck (inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		$("#qos_dscp_conf_table").slideDown("slow");
	}
	else
	{
		$("#qos_dscp_conf_table").slideUp("slow");
	}
}

function updateQoS () // update QoS menu status onload
{
	if (network_qos_cos_enable == 1)
		$("#qos_cos_conf_table").show();
	else
		$("#qos_cos_conf_table").hide();

	if (network_qos_dscp_enable == 1)
		$("#qos_dscp_conf_table").show();
	else
		$("#qos_dscp_conf_table").hide();
}

/* CoS and QoS/DSCP submit form */
function submitform()
{
	if (checkvalue())
	{
		return -1;
	}

	document.getElementById("network_qos_form").submit();
	showNotification(30);
}


function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&network&system_timezoneindex&capability_naudioin&capability_protocol_qos_cos&capability_protocol_qos_dscp", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("QoS");
	
	loadlanguage();
	$('#notification').bgiframe();
}

function loadvaluedone()
{
	if (capability_naudioin == "0" )
	{
		document.getElementById("qos_dscp_audio").style.display = "none";
		document.getElementById("qos_cos_audio").style.display = "none";
	}
	document.getElementById("content").style.visibility = "visible";
	
	if(capability_protocol_qos_cos == "0")
	{
		$('#qos_fieldset').hide();	
	}

	if(capability_protocol_qos_dscp == "0")
	{
		$('#qos_dscp_fieldset').hide();	
	}	

	// QoS/DSCP
	updateQoS();
}
