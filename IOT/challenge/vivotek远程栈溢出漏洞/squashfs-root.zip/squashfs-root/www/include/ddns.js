license=0;
function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&ddns&expresslink_state&expresslink_url&expresslink_enable", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("ddns");
	loadlanguage();		
	
	loadstate();
}
function loadvaluedone()
{
	form=document.ddns;
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="Safe100")
		license=1;
	
	var aProvider = initProvider();
	for (i = 0; i < aProvider.length; i++)
	{
		if (document.getElementsByName("ddns_" + aProvider[i] + "_usernameemail")[0].value != "")
		{
			document.getElementsByName("ddns_" + aProvider[i] + "_passwordkey")[0].value = getDefaultPassword();
		}
	}

	showddns();
	document.getElementById("content").style.visibility = "visible";
}
function showddns()
{
	form=document.ddns;
	for(i=0; i<form.ddns_provider.length; i++)
		document.getElementById(form.ddns_provider.options[i].value).style.display = "none";
	document.getElementById(form.ddns_provider.options[form.ddns_provider.selectedIndex].value).style.display = "block";
	
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="Safe100"||form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="CustomSafe100")
		document.forms["ddnsregister"].style.display = "block";
	else
		document.forms["ddnsregister"].style.display = "none";
		
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="Safe100"&&license==0)
	{
		document.getElementById("content").style.display = "none";
		document.getElementById("license").style.display = "block";
		document.getElementById("license").focus();
	}
	else
	{
		document.getElementById("content").style.display = "block";
		document.getElementById("license").style.display = "none";
	}
}

function agree()
{
	license=1;
	showddns();
}

function cancel()
{
	license=0;
	location.href="/setup/network/ddns.html"
}

function copyRegister2DDNS()
{
	form=document.ddns;
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="Safe100")
	{
		document.getElementsByName("ddns_Safe100_hostname")[0].value = document.getElementsByName("hostname")[0].value;
		document.getElementsByName("ddns_Safe100_usernameemail")[0].value = document.getElementsByName("email")[0].value;
		document.getElementsByName("ddns_Safe100_passwordkey")[0].value = document.getElementsByName("key")[0].value;
	}
	
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="CustomSafe100")
	{
		document.getElementsByName("ddns_CustomSafe100_hostname")[0].value = document.getElementsByName("hostname")[0].value;
		document.getElementsByName("ddns_CustomSafe100_usernameemail")[0].value = document.getElementsByName("email")[0].value;
		document.getElementsByName("ddns_CustomSafe100_passwordkey")[0].value = document.getElementsByName("key")[0].value;
	}
}

function validRegisterForm()
{
    var sform = document.ddnsregister;
	if (document.getElementsByName("ddns_CustomSafe100_servername")[0].value  == "" && form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="CustomSafe100")
	{
	    alert(translator("please_enter_servername"));
		document.getElementsByName("ddns_CustomSafe100_servername")[0].focus();
		document.getElementsByName("ddns_CustomSafe100_servername")[0].select();
	    return false;
	}
	if (sform.hostname.value  == "")
	{
	    alert(translator("please_enter_hostname"));
		sform.hostname.focus();
		sform.hostname.select();
	    return false;
	}
	
	if(checkemail(sform.email))
		return false;
		
	return true;
}

function ForgetKey()
{
	if (!validRegisterForm())	return 1;	
	dr = document.ddnsregister;
	document.getElementsByName("method")[0].value = "forgetkey";
	
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="CustomSafe100")
	{
		document.getElementsByName("customenable")[0].value=1;
		document.getElementsByName("servername")[0].value=document.getElementsByName("ddns_CustomSafe100_servername")[0].value;
	}
	else
	{
		document.getElementsByName("customenable")[0].value=0;
	}
	dr.submit();
}

function RegisterHost()
{
	if (!validRegisterForm())	return 1;	
	dr = document.getElementsByName("ddnsregister")[0];
	document.getElementsByName("method")[0].value = "register";
	if(form.ddns_provider.options[form.ddns_provider.selectedIndex].value=="CustomSafe100")
	{
		document.getElementsByName("customenable")[0].value=1;
		document.getElementsByName("servername")[0].value=document.getElementsByName("ddns_CustomSafe100_servername")[0].value;
	}
	else
	{
		document.getElementsByName("customenable")[0].value=0;
	}
	
	key = document.getElementsByName("key")[0];
	if (key.value  == "")
	{
	    alert(translator("please_enter_key"));
		key.focus();
		key.select();
	    return 1;
	}
	confirmkey = document.getElementsByName("confirmkey")[0];
	if (key.value != confirmkey.value)
	{
		alert(translator("the_confirm_password_differs_from_the_password"));
        key.focus();
        key.select();
		return;
	}
	else
		dr.submit();
}

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	else
	{
		if(checkPasswordVal() != 0)
		{
			return -1;
		}
		form.submit();	
		setTimeout("location.reload();", 1000);
	}	
}

function checkPasswordVal()
{
	var passwordval;
	var aProvider = initProvider();
	for (i = 0; i < aProvider.length; i++)
	{
		passwordval = document.getElementsByName("ddns_" + aProvider[i] + "_passwordkey")[0].value;

		if(checkDefaultPassword(passwordval) != 0)
		{
			document.getElementsByName("ddns_" + aProvider[i] + "_passwordkey")[0].disabled = true;
		}
	}	
	return 0;
}

function initProvider()
{
	var aProvider = new Array("Safe100", "DyndnsDynamic", "DyndnsCustom", "CustomSafe100");
	return aProvider;
}