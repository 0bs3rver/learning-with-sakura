function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?https", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("create_certificate");
	loadlanguage();
	eval(location.search.toString().slice(1));
	var input=document.getElementsByTagName("input");
	if (mode == 1) {
		document.getElementById("validity").style.display = "none";
		document.getElementsByName("https_status")[0].value = -1;
		document.getElementsByName("https_method")[0].value = "install";
	}
	else {
		document.getElementsByName("https_status")[0].value = -3;
		document.getElementsByName("https_method")[0].value = "manual";
	}
	$('#notification').bgiframe();
}

function proceed()
{
	var board = document.getElementById("progress_bar");
	count --;
	if (count < 0)
	{
		parent.location.reload();
		self.parent.tb_remove();
	}
	else
	{
		board.value = board.value + "|";
		setTimeout("proceed()", intervel);
	}
}

function checkCountrycode(input)
{
    var filter=/[a-zA-Z][a-zA-Z]/;
    if (!filter.test(input.value))
    {
        alert(translator("please_enter_the_correct_country_code"));
        return -1;
    }
    return 0;
}

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	if (checkCountrycode(document.forms[0].https_countryname))
	{
		return -1;
	}
	document.forms[0].submit();
	document.getElementById("notification").style.display = "block";
	wait_time = 20;
	count = 70;
	intervel = wait_time * 1000 / count;
	proceed();
}
