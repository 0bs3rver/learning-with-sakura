var WinLessPluginCtrlObject;
var httpfilePath = "";
var oTable;
var client;
var szFilePath = "";
var szFileType = "";
var widthheight = "";

var direStart0 = "/NCMF/";
var direStart1 = "/mnt/CF/link0/";
var direStart2 = "/mnt/CF/link0/";

var pathKeyWorkArray = new Array(direStart0, direStart1, direStart2);

var searchRet = new Array();

var DataTableCheckbox = 0;
var checkboxIdx = 0;
var triTimeIdx = 1;
var mediaTypeIdx = 2;
var triTypeIdx = 3;
var isLockedIdx = 4;
var backupIdx = 5;
var labelIdx = 6;
var filepathIdx = 7;
var resolutionIdx = 8;
var HiddenSelector = 9;

var VIDEOCLIP_STR = "";
var SNAPSHOT_STR = "";
var TEXT_STR = "";
var TRUE_STR = "";
var FALSE_STR = "";

var TAMPERING_STR = "";
var DI_STR = "";
var VLOSS_STR = "";
var BOOT_STR = "";
var RENOTIFY_STR = "";
var MOTION_STR = "";
var SEQ_STR = "";
var RECOVER_STR = "";
var AUDIO_STR = "";
var VADP_STR = "";

var browserType = "";
var bRotation = "";

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

platform = navigator.platform.substr(0, 3);
if ((navigator.appName == "Microsoft Internet Explorer") && (platform == "Win"))
{
	browserType = "IE";
}
else if (navigator.appName == "Netscape") 
{
    browserType = "NetScape";	
}

function searchSD(queryStr) 
{
	if (window.XMLHttpRequest)
	{
		client = new XMLHttpRequest();
	}
	else
	{
		client = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	if (client.overrideMimeType)
		client.overrideMimeType('text/xml');
		
	client.onreadystatechange = loadSearchResults;
	client.open("GET", queryStr, true);
	client.setRequestHeader("If-Modified-Since","0");
	client.send(null);

	document.diskSearch.searchButton.disabled = true;
	oTable.fnClearTable();
}

function updateDataTblCheck()
{
	if (checkbox.checked)
		inputName.value = "1";
	else
		inputName.value = "0";
}

function loadSearchResults()
{
	document.body.style.cursor = 'wait';
	if(client.readyState == 4 && client.status == 200) 
	{
		if (client.responseXML != null)
		{
			var xmldata = client.responseXML;
			
			var ss = xmldata.getElementsByTagName("statusCode")[0].childNodes[0].nodeValue;
			
			if (ss == "200")
			{
				var counts = xmldata.getElementsByTagName("counts")[0].childNodes[0].nodeValue;
				
				var triggerTime = xmldata.getElementsByTagName("triggerTime");
				var mediaType = xmldata.getElementsByTagName("mediaType");
				var triggerType = xmldata.getElementsByTagName("triggerType");
				var label = xmldata.getElementsByTagName("label");
				var destPath = xmldata.getElementsByTagName("destPath");
				var resolution = xmldata.getElementsByTagName("resolution");
				var isLocked = xmldata.getElementsByTagName("isLocked");
				var backup = xmldata.getElementsByTagName("backup");
				
				for (var i = 0; i < counts; i++)
				{
					if ("0" == backup[i].childNodes[0].nodeValue)
					{
						backup[i].childNodes[0].nodeValue = FALSE_STR;
					}
					else
					{
						backup[i].childNodes[0].nodeValue = TRUE_STR;
					}
					
					if ("0" == isLocked[i].childNodes[0].nodeValue)
					{
						isLocked[i].childNodes[0].nodeValue = FALSE_STR;
					}
					else
					{
						isLocked[i].childNodes[0].nodeValue = TRUE_STR;
					}
					
					var mt = "";
					
					if (mediaType[i].childNodes[0].nodeValue == "videoclip")
					{
						mt = VIDEOCLIP_STR;
					}
					else if (mediaType[i].childNodes[0].nodeValue == "snapshot")
					{
						mt = SNAPSHOT_STR;
					}
					else if (mediaType[i].childNodes[0].nodeValue == "text")
					{
						mt = TEXT_STR;
					}
					
					var tt = "";
					
					if (triggerType[i].childNodes[0].nodeValue == "tampering")
					{
						tt = TAMPERING_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "di")
					{
						tt = DI_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "videoloss")
					{
						tt = VLOSS_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "boot")
					{
						tt = BOOT_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "recnotify")
					{
						tt = RENOTIFY_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "motion")
					{
						tt = MOTION_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "seq")
					{
						tt = SEQ_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "linkstatus")
					{
						tt = NWTWORKFAIL_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "recover")
					{
						tt = RECOVER_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "temperature")
					{
						tt = TEMPERATURE_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "vi")
					{
						tt = VI_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "volalarm")
					{
						tt = AUDIO_STR;
                                        }
					else if (triggerType[i].childNodes[0].nodeValue == "vadp")
					{
						tt = VADP_STR;
					}
					else if (triggerType[i].childNodes[0].nodeValue == "recover")
					{
						tt = RECOVER_STR;
					}
					
					searchRet[i] = new Array( "<input type='checkbox' name='dataTblbox' />",
												triggerTime[i].childNodes[0].nodeValue, 
												mt,
												tt,
												//translator(mediaType[i].childNodes[0].nodeValue), 
												//translator(triggerType[i].childNodes[0].nodeValue), 
												isLocked[i].childNodes[0].nodeValue,
												backup[i].childNodes[0].nodeValue,
												label[i].childNodes[0].nodeValue, 
												destPath[i].childNodes[0].nodeValue,
												resolution[i].childNodes[0].nodeValue,
												0
											);
				}
		
				var searchRetLen = searchRet.length;
				
				searchRet.splice(counts, searchRetLen);
				
				oTable.fnClearTable();
				oTable.fnAddArray(searchRet);
			}
			else
			{
				oTable.fnClearTable();
			}
		}
		document.diskSearch.searchButton.disabled = false;
	}
	document.body.style.cursor = 'default';
}

function clearDBSearch()
{
	var searchForm = document.diskSearch;

	var boxes = document.getElementsByName("box");
	
	for (var i = 0; i < boxes.length; i++)
	{
		boxes[i].checked=0;
	}
	
	searchForm.trigger_type_tampering.value = "";
	searchForm.trigger_type_di.value = "";
	searchForm.trigger_type_boot.value = "";
	searchForm.trigger_type_recording_notify.value = "";
	searchForm.trigger_type_motion.value = "";
	searchForm.trigger_type_seq.value = "";
	searchForm.trigger_type_networkfail.value = "";
	searchForm.trigger_type_vi.value = "";
	searchForm.trigger_type_volalarm.value = "";
	searchForm.trigger_type_vadp.value = "";
	searchForm.trigger_type_recovered.value = "";
	
	searchForm.media_type_videoclip.value = "";
	searchForm.media_type_snapshot.value = "";
	searchForm.media_type_text.value = "";
	
	searchForm.lock_type_locked.value = "";
	searchForm.lock_type_unlocked.value = "";
	
	searchForm.backup_media.value = "";
	
	searchForm.schedule_from_date.value = "";
	searchForm.schedule_from_time.value = "";
	searchForm.schedule_to_date.value = "";
	searchForm.schedule_to_time.value = "";
}

function GetHttpFilePath(szPath)
{
	var i = location.hostname.indexOf(":");
	var j = -1;
	var httpfilePath = "";
	var s = "";
	var port = "";
	
	for (var k = 0; k < pathKeyWorkArray.length; k++)
	{
		j = szPath.indexOf(pathKeyWorkArray[k]);
		
		if (j != -1)
		{
			s = szPath.substring(j+pathKeyWorkArray[k].length, szPath.length);
			break;
		}
	}
	
	if (-1 == j)
		return;
	
	if (location.port == "")
		port = "80";
	else
		port = location.port;
		
	if (i > 0)
		httpfilePath = "http://" + "[" + location.hostname + "]:" + port + "/NCMF/" + s;
	else if (i == -1)
		httpfilePath = "http://" + location.hostname + ":" + port + "/NCMF/" + s;
	
	return httpfilePath;
}

var g_httpfilePath = "";
function setFilePathToPlugin()
{
	if (g_httpfilePath == "")
		retrun;
		
	//console.log(g_httpfilePath);
	WinLessPluginCtrlObject = document.getElementById(PLUGIN_ID);
	WinLessPluginCtrlObject.SetPlaybackFilePath(g_httpfilePath);
	WinLessPluginCtrlObject.ControlPlayback(2);
	$('#showimage_block').parent().find("button").each(function() {
		$(this).attr('disabled', false);
	});
}

function drawDialog(iwidth, iheight, szPath, mediaType)
{

	if ("" == mediaType)
	{
		return;
	}
	
	g_httpfilePath = GetHttpFilePath(szPath);
	
	if (VIDEOCLIP_STR == mediaType)
	{
		if (document.getElementById(PLUGIN_ID) != null)
		{
			document.getElementById(PLUGIN_ID).ControlPlayback(1);
			$("#"+PLUGIN_ID).attr("width", iwidth).width(parseInt(iwidth));
			$("#"+PLUGIN_ID).attr("height", iheight).height(parseInt(iheight));
		}
		else
		{
			showimage2('2','showimage_block', iwidth, iheight, g_httpfilePath);
		}

		if (bIsWinMSIE || ffversion >= 3 || bIsChrome)
		{
			$('#showimage_block').parent().find("button").each(function() {
				$(this).attr('disabled', true);
			});
			//setTimeout('addPluginEvent(document.getElementById("WinLessPluginCtrl"), "VNDPWrapperReady", setFilePathToPlugin);', 1);
			setFilePathToPlugin(g_httpfilePath);
		}
	}
	else if (SNAPSHOT_STR == mediaType)
	{
		document.getElementById('showimage_block').innerHTML = "<img src='" + g_httpfilePath + "' width='" + iwidth + "height='" + iheight + "'/>";
	}
	else if (TEXT_STR == mediaType)
	{
		document.getElementById('showimage_block').innerHTML = "<html><body><iframe width='" + iwidth + "' height='" + iheight + "' src='" + g_httpfilePath + "'></iframe></body></html>";
	}
	else
	{
		alert(translator("unrecognized_media_type"));
	}
}

function clear_aData()
{
	var aaData = oTable.fnSettings().aaDataMaster;
	
	for ( var i=0 ; i<aaData.length ; i++ )
	{
		aaData[i][HiddenSelector] = 0;
	}
}

function loadCurrentSetting()
{	
	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};
	
	//updata 
	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;
			
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];
		
		if(!type || compare(type.description, plugin.description)) {
			xpi = plugin.xpi;
		}
	
		if(xpi) {
			if( window.InstallTrigger == undefined) // It means this page is include in other page
				parent.window.InstallTrigger.install(xpi); 
			else
			window.InstallTrigger.install(xpi);
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');
		}																					   //
	}
	
	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}

	$('#InstallerArea').hide();
	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info_language&system_info_customlanguage&network_http_port", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("local_storage");
	
	loadlanguage();
	
	//'showimage_block' means a div id
    $("#showimage_block").dialog({
    		autoOpen: false,
    		closeOnEscape: true,
			width: 400, 
			Height: 370,
			position:['right',''],
			overlay:{opacity:0.5,background:"white"}, 
			draggable: true,
			resizable: false,
			buttons: {
				"Small":function(){ 
								   if(bRotation == "1")
								   {
									   $(this).data("width.dialog", 290); 
									   $(this).data("height.dialog", 440); 
									   drawDialog(240, 320, szFilePath, szFileType);
								   }
								   else
								   {
									   $(this).data("width.dialog", 400); 
									   $(this).data("height.dialog", 370); 
									   drawDialog(320, 240, szFilePath, szFileType);
								   }
								},
				"Medium":function(){ 
								   if(bRotation == "1")
								   {
									   $(this).data("width.dialog", 530); 
									   $(this).data("height.dialog", 760); 
									   drawDialog(480, 640, szFilePath, szFileType);
								   }
								   else
								   {
									   $(this).data("width.dialog", 720); 
									   $(this).data("height.dialog", 610); 
									   drawDialog(640, 480, szFilePath, szFileType);
								   }
								},
				"Primary":function(){
								   if(bRotation == "1")
								   {
									   if (Number(widthheight[0]) < 260)
									   {
										   $(this).data("width.dialog", 340);
									   }
									   else
									   {
										   $(this).data("width.dialog", Number(widthheight[0])+50); 
									   }
									   $(this).data("height.dialog", Number(widthheight[1])+120); 
									   drawDialog(Number(widthheight[0]), Number(widthheight[1]), szFilePath, szFileType);
								   }
								   else
								   {
									   if (Number(widthheight[0]) < 260)
									   {
										   $(this).data("width.dialog", 340);
									   }
									   else
									   {
										   $(this).data("width.dialog", Number(widthheight[0])+80); 
									   }
									   $(this).data("height.dialog", Number(widthheight[1])+130); 
									   drawDialog(Number(widthheight[0]), Number(widthheight[1]), szFilePath, szFileType);
								   }
								},
				"Close":function(){ 
									if (VIDEOCLIP_STR == szFileType) 
									{
										if (bIsWinMSIE || ffversion >= 3 || bIsChrome)
										{
											document.getElementById(PLUGIN_ID).ControlPlayback(1);
										}
									}
									$("#showimage_block").dialog("close");
								}
				//"Pause":function(){ if (VIDEOCLIP_STR == szFileType) RtspVapgCtrl.ControlPlayback(3); },
				//"Play":function(){ if (VIDEOCLIP_STR == szFileType) RtspVapgCtrl.ControlPlayback(2); }
			},
			beforeClose: function(e, ui){
				if (VIDEOCLIP_STR == szFileType) 
				{
					if (bIsWinMSIE || ffversion >= 3 || bIsChrome)
					{
						document.getElementById(PLUGIN_ID).ControlPlayback(1);
					}
				}
				$('#showimage_block').html("");
			},
			close: function(e, ui) { 
				if (VIDEOCLIP_STR == szFileType) 
				{
					if (bIsWinMSIE || ffversion >= 3 || bIsChrome)
					{
						document.getElementById(PLUGIN_ID).ControlPlayback(1);
					}
				}

				//firefox will crash if not clean
				if (ffversion >= 3)
					$('#showimage_block')[0].innerHTML="";
			}
	});
    
    clearDBSearch();
    
    var nCloneTd = document.createElement( 'td' );
	nCloneTd.appendChild( document.createTextNode( '0' ) );
	
	var nCloneTh = document.createElement( 'th' );
	nCloneTh.appendChild( document.createTextNode( '0' ) );
	
	$('#results tbody tr').each( function () {
		this.appendChild( nCloneTd.cloneNode( true ) );
	} );
	
	$('#results thead tr').each( function () {
		this.appendChild( nCloneTh.cloneNode( true ) );
	} );

    oTable = $('#results').dataTable({
    	"aoColumns": [ 
			{
				"bSortable": false
			},
			null,
			null,
			null,
			null,
			null,
			{
				"bVisible": false,
				"bSearchable": false,
				"bSortable": false
			},
			{
				"bVisible": false,
				"bSearchable": false,
				"bSortable": false
			},
			{
				"bVisible": false,
				"bSearchable": false,
				"bSortable": false
			},
			{
				"bVisible": false,
				"bSearchable": false,
				"bSortable": false
			}
		],
		"fnRowCallback": function( nRow, aData, iDisplayIndex ) {
			/* Deal with a click on each row */
			$(nRow).click( function() {
				
				$("#results tr").attr("class","even");
				
				clear_aData();
				aData[HiddenSelector] = 1;
				
				var tblCheck = document.getElementsByName("dataTblbox")[iDisplayIndex];
					
				if (tblCheck.checked)
				{
					aData[DataTableCheckbox] = "<input type='checkbox' name='dataTblbox' checked/>";
				}
				else
				{
					aData[DataTableCheckbox] = "<input type='checkbox' name='dataTblbox' />";
				}

				this.className = this.className+'_selected';
				
			} );
			
			nRow.className = (aData[HiddenSelector] == 1) ? nRow.className+'_selected' : nRow.className.replace( /_selected/, "" );
			
			return nRow;
		},
		"fnDrawCallback": function() {
			if ($("#checkAll").attr("checked")==true)
				uncheckall();
			
		}
	});
	
	oTable.fnClearTable();
	$("#results th:eq(0)").html('<input type="checkbox" onclick="switchCheck()" id="checkAll">');
}

function fnGetSelected_o( oTableLocal )
{
	var aSelected = new Array();
	var aaData = oTableLocal.fnSettings().aaDataMaster;
	
	for ( var i=0 ; i<aaData.length ; i++ )
	{
		if ( aaData[i][HiddenSelector] == 1 )
		{
			// should be only one
			aSelected.push( i );
			return aSelected;
		}
	}
	
	return aSelected;
}

function fnGetSelected_p (oTableLocal)
{
	var aSelected = new Array();
	var aaData = oTableLocal.fnSettings().aaDataMaster;
	
	for ( var i=0 ; i<aaData.length ; i++ )
	{
		if ( aaData[i][checkboxIdx] == "<input type='checkbox' name='dataTblbox' checked/>" )
		{
			// could be many
			aSelected.push( i );
		}
	}
	return aSelected;
}

function receivedone()
{
    if( lan >= 100 ) //custom language
       return -1;
}

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
	var hideArray = new Array();
	
	hideArray.push("daynightChild");
	hideArray.push("SDCtrlChild");
	
	jQuery.each(hideArray, function(i) { 
		$("#" + hideArray[i]).css("display","none");
	});
	
	VIDEOCLIP_STR = translator("videoclip");
	SNAPSHOT_STR = translator("snapshot");
	TEXT_STR = translator("text");
	TRUE_STR = translator("yes");
	FALSE_STR = translator("no");
	
	TAMPERING_STR = translator("tampering");
	DI_STR = translator("di");
	VLOSS_STR = translator("videoloss");
	BOOT_STR = translator("boot");
	RENOTIFY_STR = translator("recording_notify");
	MOTION_STR = translator("motion");
	SEQ_STR = translator("seq");
	NWTWORKFAIL_STR = translator("network_fail");
	RECOVER_STR = "Recovered";
	TEMPERATURE_STR = translator("temperature_alarm");
	VI_STR = translator("manual_trigger");
	AUDIO_STR = translator("audio_detection");
	VADP_STR = translator("VADP");
	RECOVER_STR = translator("recover");
}

function updateSDStatus(param)
{
	if ("status" == param)
	{
		document.write("<span title=\"symbol\">"+ disk_i0_cond +"</span>");
	}
}

function formatsd()
{
        var form = document.FormatSD;
        window.open("", "formatsd", "height=100,width=400");
        form.submit();
}

function submitform()
{
	var form = document.localstorage;
    
	if(checkNumRange(form.disk_i0_autocleanup_maxage, 999, 1))
	{
		return -1;
	}
	else
	{
		form.submit();
	}
}

function checkSQLYYYYMMDD(input)
{
	var filter=/\d\d\d\d\-\d\d\-\d\d/;
	
	if (!filter.test(input.value))
	{
		alert(translator("please_enter_a_valid_date_sql"));
		input.focus();
		input.select();
		return -1;
	}
	
	input.value = input.value.match(filter)[0];
	sub_item = input.value.split("-");
	
	if (((parseInt(sub_item[0], 10) > 2035) || (parseInt(sub_item[0], 10) < 1970)) ||
			((parseInt(sub_item[1], 10) > 12) || (parseInt(sub_item[1], 10) < 01)) ||
			((parseInt(sub_item[2], 10) > 31) || (parseInt(sub_item[2], 10) < 01)))
	{
		alert(translator("please_enter_a_valid_date_sql"));
		input.focus();
		input.select();
		return -1;
	}
	
	return 0;
}

function searchDB()
{
	var searchForm = document.diskSearch;
	
	var triggerTypes = [
		[searchForm.trigger_type_tampering.value, "tampering"],
		[searchForm.trigger_type_di.value, "di"],
		[searchForm.trigger_type_boot.value, "boot"],
		[searchForm.trigger_type_recording_notify.value, "recnotify"],
		[searchForm.trigger_type_motion.value, "motion"],
		[searchForm.trigger_type_seq.value, "seq"],
		[searchForm.trigger_type_networkfail.value, "linkstatus"],
		[searchForm.trigger_type_vi.value, "vi"],
		[searchForm.trigger_type_volalarm.value, "volalarm"],
		[searchForm.trigger_typr_vadp.value, "vadp"],
		[searchForm.trigger_type_recovered.value, "recover"]
	];

	var mediaTypes = [
		[searchForm.media_type_videoclip.value, "videoclip"],
		[searchForm.media_type_snapshot.value, "snapshot"],
		[searchForm.media_type_text.value, "text"]
	];
	
	var lockedTypes = [
		[searchForm.lock_type_locked.value, "1"],
		[searchForm.lock_type_unlocked.value, "0"]
	];
	
	var backupTypes = [
		[searchForm.backup_media.value, "1"],
		0
	];
	
	var i;
	var hasItem = 0;
	var queryStr = "/cgi-bin/admin/lsctrl.cgi?cmd=search";
	
	for (i = 0; i < triggerTypes.length; i++)
	{
		if (triggerTypes[i][0] == 1)
		{
			if (0 == hasItem)
			{
				queryStr += "&triggerType='" + triggerTypes[i][1] + "'";
				hasItem = 1;
			}
			else
			{
				queryStr += "+OR+'" + triggerTypes[i][1] + "'";
			}
		}
	}

	hasItem = 0;
	
	for (i = 0; i < mediaTypes.length; i++)
	{
		if (mediaTypes[i][0] == 1)
		{
			if (0 == hasItem)
			{
				queryStr += "&mediaType='" + mediaTypes[i][1] + "'";
				hasItem = 1;
			}
			else
			{
				queryStr += "+OR+'" + mediaTypes[i][1] + "'";
			}
		}
	}
	
	hasItem = 0;
	
	for (i = 0; i < lockedTypes.length; i++)
	{
		if (lockedTypes[i][0] == 1)
		{
			if (0 == hasItem)
			{
				queryStr += "&isLocked='" + lockedTypes[i][1] + "'";
				hasItem = 1;
			}
			else
			{
				queryStr += "+OR+'" + lockedTypes[i][1] + "'";
			}
		}
	}
	
	hasItem = 0;
	
	// Backup media 	
	for (i = 0; i < backupTypes.length; i++)
	{
		if (backupTypes[i][0] == 1)
		{
			if (0 == hasItem)
			{
				queryStr += "&backup='" + backupTypes[i][1] + "'";
				hasItem = 1;
			}
			else
			{
				queryStr += "+OR+'" + backupTypes[i][1] + "'";
			}
		}
	}
	
	hasItem = 0;
	
	if ( (searchForm.schedule_from_date.value != "") && (checkSQLYYYYMMDD(searchForm.schedule_from_date)) )
	{
			return;
	}
	if ( (searchForm.schedule_from_time.value != "") && (checkHHMMSS(searchForm.schedule_from_time)) )
	{
			return;
	}
	if ( (searchForm.schedule_to_time.value != "") && (checkHHMMSS(searchForm.schedule_to_time)) )
	{
			return;
	}
	if ( (searchForm.schedule_to_date.value != "") && (checkSQLYYYYMMDD(searchForm.schedule_to_date)) )
	{
			return;
	}
	
	if (searchForm.schedule_from_date.value == "")
	{
		searchForm.schedule_from_date.value = "1970-01-01";
	}
	if (searchForm.schedule_from_time.value == "")
	{
		searchForm.schedule_from_time.value = "00:00:00";
	}
	if (searchForm.schedule_to_date.value == "")
	{
		searchForm.schedule_to_date.value = "2035-12-31";
	}
	if (searchForm.schedule_to_time.value == "")
	{
		searchForm.schedule_to_time.value = "23:59:59";
	}
	
	if (searchForm.schedule_to_date.value < searchForm.schedule_from_date.value)
	{
		alert(translator("invalid_end_date"));
		return;
	}
	else if (searchForm.schedule_to_date.value == searchForm.schedule_from_date.value)
	{
		if (searchForm.schedule_to_time.value < searchForm.schedule_from_time.value)
		{
			alert(translator("invalid_end_time"));
			return;
		}
	}
	

	queryStr += "&triggerTime='" + searchForm.schedule_from_date.value + " " + searchForm.schedule_from_time.value + "'" + "+TO+" + "'" + searchForm.schedule_to_date.value + " " + searchForm.schedule_to_time.value + "'";

	searchSD(queryStr);
}

function view()
{
	var SelIndex = fnGetSelected_o(oTable);
	var vLen = SelIndex.length;
	
	if (0 == vLen)
	{
		alert(translator("pls_select_an_entry"));
		return;
	}
	else if (vLen > 1)
	{
		alert(translator("pls_select_an_entry_at_a_time"));
		return;
	}
	else
	{
		var aaData = oTable.fnSettings().aaDataMaster;
		
		var mediaType = aaData[SelIndex[0]][mediaTypeIdx];
		var resolution = aaData[SelIndex[0]][resolutionIdx];
		
		widthheight = resolution.split("x");
		
		if ($("#showimage_block").dialog("isOpen") == false)
		{
			$("#showimage_block").dialog("open");
		}
		
		if((widthheight[0]/widthheight[1]) < "1")
		{
			bRotation = 1;
		}
		else
		{
			bRotation = 0 ;
		}

		if(bRotation == "1")
		{
			$("#showimage_block").data("width.dialog", 290); 
			$("#showimage_block").data("height.dialog", 440);
		}
		else
		{
			$("#showimage_block").data("width.dialog", 400); 
			$("#showimage_block").data("height.dialog", 370);
		}
		/*Workaround: set the start point of preview window at (10, 10)
		  Bugzilla:#23776
		  jQuery libray bug */
		$("#.ui-draggable").offset({ top: 10, left: 10 });
		
		szFilePath = escape(aaData[SelIndex[0]][filepathIdx]);
		szFileType = mediaType;

		if(bRotation == "1")
		{
			drawDialog(240, 320, szFilePath, szFileType);
		}
		else
		{
			drawDialog(320, 240, szFilePath, szFileType);
		}
		
		return;
	}
}

function download()
{
	var SelIndex = fnGetSelected_o(oTable);
	var dLen = SelIndex.length;
	
	if (0 == dLen)
	{
		alert(translator("pls_select_an_entry"));
		return;
	}
	else if (dLen > 1)
	{
		alert(translator("pls_select_an_entry_at_a_time"));
		return;
	}
	else
	{
		var aaData = oTable.fnSettings().aaDataMaster;
		
		var locStr = "/cgi-bin/admin/downloadMedias.cgi?" + encodeURIComponent(aaData[SelIndex[0]][filepathIdx]);

		location.href=locStr;
		return;
	}
}

// label=2&label=4&label=13&cmd=delete
function remove()
{
	var SelIndex = fnGetSelected_p(oTable);
	var aaData = oTable.fnSettings().aaDataMaster.slice();
	var rLen = SelIndex.length;

	if (0 == rLen)
	{
		alert(translator("pls_select_an_entry"));
		return;
	}

	var delList = "";
	var i;

	for (i = 0; i < rLen; i++)
	{
		if (TRUE_STR == aaData[SelIndex[i]][isLockedIdx])
		{
			alert(translator("one_or_more_files_are_locked"));
			return ;
		}
		else
		{
			delList += "&label=" + aaData[SelIndex[i]][labelIdx];
		}
	}

	for (i = rLen - 1; i >= 0; i--)
	{
		aaData.splice(SelIndex[i], 1);
	}
	var iDisplayStart = oTable.fnSettings().iDisplayStart;
	oTable.fnClearTable();
	oTable.fnAddArray(aaData);

	var iDisplayLength = oTable.fnSettings().iDisplayLength;
	if ( aaData.length - 1 < iDisplayStart)
	{
		oTable.fnSettings().iDisplayStart =aaData.length - ((aaData.length-1) % iDisplayLength + 1);
	}
	else
	{
		oTable.fnSettings().iDisplayStart = iDisplayStart;
	}
	oTable.fnDraw();

	var queryStr = "/cgi-bin/admin/lsctrl.cgi?cmd=delete" + delList;

	var remove_req;

	if (window.XMLHttpRequest)
	{
		remove_req = new XMLHttpRequest();
	}
	else
	{
		remove_req = new ActiveXObject("Microsoft.XMLHTTP");
	}

	if (remove_req.overrideMimeType)
		remove_req.overrideMimeType('text/xml');

	remove_req.onreadystatechange = emptyfun;
	remove_req.open("GET", queryStr, true);
	remove_req.setRequestHeader("If-Modified-Since","0");
	remove_req.send(null);
	
	$("#checkAll").attr("checked", false)
}

function emptyfun(){}

function updateLock(inputStr, isLocked)
{
	var queryStr = "/cgi-bin/admin/lsctrl.cgi?cmd=update&isLocked=" + isLocked + inputStr;
	
	var lock_unlock_req;
	
	if (window.XMLHttpRequest)
	{
		lock_unlock_req = new XMLHttpRequest();
	}
	else
	{
		lock_unlock_req = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	if (lock_unlock_req.overrideMimeType)
		lock_unlock_req.overrideMimeType('text/xml');

	lock_unlock_req.onreadystatechange = emptyfun;
	lock_unlock_req.open("GET", queryStr, true);
	lock_unlock_req.setRequestHeader("If-Modified-Since","0");
	lock_unlock_req.send(null);
}

function lock_unlock()
{
	var SelIndex = fnGetSelected_p(oTable);
	var aaData = oTable.fnSettings().aaDataMaster;
	var lLen = SelIndex.length;
	
	if (0 == lLen)
	{
		alert(translator("pls_select_an_entry"));
		return;
	}
	
	var lockedList = "";
	var unlockedList = "";
	
	for (var i = 0; i < lLen; i++)
	{
		// switch locked/unlocked
		if (TRUE_STR == aaData[SelIndex[i]][isLockedIdx])
		{
			aaData[SelIndex[i]][isLockedIdx] = FALSE_STR;
			unlockedList += "&label=" + aaData[SelIndex[i]][labelIdx];
		}
		else
		{
			aaData[SelIndex[i]][isLockedIdx] = TRUE_STR;
			lockedList += "&label=" + aaData[SelIndex[i]][labelIdx];
		}
	}
	
	if (lockedList.length > 0)
	{
		updateLock(lockedList, 1);
	}
	
	if (unlockedList.length > 0)
	{
		updateLock(unlockedList, 0);
	}
	
	oTable.fnDraw();
}

function jpeg_to_avi()
{
	var SelIndex = fnGetSelected_p(oTable);
	var aaData = oTable.fnSettings().aaDataMaster;
	var jLen = SelIndex.length;
	
	if (0 == jLen)
	{
		alert(translator("pls_select_an_entry"));
		return;
	}
	
	var fileList = "";
	
	for (var i = 0; i < jLen; i++)
	{
		if (SNAPSHOT_STR != aaData[SelIndex[i]][mediaTypeIdx])
		{
			alert(translator("pls_select_jpeg_fmt"));
			return;
		}
		else
		{
			fileList += "'" + aaData[SelIndex[i]][filepathIdx] + "',";
		}
	}
	fileList = encodeURIComponent(fileList);
	// resolution is determined by the first picture
	var resolution = aaData[SelIndex[0]][resolutionIdx];
	var dataStr = "resolution=" + resolution + "&fps=1" + "&list=" + fileList;
	$.ajax({
		type: "POST",
		cache: false,
		url: "/cgi-bin/admin/jpegtoavi.cgi",
		data:dataStr,
		success : function (response) {
			var $ifrm = $("<iframe style='display:none' />");
			$ifrm.attr("src",response);
			$ifrm.appendTo("body");
		}
	})
	
	return;
	
}

function uncheckall()
{
	var tblCheck = document.getElementsByName("dataTblbox");
					
	for (var i = 0; i < tblCheck.length; i++)
	{
		if (tblCheck[i].checked)
		{
			tblCheck[i].checked = 0;
		}
	}
	
	var aaData = oTable.fnSettings().aaDataMaster;
	
	for ( var i=0 ; i<aaData.length ; i++ )
	{
		aaData[i][DataTableCheckbox] = "<input type='checkbox' name='dataTblbox' />";
	}
	
	$("#checkAll").attr("checked", false)
}

function checkall()
{
	var tblCheck = document.getElementsByName("dataTblbox");
	var startCheck = oTable.fnSettings().iDisplayStart;	
					
	for (var i = 0; i < tblCheck.length; i++)
	{
		if (tblCheck[i].checked == false)
		{
			tblCheck[i].checked = 1;
		}
	}
	
	var aaData = oTable.fnSettings().aaDataMaster;
	var endCheck = startCheck + tblCheck.length;
	
	for ( var i=startCheck ; i< endCheck ; i++ )
	{
		aaData[i][DataTableCheckbox] = "<input type='checkbox' name='dataTblbox' checked/>";
	}
	
	$("#checkAll").attr("checked", true)
}

function switchCheck()
{
	if ($("#checkAll").attr("checked")==true)
		checkall()
	else
		uncheckall()
}

