function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&network&upnppresentation&upnpportforwarding&system_timezoneindex&https&capability_nmediastream&capability_protocol_sip&capability_protocol_pppoe&capability_protocol_ieee8021x&capability_protocol_qos_cos", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("general_settings");

	if (g_mode == "0")
	{
		$(".adv").css("display","none");
		$(".tabs").hide();
		$(".tab-content").css({"border":"none", "padding": "0px"});
		$("#tabs-1 form").wrap("<fieldset>")
		$("#tabs-1 fieldset").prepend("<legend><strong><span>" + translator("network_type") + "</span></strong></legend>")
	}
	loadlanguage();
	$('#notification').bgiframe();

}

var bLan = "false",bPPPOE = "false",bDhcp = "false", bStatic = "false";
var orig_https;
var orig_ftp;

function receivedone()
{
	JudgeTwoWayAudioPortExist();
}

function loadvaluedone()
{
	var hideArray = new Array();
	
	if (network_type == "lan")
	{
		bLan = "true";
		hideArray.push("pppoeChild");
		if (network_resetip == "1")
		{
			bDhcp = "true"
			hideArray.push("fixipChild");
		}
		else
			bStatic = "true"
	}
	else
	{
		bPPPOE = "true"
		hideArray.push("lanChild")
	}

   jQuery.each(hideArray, function(i) { 
     $("#" + hideArray[i]).css("display","none");
   });	
	
	if(upnpportforwarding_upnpnatstatus==1&&upnpportforwarding_enable==1)
		$("#router_error")[0].innerHTML=translator("error_upnp_port_forwarding_fail_please_open_required_ports_manually");
	else if(upnpportforwarding_upnpnatstatus==2&&upnpportforwarding_enable==1)
		$("#router_error")[0].innerHTML=translator("error_router_does_not_support_upnp_port_forwarding");
	else
		$("#router_error").hide();
	updateDisabled();

	if(netForm.network_pppoe_user.value != "")
	{
		document.getElementsByName("network_pppoe_pass")[0].value = getDefaultPassword();
		document.getElementsByName("network_pppoe_confirmpass")[0].value = getDefaultPassword();
	}
	document.getElementById("content").style.visibility = "visible";

	if (network_ipv6_enable == 1)		
		$("#IPv6_setting").show();
	else
		$("#IPv6_setting").hide();
	
	if (network_ipv6_allowoptional == 1)	
		$("#IPv6_setting_manual").show().css("height", "auto").slideDown('slow');			
	else
		$("#IPv6_setting_manual").hide().slideUp('slow');


	if (capability_protocol_pppoe == 0)
	{
		$("#pppoeParent").hide();
		$("#pppoeChild").hide();
	}	

	orig_https = network_https_port;
	orig_ftp = network_ftp_port;
}

function autoSubmask()
	{
	var ip_str_array = $("input:[name=network_ipaddress]").val().split(".");
	
	if (ip_str_array[0] >= 1 && ip_str_array[0] <= 126)
		$('input:[name=network_subnet]').val('255.0.0.0');
	else if (ip_str_array[0] >= 128 && ip_str_array[0] <= 191)
		$('input:[name=network_subnet]').val('255.255.0.0');
	else if (ip_str_array[0] >= 192 && ip_str_array[0] <= 233)
		$('input:[name=network_subnet]').val('255.255.255.0');
	}		

function checkSubmask()
	{
	mask_str_array = $('input:[name=network_subnet]').val().split(".")
	
	if (mask_str_array[0] != 255)
		autoSubmask();
	
	if (mask_str_array[1] != 255 && mask_str_array[1] != 0)
		autoSubmask();
		
	if (mask_str_array[1] != 255 && mask_str_array[2] != 0)
		autoSubmask();
		
	if (mask_str_array[1] != 255 && mask_str_array[3] != 0)
		autoSubmask();

}

function checkPasswordVal()
{
	var passwordval;
	passwordval = document.getElementsByName("network_pppoe_pass")[0].value;

	if(checkDefaultPassword(passwordval) != 0)
	{
		document.getElementsByName("network_pppoe_pass")[0].disabled = true;
	}

	return 0;
}

function updateIPv6ManualCheck(inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		document.getElementById("IPv6_setting_manual").style.height = "auto";
		$('#IPv6_setting_manual').slideDown('slow');
	}			
	else
	{
		$('#IPv6_setting_manual').slideUp('slow',function(){
//			$(this).css("height","0")
		});
		
	}
	
}

function updateDisabled()
{
	var netForm = document.eth_setting;
	if (netForm.network_type[0].checked) //lan
	{
		disablePPPoESetting(true);
		if (netForm.network_resetip[0].checked)
			disableStaticIPSetting(true);
		else
			disableStaticIPSetting(false);
	}
	else //pppoe
	{
		disablePPPoESetting(false);
		disableStaticIPSetting(true);
	}
}

function NetworkTypeSelector()
{
	updateDisabled();
	if (getCheckedValue(document.eth_setting.network_type) == "lan")
	{
		if (bLan == "false") 
		{
		  	bLan = "true";
				$("#lanChild").slideDown("slow");
				$("#pppoeChild").slideUp("slow");
			bPPPOE = "false";
		}
		else 
		{
			if (getCheckedValue(document.eth_setting.network_resetip) == "1") //dhcp
			{
				if (bDhcp == "false") 
				{
					bDhcp = "true";
					$("#fixipChild").slideUp("slow");
					bStatic = "false";
				}		
			}
			else //static
			{
				if (bStatic != "true") 
				{
					bStatic = "true";
					$("#fixipChild").slideDown("slow");
					bDhcp = "false";
				}
			}
		}	
		$("#manualSetup, #IPv6addonipaddress, #IPv6addonprefixlen, #IPv6addonrouter, #IPv6addondns").attr("disabled",false);		
	}
	else //pppoe
	{
		if(bPPPOE == "false")
		{
			bPPPOE == "true";
			$("#pppoeChild").slideDown("slow");
			$("#lanChild").slideUp("slow");
			bLan = "false";
			$("#manualSetup, #IPv6addonipaddress, #IPv6addonprefixlen, #IPv6addonrouter, #IPv6addondns").attr("disabled",true);
		}
	}
}

function submitform_eth_setting()
{
	var netForm = document.eth_setting;
	
	if (netForm.network_resetip[1].checked)
	{
		if (checkIPaddr(netForm.network_ipaddress) == -1 ||
			checkIPaddr(netForm.network_subnet) == -1 ||
			checkIPaddr(netForm.network_router) == -1)
		{
			return -1;
		}
		
		if (netForm.network_dns1.value != "" && checkIPaddr(netForm.network_dns1) == -1)
		{
			return -1;
		}
		if (netForm.network_dns2.value != "" && checkIPaddr(netForm.network_dns2) == -1)
		{
			return -1;
		}
		if (checkWinsIPaddr(netForm.network_wins1) == -1 ||
			checkWinsIPaddr(netForm.network_wins2) == -1)
		{
			return -1;
		}
		
		ipaddress = netForm.network_ipaddress.value.split(".");
		netmask = netForm.network_subnet.value.split(".");
		router = netForm.network_router.value.split(".");
		
		for (i=0; i<3; i++)
		{
			if ((ipaddress[i] & netmask[i]) != (router[i] & netmask[i]))
			{
				alert(translator("please_input_a_valid_value"));
				return -1;
			}
		}
	}

	if (netForm.IPv6checkbox.checked && netForm.manualSetup.checked)
	{
		if( checkIPaddr6(netForm.network_ipv6_addonipaddress) == -1 ||
			checkIP6_linkLocal(netForm.network_ipv6_addonrouter) == -1 ||
			checkIPaddr6(netForm.network_ipv6_addondns) == -1 ||
			checkNumRange(netForm.network_ipv6_addonprefixlen, 128, 0) == -1)
		{
			return -1;
		}
	}
	
	if (getCheckedValue(netForm.network_type) == "pppoe")
	{
		if ((CheckEmptyString(netForm.network_pppoe_user) == -1) || (CheckEmptyString(netForm.network_pppoe_pass) == -1))
		{
			return -1;
		}
		checkStringSize(netForm.network_pppoe_user);
		if(checkInString(netForm.network_pppoe_user))
		{
			return -1;
		}
		checkStringSize(netForm.network_pppoe_pass);
		if (checkPassword(netForm.network_pppoe_pass, netForm.network_pppoe_confirmpass) == -1)
		{
			return -1;
		}
	}
	else
	{
		if(netForm.network_pppoe_user.value != "")
		{
			checkStringSize(netForm.network_pppoe_user);
			if(checkInString(netForm.network_pppoe_user))
			{
				return -1;
			}
		}
	}
		

	if (netForm.network_resetip[1].checked) 
		network_ipaddress=netForm.network_ipaddress.value;

	if (netForm.manualSetup.checked)
	{
		netForm.network_ipv6_allowoptional.value = 1;
	}
	else
	{
		netForm.network_ipv6_allowoptional.value = 0;
	}
			
	if(checkPasswordVal() != 0)
	{
		return -1;
	}

	// set network setting without reboot
	netForm.system_reset.value = "";
	if ((getCheckedValue(netForm.network_type) == "pppoe") ||
	   ((network_type == "pppoe") && (getCheckedValue(netForm.network_type) == "lan")))
	{
		netForm.system_reset.value = 3;
		netForm.network_restart.value = 0;
		showNotification(60);
	}
	else
	{
		netForm.system_reset.disabled = true;
		netForm.network_restart.value = 1;
		showNotification(30);
	}
	
	netForm.submit();
}

function submitform_port_setting()
{
	var netForm = document.port_setting;
	var setPortValue = 0;

	var network_rtcp_videoport = parseInt(network_rtp_videoport) + 1;
	var network_rtcp_audioport = parseInt(network_rtp_audioport) + 1;
	var videoport;
	var audioport;
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		videoport = eval('parseInt(network_rtsp_s'+i+'_multicast_videoport) + 1');
		audioport = eval('parseInt(network_rtsp_s'+i+'_multicast_audioport) + 1');
		eval('var network_rtsp_s'+i+'_multicast_rtcp_videoport = '+videoport);
		eval('var network_rtsp_s'+i+'_multicast_rtcp_audioport = '+audioport);
	}
	var port = new Array(network_http_port,                  //0
						 network_http_alternateport,         //1
						 netForm.network_https_port.value,				 //2
						 netForm.network_sip_port.value,                   //3
						 netForm.network_ftp_port.value,                   //4
						 network_rtsp_port,                  //5
						 network_rtp_videoport,              //6
						 network_rtcp_videoport.toString(),    //7
						 network_rtp_audioport,              //8
						 network_rtcp_audioport.toString()             //9
					 );
	// Dynamic push audio and video port into port array 
	for(i=0; i < parseInt(capability_nmediastream,10); i++)
	{
		port.push(eval('network_rtsp_s'+i+'_multicast_videoport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_rtcp_videoport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_audioport'));
		port.push(eval('network_rtsp_s'+i+'_multicast_rtcp_audioport'));
	}
					 //console.log("port = "+port); 
	if(checkvalue())
	{
		return -1;
	}

	// Check port conflict: https_port, sip_port, ftp_port
	for (var i = 2; i <= 4; i++)
	{
		if(CheckEmptyString(port[i]) == -1)
		{
			return -1
		}

		for (var j = 0; j < port.length; j++)
		{
			if (i == j)
			{
				continue;
			}
			if (port[i] == port[j])
			{

				if (i == 2)//https
				{
					netForm.network_https_port.select();
					netForm.network_https_port.focus();
				}
				else if (i == 3)//sip
				{
					netForm.network_sip_port.select();
					netForm.network_sip_port.focus();
				}
				else if (i == 4)//ftp
				{
					netForm.network_ftp_port.select();
					netForm.network_ftp_port.focus();
				}

				switch (i)
				{
					case 2:
						alert(translator("https_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 3:
						alert(translator("two_way_audio_port_can_not_be_the_same_as_other_port"));
						return -1;
					case 4:
						alert(translator("ftp_port_can_not_be_the_same_as_other_port"));
						return -1;
				}
			}
		}
	}

	// Check SIP port confliction
	if (checkSipPort(netForm.network_sip_port))
	{
		netForm.network_sip_port.select();
		netForm.network_sip_port.focus();
		return -1;
	}

	// stop related process before set port value
	if (netForm.network_https_port.value != orig_https)
	{
		eval(setPortValue = setPortValue + 2);
        orig_https = netForm.network_https_port.value;
	}
	if (netForm.network_ftp_port.value != orig_ftp)
	{
		eval(setPortValue = setPortValue + 4);
        orig_ftp = netForm.network_ftp_port.value;
	}
	netForm.network_preprocess.value = setPortValue;

	netForm.submit();
}

function checkSipPort(SipPort)
{
	val=SipPort.value;
	if (val == 10000)
	{
		// 10000: DRM
		alert(translator("invalid_port_number") + "(10000)");
		return -1;
	}
	else
	{
		// 8888~8895: RTSP Multicast
		for(j=0; j < 8; j++)
		{
			var k = 8888+j;
			if (val == k)
			{
				alert(translator("invalid_port_number") + "(8888~8895)");
				return -1;
			}
		}
	}
    return 0;
}

// switch the static IP settings between enable or disabled by input
function disableStaticIPSetting(input)
{
	netForm = document.eth_setting;
	netForm.network_ipaddress.disabled = input;
	netForm.network_subnet.disabled = input;
	netForm.network_router.disabled = input;
	netForm.network_dns1.disabled = input;
	netForm.network_dns2.disabled = input;
	netForm.network_wins1.disabled = input;
	netForm.network_wins2.disabled = input;
}

function viewIPv6()
{
	window.open("/cgi-bin/admin/dumpipv6info.cgi" , "","width=400, height=200, scrollbars=yes, status=yes");
}

function updateIPv6check(inputName, checkbox)
{
	updatecheck(inputName, checkbox);
	if (checkbox.checked)
	{
		$("#IPv6_setting, #IPv6_info_button").slideDown("slow");
	}
	else
	{
		$("#IPv6_setting, #IPv6_info_button").slideUp("slow");
	}
}

function disablePPPoESetting(input)
{
	netForm = document.eth_setting;
	netForm.network_pppoe_user.disabled = input;
	netForm.network_pppoe_pass.disabled = input;
	netForm.network_pppoe_confirmpass.disabled = input;
}

function JudgeTwoWayAudioPortExist()
{
	if(ParamUndefinedOrZero("capability_protocol_sip"))
	{
		$("#two_way_audio_port").hide();
	}
}
