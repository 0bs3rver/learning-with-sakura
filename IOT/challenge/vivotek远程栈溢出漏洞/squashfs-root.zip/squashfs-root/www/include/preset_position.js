var PresetNameNum=0;
var MAX_PRESET_COUNT = 20;
var MAX_PATROL_COUNT = 40;
var g_patrolSeqMaxIdx = 0;

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

function loadCurrentSetting()
{
	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};
	
	//updata 
	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;
			
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];
		
		if(!type || compare(type.description, plugin.description)) {
			xpi = plugin.xpi;
		}
	
		if(xpi) {
			if( window.InstallTrigger == undefined) // It means this page is include in other page
				parent.window.InstallTrigger.install(xpi); 
			else
			window.InstallTrigger.install(xpi);
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) {
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');
		}																					   //
	}
	
	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}

	$('#InstallerArea').hide();
	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?camctrl_c0&uart_i0_ptzdriver&uart_enablehttptunnel", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	if (window.XMLHttpRequest)
		receiveparam();
	
	eval("AccessName=network_rtsp_s0_accessname");
	//eval("codectype=videoin_c" + channelsource + "_s0_codectype");
	evalPluginSize();
	
	showimage_innerHTML('4', 'showimageBlock', false, true, true);
	
	initPrestAndPatrolBlk();
    // Dynamically adjust "left" value because of multilingual issue 
    $("label.overlay").css("left", $("#presetNameID").width() + 15);

    // Show More/Less button if ScrollBar appears.
    presetSclBarDetect();
    patrolSclBarDetect();
	
	//init sel_gotoPreset
	for (i = 0; i < MAX_PRESET_COUNT; i++)
	{
		var preset_name = eval("camctrl_c0_preset_i" + i + "_name");
		if (preset_name != "")
		{
			$("#sel_gotoPreset").addOption(i, preset_name , false);
		}
	}
}

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
	document.title=translator("preset_position");
	loadlanguage();
}

function receivedone()
{
	var ChannelNo = 0;
	var LilinPreProcess = false;
/*
	if (uart_i0_ptzdriver == 127)
	{
		disableTR(document.all("panspeed"), true);
		disableTR(document.all("tiltspeed"), true);
		disableTR(document.all("zoomspeed"), true);
	}
	
	
	if (uart_i0_ptzdriver == 1)
	{
		//document.getElementById("gotobutton").style.display="none";
	}
	else if (uart_i0_ptzdriver == 127)
	{
		//disableTR(document.all("PresetPatrol"), true);
	}
*/	
	//document.getElementById("content").style.visibility = "visible";
	
	for (var i = 0; i < 20; i++)
	{
		var CamPresetName = eval('camctrl_c0_preset_i' + i + '_name');
		
		if (CamPresetName == "")
		{
			if ((uart_i0_ptzdriver == 1) && (LilinPreProcess == false))
			{
				parent.retframe.location.href='/cgi-bin/camctrl/recall.cgi?channel='+ChannelNo+'&index=' + i;
				LilinPreProcess = true;
			}
			break;
		}
	}
}

function submitform()
{
	if(checkvalue())
	{
		return -1;
	}
	else
		document.forms[0].submit();
}

function checkAsciiString(instr){
    for (i = 0; i < instr.value.length; i++){
        c = instr.value.charAt(i);
        if (!( (c>='@' && c<='Z') || (c>='a' && c<='z') || (c>='0' && c<='9') || c=="!" ||
               (c>="#" && c<="'") || c=="-" || c=="." || c=="^" || c=="_" || c=="~"))
        {
          alert(translator("you_have_used_invalid_characters_passwd"));
          return 0;
        }
    }

   return 1;
}

//for new UI
function KeyPress(evt)
{
    var code = window.event?evt.keyCode:evt.which;
	if (code == 13)
	{
        return false;
	}
}

function AddPresetLoc()
{
    var MaxPresetLen = 40;

    if (CheckEmptyString(document.add.addpos_temp) == -1)
	{
		return false;
	}

	if (checkInString(document.add.addpos_temp))
	{
	    return false;	    
	}

    if (document.add.addpos_temp.value.match(',') != null)
	{
        alert(translator("you_have_used_invalid_characters_comma"));
	    return false;	    
	}
	
    // "--- Select one ---" is a fake preset
    if (document.ctrlpanel.presetLocs.length > MAX_PRESET_COUNT)
    {
        alert(translator("no_more_than_20_locations"));
        return false;
    }

    if (CountLength(document.add.addpos_temp.value) > MaxPresetLen)
    {
        alert(translator("the_length_is_over_40_characters"));
        return false;
    }

    for (var i = 0; i < document.ctrlpanel.presetLocs.length; i++)
    {
        if (document.add.addpos_temp.value == document.ctrlpanel.presetLocs.options[i].text)
        {
		alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
            return false;
        }
    }
  
//	document.add.addpos.value = document.add.addpos_temp.value.replace(/\$/g, "\\$"); //$$, $var will be replaced by OS as some number
    document.add.addpos.value = document.add.addpos_temp.value;
    //var presetURL = "/cgi-bin/operator/preset.cgi?addpos=" + document.add.addpos.value;
	var presetURL = "/cgi-bin/operator/preset.cgi?channel=0&addpos=" + encodeURI(document.add.addpos.value) + "&return=/setup/ptz/preset_position.html";
    document.add.Submit2.disabled=true;

    // adding preset location by AJAX
	$.ajax({
		url: presetURL,
		cache: false,
        beforeSend: function () {
            $("#ajaxLoadIcon").show();
        },
		error: function (xhr) {
			document.add.addpos_temp.value = "";
			document.add.Submit2.disabled = false;
			return; 
		},
		success: function (response) {
			for (i = 0; i < MAX_PRESET_COUNT; ++i)
			{
				if (eval("camctrl_c0_preset_i" + i + "_name") == "")
				{
					eval("camctrl_c0_preset_i" + i + "_name=" + "'" + document.add.addpos.value + "'");
					break;
				}
			}

            $("#sel_gotoPreset").addOption($("#sel_gotoPreset option:last").val() + 1, document.add.addpos.value , false);
            $("#table-preset tbody").append("<tr><td><input  type='checkbox'/></td><td style='cursor: default;' title='" + document.add.addpos.value + "'>" + document.add.addpos.value + "</td></tr>");
			document.add.addpos_temp.value = "";
			document.add.Submit2.disabled = false;
            $("#addPresetInput").blur();
            $("#ajaxLoadIcon").fadeOut(1000);
            presetSclBarDetect();
			return;
		}
	});

//  document.add.submit();   
}


function presetSclBarDetect() 
{
	if($("#table-preset").height() >= 130)
	{
		$("#btn_adjPresetTbl").show();
	}
	else
	{
		($(".tablescroll_wrapper:eq(0)").hasScrollbar()) ? $("#btn_adjPresetTbl").show() : $("#btn_adjPresetTbl").hide();
	}
}

function patrolSclBarDetect() 
{
	if($("#table-patrol").height() >= 130)
	{
		$("#btn_adjPatrolTbl").show();
	}
	else
	{
		($(".tablescroll_wrapper:eq(1)").hasScrollbar()) ? $("#btn_adjPatrolTbl").show() : $("#btn_adjPatrolTbl").hide();
	}
}

function initPrestAndPatrolBlk()
{
	// Init "add preset location"
    $('label.pre').labelOver('overlay').show();

    // Preset - Select All or Clear
    $("#chk_SelAllPreset").click(function() {
        $(this).attr("checked") ? $("#table-preset :checkbox").attr("checked", true) : $("#table-preset :checkbox").attr("checked", false);
    });

    // Patrol - Select All or Clear
    $("#chk_SelAllPatrol").click(function() {
        $(this).attr("checked") ? $("#table-patrol :checkbox").attr("checked", true) : $("#table-patrol :checkbox").attr("checked", false);
    });

    // Generate Preset table
    var presetItemStr = "";
    for (i = 0; i < MAX_PRESET_COUNT; i ++)
    {
        //var presetName = eval("camctrl_c0_preset_i" + i + "_name");
		
		var presetName = eval("camctrl_c0_preset_i" + i + "_name");
		if (presetName != "")
        {
            presetItemStr += "<tr><td><input  type='checkbox'/></td><td style='cursor: default;' title='" + presetName + "'>" + presetName + "</td></tr>";
        }
    }
    $("#table-preset tbody").append(presetItemStr);
    
    //Avoid draggin operation on this field.
    $("#table-preset td:odd").live("mousedown", function(){
        return false;
    });

    // Generate Patrol table
    var patrolItemStr = "";
	
	var tmpPatrol = eval("camctrl_c0_patrolseq").split(',');
	var tmpDwelling = eval("camctrl_c0_patroldwelling").split(','); 
	
    if (tmpPatrol != "")
    {
        for (i = 0; i < tmpPatrol.length; i ++)
        {
			var patrolName = eval("camctrl_c0_preset_i"+tmpPatrol[i]+"_name");
			var patrolDwell = tmpDwelling[i];
			
			patrolItemStr += "<tr><td><input  type='checkbox'/></td><td title='"+ patrolName +"'>" + patrolName + "</td><td><input  type='text' style='width:70px;' value='" + patrolDwell + "' maxlength='3'/></td></tr>";
        }
		
		$("#table-patrol tbody").append(patrolItemStr);
    }

    // Make Patrol locations Drag & Drop
    $("#table-patrol").tableDnD({ onDragClass: "myDragClass" });
    if (bIsWinMSIE) $("#table-patrol :checkbox").css("cursor", "default");

    $("#table-patrol tr").live('click', function(){
        $(this).siblings().attr("selected", 0).css("background", "#fff");
        $(this).attr("selected", 1).css("background", "#ccc");
    });

    // Finetune Patrol dwell time layout
    $("#table-patrol :text").css("padding", "0 3px");
}

var g_delPresetLocSeq = [];  // Preset Locations to be deleted!
function delPresetLocs()
{
    $("#table-preset :checked").parent().next().each(function(){
        tmpPresetName = $(this).attr("title");
        g_delPresetLocSeq.push(tmpPresetName);
	$("#table-patrol tr td[title!='']").each(function(){
            if (tmpPresetName == $(this).attr("title")) {
                $(this).parent().remove();
            }
        });
    });

    $("#table-preset :checked").parent().parent().remove();
    $("#btn_adjPresetTbl").click().click(); //force click twice to auto adjust #table-patrol
    $("#chk_SelAllPreset").attr("checked", false);
    presetSclBarDetect();
    patrolSclBarDetect();
}

function delPatrolLocs()
{
    $("#table-patrol :checked").parent().parent().remove();
    $("#btn_adjPatrolTbl").click().click(); //force click twice to auto adjust #table-patrol
    $("#chk_SelAllPatrol").attr("checked", false);
    patrolSclBarDetect();
}

function AddToPatrol()
{
    if ( (MAX_PATROL_COUNT - $("#table-patrol tr").length) < $("#table-preset :checked").length )
    {
		alert(translator("no_more_than_40_locations"));
        return;
    }

    var patrolItemStr = "";
    $("#table-preset :checked").each(function(i, obj){
        // Insert to Patrol table
        var patrolName = $(obj).parent().siblings().attr("title");
        //Set default dwell time to 5
        var patrolDwell = 5; 
        patrolItemStr += "<tr><td><input  type='checkbox'/></td><td title='" + patrolName +"'>" + patrolName + "</td><td><input  style='padding: 0 3px; width: 70px;' type='text' value='" + patrolDwell + "' maxlength='3'/></td></tr>";
    });

    $("#table-patrol tbody").append(patrolItemStr);
    
    //Make new item Drag & Drop 
    $("#table-patrol").tableDnD({ onDragClass: "myDragClass" });
    if (bIsWinMSIE) $("#table-patrol :checkbox").css("cursor", "default");

    patrolSclBarDetect();
}

function MoveUp()
{
    var Index = $("#table-patrol tr").index($("#table-patrol tr[selected='1']"));
    if ( -1 == Index) return;

    if ( Index == $("#table-patrol tr").index($("#table-patrol tr:first")) ) return;  // At first place
    $("#table-patrol tr[selected='1']").insertBefore($("#table-patrol tr:eq("+ (Index-1) +")"));
}

function MoveDown()
{
    var Index = $("#table-patrol tr").index($("#table-patrol tr[selected='1']"));
    if ( -1 == Index ) return;

    if ( Index == $("#table-patrol tr").index($("#table-patrol tr:last")) ) return;  // At last place
    $("#table-patrol tr[selected='1']").insertAfter($("#table-patrol tr:eq("+ (Index + 1) +")"));
}

function adjustPatrolTbl(obj)
{
    var currentH = $("div.tablescroll_wrapper:eq(1)").css("height");
    if ("130px" == currentH) 
    {
        if($("#table-patrol").height() <= 130) return;
        $("div.tablescroll_wrapper:eq(1)").css("height", "auto");
        $(obj).val(translator("less"));
    }
    else
    {
        $("div.tablescroll_wrapper:eq(1)").css("height", "130px");
        $(obj).val(translator("more"));
    }
    obj.blur();
}

function adjustPresetTbl(obj)
{
    var currentH = $("div.tablescroll_wrapper:eq(0)").css("height");
    if ("130px" == currentH) 
    {
        if($("#table-preset").height() <= 130) return;
        $("div.tablescroll_wrapper:eq(0)").css("height", "auto");
        $(obj).val(translator("less"));
    }
    else
    {
        $("div.tablescroll_wrapper:eq(0)").css("height", "130px");
        $(obj).val(translator("more"));
    }
    obj.blur();
}

function SubmitPreset(selObj)
{
	for (var i=0; i < selObj.options.length-1; i++)
    {
		if (selObj.options[i].selected)
			break;
    }

	if (selObj.options[i].value == -1)
	{
		return;
	}

    retframe.location.href='/cgi-bin/camctrl/recall.cgi?channel=0&recall=' + encodeURIComponent(selObj.options[i].text);
}

function SubmitAll()
{
	/*
    if (checkNumRange($("input[name=camctrl_c0_idleaction_interval]")[0], 999, 1))
	{
		return false;
	}
*/

    /*
     * To reduce unnecessary param setting, improve cgi speed.
     * Rather than setting from camctrl_c0_patrol_i0_xxx ~ camctrl_c0_patrol_i39_xxx
     */
	var patrolSeqArray = [];
	var patrolDwellingArray = [];
    var patrolSeqParam = "";
    var bError = false;
    $("#table-patrol tr").each(function(idx, obj){
		for (i = 0; i < MAX_PRESET_COUNT; i++)
		{
			if (eval("camctrl_c0_preset_i" + i + "_name") == $(this).find("td:eq(1)").attr("title")) 
				patrolSeqArray.push(i);
		}
		
        if (checkNumRange($(this).find(":text")[0], 999, 0))
        {
            bError = true;
            return false; // beak each() loop
        }
		patrolDwellingArray.push($(this).find(":text").val());
		
    });
    if (bError) return false;
	
	patrolSeqParam = "camctrl_c0_patrolseq=" + encodeURIComponent(patrolSeqArray.join(",")) + 
					 "&camctrl_c0_patroldwelling=" + encodeURIComponent(patrolDwellingArray.join(","));
	
	
	/*
    for (var idx = $("#table-patrol tr").length; idx < g_patrolSeqMaxIdx + 1; idx++) {
        patrolSeqParam += "&camctrl_c0_patrol_i"+idx+"_name=&camctrl_c0_patrol_i"+idx+"_dwelling=";
    }*/
	

    /*
     * End
     */

    /*
     * Note: We should set preset.cgi first, then setparam.cgi?camctrl_xxx
     *       Because setparam.cgi?camctrl_c0_patrl_xxx will send SIGUSR1 to ptzctrl,
     *       ptzctrl will reconfig patrol information. 
     *
     *       If we setparam.cgi?camctrl_xxx first, then ptzctrl reconfig still in progress, 
     *       thus PTHIS->szPatrolName is not update to date, 
     *       so it would cause ptzctrl->PTZCTRL_DeletePatrol() miss removing non-exist loations. 
     */

    $("#ajaxLoadIcon2").show();
    //1st. Delete preset locations. 
    if ( "" != g_delPresetLocSeq)
    {
        $.ajax({
            url: "/cgi-bin/operator/preset.cgi",
            type: "POST",
            dataType: "script",
            async: false,
            data: "channel=0&delpos=" + encodeURIComponent(g_delPresetLocSeq.join(',')),
            beforeSend: function () {
                //$("#ajaxLoadIcon2").show();
            },
            success: function() {
                //window.location="/setup/cameracontrol.html";
            },
            error: function() {
                //called when there is an error
            }
        });
    }

    //2nd. Setting patrol locations and misc settings!
    $.ajax({
        url: "/cgi-bin/admin/setparam.cgi",
        type: "POST",
        dataType: "script",
        //data: patrolSeqParam + "&" + $(document.miscform).serialize(),
		data: patrolSeqParam,
        complete: function() {
            //$("#ajaxLoadIcon2").hide();
        },
        success: function() {
            window.location="/setup/ptz/preset_position.html";
        },
        error: function() {
            //called when there is an error
        }
    });
}

jQuery.fn.labelOver = function(overClass) {
    return this.each(function(){
        var label = jQuery(this);
        var f = label.attr('for');
        if (f) {
            var input = jQuery('#' + f);
            
            this.hide = function() {
                label.css({ textIndent: -10000 });
                $(this).nextAll(":button").css("visibility", "visible");
            };
            
            this.show = function() {
                if (input.val() == '') {
                    label.css({ textIndent: 0 });
                    $(this).nextAll(":button").css("visibility", "hidden");
                } 
            };

            // handlers
            input.focus(this.hide);
            input.blur(this.show);
            label.addClass(overClass).click(function(){ input.focus(); });
            
            if (input.val() != '') this.hide(); 
        }
    });
};

jQuery.fn.hasScrollbar = function() {
    var scrollHeight = this.get(0).scrollHeight - 2; //2px for Top & Bottom border width

    //safari's scrollHeight includes padding
    if ($.browser.safari)
        scrollHeight -= parseInt(this.css('padding-top')) + parseInt(this.css('padding-bottom'));

    if (this.height() < scrollHeight)
        return true;
    else
        return false;
};
