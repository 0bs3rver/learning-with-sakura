high=translator("high");
low=translator("low");
opened=translator("open");
grounded=translator("grounded");
var beLoadFirst=true;

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info_language&system_info_customlanguage&status_di&status_do&di&do&ircutcontrol_enableextled", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	document.title=translator("di_and_do");
	
	if (g_mode == "0")
	{
        $("#adv_dido").css("display","none");
	}
	
	loadlanguage();	
}

function reloadDOsetting()
{
    if(beLoadFirst)
    {
        beLoadFirst=false;
    }
    else
    {
        setTimeout("location.reload();", 1000 );
    }
}

function receivedone()
{	
	document.getElementById("content").style.visibility = "visible";
	for (iDI = 0 ;iDI < parseInt(capability_ndi, 10) ; iDI++)
	{
		eval("di_i"+iDI+"_currentstate=0;");
	}
	for (iDO = 0 ;iDO < parseInt(capability_ndo, 10) ; iDO++)
	{
		eval("do_i"+iDO+"_currentstate=0;");
	}
	
	ShowCurrentState();
	
	GenerateDIDOList();
}

function loadvaluedone()
{
	var hideArray = new Array();
	var netForm = document.forms[0];
	
	if (ircutcontrol_enableextled == "1")
	{
		$("input[name=do_i0_normalstate]").attr("disabled", true);
		$("#warning_message_for_do").css("display", "block");
	}
	
}

function ShowCurrentState() // high:1, low:0 ; open:1, grounded:0
{
	for (iDI = 0; iDI < parseInt(capability_ndi, 10); iDI++)
	{
		if(eval("status_di_i"+iDI) == 0)
		{
			eval("di_i"+iDI+"_currentstate = "+((eval("di_i"+iDI+"_normalstate") == "high") ? 1 : 0));
		}
		else if(eval("status_di_i"+iDI) == 1)
		{
			eval("di_i"+iDI+"_currentstate = "+((eval("di_i"+iDI+"_normalstate") == "high") ? 0 : 1));
		}
	}
	
	for (iDO = 0; iDO < parseInt(capability_ndo, 10); iDO++)
	{
		if(eval("status_do_i"+iDO) == 0)
		{
			eval("do_i"+iDO+"_currentstate = "+((eval("do_i"+iDO+"_normalstate") == "open") ? 1 : 0));
		}
		else if(eval("status_do_i"+iDO) == 1)
		{
			eval("do_i"+iDO+"_currentstate = "+((eval("do_i"+iDO+"_normalstate") == "open") ? 0 : 1));
		}
	}
}

function GenerateDIDOList()
{
	//Dynamic generate DI & DO list
	var highlowstate;
	var opengroundstate;

	//Generate DI and DO title in the top of page
	if(ParamUndefinedOrZero("capability_ndi") && !ParamUndefinedOrZero("capability_ndo")) // only DO
	{
		$(document.getElementById("confGroup")).append(""
		+'<span title="symbol">'+translator("do")+'</span>');
	}
	else if(!ParamUndefinedOrZero("capability_ndi") && ParamUndefinedOrZero("capability_ndo")) // only DI
	{
		$(document.getElementById("confGroup")).append(""
		+'<span title="symbol">'+translator("di")+'</span>');
	}
	else // show di_and do (if it does not support both di and do, it will be hide) 
	{
		$(document.getElementById("confGroup")).append(""
		+'<span title="symbol">'+translator("di_and_do")+'</span>');
	}

	//Generate DO
	for (iDO = parseInt(capability_ndo, 10)-1 ; iDO >= 0; iDO--)
	{
		opengroundstate=eval("do_i"+iDO+"_currentstate")%2?opened:grounded;	
		$(document.getElementById("system")).prepend(""
		+'<fieldset  id="NDO_DIR'+iDO+'">'
		+'	<legend>'
		+'	  <strong><span title="symbol">'+translator("digital_output")+'</span></strong><span id="digital_output_num_'+iDO+'"> '+eval(iDO+1)+'</span></strong>'
		+'	</legend>'
		+'	<dl>'
		+'    <dt style="margin-top:5px;">'
		+'		<span title="symbol">'+translator("normal_status")+'</span>: '
		+'		<span class="position">'
		+'			<input  name="do_i'+iDO+'_normalstate" type="radio" title="param" value="open"><span title="symbol">'+translator("open")+'</span>'
		+'			<input  name="do_i'+iDO+'_normalstate" type="radio" title="param" value="grounded"><span title="symbol">'+translator("grounded")+'</span>'
		+'		</span>'
		+'	</dt>'
		+'	<dt>'	
		+'		<span title="symbol">'+translator("current_status")+'</span>:' 
		+'		<strong><span class="position" title="param">'+opengroundstate+'</span></strong>'
		+'    </dt>'
		+'  </dl>'
		+'	<div id="warning_message_for_do" style="display:none">'
		+'		<p class="note">'
		+'			<span title="symbol">'+translator("turn_on_extir_warning_message_for_do_config")+'</span>'
		+'		</p>'
		+'	</div>'
		+'</fieldset>');		         
	}
	//If only 1 DO, hide the number
	if(parseInt(capability_ndo, 10) == 1)
	{
		$("#digital_output_num_0").hide();	
	}
	//Generate DI
	for (iDI = parseInt(capability_ndi, 10)-1 ; iDI >= 0; iDI--)
	{
		highlowstate=eval("di_i"+iDI+"_currentstate")%2?high:low;
		$(document.getElementById("system")).prepend(""
		+'<fieldset id="NDI_DIR'+iDI+'">'
		+'  <legend>'
		+'    <strong><span title="symbol">'+translator("digital_input")+'</span><span id="digital_input_num_'+iDI+'"> '+eval(iDI+1)+'</span></strong>'
		+'  </legend>'
		+'  <dl>'
		+'	  <dt>'
		+'      <span title="symbol">'+translator("normal_status")+'</span>: '
		+'	    <span class="position">'
		+'	      <input  name="di_i'+iDI+'_normalstate" type="radio" title="param" value="high"><span title="symbol">'+translator("high")+'</span>'
		+'	      <input  name="di_i'+iDI+'_normalstate" type="radio" title="param" value="low"><span title="symbol">'+translator("low")+'</span>'
		+'	    </span>'
		+'	  </dt>'
		+'	  <dt>'
		+'	    <span title="symbol">'+translator("current_status")+'</span>: '
		+'	    <strong><span class="position" title="param">'+highlowstate+'</span></strong>'
		+'	  </dt>'
		+'  </dl>'
		+'</fieldset>');
	}
	//If only 1 DI, hide the number
	if(parseInt(capability_ndi, 10) == 1)
	{
		$("#digital_input_num_0").hide();	
	}
}

function submitform()
{
	var form = document.forms[0];

	if(checkvalue())
	{
		return -1;
	}
	else
	{
	  form.submit();
	}
}
