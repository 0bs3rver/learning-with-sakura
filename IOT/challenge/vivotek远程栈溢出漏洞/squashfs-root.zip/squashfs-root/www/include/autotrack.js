
var channelsource = 0;
var TOP_REDUNDANCY_PIXEL = 23;
var LEFT_REDUNDANCY_PIXEL = 3;
var PLUGIN_SIZE_WIDTH = 320;
var PLUGIN_SIZE_HEIGHT = 240;

var aSensitivityTbl = new Array("low", "medium", "high");

eval("MaxSize=capability_videoin_c"+ channelsource + "_maxsize");
var MaxWidth = MaxSize.split("x")[0];
var MaxHeight = MaxSize.split("x")[1];

//"<PARAM NAME=\"PMSettingData3D\" VALUE=\"Name=IM1&TopLeftX=128&TopLeftY=104&Width=80&Height=48\">";
function loadCurrentSetting()
{
	InstallPlugin();

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?autotrack", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("auto_tracking");
	loadlanguage();

	adjustPluginSize();
	//showimage_innerHTML('motion', 'showimageBlock', false, true, true, 0);
	showimage_innerHTML('12', 'showimageBlock', false, true, true, 0);

	/* IP8x62 should not bind these keys for click on image
	$(document).keydown(function(event){return noNumbers(event)}); //Click on Image for Keyboard.
	*/
	if (bIsWinMSIE || ffversion >= 3)
	{
		genSensitivityWin();
	}
	
	initSensitivitySlider();

}

function genSensitivityWin()
{
	$("#StreamContainer").addClass("StreamContainerStyle");
	$("#StreamContainer").append('<div id="3DPMWindow" class="PMW_style"></div>');
	adjustStreamContainerStyleCSS();

	//initial PM Window by jQueryUI, enable resizable and draggable
	$('.PMW_style').resizable({
		containment: "#StreamContainer",
		handles: 'all',
		autoHide: true,
		minWidth: 30,
		minHeight: 30,
		maxWidth: PLUGIN_SIZE_WIDTH,
		maxHeight: PLUGIN_SIZE_HEIGHT,
		resize: function(e, ui)
		{
			//$("#PM_width_value").text(ui.size.width);
			//$("#PM_height_value").text(ui.size.height);

			//g_bConsole = true;
			//Log("ui.originalSize = %dx%d", ui.originalSize.width, ui.originalSize.height);
			//Log("ui.size = %dx%d", ui.size.width, ui.size.height);

			//ui.position.left = 160 - ui.size.width/2 + 3;
			//ui.position.top  = 120 - ui.size.height/2 + 23;

		},
		stop: function(e, ui)
		{
			//$("#PM_width_value").text(ui.size.width);
			//$("#PM_height_value").text(ui.size.height);

			//ui.position.left = 160 - ui.size.width/2 + 3;
			//ui.position.top  = 120 - ui.size.height/2 +23;
		}
	})
	.draggable({          
        cursor: 'move',  
        handle: "#StreamContainer",
        containment: "#StreamContainer",
        stop: function(e, ui) {
                if ($(this).position().top < 20) $('#3DPMWindow').css("top",20);
        },
    }).attr("disabled",true);
		
	$('#3DPMWindow').css("width",autotrack_c0_objsize_customized_width);
	$('#3DPMWindow').css("height",autotrack_c0_objsize_customized_height);
	//keep at center
	$('#3DPMWindow').css("top",(PLUGIN_SIZE_HEIGHT-parseInt(autotrack_c0_objsize_customized_height))/2+TOP_REDUNDANCY_PIXEL);
	$('#3DPMWindow').css("left",(PLUGIN_SIZE_WIDTH-parseInt(autotrack_c0_objsize_customized_width))/2+LEFT_REDUNDANCY_PIXEL);
	
}

function modifywindow()
{
	$('#3DPMWindow').css("border-color","ffffff");
	$('#3DPMWindow').attr("disabled",false);
	$('#modify_btn').attr("disabled",true);
}

// Add Sensitivity slider function
function initSensitivitySlider()
{
	var f = document.autotrack;
	$("#autotrack_c0_sensitivity_adjust_fix").html(translator(aSensitivityTbl[autotrack_c0_sensitivity]));
	$("#autotrack_c0_sensitivity_configBlk" ).slider({
		min: 1,
		max: aSensitivityTbl.length,
		animate: true,
		value: parseInt(autotrack_c0_sensitivity)+1,
		slide: function(event, ui)
		{
			$("#autotrack_c0_sensitivity_adjust_fix").html(translator(aSensitivityTbl[ui.value-1]));
		},
		change: function(event, ui)
		{
			$("#autotrack_c0_sensitivity_configBlk div.ui-slider-handle").attr("title", translator(aSensitivityTbl[ui.value-1]));
			f.autotrack_c0_sensitivity.value = ui.value-1;
		}	
	});
	$("#autotrack_c0_sensitivity_configBlk div.ui-slider-handle").attr("title", translator(aSensitivityTbl[autotrack_c0_sensitivity]));
}

function submitform()
{
	var f = document.autotrack
	f.autotrack_c0_objsize_customized_width.value  = $("#3DPMWindow").width();
	f.autotrack_c0_objsize_customized_height.value = $("#3DPMWindow").height();
	
	//use customized window size, autotrack_c0_objsize_type must be -1
	f.autotrack_c0_objsize_type.value = -1;
	
	$('#3DPMWindow').css("border-color","888888");
	$('#3DPMWindow').attr("disabled",true);
	$('#modify_btn').attr("disabled",false);
	
    document.forms["autotrack"].submit();
}

function adjustPluginSize()
{
	if (MaxWidth*9 == MaxHeight*16) 
	{
		PLUGIN_SIZE_WIDTH = 320;
		PLUGIN_SIZE_HEIGHT = 180;
	}
	else if (MaxWidth*3 == MaxHeight*4) 
	{
		PLUGIN_SIZE_WIDTH = 320;
		PLUGIN_SIZE_HEIGHT = 240;
	}
	else
	{
		PLUGIN_SIZE_WIDTH = 320;
		PLUGIN_SIZE_HEIGHT = 240;
	}
}

function adjustStreamContainerStyleCSS()
{
	if (MaxWidth*9 == MaxHeight*16) 
	{
		$('.StreamContainerStyle').css("width", 326);
		$('.StreamContainerStyle').css("height", 205);
	}
	else if (MaxWidth*3 == MaxHeight*4) 
	{
		$('.StreamContainerStyle').css("width", 324);
		$('.StreamContainerStyle').css("height", 264);
	}
	else
	{
		$('.StreamContainerStyle').css("width", 324);
		$('.StreamContainerStyle').css("height", 264);
	}
}
