var MAX_PATROL_COUNT = 40;
var g_patrolSeqMaxIdx = 0;
var MAX_PRESET_COUNT = capability_npreset;
var giCH_Curr = 0;

$.Installer = {
	plugins: {
		mime: "application/x-installermgt", 
		description: FF_XPI_DESCRIPTION
	}
};
// Add xpi, in order to dynamically set JSON name of FF_XPI_DESCRIPTION
$.Installer.plugins.xpi = {};
$.Installer.plugins.xpi[FF_XPI_DESCRIPTION] = "/npVivotekInstallerMgt.xpi";

function pluginCreated()
{
	if (bIsWinMSIE && document.getElementById(PLUGIN_ID).PluginBeCreated != true)
	{
		setTimeout('pluginCreated()', 100);
	}
}
 
function loadCurrentSetting()
{
	var version = function(name) {
		var pos = name.search(" v");
		if(pos == -1) {
			return [];
		}
		return name.substr(pos + 2).split(".");
	};
		
	var compare = function(cur, src) {
		var cur = version(cur);
		var src = version(src);
		for(var i = 0; i < 4; ++i) {
			if(src[i] > cur[i]) {
				return true;
			} else if(src[i] < cur[i]) {
				return false;
			}
		}
	};
	
	//updata 
	if (navigator.userAgent.match("Firefox") != null)
	{
		var xpi = undefined;			
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];
		
		if(!type || compare(type.description, plugin.description)) 
		{
			xpi = plugin.xpi;
		}
	
		if(xpi) 
		{
			if( window.InstallTrigger == undefined) // It means this page is include in other page
				parent.window.InstallTrigger.install(xpi); 
			else
				window.InstallTrigger.install(xpi);
		}
	}
	else if (bIsChrome)
	{
		var crx = undefined;
		var plugin = $.Installer.plugins;
		var type = window.navigator.mimeTypes[plugin.mime];

		if(!type || compare(type.description, plugin.description)) 
		{
			// update chrome extension : crx
			$("#InstallerArea").append('<iframe width="1" height="1" frameborder="0" src="/npVivotekInstallerMgt.crx"></iframe>');
		}
	}
	
	if (bIsFireFox || bIsChrome)
	{
		$('#InstallerArea').html('<object id="Installer" type="application/x-installermgt"></object>');
		$('#Installer').attr("InstallerPath", window.location.protocol + "//" + window.location.hostname + "/VVTK_Plugin_Installer.exe");
	}

	$('#InstallerArea').hide();

    XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?camctrl&uart&network_http_port", false);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("camera_control");
	loadlanguage();

    //genPresetNameList(); 
	//genPatrolNameList();
    //genPatrolDwellingList();

    var sform = document.patrolform;
    var spdform = document.spdfm;
	
    receiveparam(); //for updatelogo
    loadvalue();

    spdform.eptz_c0_panspeed.selectedIndex= 5 - parseInt(eptz_c0_panspeed);
    spdform.eptz_c0_tiltspeed.selectedIndex= 5 - parseInt(eptz_c0_tiltspeed);
    spdform.eptz_c0_zoomspeed.selectedIndex= 5 - parseInt(eptz_c0_zoomspeed);	
    spdform.eptz_c0_autospeed.selectedIndex= 5 - parseInt(eptz_c0_autospeed);

    document.title=translator("camera_control");		

    // ePTZ support streaming number
	// parse the capability_eptz
	var ePTZStreamNumber = parseInt(capability_eptz, 10).toString(2).length;
    for (i=0; i < ePTZStreamNumber; i++)
    {
		if( ePTZStreamSupport(giCH_Curr, i) )
		{
			$("#StreamSelector").addOption(i, i+1);
		}
    }
	if( !ePTZStreamSupport(giCH_Curr, streamsource) )
	{
		setCookie("streamsource", ePTZStreamNumber-1);
		streamsource=getCookie("streamsource");
	}
    $("#StreamSelector").val(streamsource);

	showimage_innerHTML('4', 'showimageBlock', false, false, true, 0);
	setTimeout("addPluginEvent(document.getElementById(PLUGIN_ID), 'VNDPWrapperReady', PTZWinlessReady)", 500);

	//default load digital page
	setCookie('activatedmode', 'digital');

	// If capability_nuart = 1, it has RS485 and shows mechanical tab
	// If capability_nuart = 0, hide the mechanical tab
	if( capability_nuart == '0')
	{
		switchPTZPanel('digital');
	}
	else if (capability_nuart == '1')
	{
		document.getElementById("mechanical-tab").style.display = "inline";
	}

	pluginCreated();
	
	initPluginCallbackFnCamctrl();
    updateStatus("zoom"); //for ePTZ digital zoom
	
	initPrestAndPatrolBlk();
    // Dynamically adjust "left" value because of multilingual issue 
    $("label.overlay").css("left", $("#presetNameID").width() + 15);

    // Show More/Less button if ScrollBar appears.
    presetSclBarDetect();
    patrolSclBarDetect();
	
	//init sel_gotoPreset
	for (i = 0; i < MAX_PRESET_COUNT; i++)
	{
		var preset_name = eval("eptz_c0_s" + streamsource + "_preset_i" + i + "_name");
		if (preset_name != "")
		{
			$("#sel_gotoPreset").addOption(i, preset_name , false);
		}
	}
	
	if (document.spdfm.presetLocs.length > MAX_PRESET_COUNT)
	{
		$("#Submit2_add").attr("disabled", true);
	}
	else
	{
		$("#Submit2_add").attr("disabled", false);
	}
	
	//init zoom factor
	updateStatus("zoom");
	
	
	 

}

function zoomFactor(pluginId, pStrSendCmd)
{
	if (pStrSendCmd.match(/zoom=/) != null)
		setTimeout('updateStatus("zoom")', 500);
}

function initPluginCallbackFnCamctrl()
{
	var PluginObj = document.getElementById(PLUGIN_ID);
	addPluginEvent(PluginObj, "EPTZSend", zoomFactor);
}

function genPresetNameList()
{
    $("select[name='delpos']").removeOption(/./);
    $("select[name='preloc']").removeOption(/./);
    for (i = 0; i < MAX_PRESET_COUNT; i++)
    {
        var tmpPresetName = eval("eptz_c0_s"+ streamsource +"_preset_i"+i+"_name");
        if (tmpPresetName != "")
        {
            $("select[name='delpos']").addOption(tmpPresetName, tmpPresetName, false);
            $("select[name='preloc']").addOption(i, tmpPresetName, false);
        }
    }
}

function checkKeyCode(ev)
{
	var keycode;

	if (!ev)
		/* for IE */
		keycode = window.event.keyCode;
	else
		/* for Firefox */
		keycode = ev.keyCode;

	if (keycode != 13)
		return true;
	else
		return false;
}

function genPatrolNameList()
{
    $("select[name='selloc']").removeOption(/./);

    var tmpPatrol = eval("eptz_c0_s"+ streamsource +"_patrolseq").split(',');
    if (tmpPatrol != "")
    {
        for (i = 0; i < tmpPatrol.length; i ++)
        {
            $("select[name='selloc']").addOption(tmpPatrol[i], eval("eptz_c0_s"+ streamsource +"_preset_i"+tmpPatrol[i]+"_name"), false);
        }
    }
}

function genPatrolDwellingList()
{
    $("select[name='seldwelling']").removeOption(/./);

    var tmpPatrol = eval("eptz_c0_s"+ streamsource +"_patrolseq").split(',');
    var tmpDwelling = eval("eptz_c0_s"+ streamsource +"_patroldwelling").split(','); 

    if (tmpPatrol != "")
    {
        for (i = 0; i < tmpDwelling.length; i ++)
        {
            $("select[name='seldwelling']").addOption(tmpPatrol[i], tmpDwelling[i], false);
        }
    }
}

function CheckName()
{	
    var MaxPresetLen = 40;
	
    if (CheckEmptyString(document.add.addpos))
    	return false;
	
    if (checkFilenameString(document.add.addpos))
        return false;

    if (document.del.delpos.length >= MAX_PRESET_COUNT){
        alert(translator("no_more_than_"+ MAX_PRESET_COUNT +"_locations"));
        return false;
    }

    if (CountLength(document.add.addpos.value) > MaxPresetLen)
    {
        alert(translator("the_length_is_over_40_characters"));
        return false;
    }

    for(var i = 0; i < document.del.delpos.length; i++)
    {
        if(document.add.addpos.value == document.del.delpos.options[i].text)
        {
            alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
            return false;
        }
    }

    document.add.stream.value = getCookie("streamsource");
    document.add.Submit2.disabled=true;
    document.add.submit();   
}

function deletepos()
{
	document.del.stream.value = getCookie("streamsource");
	document.del.submit();
}

function CamCtrlSubmit()
{
	if(checkvalue())
	{
		return -1;
	}
	
	var sform = document.patrolform
    var strPatrolSeq = new Array();
    var strPatrolDwelling = new Array(); 
    $("select[name='selloc'] option").each(function(){
        strPatrolSeq.push(this.value);
    });
    $("select[name='seldwelling'] option").each(function(){
        strPatrolDwelling.push(this.text);
    });
    
    for(j=0; j<capability_nmediastream-1 ;j++)
    {
        if( j != streamsource)
        {
            eval('sform.eptz_c0_s'+ j +'_patrolseq.disabled = true');
            eval('sform.eptz_c0_s'+ j +'_patroldwelling.disabled = true');
        }
    }
    eval('sform.eptz_c0_s'+streamsource+'_patrolseq.value="' + strPatrolSeq.join(',')+'"');
    eval('sform.eptz_c0_s'+streamsource+'_patroldwelling.value="' + strPatrolDwelling.join(',')+'"');
	sform.submit();  
}

function SelectPos()
{
	var sform = document.patrolform
	var sel = sform.preloc.selectedIndex
	
	if(sform.preloc.selectedIndex == -1)
		return;
	
	if (sform.selloc.options.length >= 40)
	{
    	alert(translator("no_more_than_40_locations"));
    	return;
	}
	
	sform.selloc.options[sform.selloc.options.length] = new Option(sform.preloc.options[sel].text, sform.preloc.options[sel].value, false, false);
	sform.selloc.selectedIndex = sform.selloc.options.length-1;
	sform.seldwelling.options[sform.seldwelling.options.length] = new Option("10", sform.preloc.options[sel].value, false, false);
	sform.seldwelling.selectedIndex = sform.seldwelling.options.length-1;
	sform.dwelling.value = 10;
}

function RemovePos()
{
	var sform = document.patrolform
	var sel = sform.selloc.selectedIndex
	
	if(sel == -1)
		return;
	
	if (sform.selloc.options.length == 0)
		return;
	
	sform.selloc.options[sel] = null
	sform.seldwelling.options[sel] = null
	if (sel < sform.selloc.options.length)
	{
    	sform.selloc.selectedIndex = sel
    	sform.seldwelling.selectedIndex = sel
    }
	else
	{
    	sform.selloc.selectedIndex = sform.selloc.options.length-1
    	sform.seldwelling.selectedIndex = sform.selloc.options.length-1
    }
    if(sform.seldwelling.selectedIndex >= 0)
	{
    	sform.dwelling.value = sform.seldwelling.options[sform.seldwelling.selectedIndex].text
    }
	else
	{
		sform.dwelling.value = ""
	}
}

function UpwardPos()
{
	var tmpText
	var tmpValue
	var sform = document.patrolform
	var sel = sform.selloc.selectedIndex
	
	if(sel == -1)
		return;
	
	if(sel > 0)
	{
    	tmpText = sform.selloc.options[sel].text
    	sform.selloc.options[sel].text = sform.selloc.options[sel-1].text
    	sform.selloc.options[sel-1].text = tmpText
    	
    	tmpText = sform.seldwelling.options[sel].text
    	sform.seldwelling.options[sel].text = sform.seldwelling.options[sel-1].text
    	sform.seldwelling.options[sel-1].text = tmpText
    	
    	tmpValue = sform.selloc.options[sel].value
    	sform.selloc.options[sel].value = sform.selloc.options[sel-1].value
    	sform.selloc.options[sel-1].value = tmpValue
    	
    	tmpValue = sform.seldwelling.options[sel].value
    	sform.seldwelling.options[sel].value = sform.seldwelling.options[sel-1].value
    	sform.seldwelling.options[sel-1].value = tmpValue
    	
    	sform.selloc.selectedIndex = sel-1
    	sform.seldwelling.selectedIndex = sel-1
	}
	if(sform.seldwelling.selectedIndex >= 0)
	{
    	sform.dwelling.value = sform.seldwelling.options[sform.seldwelling.selectedIndex].text
    }
	else
	{
		sform.dwelling.value = ""
	}
}

function DownwardPos()
{
	var tmpText
	var tmpValue
	var sform = document.patrolform
	var sel = sform.selloc.selectedIndex
	
	if(sel == -1)
		return;
	
	if(sel < sform.selloc.options.length-1)
	{
    	tmpText = sform.selloc.options[sel].text
    	sform.selloc.options[sel].text = sform.selloc.options[sel+1].text
    	sform.selloc.options[sel+1].text = tmpText
    	
    	tmpText = sform.seldwelling.options[sel].text
    	sform.seldwelling.options[sel].text = sform.seldwelling.options[sel+1].text
    	sform.seldwelling.options[sel+1].text = tmpText
    	
    	tmpValue = sform.selloc.options[sel].value
    	sform.selloc.options[sel].value = sform.selloc.options[sel+1].value
    	sform.selloc.options[sel+1].value = tmpValue
    	
    	tmpValue = sform.seldwelling.options[sel].value
    	sform.seldwelling.options[sel].value = sform.seldwelling.options[sel+1].value
    	sform.seldwelling.options[sel+1].value = tmpValue
    	
    	sform.selloc.selectedIndex = sel+1
    	sform.seldwelling.selectedIndex = sel+1
	}
	if(sform.seldwelling.selectedIndex >= 0)
	{
    	sform.dwelling.value = sform.seldwelling.options[sform.seldwelling.selectedIndex].text
    }
	else
	{
		sform.dwelling.value = ""
	}
}

function DwellingSave()
{
	var sform = document.patrolform;
	var sel = sform.seldwelling.selectedIndex;
	
	if(sel == -1)
		return;
	//if (sform.seldwelling.options[sel].text != "")
	//{
    	if (checkNumRange(sform.dwelling, 999, 0))
    	{
    		return -1;
    	}
    	sform.seldwelling.options[sel].text = sform.dwelling.value;
    	sform.seldwelling.selectedIndex = sel;
    	sform.selloc.selectedIndex = sel;
	//}
}

function UpdateSel()
{
	var sform = document.patrolform;
	var sel = sform.selloc.selectedIndex;
	
	if(sel == -1)
		return;
	
	sform.seldwelling.selectedIndex = sel;
	sform.dwelling.value = eval(sform.seldwelling.options[sel].text);
}

function UpdateDwelling()
{
    var sform = document.patrolform;
    var sel = sform.seldwelling.selectedIndex;

    if(sel == -1)
        return;
	
    if (sform.selloc.options[sel].text != "")
    {
        sform.selloc.selectedIndex = sel;
        sform.dwelling.value = eval(sform.seldwelling.options[sel].text);                       
    }
}

function KeyPress(evt)
{
    var code = window.event?evt.keyCode:evt.which;
	if (code == 13)
	{
        return false;
	}
}

function switchPTZPanel(value)
{
    if(value == 'mechanical') //mechanical
    {
        if(typeof(WinLessPluginCtrl) != "undefined") $("#" + PLUGIN_ID).attr("PtzURL","/cgi-bin/camctrl/camctrl.cgi");
        $("#eptz_panel").hide();
        $("#select_stream_panel").hide();
        $("#camctrl_panel").show();
    }
    else if(value == 'digital') //digital
    {
		showimage_innerHTML('4', 'showimageBlock', false, false, true);
		setTimeout("addPluginEvent(document.getElementById(PLUGIN_ID), 'VNDPWrapperReady', PTZWinlessReady)", 500);
        $("#eptz_panel").show();
        $("#select_stream_panel").show();
        $("#camctrl_panel").hide();
    }

    if(value != getCookie("activatedmode"))
    {
        setCookie("activatedmode", value);
    }
}

function PTZWinlessReady()
{
	if(typeof(WinLessPluginCtrl) != "undefined") 
		$("#" + PLUGIN_ID).attr("PtzURL","/cgi-bin/camctrl/eCamCtrl.cgi")
}

function switchStream(selectedIndex)
{		
//    var WinlessCtrlObject = document.getElementById(PLUGIN_ID);

    // plugindef.js  begin
    streamsource = selectedIndex;
/*
    eval("VideoSize=videoin_c0_s" + streamsource + "_resolution");
    eval("codectype=videoin_c0_s" + streamsource + "_codectype");
    if (codectype == "mpeg4") 
    eval("AccessName=network_rtsp_s" + streamsource + "_accessname");
    else 
    eval("AccessName=network_http_s" + streamsource + "_accessname");

    // showimage(0)  begin	
    var str_innerHTML = "";

    if (bIsWinMSIE)
    {			
        //To avoid switch streaming source too fast.
        $("#StreamSelector").attr("disabled", true);

        WinlessCtrlObject.Disconnect();
        // The ActiveX plug-in
        
        WinlessCtrlObject.ViewStream  = streamsource;
        WinlessCtrlObject.Stretch = true;

        updateStatus("zoom");
        setTimeout("WinlessCtrlObject.Connect()", 500);
        //WinlessCtrlObject.Connect();
        setTimeout('$("#StreamSelector").attr("disabled", false)', 2000);
    }
    else if (navigator.appName == "Netscape") 
    {
        if (codectype == "mjpeg") 
        {
            thisURL = document.URL;
            http_method = thisURL.split(":");
            if (http_method[0] == "https") 
            {
                str_innerHTML += "<img src=\"https://" + location.host + "/" + AccessName + "\" width=\"" + Width + "\" height=\"" + Height + "\"/>";
            }
            else 
            {
                str_innerHTML += "<img src=\"http://" + location.host + "/" + AccessName + "\" width=\"" + Width + "\" height=\"" + Height + "\"/>";
            }
        }
        else 
        {
            str_innerHTML += "<embed SCALE=\"ToFit\" width=\"" + Width + "\" height=\"" + Height + "\"";
            str_innerHTML += " type=\"video/quicktime\" qtsrc=\"rtsp://" + location.hostname + "/" + AccessName + "\"";
            str_innerHTML += " qtsrcdontusebrowser src=\"/realqt.mov\" autoplay=\"true\" controller=\"true\"\>";
        }
        document.getElementById("showimageBlock").innerHTML = str_innerHTML;
    }
*/
    setCookie("streamsource", selectedIndex);

    //genPresetNameList(); 
    //genPatrolNameList();
    //genPatrolDwellingList();
	/*
	$("#table-preset tbody").empty();
	$("#table-patrol tbody").empty();
	g_delPresetLocSeq = [];
	
	initPrestAndPatrolBlk();
    // Dynamically adjust "left" value because of multilingual issue 
    $("label.overlay").css("left", $("#presetNameID").width() + 15);

    // Show More/Less button if ScrollBar appears.
    presetSclBarDetect();
    patrolSclBarDetect();*/
	document.location.reload()
}

/*
 * For Camera Control (physial)
 */

var camctrl_c0_isptz = 0;//disable ptz
function receivedone()
{
	document.getElementById("content").style.visibility = "visible";
	
	if (capability_ptzenabled != 0) 
	{
		if (camctrl_c0_isptz == 0)
		{
			DisableMode();
		}
		else if (camctrl_c0_isptz == 1)
		{
			//Custom camera doesn't support preset.
			if(uart_i0_ptzdriver != 127 && uart_i0_ptzdriver != 128)
			{
				document.getElementById("preset_position").disabled = false;
			}
			EnableMode(1);
		}
		else if (camctrl_c0_isptz == 2)
		{
			EnableMode(2);
		}
		
	    form = document.cameractrl;
		
		if (form.uart_i0_ptzdriver.length == 2)
		{
			for (var i = 0; i < 20; i++)
			{
				var PtzDrvName = eval('uart_ptzdrivers_i' + i + '_name');
				if (PtzDrvName)
				{
					form.uart_i0_ptzdriver.options[++form.uart_i0_ptzdriver.length-1].text=PtzDrvName;
					form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.length-1].value=i;
				}
				else
				{
					break;
				}
			}
		}
	}
}

function submitform()
{
    form = document.cameractrl;
	/*
	if(checkvalue())
	{
		return;
	}
	*/
	selectedDriver = form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex];
	if (camctrl_c0_isptz == 1 && selectedDriver.value != uart_i0_ptzdriver && uart_i0_ptzdriver!=128 &&uart_i0_ptzdriver!=127)
	{
		if(!confirm(translator("the_preset_locations_will_be_cleared_after_change_the_ptz_driver_do_you_want_to_continue")))
		{
			return;
		}
		else
		{
			uart_i0_ptzdriver = selectedDriver.value;
		}
	}

	if (CheckEmptyString(form.camctrl_c0_cameraid))
	{
		return;
	}
	form.submit();
	
	if (form.rs485setting_2.checked == true)
	{
		uart_i0_ptzdriver = form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex].value;
		camctrl_c0_isptz = 1;
	}
	else
	{
		uart_i0_ptzdriver = 128;
		camctrl_c0_isptz = 0;
	}
	ShowPresetButton();
}

function CheckInputText(InputText)
{
	if (!checkNumberString(InputText))
	{
		InputText.focus();
		return;
	}  
	if (parseInt(InputText.value) > 255 || parseInt(InputText.value) < 0)
	{
		alert(translator("please_input_a_value_between_0_and_255"));
		InputText.focus();
		return;
	}
}

function checkNumberString(instr)
{
    for (i = 0; i < instr.value.length; i++)
	{
        c = instr.value.charAt(i);
        
        if (!(c>='0' && c<='9'))
        {
			alert(translator("please_input_a_valid_value"));
			return 0;
        }
    }

   return 1;
}

function DisableMode()
{
	document.getElementById("ptz_camera").style.display = "none";
	document.getElementById("port_settings").style.display = "none";
	document.getElementById("buttons").style.display = "none";
}

function EnableMode(mode)
{
	if (mode == 1)
	{
		document.getElementById("ptz_camera").style.display = "block";
		document.getElementById("port_settings").style.display = "block";
		document.getElementById("buttons").style.display = "inline";
	}
	else if (mode == 2)
	{
		document.getElementById("ptz_camera").style.display = "none";
		document.getElementById("port_settings").style.display = "block";
		document.getElementById("buttons").style.display = "none";
	}
}

function SubmitCameraType()
{
    form = document.cameractrl;
	if (form.rs485setting_1.checked == true)
	{
		document.getElementById("uart_i0_ptzdriver").value = 128;
		document.getElementById("uart_enablehttptunnel").value = 0;
		// document.getElementById("camctrl_enableptztunnel").value = 0;
		DisableMode();
		ShowPresetButton();
	}
	else if (form.rs485setting_2.checked == true)
	{
		document.getElementById("uart_enablehttptunnel").value = 0;
		EnableMode(1);
	}
	else if (form.rs485setting_3.checked == true)
	{
		document.getElementById("uart_enablehttptunnel").value = 1;
		// document.getElementById("camctrl_enableptztunnel").value = 0;
		EnableMode(2);
	}
}

function openurl_wider(urladdr, h, w)
{
	var subWindow = window.open(urladdr, "","height="+h+",width="+w+",scrollbars=yes, status=yes");
	subWindow.focus();
}

function openCustumCmdPage()
{
    form=document.cameractrl;
    var CustomCmdURI = "/setup/ptz/custom_cmd.html?";

    if (form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex].value == "127")
    {
        CustomCmdURI = CustomCmdURI + "CustomDriver=true";
    }
    else
    {
        CustomCmdURI = CustomCmdURI + "CustomDriver=false";
    }
    openurl_wider(CustomCmdURI, 600, 550);
}

function ShowPresetButton()
{
    form=document.cameractrl;
	selectedDriver = form.uart_i0_ptzdriver.options[form.uart_i0_ptzdriver.selectedIndex];
	if (camctrl_c0_isptz == 1 && selectedDriver.value == uart_i0_ptzdriver && selectedDriver.text != "Custom camera" && selectedDriver.text != "None")
	{
		document.getElementById("preset_position").disabled = false;
	}
	else
	{
		document.getElementById("preset_position").disabled = true;
	}
}

//for new UI
function AddPresetLoc()
{
    var MaxPresetLen = 40;

    if (CheckEmptyString(document.add.addpos_temp) == -1)
	{
		return false;
	}

	if (checkInString(document.add.addpos_temp))
	{
	    return false;	    
	}

    if (document.add.addpos_temp.value.match(',') != null)
	{
        alert(translator("you_have_used_invalid_characters_comma"));
	    return false;	    
	}

    // "--- Select one ---" is a fake preset
    if (document.spdfm.presetLocs.length > MAX_PRESET_COUNT)
    {
        alert(translator("no_more_than_"+ MAX_PRESET_COUNT +"_locations"));
        $("#Submit2_add").attr("disabled", true);
        return false;
    }

    if (CountLength(document.add.addpos_temp.value) > MaxPresetLen)
    {
        alert(translator("the_length_is_over_40_characters"));
        return false;
    }

    for (var i = 0; i < document.spdfm.presetLocs.length; i++)
    {
        if (document.add.addpos_temp.value == document.spdfm.presetLocs.options[i].text)
        {
            alert(translator("the_name_has_already_existed_please_try_another_name_or_delete_the_old_one"));
            return false;
        }
    }
  
//	document.add.addpos.value = document.add.addpos_temp.value.replace(/\$/g, "\\$"); //$$, $var will be replaced by OS as some number
    document.add.addpos.value = document.add.addpos_temp.value;
    //var presetURL = "/cgi-bin/operator/preset.cgi?addpos=" + document.add.addpos.value;
	var presetURL = "/cgi-bin/operator/ePreset.cgi?addpos=" + encodeURI(document.add.addpos.value) + "&stream=" + streamsource + "&return=/setup/ptz/cameracontrol.html";
    document.add.Submit2.disabled=true;

    // adding preset location by AJAX
	$.ajax({
		url: presetURL,
		cache: false,
        beforeSend: function () {
            $("#ajaxLoadIcon").show();
        },
		error: function (xhr) {
			document.add.addpos_temp.value = "";
			document.add.Submit2.disabled = false;
			return; 
		},
		success: function (response) {
			for (i = 0; i < MAX_PRESET_COUNT; ++i)
			{
				if (eval("eptz_c0_s" + streamsource + "_preset_i" + i + "_name") == "")
				{
					eval("eptz_c0_s" + streamsource + "_preset_i" + i + "_name=" + "'" + document.add.addpos.value + "'");
					break;
				}
			}
			var table_preset_rows = document.getElementById('table-preset').rows.length

            $("#sel_gotoPreset").addOption($("#sel_gotoPreset option:last").val() + 1, document.add.addpos.value , false);
            $("#table-preset tbody").append("<tr><td><input id=\"DAUTOID_input_preset_checkbox_" + table_preset_rows + "\"" + " type='checkbox'/></td><td id=\"DAUTOID_td_preset_name_" + table_preset_rows + "\"" + " style='cursor: default;' title='" + document.add.addpos.value + "'>" + document.add.addpos.value + "</td></tr>");
			document.add.addpos_temp.value = "";
			document.add.Submit2.disabled = false;
            $("#addPresetInput").blur();
            $("#ajaxLoadIcon").fadeOut(1000);
            presetSclBarDetect();
			return;
		}
	});

//  document.add.submit();   
}

function presetSclBarDetect() 
{
	if($("#table-preset").height() >= 130)
	{
		$("#btn_adjPresetTbl").show();
	}
	else
	{
		($(".tablescroll_wrapper:eq(0)").hasScrollbar()) ? $("#btn_adjPresetTbl").show() : $("#btn_adjPresetTbl").hide();
	}
}

function patrolSclBarDetect() 
{
	if($("#table-patrol").height() >= 130)
	{
		$("#btn_adjPatrolTbl").show();
	}
	else
	{
		($(".tablescroll_wrapper:eq(1)").hasScrollbar()) ? $("#btn_adjPatrolTbl").show() : $("#btn_adjPatrolTbl").hide();
	}
}

function initPrestAndPatrolBlk()
{
	// Init "add preset location"
    $('label.pre').labelOver('overlay').show();

    // Preset - Select All or Clear
    $("#chk_SelAllPreset").click(function() {
        $(this).attr("checked") ? $("#table-preset :checkbox").attr("checked", true) : $("#table-preset :checkbox").attr("checked", false);
    });

    // Patrol - Select All or Clear
    $("#chk_SelAllPatrol").click(function() {
        $(this).attr("checked") ? $("#table-patrol :checkbox").attr("checked", true) : $("#table-patrol :checkbox").attr("checked", false);
    });

    // Generate Preset table
    var presetItemStr = "";
    for (i = 0; i < MAX_PRESET_COUNT; i ++)
    {
        //var presetName = eval("camctrl_c0_preset_i" + i + "_name");
		
		//add by ken, for eptz
		var presetName = eval("eptz_c0_s" + streamsource + "_preset_i" + i + "_name");
		if (presetName != "")
        {
            presetItemStr += "<tr><td><input id=\"DAUTOID_input_preset_checkbox_"+i+"\" type='checkbox'/></td><td id=\"DAUTOID_td_preset_name_" + i + "\"" + " style='cursor: default;' title='" + presetName + "'>" + presetName + "</td></tr>";
        }
    }
    $("#table-preset tbody").append(presetItemStr);
    
    //Avoid draggin operation on this field.
    $("#table-preset td:odd").live("mousedown", function(){
        return false;
    });

    // Generate Patrol table
    var patrolItemStr = "";
	
	//add by ken, for eptz
	var tmpPatrol = eval("eptz_c0_s"+ streamsource +"_patrolseq").split(',');
	var tmpDwelling = eval("eptz_c0_s"+ streamsource +"_patroldwelling").split(','); 
	
    if (tmpPatrol != "")
    {
        for (i = 0; i < tmpPatrol.length; i ++)
        {
			var patrolName = eval("eptz_c0_s"+ streamsource +"_preset_i"+tmpPatrol[i]+"_name");
			var patrolDwell = tmpDwelling[i];
			
			patrolItemStr += "<tr><td><input id=\"DAUTOID_input_patrol_checkbox_"+i+"\" type='checkbox'/></td><td id=\"DAUTOID_td_patrol_name_" + i + "\"" + "title='"+ patrolName +"'>" + patrolName + "</td><td><input id=\"DAUTOID_td_patrol_dwelling_" + patrolDwell + "\" type='text' style='width:70px;' value='" + patrolDwell + "' maxlength='3'/></td></tr>";
        }
		
		$("#table-patrol tbody").append(patrolItemStr);
    }

    // Make Patrol locations Drag & Drop
    $("#table-patrol").tableDnD({ onDragClass: "myDragClass" });
    if (bIsWinMSIE) $("#table-patrol :checkbox").css("cursor", "default");

    $("#table-patrol tr").live('click', function(){
        $(this).siblings().attr("selected", 0).css("background", "#fff");
        $(this).attr("selected", 1).css("background", "#ccc");
    });

    // Finetune Patrol dwell time layout
    $("#table-patrol :text").css("padding", "0 3px");
}

var g_delPresetLocSeq = [];  // Preset Locations to be deleted!
function delPresetLocs()
{
    $("#table-preset :checked").parent().next().each(function(){
        tmpPresetName = $(this).attr("title");
        g_delPresetLocSeq.push(tmpPresetName);
        //$("#table-patrol tr td:eq(1)").each(function(){//ken :not work?! why??
		$("#table-patrol tr td[title!='']").each(function(){
            if (tmpPresetName == $(this).attr("title")) {
                $(this).parent().remove();
            }
        });
    });

    $("#table-preset :checked").parent().parent().remove();
    $("#btn_adjPresetTbl").click().click(); //force click twice to auto adjust #table-patrol
    $("#chk_SelAllPreset").attr("checked", false);
    presetSclBarDetect();
    patrolSclBarDetect();
}

function delPatrolLocs()
{
    $("#table-patrol :checked").parent().parent().remove();
    $("#btn_adjPatrolTbl").click().click(); //force click twice to auto adjust #table-patrol
    $("#chk_SelAllPatrol").attr("checked", false);
    patrolSclBarDetect();
}

function AddToPatrol()
{
    if ( (MAX_PATROL_COUNT - $("#table-patrol tr").length) < $("#table-preset :checked").length )
    {
		alert(translator("no_more_than_40_locations"));
        return;
    }

    var patrolItemStr = "";
    $("#table-preset :checked").each(function(i, obj){
		var table_preset_rows = document.getElementById('table-patrol').rows.length
        // Insert to Patrol table
        var patrolName = $(obj).parent().siblings().attr("title");
        //Set default dwell time to 5
        var patrolDwell = 5; 
        patrolItemStr += "<tr><td><input id=\"DAUTOID_input_patrol_checkbox_" + table_preset_rows + "\"" + " type='checkbox'/></td><td id=\"DAUTOID_td_patrol_name_" + table_preset_rows + "\"" + " title='" + patrolName +"'>" + patrolName + "</td><td><input id=\"DAUTOID_input_patrol_dwelling_" + table_preset_rows + "\"" + " style='padding: 0 3px; width: 70px;' type='text' value='" + patrolDwell + "' maxlength='3'/></td></tr>";
    });

    $("#table-patrol tbody").append(patrolItemStr);
    
    //Make new item Drag & Drop 
    $("#table-patrol").tableDnD({ onDragClass: "myDragClass" });
    if (bIsWinMSIE) $("#table-patrol :checkbox").css("cursor", "default");

    patrolSclBarDetect();
}

function MoveUp()
{
    var Index = $("#table-patrol tr").index($("#table-patrol tr[selected='1']"));
    if ( -1 == Index) return;

    if ( Index == $("#table-patrol tr").index($("#table-patrol tr:first")) ) return;  // At first place
    $("#table-patrol tr[selected='1']").insertBefore($("#table-patrol tr:eq("+ (Index-1) +")"));
}

function MoveDown()
{
    var Index = $("#table-patrol tr").index($("#table-patrol tr[selected='1']"));
    if ( -1 == Index ) return;

    if ( Index == $("#table-patrol tr").index($("#table-patrol tr:last")) ) return;  // At last place
    $("#table-patrol tr[selected='1']").insertAfter($("#table-patrol tr:eq("+ (Index + 1) +")"));
}

function adjustPatrolTbl(obj)
{
    var currentH = $("div.tablescroll_wrapper:eq(1)").css("height");
    if ("130px" == currentH) 
    {
        if($("#table-patrol").height() <= 130) return;
        $("div.tablescroll_wrapper:eq(1)").css("height", "auto");
        $(obj).val(translator("less"));
    }
    else
    {
        $("div.tablescroll_wrapper:eq(1)").css("height", "130px");
        $(obj).val(translator("more"));
    }
    obj.blur();
}

function adjustPresetTbl(obj)
{
	var currentH = $("div.tablescroll_wrapper:eq(0)").css("height");
    if ("130px" == currentH) 
    {
        if($("#table-preset").height() <= 130) return;
        $("div.tablescroll_wrapper:eq(0)").css("height", "auto");
        $(obj).val(translator("less"));
    }
    else
    {
        $("div.tablescroll_wrapper:eq(0)").css("height", "130px");
        $(obj).val(translator("more"));
    }
    obj.blur();
}

function SubmitPreset(selObj)
{
	for (var i=0; i < selObj.options.length-1; i++)
    {
		if (selObj.options[i].selected)
			break;
    }

	if (selObj.options[i].value == -1)
	{
		return;
	}
	
	var ChannelNo = 0;

	if (getCookie("activatedmode") == "mechanical")
	{
		var CGICmd='/cgi-bin/camctrl/recall.cgi?channel=' + ChannelNo + '&index=' + $(selObj).selectedOptions().val();
	}
	else
	{
		var CGICmd='/cgi-bin/camctrl/eRecall.cgi?stream=' + streamsource + '&recall=' + encodeURIComponent($(selObj).selectedOptions().text());
	}
	
    retframe.location.href=CGICmd;
	// Show ZoomRatio after goto some presetlocation!
	var preset_num = $(selObj).selectedOptions().val();
	setTimeout("ShowPresetZoomRatio("+preset_num+")",1500);
}

function SubmitAll()
{
	/*
    if (checkNumRange($("input[name=camctrl_c0_idleaction_interval]")[0], 999, 1))
	{
		return false;
	}
	*/

    /*
     * To reduce unnecessary param setting, improve cgi speed.
     * Rather than setting from camctrl_c0_patrol_i0_xxx ~ camctrl_c0_patrol_i39_xxx
     */
	var patrolSeqArray = [];
	var patrolDwellingArray = [];
    var patrolSeqParam = "";
    var bError = false;
    $("#table-patrol tr").each(function(idx, obj){
        //patrolSeqParam += "&camctrl_c0_patrol_i"+idx+"_name=" + $(this).find("td:eq(1)").text();
		
		for (i = 0; i < MAX_PRESET_COUNT; i++)
		{
			if (eval("eptz_c0_s" + streamsource + "_preset_i" + i + "_name") == $(this).find("td:eq(1)").attr("title")) 
				patrolSeqArray.push(i);
		}
		
        if (checkNumRange($(this).find(":text")[0], 999, 0))
        {
            bError = true;
            return false; // beak each() loop
        }
		patrolDwellingArray.push($(this).find(":text").val());
		
    });
    if (bError) return false;
	
	patrolSeqParam = "eptz_c0_s" + streamsource + "_patrolseq=" + encodeURIComponent(patrolSeqArray.join(",")) + 
					 "&eptz_c0_s" + streamsource + "_patroldwelling=" + encodeURIComponent(patrolDwellingArray.join(",")) +
					 "&eptz_c0_osdzoom=" + eptz_c0_osdzoom;
	
    /*
     * End
     */

    /*
     * Note: We should set preset.cgi first, then setparam.cgi?camctrl_xxx
     *       Because setparam.cgi?camctrl_c0_patrl_xxx will send SIGUSR1 to ptzctrl,
     *       ptzctrl will reconfig patrol information. 
     *
     *       If we setparam.cgi?camctrl_xxx first, then ptzctrl reconfig still in progress, 
     *       thus PTHIS->szPatrolName is not update to date, 
     *       so it would cause ptzctrl->PTZCTRL_DeletePatrol() miss removing non-exist loations. 
     */

    $("#ajaxLoadIcon2").show();
    //1st. Delete preset locations. 
    if ( "" != g_delPresetLocSeq)
    {
        $.ajax({
            url: "/cgi-bin/operator/ePreset.cgi",
            type: "POST",
            dataType: "script",
            async: false,
            data: "delpos=" + encodeURIComponent(g_delPresetLocSeq.join(',')) + "&stream=" + streamsource,
            beforeSend: function () {
                //$("#ajaxLoadIcon2").show();
            },
            success: function() {
                //window.location="/setup/cameracontrol.html";
            },
            error: function() {
                //called when there is an error
            }
        });
    }

    //2nd. Setting patrol locations and misc settings!
    $.ajax({
        url: "/cgi-bin/admin/setparam.cgi",
        type: "POST",
        dataType: "script",
        //data: patrolSeqParam + "&" + $(document.miscform).serialize(),
		data: patrolSeqParam,
        complete: function() {
            //$("#ajaxLoadIcon2").hide();
        },
        success: function() {
            window.location="/setup/ptz/cameracontrol.html";
        },
        error: function() {
            //called when there is an error
        }
    });
}

function enable_osdzoom()
{
	if (bIsWinMSIE)
    {
		if ($("input:[name=osdzoom]").attr("checked")== true) 
			eptz_c0_osdzoom = 1;
		else
			eptz_c0_osdzoom = 0;
		
	/*	$.ajax({
			url: "/cgi-bin/admin/setparam.cgi",
			type: "POST",
			dataType: "script",
			//data: patrolSeqParam + "&" + $(document.miscform).serialize(),
			data: "eptz_c0_osdzoom="+eptz_c0_osdzoom,
			complete: function() {
				//$("#ajaxLoadIcon2").hide();
			},
			success: function() {
				window.location="/setup/ptz/cameracontrol.html";
			},
			error: function() {
				//called when there is an error
			}
		});*/
	}
}

jQuery.fn.labelOver = function(overClass) {
    return this.each(function(){
        var label = jQuery(this);
        var f = label.attr('for');
        if (f) {
            var input = jQuery('#' + f);
            
            this.hide = function() {
                label.css({ textIndent: -10000 });
                $(this).nextAll(":button").css("visibility", "visible");
            };
            
            this.show = function() {
                if (input.val() == '') {
                    label.css({ textIndent: 0 });
                    $(this).nextAll(":button").css("visibility", "hidden");
                } 
            };

            // handlers
            input.focus(this.hide);
            input.blur(this.show);
            label.addClass(overClass).click(function(){ input.focus(); });
            
            if (input.val() != '') this.hide(); 
        }
    });
};

jQuery.fn.hasScrollbar = function() {
    var scrollHeight = this.get(0).scrollHeight - 2; //2px for Top & Bottom border width

    //safari's scrollHeight includes padding
    if ($.browser.safari)
        scrollHeight -= parseInt(this.css('padding-top')) + parseInt(this.css('padding-bottom'));

    if (this.height() < scrollHeight)
        return true;
    else
        return false;
};
