


var giCH_Curr = 0;
var giTab_Curr = 0;


function loadCurrentSetting()
{	
	giCH_Curr = Number(getCookie("channelsource"));
	
	// capability group
	{
		var capabilityStr="&capability_nvideoin"+"&capability_image"+
		                  "&capability_daynight_c"+giCH_Curr+"_support"+"&capability_daynight_c"+giCH_Curr+"_lightsensor"+
         			  "&capability_image_c"+giCH_Curr+"_remotefocus"+"&capability_image_c"+giCH_Curr+"_focuswindow_nwindow"+
                                  "&capability_image_c"+giCH_Curr+"_lensconfiguration_support"+"&capability_image_c"+giCH_Curr+"_privacymask_wintype"+
				  "&capability_fisheye&capability_ptzenabled";
	}

	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage"+capabilityStr, true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("image");

	$("div.tabs").css("display","block");
		
	loadlanguage();
}

function receivedone()
{
	//Handle channel select.
	if (parseInt(capability_nvideoin, 10) == 1)
	{
		document.getElementById("content").removeChild(document.getElementById("ch_ctrlblk"));
	}
	else
	{
		document.getElementById("ch_sel").length = capability_nvideoin;
		document.getElementById("ch_sel").selectedIndex = giCH_Curr;
	}

	if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_remotefocus") && ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_focuswindow_nwindow"))
	{
		$("#remotefocustab").hide();
	}

	if(ParamUndefinedOrZero("capability_fisheye"))
	{
		$("#pixelcalculatetab").hide();
	}

	if (ParamUndefinedOrZero("capability_image_c"+giCH_Curr+"_lensconfiguration_support"))
	{	
		$("#lensconfigurationtab").hide();
	}

	$('#tab0').append("<iframe id='generalpage_video' src='/setup/media/generalsetting_video.html?ch="+ giCH_Curr +"' width='100%' height='250px' scrolling=no frameborder=0></iframe>");

	dispalyDayNightSettings();

	$('#tab0').append("<iframe id='generalpage_button' src='/setup/media/generalsetting_button.html' width='100%' height='10px' scrolling=no frameborder=0></iframe>");
	tabsUI(0);

}

//TODO
//translator("the_preset_locations_will_be_cleared_after_flip_mirror_do_you_want_to_continue");

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
}

function changeTab(idx)
{

	if (giTab_Curr == parseInt(idx, 10))
	{
		return;
	}

	giTab_Curr = parseInt(idx, 10);
	

	$('.tab-content iframe').attr("src", "");
	$('.tab-content iframe').remove();
	$('#sensortab_outline').remove();
	$('#imagetab_outline').remove();

	if (idx == 0)
	{
		$('#tab0').append("<iframe id='generalpage_video' src='/setup/media/generalsetting_video.html?ch="+ giCH_Curr +"' width='100%' height='250px' scrolling=no frameborder=0></iframe>");

		dispalyDayNightSettings();

		$('#tab0').append("<iframe id='generalpage_button' src='/setup/media/generalsetting_button.html' width='100%' height='10px' scrolling=no frameborder=0></iframe>");
	}
	else if (idx == 1)
	{
		setCookie("imageprofileindex",0);

		// resize button
		$('#tab1').append("<iframe id='resizebutton' src='/setup/media/resizebutton.html' width='100%' height='100px' scrolling='no' frameborder=0></iframe>");

		// view
		$('#tab1').append("<iframe id='viewpage' src='/setup/media/viewpage.html?ch="+ giCH_Curr +"&image' id='viewpage' width='100%' height='100px' scrolling='auto' frameborder=0></iframe>");

		// image profile tab
		$('#tab1').append("<iframe src='/setup/media/imageprofilebutton.html' id='profiletab' width='100%' height='39px' scrolling=no frameborder=0></iframe>")

		// image profile content
		$('#tab1').append("<div id='imagetab_outline' class='tab-content' style='display:none'></div>")
		$('#imagetab_outline').append("<iframe src='/setup/media/image.html?ch="+ giCH_Curr +"' id='imagepage' width='100%' height='100px' scrolling=yes frameborder=0></iframe>");

		// save, restore button
		$('#tab1').append("<iframe src='/setup/media/imagebutton.html' id='imagebutton' width='100%' height='10px' scrolling=no frameborder=0></iframe>");
	}
	else if (idx == 2)
	{
		setCookie("sensorprofileindex",0);

		// resize button
		$('#tab2').append("<iframe id='resizebutton' src='/setup/media/resizebutton.html' width='100%' height='100px' scrolling='no' frameborder=0></iframe>");

		// view 
		$('#tab2').append("<iframe id='viewpage' src='/setup/media/viewpage.html?ch="+ giCH_Curr +"&exposure' id='viewpage' width='100%' height='100px' scrolling='auto' frameborder=0></iframe>");

		// exposure window button
		$('#tab2').append("<iframe src='/setup/media/expwinbutton.html' id='expwinbutton' width='100%' height='35px' scrolling=no frameborder=0 style='display:none'></iframe>")

		// sensor profile tab
		$('#tab2').append("<iframe src='/setup/media/sensorprofilebutton.html' id='profiletab' width='100%' height='39px' scrolling=no frameborder=0></iframe>")

		// sensor profile content
		$('#tab2').append("<div id='sensortab_outline' class='tab-content' style='display:none'></div>")
		$('#sensortab_outline').append("<iframe src='/setup/media/sensor.html?ch="+ giCH_Curr +"' id='exposurepage' width='100%' height='100px' scrolling=yes frameborder=0></iframe>");

		// save, restore button
		$('#tab2').append("<iframe src='/setup/media/sensorbutton.html' id='exposurebutton' width='100%' height='10px' scrolling=no frameborder=0></iframe>");
	}
	else if (idx == 3)
	{
		$('#tab3').append("<iframe src='/setup/media/lens_configuration.html?ch="+ giCH_Curr +"' name='lensconfiguration' width='100%' height='800' scrolling=no frameborder=0></iframe>");
	}
	else if (idx == 4)
	{
		$('#tab4').append("<iframe id='remotefocus' src='/setup/media/focuszoom.html?ch="+ giCH_Curr +"' width='100%' height='780px' scrolling=no frameborder=0></iframe>");
	}
	else if (idx == 5)
	{
		if (eval("capability_image_c"+giCH_Curr+"_privacymask_wintype") == "3Drectangle") 
		{
			if ( isIZ(capability_ptzenabled) == 1)
			{
				$('#tab5').append("<iframe id='privacy' src='/setup/media/privacy3d_iz.html' width='100%' height='450px' scrolling=yes frameborder=0></iframe>");
			}
			else
			{
				$('#tab5').append("<iframe id='privacy' src='/setup/media/privacy3d.html' width='100%' height='450px' scrolling=yes frameborder=0></iframe>");
			}
		}
		else
		{
			$('#tab5').append("<iframe id='privacy' src='/setup/media/privacy.html?ch="+ giCH_Curr +"' width='100%' height='400px' scrolling=no frameborder=0></iframe>");
		}
	}
	else if (idx == 6)
	{
		$('#tab6').append("<iframe src='/setup/media/pixelcount.html' name='pixelcount' width='100%' height='800' scrolling=no frameborder=0></iframe>");
	}

}

function changeChannel(ch)
{
	var iTmp;

	if (parseInt(ch, 10) >= parseInt(eval("capability_nvideoin"), 10))
	{
		return;
	}

	giCH_Curr = ch;
	setCookie("channelsource", giCH_Curr);
	iTmp = giTab_Curr;
	giTab_Curr = 999;

	changeTab(iTmp);

}

function dispalyDayNightSettings()
{
	if (parseInt(eval("capability_daynight_c"+giCH_Curr+"_support"), 10) == 1)
	{
		$('#tab0').append("<iframe id='generalpage_daynight' src='/setup/media/generalsetting_daynight.html?ch="+ giCH_Curr +"' width='100%' height='300px' scrolling=no frameborder=0></iframe>");
	}
}
