//paramters of general form
var g_ipfilter_maxconnection
var g_ipfilter_enable
//paramters of policy form
var g_ipfilter_type
//paramters of admin form
var g_ipfilter_admin_enable
var g_ipfilter_admin_ip

function loadCurrentSetting()
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage&ipfilter&network_ipv6_enable", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("access_list");
	loadlanguage();
}

function receivedone()
{
	document.GeneralSetting.ipfilter_maxconnection.value = ipfilter_maxconnection;
	document.GeneralSetting.original_maxconnection.value = ipfilter_maxconnection;
	showlist();
	loadlist();
	document.getElementById("content").style.visibility = "visible";
	
	g_ipfilter_maxconnection 		= ipfilter_maxconnection
	g_ipfilter_enable				= ipfilter_enable
	//paramters of policy form
	g_ipfilter_type					= ipfilter_type
	//paramters of admin form
	g_ipfilter_admin_enable			= ipfilter_admin_enable	
	g_ipfilter_admin_ip				= ipfilter_admin_ip
}

function showlist()
{
	if (network_ipv6_enable == "1")
	{
		document.getElementById("IPv6List").style.display = "block";
	}
	else
	{
		document.getElementById("IPv6List").style.display = "none";
	}
}
function showConnSt()
{
	weburl = "connection_status.html";
	openWeb(weburl, 500, 300);
}

function prepareAnEntry(anEntry, content)
{
	if (content.length != 0)
	{
		anEntry[0] = true;
		anEntry[1] = content;
	}
}

function loadlist()
{
	for (iCnt = 0; iCnt < 10; iCnt++)
	{
		v4_allow_ip = eval("ipfilter_ipv4list_i" + iCnt);
		prepareAnEntry(aIPv4AllowList[iCnt], v4_allow_ip);
		prepareAnEntry(aIPv6AllowList[iCnt], eval("ipfilter_ipv6list_i" + iCnt));
	}

	updateDynSelOpt(document.ipfilterList.ipv4, aIPv4AllowList);
	updateDynSelOpt(document.ipfilterList.ipv6, aIPv6AllowList);
}

/* load netfilter list */
var aIPv4AllowList = new Array(10);
var aIPv6AllowList = new Array(10);
for (i = 0; i < 10; i ++)
{
	aIPv4AllowList[i] = new Array(false, "", i);
	aIPv6AllowList[i] = new Array(false, "", i);
}

function openWeb(weburl, widthLen, heightLen)
{
	var property = "width=" + widthLen + ", height=" + heightLen + ", scrollbars=yes, status=yes";
	var subWindow = window.open(weburl, "", property);
	subWindow.focus();
}

function addList(ProtocolType)
{
	for (iCnt = 0; iCnt < 10; iCnt++)
	{
		if (ProtocolType == 4)
		{
			ListValue = eval("ipfilter_ipv4list_i" + iCnt);
		}
		else
		{
			ListValue = eval("ipfilter_ipv6list_i" + iCnt);
		}
		if ( ListValue == "")
		{
			weburl = "add" + ProtocolType + "list.html?index=" + iCnt;
			openWeb(weburl, 600, 200);
			break;
		}
	}
	if(iCnt == 10)
	{
		alert(translator("no_more_list_to_enter"));
	}
}

function delList(ProtocolType)
{
	Netform = document.ipfilterList;
	selIndex = eval("Netform.ipv" + ProtocolType + ".selectedIndex");
	if (selIndex >= 0)
	{
		idx = eval("Netform.ipv" + ProtocolType + ".options[selIndex].value");

		if (ProtocolType == 4)
		{
			var msg = "/cgi-bin/admin/ipfilter.cgi?method=delv4&index=" + idx;
		}
		else
		{
			params  = "ipfilter_ipv6list_i" + idx;
			var msg = "/cgi-bin/admin/ipfilter.cgi?method=delv6&index=" + idx;
		}

		XMLHttpRequestObject.open("GET", msg, false);
		XMLHttpRequestObject.send(null);
		window.location.reload();
	}
}

function checkNetfilterAdminIP(adminIP)
{
	if (network_ipv6_enable == "1")
	{
		if (checkIPtableAdmin(adminIP))
			return -1;
	}
	else
	{
		if (checkIPaddr(adminIP))
			return -1;
	}
}

function submitGeneral()
{
	var genForm = document.GeneralSetting;
	if (parseInt(genForm.ipfilter_maxconnection.value) < parseInt(genForm.original_maxconnection.value))
	{
		XMLHttpRequestObject.open("GET", "/cgi-bin/admin/connst.cgi?_a=3&_m=setup/security/accesslist.html", true);
		XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
		XMLHttpRequestObject.send(null);
	}
	genForm.submit();
	genForm.original_maxconnection.value = genForm.ipfilter_maxconnection.value;
}

function submitAdmin()
{
	var adminForm = document.admin;
	var adminIP = adminForm.ipfilter_admin_ip;
	if (document.admin.ipfilter_admin_enable_check.checked)
	{
		if (checkNetfilterAdminIP(adminIP))
			return -1;
	}
	else if (adminIP.value != "")
	{
		if (checkNetfilterAdminIP(adminIP))
		{
			return -1;
		}
	}
	adminForm.submit();
}

function submitPolicy()
{
	if (getCheckedValue(document.policy.ipfilter_type) != ipfilter_type)
	{
		if(!confirm(translator("switch_ipfilter_policy_warning_message")))
		{
			return -1;
		}
	}
	document.policy.submit();
}

function submitAll()
{
	if (document.GeneralSetting.ipfilter_maxconnection.value != g_ipfilter_maxconnection)
	{
		submitGeneral();
		g_ipfilter_maxconnection = document.GeneralSetting.ipfilter_maxconnection.value
		
	}
	
	if (document.policy.ipfilter_enable.value != g_ipfilter_enable)
	{
		submitPolicy();
		g_ipfilter_enable		= document.policy.ipfilter_enable.value
	}
	
	var tempVal;
	if (document.policy.ipfilter_type[0].checked == true)
		tempVal = 0;
	else
		tempVal = 1;
	
	if (tempVal != g_ipfilter_type)
	{
		submitPolicy();
		g_ipfilter_type	= tempVal
	}
			
	if (document.admin.ipfilter_admin_enable.value != g_ipfilter_admin_enable ||
		document.admin.ipfilter_admin_ip.value != g_ipfilter_admin_ip)
	{
		submitAdmin();
		g_ipfilter_admin_enable	= document.admin.ipfilter_admin_enable.value	
		g_ipfilter_admin_ip		= document.admin.ipfilter_admin_ip.value
	}
}
