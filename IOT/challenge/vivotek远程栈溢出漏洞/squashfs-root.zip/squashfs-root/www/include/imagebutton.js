function loadCurrentSetting()
{	
	loadlanguage();
	parent.document.getElementById("imagebutton").height = document.body.scrollHeight;
	document.getElementById("content").style.visibility = "visible";
}

function RestoreButton()
{
	getIframeDocumentById("imagepage").getElementById("imageRestoreButton").click();
}

function SaveButton()
{
	getIframeDocumentById("imagepage").getElementById("imageSaveButton").click();
}

