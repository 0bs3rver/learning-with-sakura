function loadCurrentSetting()
{
        XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam_cache.cgi?system_info_language&system_info_customlanguage", true);
        XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
        XMLHttpRequestObject.send(null);
	Nifty("div#outter-wrapper","small","nonShadow");
	Nifty("div#case","normal","nonShadow");
	document.getElementsByTagName("b")[5].style.position = "relative";
	document.title=translator("parameter_list");
	loadlanguage();
}

