var roi_c0_s3_size; //for DM365
var TRUEWIDTH,TRUEHEIGHT;
var BOXWIDTH, BOXHEIGHT; 
var SNWIDTH, SNHEIGHT; 
var MOBILE_WIDTH = 176, MOBILE_HEIGHT = 144;
var RATIO_X, RATIO_Y;
var JcropObj = null; 
var VIDEO_JPG; //="/cgi-bin/viewer/video.jpg?streamid=2&resolution=400x300&quality=5";
var g_bSmooth = false;
var giCH_Curr = 0;
var gciMode_Curr;

// Interval for refreshImage()
var INTERVAL_snapshot=1000;
var INTERVAL_ROI=5000;

// parameters have already been fetched  
// is $.getJSON needed ?
$.ajaxSetup({ async: false }); 
$.getJSON("/cgi-bin/viewer/getparam.cgi?videoin_c0_crop_size&capability_nmediastream&eptz_c0_s0_preset&videoin_c0_rotate&capability_videoin_c0_rotation")

var CPATURE_SIZE;
var CAPTURE_WIDTH;
var CAPTURE_HEIGHT;
var FULLVIEW_STREAM_INDEX;

$.ajax({
	type: "GET",
	url: "/cgi-bin/viewer/getparam.cgi",
	data: "capability_videoin_c"+giCH_Curr+"&capability_nmediastream",
	dataType: "script",
	async: false,
	cache: false,
	success: function(data){
		gciMode_Curr = eval("capability_videoin_c"+giCH_Curr+"_mode");
		CPATURE_SIZE = eval("capability_videoin_c"+giCH_Curr+"_mode"+gciMode_Curr+"_outputsize");
		CAPTURE_WIDTH = CPATURE_SIZE.split("x")[0];
		CAPTURE_HEIGHT = CPATURE_SIZE.split("x")[1];
		FULLVIEW_STREAM_INDEX = capability_nmediastream - 1;
	}
});

function initEPTZParams(type)
{
    if (type == "global_view")
    {
    	if (CAPTURE_WIDTH*3 == CAPTURE_HEIGHT*4)
    	{
		//console.log("eptz.js CAPTURE_WIDTH = " + CAPTURE_WIDTH + ", CAPTURE_HEIGHT = " + CAPTURE_HEIGHT);
         	SNWIDTH=BOXWIDTH = 160;
       	 	SNHEIGHT=BOXHEIGHT = 120;
    	}
    	else
    	{
			if ((0 != capability_videoin_c0_rotation) && (videoin_c0_rotate == 90 || videoin_c0_rotate == 270))
			{
				SNWIDTH=BOXWIDTH = 160;
				SNHEIGHT=BOXHEIGHT = 90;
			}
			else
			{
				SNWIDTH=BOXWIDTH = 160;
				SNHEIGHT=BOXHEIGHT = 90;
			}
	}
    }
    else //cropping_setting & viewing_window
    {
        //in order to let RATIO_X00x1200 mapping to 400x300 correctly, we use 400x300(RATIO_X=4) rather than 320x240(RATIO_X=5)
		//Max cap size is 2560x1920
        if (CAPTURE_WIDTH*3 == CAPTURE_HEIGHT*4)
        {
        	SNWIDTH=BOXWIDTH = 400;
        	SNHEIGHT=BOXHEIGHT = 300;
        }
    	else
    	{
        	SNWIDTH=BOXWIDTH = 400;
        	SNHEIGHT=BOXHEIGHT = 250;
    	}
    }
    
    if ((type == "cropping_setting") || (type == "exposure_window"))  //cropping setting always use fullsize
    {
        TRUEWIDTH = CAPTURE_WIDTH;
        TRUEHEIGHT = CAPTURE_HEIGHT;
    }
    else
    {
	    TRUEWIDTH = CAPTURE_WIDTH;
	    TRUEHEIGHT = CAPTURE_HEIGHT;
	    /*
        if (videoin_c0_options == "framerate") 
        {
            TRUEWIDTH = 800;
            TRUEHEIGHT = 600;
        }
        else if (videoin_c0_options == "quality") 
        {
            TRUEWIDTH = CAPTURE_WIDTH;
            TRUEHEIGHT = CAPTURE_HEIGHT;
        }
        else if (videoin_c0_options == "crop") //normalize BOXWIDTH & BOXHEIGHT to fit the window
        {
            TRUEWIDTH=videoin_c0_crop_size.split('x')[0];
            TRUEHEIGHT=videoin_c0_crop_size.split('x')[1];
            if (BOXWIDTH * TRUEHEIGHT <= BOXHEIGHT * TRUEWIDTH)
            {
                SNHEIGHT=BOXHEIGHT=parseInt(BOXWIDTH * TRUEHEIGHT / TRUEWIDTH);
                //TI DM365 platform limitation, width&height should >= 64
                if (SNHEIGHT <= 64)
                {
                    SNHEIGHT=64;
                    SNWIDTH=parseInt(BOXHEIGHT * TRUEWIDTH / TRUEHEIGHT);
                }
            } 
            else
            {
                BOXWIDTH=parseInt(BOXHEIGHT * TRUEWIDTH / TRUEHEIGHT);
                if (type == "viewing_window")  //cropping setting always use fullsize
                {
                    SNWIDTH = 400
                    SNHEIGHT=parseInt(SNWIDTH * TRUEHEIGHT / TRUEWIDTH);
                }
                else
                {
                    SNWIDTH=160;
                    SNHEIGHT=parseInt(SNWIDTH * TRUEHEIGHT / TRUEWIDTH);
                }
            }
        }
	*/
    }
	//console.log("before swapped: BOXWIDTH = " + BOXWIDTH + ", BOXHEIGHT = " + BOXHEIGHT);
	//console.log("before swapped: TRUEWIDTH = " + TRUEWIDTH + ", TRUEHEIGHT = " + TRUEHEIGHT);
	RATIO_X = TRUEWIDTH/BOXWIDTH;
	RATIO_Y = TRUEHEIGHT/BOXHEIGHT;

	if ((0 != capability_videoin_c0_rotation) && (videoin_c0_rotate == 90 || videoin_c0_rotate == 270))
	{
		TEMPSWAPVALUE=SNWIDTH=BOXWIDTH;
		SNWIDTH=BOXWIDTH=SNHEIGHT=BOXHEIGHT;
		SNHEIGHT=BOXHEIGHT=TEMPSWAPVALUE;
		
		TEMPSWAPVALUE=RATIO_X;
		RATIO_X=RATIO_Y;
		RATIO_Y=TEMPSWAPVALUE;
		
		TEMPSWAPVALUE=MOBILE_WIDTH;
		MOBILE_WIDTH=MOBILE_HEIGHT;
		MOBILE_HEIGHT=TEMPSWAPVALUE;
		
		TEMPSWAPVALUE=TRUEWIDTH;
		TRUEWIDTH=TRUEHEIGHT;
		TRUEHEIGHT=TEMPSWAPVALUE;

		//console.log("SNWIDTH = " + SNWIDTH + "; BOXWIDTH = " + BOXWIDTH);
		//console.log("SNHEIGHT = " + SNHEIGHT + "; BOXHEIGHT = " + BOXHEIGHT);
		//console.log("RATIO_X= " + RATIO_X + "; RATIO_Y = " + RATIO_Y);
    	VIDEO_JPG="/cgi-bin/viewer/video.jpg?streamid="+FullviewStreamIndex()+"&resolution="+ SNHEIGHT*2 +"x"+ SNWIDTH*2 +"&quality=5";        
	}
	else
	{
    	VIDEO_JPG="/cgi-bin/viewer/video.jpg?streamid="+FullviewStreamIndex()+"&resolution="+ SNWIDTH*2 +"x"+ SNHEIGHT*2 +"&quality=5";
	}
    //VIDEO_JPG="/cgi-bin/viewer/video.jpg?streamid=2&resolution="+ SNWIDTH +"x"+ SNHEIGHT +"&quality=5";

    RATIO_X = TRUEWIDTH/BOXWIDTH;
    RATIO_Y = TRUEHEIGHT/BOXHEIGHT;
    roi_c0_s3_size = TRUEWIDTH + "x" + TRUEHEIGHT;
}

var bImgLoaded = true;
function refreshImage(video_jpg)
{
    //Ensure GV show image in the order of timestamp
    if (bImgLoaded == false) return;
    var img = new Image();
    var date = new Date();

    img.onload = function(){
        bImgLoaded = true;
        $('.jcrop-hline:eq(0)').prev().attr('src', img.src);
        $("#cropbox").attr('src', img.src);
        //Log("Snapshot completed on : %s",date);
        imgComplete();
    };
    img.onerror = function(){ imgComplete(); };
    img.onabort = function(){ imgComplete(); };

    imgComplete = function(){
        img.onload=null;
        img.onerror=null;
        img.onabort = null;
        img = null; //add this line to prevent memory leak?
        bImgLoaded = true;
        //Log("Snapshot completed on : %s",date);
    };

    img.src = video_jpg + "&date=" + date;
    bImgLoaded = false;
}

function ePTZControl(movetype, param)
{
    if(JcropObj && g_bSmooth) //used in Index.html
    {
        g_bPreventResend = false;
        var coordsData;
        var panspeed  = (parseInt($("#camctrl_c0_panspeed").val()) + 6)*RATIO_X;
        var tiltspeed = (parseInt($("#camctrl_c0_tiltspeed").val()) + 6)*RATIO_X;
        var zoomspeed = 1.05 + (parseInt($("#camctrl_c0_zoomspeed").val()) + 6)*0.05; // -5 ~ +5 : 1.05 ~ 1.55

        var now_coords = JcropObj.tellSelect(); 
        now_x = now_coords.x;
        now_y = now_coords.y;
        now_w = now_coords.w;
        now_h = now_coords.h;

        if (movetype == "move")
        {
            switch( param)
            {
                case "up":
                    correct_y = parseInt(now_y - tiltspeed);
                    if (correct_y <= 0 ) correct_y = 0;
                        coordsData = "x=" + now_x + "&y=" + correct_y + "&w=" + now_w + "&h=" + now_h;
                    break;
                case "down":
                    correct_y = parseInt(now_y + tiltspeed);
                    if ((correct_y + now_h) >= CAPTURE_HEIGHT) correct_y = CAPTURE_HEIGHT - now_h; 
                        coordsData = "x=" + now_x + "&y=" + correct_y + "&w=" + now_w + "&h=" + now_h;
                    break;
                case "left":
                    correct_x = parseInt(now_x - panspeed);
                    if (correct_x <= 0 ) correct_x = 0;
                        coordsData = "x=" + correct_x + "&y=" + now_y + "&w=" + now_w + "&h=" + now_h;
                    break;
                case "right":
                    correct_x = parseInt(now_x + panspeed);
                    if ((correct_x + now_w) >= CAPTURE_WIDTH) correct_x = CAPTURE_WIDTH - now_w; 
                        coordsData = "x=" + correct_x + "&y=" + now_y + "&w=" + now_w + "&h=" + now_h;
                    break;
                case "home":
                    coordsData = "x=" + ROI_X + "&y=" + ROI_Y + "&w=" + ROI_W + "&h=" + ROI_H;
                    break;
            } 
        }
        else if(movetype == 'zoom')
        {
            switch (param)
            {
                case "wide":
                    coordsData = "x=" + parseInt(now_x - now_w*(zoomspeed-1)/2) + 
                                "&y=" + parseInt(now_y - now_h*(zoomspeed-1)/2) + 
                                "&w=" + parseInt(now_w * zoomspeed) + 
                                "&h=" + parseInt(now_h * zoomspeed);
                        break;
                case "tele":
                    if (dZoomRatio >= 4) { return; } //At most 4X digital-zoom
                    coordsData = "x=" + parseInt(now_x + now_w*(zoomspeed-1)/2) + 
                                "&y=" + parseInt(now_y + now_h*(zoomspeed-1)/2) + 
                                "&w=" + parseInt(now_w / zoomspeed) + 
                                "&h=" + parseInt(now_h / zoomspeed);
                    dZoomRatio = VideoSize.split('x')[0] / parseInt(now_w / zoomspeed);
                    if (dZoomRatio >= 4) //limit to 4X digital-zoom
                    { 
                        g_bSmooth = false;
                        ePTZControl("zoom","tele");
                        g_bSmooth = true;
                        return;
                    } 
                    break;
            }
        }
        else if (movetype == "auto")
        {	
            var CGICmd='/cgi-bin/camctrl/eCamCtrl.cgi?stream=' + streamsource + '&auto=' + param;
            parent.retframe.location.href=CGICmd;
            Log("Send: %s", CGICmd);
            return;
        }
        Log("Smooth moving to %s", coordsData);
        g_bRefreshROI = false; //add this to force smooth moving work
        parseCoords(coordsData.replace(/&/g,",")); //coordsData example=> x=170&y=80&w=640&h=480
    }
    else //non-Smooth
    {
		if (movetype == "sethome")
        {
			if (param == "define" )
			{
				$.ajax({
					url: "/cgi-bin/camctrl/eCamCtrl.cgi?stream=" + streamsource,
					async: false,
					dataType: "script",
					success: function(data){
						//Log("getparam?roi: %s",data);
						eval(data);
					}
				});	
				if (checkIsRotate(giCH_Curr))
				{
					eval(swap('x', 'y'));
					eval(swap('w', 'h'));
				}
			}
			else if (param == "default")
			{
				x=0;
				y=0;
				w=CAPTURE_WIDTH;
				h=CAPTURE_HEIGHT;
			}
			home_param = "roi_c0_s"+streamsource+"_home=" + x + "," + y;
			size_param = "roi_c0_s"+streamsource+"_size=" + w + "x" + h;

			$.ajax({
				url: "/cgi-bin/admin/setparam.cgi",
				async: true,
				cache: false,
				data: home_param + "&" + size_param,
				beforeSend: function()
				{
					//$("#currentStateBlock").show().html("<img src='/pic/ajax-loader.gif'/>");
				},
				success: function(data)
				{ 
					//$('#currentStateBlock').fadeOut(1000);
					//g_CustomSelectionText = $("select[name='ROI_S" + g_streamsource + "'] option[value='" + CUSTOMINDEX + "']")[0].text; 
					//eval(data);
					//Log("Return from setting viewing window:",data);
				}
			});
		}
		else 
		{
		
			g_bPreventResend = true;
			CGICmd='/cgi-bin/camctrl/eCamCtrl.cgi?stream=' + streamsource + '&' + movetype + '=' + param;
	
			Log("SEND: %s",CGICmd);
			$.ajax({
				url: CGICmd,
				cache: false,
				async: true, 
				success: function(data){
					Log("Return value from ePTZ.cgi => %s",data);
					if (JcropObj && movetype != 'auto')
					{
						g_bRefreshROI = false; //add this to execute JcropObj.setSelect rather than JcropObj.animateTo
						parseCoords(data); 
					}
					DisplayZoomRatio(data);
				}
			});
		}
    }
}


var dZoomRatio = 1;
function DisplayZoomRatio(data)
{
    var coords = data.split(',');
    NewVideoSize_W = parseInt(coords[2].split('=')[1]);
	if ((0 != capability_videoin_c0_rotation) && (videoin_c0_rotate == 90 || videoin_c0_rotate == 270))
	{
		//console.log("rotated VideoSize.split('x')[1] = " + VideoSize.split('x')[1] + ", NewVideoSize_W = " + NewVideoSize_W);
		dZoomRatio = CAPTURE_HEIGHT / NewVideoSize_W;
	}
	else
	{
		dZoomRatio = CAPTURE_WIDTH / NewVideoSize_W;
	}
	
    Log("dZoomRatio = %f", dZoomRatio);

    //if (eptz_c0_osdzoom == 0) return;
    if(typeof(PLUGIN_ID) != "undefined" && eptz_c0_osdzoom == 1) // for IE
    {
        //PLUGIN_ID.DisplayStringOnVideo param
        zoomText = "x" + dZoomRatio.toFixed(1);
        fontSize = 25;
        eFontStyle = 1; //Regular:0, Bold:1, Italic:2, Underline:4, Strikeout:8
        X = 30;
        Y = 35;
        fontColorR = 255;
        fontColorG = 255;
        fontColorB = 255;
        outlineColorR = 0;
        outlineColorG = 0;
        outlineColorB = 0;
		
        if(dZoomRatio > 1) // for IE
        {
			$("#digitalZoomRatio").text(zoomText).css({
				"font-size":fontSize, 
				"left":X+"px", 
				"top":Y+"px",
				"color": "rgb(" + fontColorR +"," + fontColorG + "," + fontColorB +")" 
			});
			
			switch (eFontStyle)
			{
				case 1:
					$("#digitalZoomRatio").css({"font-weight":"bold", "font-style":"normal", "text-decoration":"none"});
					break;
				case 2:
					$("#digitalZoomRatio").css({"font-weight":"noraml", "font-style":"italic", "text-decoration":"none"});
					break;
				case 4:
					$("#digitalZoomRatio").css({"font-weight":"noraml", "font-style":"normal", "text-decoration":"underline"});
					break;
				default:
					$("#digitalZoomRatio").css({"font-weight":"normal", "font-style":"normal", "text-decoration":"none"});
			}
			/*
			try {
                PLUGIN_ID.DisplayStringOnVideo(zoomText, fontSize, eFontStyle, X, Y, fontColorR, fontColorG, fontColorB, outlineColorR, outlineColorG, outlineColorB);
            }catch(e){console.log(e)}
			*/
        }
        else
        {
			$("#digitalZoomRatio").html("");
			/*
            try {
                PLUGIN_ID.DisplayStringOnVideo("", fontSize, eFontStyle, X, Y, fontColorR, fontColorG, fontColorB, outlineColorR, outlineColorG, outlineColorB);
            }catch(e){}
			*/
        }
    }
}

function ShowPresetZoomRatio(preset_num)
{
	var preset_pos=eval("eptz_c0_s"+streamsource+"_preset_i"+preset_num+"_pos").split(',');
	var preset_size=eval("eptz_c0_s"+streamsource+"_preset_i"+preset_num+"_size").split('x');
	var x = preset_pos[0];
	var y = preset_pos[1];
	var w = preset_size[0];
	var h = preset_size[1];
	var data = ("x = "+x+", y = "+y+", w = "+w+", h = "+h);
	DisplayZoomRatio(data);
}

function updateStatus(type)
{
   $.ajax({
       url: "/cgi-bin/camctrl/eCamCtrl.cgi?stream=" + streamsource,
       async: true,
       cache: false,
       success: function(data){
           Log("[updateStatus] return => %s",data);
           if (type == "zoom")
               DisplayZoomRatio(data);
           else
		   parseCoords(data); //Also upate the latest ROI for GlobalView */
       }
    });
}

var DM365_MPEG4_HEIGHT_LIMIT=984;
function Normalize(num, multiple)
{
    return parseInt(num/multiple)*multiple;
}
