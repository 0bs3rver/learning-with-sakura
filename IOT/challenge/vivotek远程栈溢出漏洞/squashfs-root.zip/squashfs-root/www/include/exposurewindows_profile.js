﻿//EP_WINDOW_NUMBER and EP_Window_selected is for non-IE(WIN) only
var EP_WINDOW_NUMBER = 10;
var EP_Window_selected = -1; // serve as the first element or selected element to show the Exposure Windowss page default window_name.
var bModifyWin = false;

var g_a320x240_EPW_width = new Array(EP_WINDOW_NUMBER) ;
var g_a320x240_EPW_height = new Array(EP_WINDOW_NUMBER) ;
var g_a320x240_EPW_left = new Array(EP_WINDOW_NUMBER) ;
var g_a320x240_EPW_top = new Array(EP_WINDOW_NUMBER) ;

var g_w_ratio;
var g_h_ratio;

var	ori_EPWindowWidth = 320;
var	ori_EPWindowHeight = 240;


function winless_loadCurrentSetting()
{
	loadlanguage();
	showimage_innerHTML('8', 'showimageBlock', false, true, false);
	$("#showimageBlock").append("<div id='EPWinContainer'></div>");
	
	//defauil plug-in border size
	tmpHeight=434;
	tmpWidth=550;
	$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
	$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);	

	if (bIsWinMSIE || ffversion >= 3)
	{
		//openChannel()
		$("#StreamContainer").addClass("StreamContainerStyle");

		/*
		 * create temporay EP window div block.
		 */
		var window_string = translator("window") + " ";
		for (i = 0; i < EP_WINDOW_NUMBER; i++)
		{
			$("#EPWinContainer").append(""
				+ '<div id="EPWindow' + i + '" class="EPW_style">'
				+ '<div class="EPW_drag">'
				+ '<span title="" class="EPW_title">' + window_string + i + '</span>'
				+ '<a class="ui-dialog-titlebar-close" href="#"><span>X</span></a>'
				+ '</div>'
				+ '</div>');
		}

		// BLC window setting
		$("#showimageBlock").append(""
			+ '<div id="BLCWindow" class="BLC_style">'
			+ '<div style="text-align: center;">'
			+ '<span class="BLC_title">BLC</span></div></div>');

		/*
		 * initial EP Window by jQueryUI, enable resizable and draggable
		 */
		$('.EPW_style').resizable({
			containment: "#EPWinContainer",
			//helper: "proxy",
			handles: 'all',
			autoHide: true,
			minWidth: 50,
			minHeight: 50,
			resize: function(e, ui)
			{
				var self = $(this).data("resizable");
				//It makes the real exposure window in the real straming window
				if(self.position.top < 3) self.position.top = 3;
				if(self.position.left < 3) self.position.left = 3;

				//if(self.size.height > Height+22) self.size.height = Height+22;
				//if(self.size.width > Width) self.size.width = Width;

				//$("#log-top").html(self.position.top + "px");
				//$("#log-left").html(self.position.left + "px");
				$("#log-height").html(self.size.height + "px");
				$("#log-width").html(self.size.width + "px");
				bModifyWin = true;
			},
			stop: function(e, ui)
			{
				var self = $(this).data("resizable");

				realHeight = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("height")) - 22);
				realWidth = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("width")) -4);
				realTop = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("top")) -3);
				realLeft = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("left")) -3);
				
				g_a320x240_EPW_width[EP_Window_selected] = Math.round(parseInt( realWidth/g_w_ratio )) ;
				g_a320x240_EPW_height[EP_Window_selected] = Math.round(parseInt( realHeight/g_h_ratio )) ;
				g_a320x240_EPW_left[EP_Window_selected] = Math.round(parseInt( realLeft/g_w_ratio )) ;
				g_a320x240_EPW_top[EP_Window_selected] = Math.round(parseInt( realTop/g_h_ratio ));; 
				
				//change ep win info for all mode
				EPWinLenTransfer(EP_Window_selected, realWidth, realHeight);
				EPWinPosTransfer(EP_Window_selected, realLeft, realTop);
				
				//eval('exposurewin_c0_profile_i0_win_i' + EP_Window_selected + '_size = exposurewin_size');
				
				//for preview
				exposurewin_size = g_a320x240_EPW_width[EP_Window_selected] + "x" + g_a320x240_EPW_height[EP_Window_selected];
				exposurewin_home = g_a320x240_EPW_left[EP_Window_selected] + "," + g_a320x240_EPW_top[EP_Window_selected];
				$.ajax({
					type: "POST",
					cache: false,
					url: "/cgi-bin/admin/setparam.cgi",
					data: "exposurewin_c0_profile_i0_win_i" + EP_Window_selected + "_size=" + exposurewin_size +
							"&exposurewin_c0_profile_i0_win_i" + EP_Window_selected +  "_home=" + exposurewin_home
				});
			}
		})
		.draggable({
			cursor: 'move',
			handle: 'div',
			containment: "#EPWinContainer",
			drag: function(e, ui)
			{
				var self = $(this).data("draggable");

				if(self.position.top < 3) self.position.top = 3;
				if(self.position.left < 3) self.position.left = 3;

				WinHeight = parseInt($("#EPWindow" + EP_Window_selected).css("height"));
				WinWidth = parseInt($("#EPWindow" + EP_Window_selected).css("width"));


				if (self.position.left + WinWidth > $("#"+PLUGIN_ID).width() - 3){
					self.position.left = $("#"+PLUGIN_ID).width() - 3 - WinWidth;
				}
				if (self.position.top + WinHeight >  $("#"+PLUGIN_ID).height() -3){
					self.position.top = $("#"+PLUGIN_ID).height() - 3 - WinHeight;
				}	

				$("#log-top").html(self.position.top + "px");
				$("#log-left").html(self.position.left + "px");
				bModifyWin = true;
			},
			stop: function()
			{
				var self = $(this).data("draggable");
				
				realHeight = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("height")) - 22);
				realWidth = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("width")) -4);
				realTop = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("top")) -3);
				realLeft = Math.round(parseInt($("#EPWindow" + EP_Window_selected).css("left")) -3);
			
				g_a320x240_EPW_width[EP_Window_selected] = Math.round(parseInt( realWidth/g_w_ratio )) ;
				g_a320x240_EPW_height[EP_Window_selected] = Math.round(parseInt( realHeight/g_h_ratio )) ;
				g_a320x240_EPW_left[EP_Window_selected] = Math.round(parseInt( realLeft/g_w_ratio )) ;
				g_a320x240_EPW_top[EP_Window_selected] = Math.round(parseInt( realTop/g_h_ratio ));; 

				//change ep win info for all mode
				EPWinLenTransfer(EP_Window_selected, realWidth, realHeight);
				EPWinPosTransfer(EP_Window_selected, realLeft, realTop);
				//eval('exposurewin_c0_profile_i0_win_i' + EP_Window_selected + '_home = exposurewin_home');
				
				//for preview
				exposurewin_size = g_a320x240_EPW_width[EP_Window_selected] + "x" + g_a320x240_EPW_height[EP_Window_selected];
				exposurewin_home = g_a320x240_EPW_left[EP_Window_selected] + "," + g_a320x240_EPW_top[EP_Window_selected];

				$.ajax({
					type: "POST",
					cache: false,
					url: "/cgi-bin/admin/setparam.cgi",
					data: "exposurewin_c0_profile_i0_win_i" + EP_Window_selected + "_size=" + exposurewin_size + 
							"&exposurewin_c0_profile_i0_win_i" + EP_Window_selected +  "_home=" + exposurewin_home
				});
			}
		}).css("display","none");
	}

	startclock();
}

var time_shift = 0;
function winless_receivedone()
{
	initEPTZParams("exposure_window");

	var pc_now = new Date().getTime();
	var system_now = new Date;
	system_now.setFullYear(parseInt(system_date.split('/')[0],10))
	system_now.setMonth(parseInt(system_date.split('/')[1],10)-1)
	system_now.setDate(parseInt(system_date.split('/')[2],10))
	system_now.setHours(parseInt(system_time.split(':')[0],10))
	system_now.setMinutes(parseInt(system_time.split(':')[1],10))
	system_now.setSeconds(parseInt(system_time.split(':')[2],10))
	time_shift = -(pc_now - system_now); // get the negative value

	//document.getElementById("content").style.visibility = "visible";
}

function winless_loadvaluedone()
{
	if (bIsWinMSIE || ffversion >= 3)
	{
		$('.EPW_style').mousedown(function(e){
			var index = $(this).attr("id").charAt(8);
			EP_Window_selected = index;

			// when EP Window onfocus, change the color of the title and border
			$(this).siblings().find(".EPW_drag").css("border-bottom-color","#ccc"); //set all EPW to default color
			$(this).siblings(":not('#EPWindow11,#EPWindow21,#EPWindow31, #Canvas_temp, #Canvas_real, #Canvas_highlight')").css("borderColor","#ccc"); //set all EPW border to default color
			$(this).siblings(".EPW_style").css("z-index",1);
			$(this).css("z-index",100);
			$(this).find(".EPW_title").css("font-weight","bolder");
			/*
			for (i = 0; i < EP_WINDOW_NUMBER; i++)
			{
				if (eval('exposurewin_c0_profile_i0_win_i'+i+'_enable') == '1' && eval('exposurewin_c0_profile_i0_win_i'+i+'_policy') == '0')
				{
					$('#EPWindow'+ i).find(".EPW_drag").css("backgroundColor","#999");
					$('#EPWindow'+ i).css("backgroundColor","#999");
				}
			}*/
		});

		/* EP window clsoe action*/
		$('.ui-dialog-titlebar-close').click(function(){
			EP_Window_selected = $(this).parent().parent().attr("id").charAt(8);
			$(this).parent().parent().hide();
			//eval('exposurewin_c0_profile_i0_win_i' + EP_Window_selected + '_enable = 0');
			//eval('exposurewin_c0_profile_i0_win_i' + EP_Window_selected + '_policy = 0');
			//eval('exposurewin_c0_profile_i0_win_i' + EP_Window_selected + '_home = 110,80');
			//default_win_size = "100x75";
			//eval('exposurewin_c0_profile_i0_win_i' + EP_Window_selected + '_size = default_win_size');
			
			//for preview
			var params = "";
			params = "exposurewin_c0_profile_i0_win_i"+ EP_Window_selected +"_enable=0&"+
					 "exposurewin_c0_profile_i0_win_i"+ EP_Window_selected +"_policy=0&"+
					 "exposurewin_c0_profile_i0_win_i"+ EP_Window_selected +"_home=110,80&"+
					 "exposurewin_c0_profile_i0_win_i"+ EP_Window_selected +"_size=100x75";

			$.ajax({
				type: "POST",
				cache: false,
				url: "/cgi-bin/admin/setparam.cgi",
				data: params
			});
			
			//Back to Initial exposure window setting
			g_a320x240_EPW_width[EP_Window_selected] = 100;
			g_a320x240_EPW_height[EP_Window_selected] = 75;
			g_a320x240_EPW_left[EP_Window_selected] = 110;
			g_a320x240_EPW_top[EP_Window_selected] = 80;

			realWidth =  Math.round(parseInt(g_a320x240_EPW_width[EP_Window_selected] * g_w_ratio));
			realHeight = Math.round(parseInt(g_a320x240_EPW_height[EP_Window_selected] * g_h_ratio));
			realLeft =   Math.round(parseInt(g_a320x240_EPW_left[EP_Window_selected]* g_w_ratio));
			realTop =    Math.round(parseInt(g_a320x240_EPW_top[EP_Window_selected]* g_h_ratio));

			//change ep win info for all mode
			EPWinLenTransfer(EP_Window_selected, realWidth, realHeight);
			EPWinPosTransfer(EP_Window_selected, realLeft, realTop);


			EP_Window_selected = getEPWCandidate();
			if (EP_Window_selected != -1)
			{
				$('#EPWindow'+ EP_Window_selected).mousedown();  //force this window to be foucs after the curent one is closed	
			}
			else
			{
				EP_Window_selected = -1;
			}
			
			$("#btnNewInclude").attr("disabled", false);
			$("#btnNewExclude").attr("disabled", false);

			bModifyWin = true;
		})

		//Initial Exposure windows, loading size and position of all EP_Window
		
		for (i = 0; i < EP_WINDOW_NUMBER; i++)
		{
			g_a320x240_EPW_width[i]  = parseInt(eval('exposurewin_c0_profile_i0_win_i' + i + '_size').split('x')[0]);
			g_a320x240_EPW_height[i] = parseInt(eval('exposurewin_c0_profile_i0_win_i' + i + '_size').split('x')[1]);
			g_a320x240_EPW_left[i]   = parseInt(eval('exposurewin_c0_profile_i0_win_i' + i + '_home').split(',')[0]);
			g_a320x240_EPW_top[i]    = parseInt(eval('exposurewin_c0_profile_i0_win_i' + i + '_home').split(',')[1]);

/* This will be done in switchView function			
			$('#EPWindow'+i).css({
				width	: g_a320x240_EPW_width[i] +'px',
				height	: g_a320x240_EPW_height[i] + 20 + 'px',
				top		: g_a320x240_EPW_top[i] +3+'px',
				left	: g_a320x240_EPW_left[i] +3+'px',
				display: (eval('exposurewin_c0_profile_i0_win_i'+i+'_enable') == '0')?"none":"block"
			})
*/			

			if (eval('exposurewin_c0_profile_i0_win_i'+i+'_policy') == '0')
			{
				$('#EPWindow'+i).css("filter","alpha(Opacity=75)").css("opacity","0.75").css("-moz-opacity","0.75");
				$('#EPWindow'+i).find(".EPW_drag").css("backgroundColor","#0066FF");
				$('#EPWindow'+i).css("borderColor","#CCCCCC");
				$('#EPWindow'+i).css("backgroundColor","#999");
				$('#EPWindow'+i).find(".EPW_title").html(translator("exclude"));
			}
			else
			{
				$('#EPWindow'+i).find(".EPW_title").html(translator("include"));
			}
		}

		//set the 1st exist EPW to be focused
		EP_Window_selected = getEPWCandidate();
		if(EP_Window_selected != '-1')  //EP Window exists.
		{
			$('#EPWindow'+ EP_Window_selected).mousedown();
		}

		// BLC window setting
		$('#BLCWindow').css("display", (eval('videoin_c0_profile_i0_enableblc') == '0')? "none" : "block");
		$('#BLCWindow').css("filter","alpha(Opacity=75)").css("opacity","0.75").css("-moz-opacity","0.75");
		$('#BLCWindow').css("borderColor","#CCCCCC");
		$('#BLCWindow').css("backgroundColor","transparent");
		
		switchView($("button.viewstyle:[title*='Auto-Fit']")[0], "Auto", true);

		if (checkEPWindowNumer() == -1)
		{
			$("#btnNewInclude").attr("disabled", true);
			$("#btnNewExclude").attr("disabled", true);
		}
		else
		{
			$("#btnNewInclude").attr("disabled", false);
			$("#btnNewInclude").attr("disabled", false);
		}
	}
}

function initS3GVMode()
{
	$("#s2_fsCb").click(function(){
		if (g_bS2FullScene == false) 
		{
			JcropObj.setAspectRatio(BOXWIDTH/BOXHEIGHT);
			JcropObj.setMinSize([BOXWIDTH, BOXHEIGHT]);
			JcropObj.setSelect([0, 0, BOXWIDTH, BOXHEIGHT]);
			g_bS2FullScene = true;
		}
		else
		{
			JcropObj.setAspectRatio(MOBILE_WIDTH/MOBILE_HEIGHT);
			JcropObj.setMinSize([MOBILE_WIDTH/RATIO_X, MOBILE_HEIGHT/RATIO_Y]);
			JcropObj.setSelect([0, 0, BOXWIDTH, BOXHEIGHT]);
			g_bS2FullScene = false;
		}
	});
}

function checkEPWindowNumer()
{
	for (i = 0; i < EP_WINDOW_NUMBER; i++)
	{
		if (eval('exposurewin_c0_profile_i0_win_i' + i + '_enable') == '0')
		{
			return i;
		}
	}
	return -1;
}

function getFirstFreeWindow()
{
	for (i = 0; i < EP_WINDOW_NUMBER; i++) 
	{
		/*
		if (eval('exposurewin_c0_profile_i0_win_i' + i + '_enable') == '0')
		{
			return i;
		}
		*/
		if ($("#EPWindow" + i).css("display") == "none")
			return i;
	}
	return -1;
}

function getEPWCandidate()
{
	for (i = 0; i < EP_WINDOW_NUMBER; i++) 
	{
		if (eval('exposurewin_c0_profile_i0_win_i' + i + '_enable') == '1')
		{
			return i;
		}
	}
	return -1;
}

function addIncludeWindow()
{
	var freeWindowIndex = getFirstFreeWindow();
	var window_string = translator("include");

	if (freeWindowIndex == -1)
	{
		return -1;
	}
	else
	{
		EP_Window_selected = freeWindowIndex;
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_enable = 1');
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_policy = 1');
		//var new_exp_home = "110,80";
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_home = new_exp_home');
		var new_exp_size = "100x75";
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_size = "' + new_exp_size + '"');

		var ep_rect;

		switch(g_mode)
		{
			case 'Auto':
				ep_rect = g_auto_ep_rect;
				break;
			case '100':
				ep_rect = g_100_ep_rect;
				break;
			case '50':
				ep_rect = g_50_ep_rect;
				break;
			case '25':
				ep_rect = g_25_ep_rect;
				break;
			default:
				//alert('Do nothing now');
				break;
		}

		$('#EPWindow'+ freeWindowIndex).css({
			"width"	: ep_rect[freeWindowIndex][0] + 4 +"px",
			"height": ep_rect[freeWindowIndex][1] + 22 +"px",
			"left"	: ep_rect[freeWindowIndex][2] + 3 + "px",
			"top"	: ep_rect[freeWindowIndex][3] + 3 + "px",
			"opacity": "0.9"
		}).show().mousedown();
		$('#EPWindow'+ freeWindowIndex).css("background-color", "transparent");
		$('#EPWindow'+ freeWindowIndex).find(".EPW_drag").css("backgroundColor","transparent");
		$('#EPWindow'+ freeWindowIndex).find(".EPW_title").html(window_string);
	}
	bModifyWin = true;
	
	//for preview
	var params = "";
	params = "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_enable=1&"+
			 "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_policy=1&"+
			 "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_home=110,80&"+
			 "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_size=" + new_exp_size;

	$.ajax({
		type: "POST",
		cache: false,
		url: "/cgi-bin/admin/setparam.cgi",
		data: params
	});
	
	//disable new when no free window.
	if (getFirstFreeWindow() < 0)
	{
		$("#btnNewInclude").attr("disabled", true);
		$("#btnNewExclude").attr("disabled", true);
	}

}

function addExcludeWindow()
{
	var freeWindowIndex = getFirstFreeWindow();
	var window_string = translator("exclude");

	if (freeWindowIndex == -1)
	{
		return -1;
	}
	else
	{
		EP_Window_selected = freeWindowIndex;
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_enable = 1');
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_policy = 0');
		//var new_exp_home = "110,80";
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_home = new_exp_home');
		var new_exp_size = "100x75";
		//eval('exposurewin_c0_profile_i0_win_i' + freeWindowIndex + '_size = "' + new_exp_size + '"');

		var ep_rect;

		switch(g_mode)
		{
			case 'Auto':
				ep_rect = g_auto_ep_rect;
				break;
			case '100':
				ep_rect = g_100_ep_rect;
				break;
			case '50':
				ep_rect = g_50_ep_rect;
				break;
			case '25':
				ep_rect = g_25_ep_rect;
				break;
			default:
				//alert('Do nothing now');
				break;
		}

		$('#EPWindow'+ freeWindowIndex).css({
			"width"				: ep_rect[freeWindowIndex][0] + 4 +"px",
			"height"			: ep_rect[freeWindowIndex][1] + 22 +"px",
			"left"				: ep_rect[freeWindowIndex][2] + 3 + "px",
			"top"				: ep_rect[freeWindowIndex][3] + 3 + "px",
			"background-color"	: "#999",
			"opacity"			: "0.75"
		}).show().mousedown().find(".EPW_title").html(window_string);
	}
	bModifyWin = true;
	
	//for preview	
	var params = "";
	params = "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_enable=1&"+
			 "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_policy=0&"+
			 "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_home=110,80&"+
			 "exposurewin_c0_profile_i0_win_i"+ freeWindowIndex +"_size=" + new_exp_size;

	$.ajax({
		type: "POST",
		cache: false,
		url: "/cgi-bin/admin/setparam.cgi",
		data: params
	});
	
	//disable new when no free window.
	if (getFirstFreeWindow() < 0)
	{
		$("#btnNewInclude").attr("disabled", true);
		$("#btnNewExclude").attr("disabled", true);
	}

}

function saveEPWindow()
{
	if(checkvalue())
	{
		return -1;
	}

	var params = "";
	for (i = 0; i < EP_WINDOW_NUMBER; i++) 
	{
		params += "exposurewin_c0_profile_i0_win_i"+ i +"_enable="+ eval("exposurewin_c0_profile_i0_win_i"+i+"_enable")+"&"+
			"exposurewin_c0_profile_i0_win_i"+ i +"_policy="+ eval("exposurewin_c0_profile_i0_win_i"+ i +"_policy")+"&"+
			"exposurewin_c0_profile_i0_win_i"+ i +"_home="+ eval("exposurewin_c0_profile_i0_win_i"+ i +"_home")+"&"+
			"exposurewin_c0_profile_i0_win_i"+ i +"_size="+ eval("exposurewin_c0_profile_i0_win_i"+ i +"_size")+"&";
	};

	$.ajax({
		type: "POST",
		cache: false,
		url: "/cgi-bin/admin/setparam.cgi",
		data: params,
		success: function(){
			alert(translator("save_window_completed"));
		},
		error: function(){
			alert(translator("save_window_failed"));
		}
	});
	bModifyWin = false;
}

function showtime()
{
	var channel = new XMLHttpRequest();
	channel.multipart = true;
	var url = "/cgi-bin/viewer/serverPush2.cgi";

	channel.onload = function(e)
	{
		var message;

		message = this.responseText;
		$("#comet_div").html(message);
	}

	channel.onerror = function()
	{
		alert("stop get datetime")
	}

	channel.open('GET', url, true);
	channel.send(null);
}

/*
 * current System time
 */

var timerID = null;
var timerRunning = false;
function stopclock()
{
	if (timerRunning)
		clearTimeout(timerID);
	timerRunning = false;
}

function showtime()
{
	var now = new Date();
	now.setTime(now.getTime() + time_shift);
	var hours = now.getHours();
	var minutes = now.getMinutes()
	var seconds = now.getSeconds();

	var dateValue = now.getFullYear() + "/" + parseInt(now.getMonth()+1) + "/" + now.getDate();
	var timeValue = "" + ((hours > 12) ? hours - 12 : hours);
	if (timeValue == "0") timeValue = 12;
	timeValue += ((minutes < 10) ? ":0" : ":") + minutes
	timeValue += ((seconds < 10) ? ":0" : ":") + seconds
	timeValue += (hours >= 12) ? " P.M." : " A.M."
	$("#comet_div").html(dateValue + " " +timeValue);
	timerID = setTimeout("showtime()", 1000);
	timerRunning = true;
}

function startclock()
{
	stopclock();
	showtime();
}

var g_aspectRatio = 1;
function switchView(obj, param, bForce)
{
	var bOverSize = false;

	// 1: 100%, 2: Best-fit, 3: 50%, 4: 25%
	// +------------------------------+
	// | $(window).height();          |
	// | $(window).width();           |
	// | $(document).height();        |
	// | $(document).wdith();         |
	// +------------------------------+


	// Reset default state, except "4:3" btn
	$(".viewstyle:gt(0)").attr("disabled", false).each(function(){
		posObj = $(this).css("backgroundPosition").split(" ");
		$(this).css("backgroundPosition", posObj[0] + " 0px");
	});
	// set selected button state
	var posObj = $(obj).css("backgroundPosition").split(" ");
	$(obj).css("backgroundPosition", posObj[0] + " -36px").attr("disabled", true);


	Log("$(window).height()=" + $(window).height()       +
		", $(window).width()=" + $(window).width()       +
		", $(document).height()=" + $(document).height() +
		", $(document).wdith()=" + $(document).width());

	//Video Server, use D1, 4CIF.. as VideoSize param, so we need to do some modification here.
	if (system_info_firmwareversion.match(/VS/) != null)
	{
		var VideoSizeW = Width;
		var VideoSizeH = Height;
	}
	else
	{
		var VideoSizeW = VideoSize.split('x')[0];
		var VideoSizeH = VideoSize.split('x')[1];
	}

	var bStretch = true;

	// default value: 100%
	var tmpHeight = Height + Y_OFFSET;
	var tmpWidth = Width + X_OFFSET;

	// Mainly used for Video Server 4:3 mode! Other models don't need this!
	// **********************************************************************
	var evalByAspectRatio = function(destVar, srcVar1, srcVar2)
	{
		if (destVar.match(/tmpWidth/) != null)
		{
			if (g_aspectRatio == 1)
				tmpWidth = srcVar1 + X_OFFSET;
			else
				tmpWidth = srcVar2 * g_aspectRatio + X_OFFSET;
		}
		else
		{
			if (g_aspectRatio == 1)
				tmpHeight = srcVar1 + Y_OFFSET;
			else
				tmpHeight = srcVar2 / g_aspectRatio + Y_OFFSET;
		}
	};
	// **********************************************************************
	var ep_rect;
	
	switch(param)
	{
		case 'Auto':
			tmpWidth = 550;
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");
			
			//ep transfer
			g_mode = 'Auto';

			g_w_ratio = (tmpWidth - X_OFFSET) / ori_EPWindowWidth;
			g_h_ratio = (tmpHeight - Y_OFFSET) / ori_EPWindowHeight;

			var arrar_length = g_auto_ep_rect.length ;
			for (i = 0; i < arrar_length; i++)
				g_auto_ep_rect.pop();

			for (i = 0; i < EP_WINDOW_NUMBER; i++)
			{
				{
					g_auto_ep_rect.push([ Math.round(parseInt( g_a320x240_EPW_width[i]* g_w_ratio)), 
							Math.round(parseInt( g_a320x240_EPW_height[i]* g_h_ratio)), 
							Math.round(parseInt( g_a320x240_EPW_left[i] * g_w_ratio)), 
							Math.round(parseInt( g_a320x240_EPW_top[i] * g_h_ratio))]);
				}
			}
			ep_rect = g_auto_ep_rect;
			// BLC window setting
			$('#BLCWindow').css({
				width:  (ori_EPWindowWidth  *  0.5) * g_w_ratio + (2+2) + 'px',
				height: (ori_EPWindowHeight *  0.5) * g_h_ratio + (2+18+2) + 'px',
				left:   (ori_EPWindowWidth  * 0.25) * g_w_ratio + (5-2) + 'px',
				top:    (ori_EPWindowHeight * 0.25) * g_h_ratio + (20+5-2) +'px'
			})
			break;
		case '100':
			g_vsRatio = 1;
			Width = parseInt(Width, 10);
			Height = parseInt(Height, 10);
			tmpWidth = Width + X_OFFSET;
			if (tmpWidth > 550)
			{
				tmpWidth = 550;
				bOverSize = true;
			}
			else
			{
				tmpWidth = 550;
				bOverSize = false;
			}
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");
			
			//ep transfer
			g_mode = '100';
			if (Width < tmpWidth && Height < tmpHeight)
			{
				g_w_ratio = (tmpWidth - X_OFFSET) / ori_EPWindowWidth;
				g_h_ratio = (tmpHeight - Y_OFFSET) / ori_EPWindowHeight;
			}
			else
			{
				g_w_ratio = Width / ori_EPWindowWidth;
				g_h_ratio = Height / ori_EPWindowHeight;
			}

			var arrar_length = g_100_ep_rect.length ;
			for (i = 0; i < arrar_length; i++)
				g_100_ep_rect.pop();

			for (i = 0; i < EP_WINDOW_NUMBER; i++)
			{
				g_100_ep_rect.push([ Math.round(parseInt( g_a320x240_EPW_width[i]* g_w_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_height[i]* g_h_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_left[i] * g_w_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_top[i] * g_h_ratio))]);
			}
			ep_rect = g_100_ep_rect;
			// BLC window setting
			$('#BLCWindow').css({
				width:  (ori_EPWindowWidth  *  0.5) * g_w_ratio + (2+2) + 'px',
				height: (ori_EPWindowHeight *  0.5) * g_h_ratio + (2+18+2) + 'px',
				left:   (ori_EPWindowWidth  * 0.25) * g_w_ratio + (5-2) + 'px',
				top:    (ori_EPWindowHeight * 0.25) * g_h_ratio + (20+5-2) +'px'
			})
			break;
		case '50':
			g_vsRatio = 1/2;
			tmpWidth = Width/2 + X_OFFSET;
			if (tmpWidth > 550)
			{
				tmpWidth = 550;
				bOverSize = true;
			}
			evalByAspectRatio("tmpHeight", (tmpWidth - X_OFFSET) * (Height/Width), tmpWidth);
			$(window).unbind("resize");
			
			//ep transfer
			g_mode = '50';
			g_w_ratio = (Width / 2) / ori_EPWindowWidth;
			g_h_ratio = (Height / 2) /  ori_EPWindowHeight;

			var arrar_length = g_50_ep_rect.length ;
			for (i = 0; i < arrar_length; i++)
				g_50_ep_rect.pop();
				
			for (i = 0; i < EP_WINDOW_NUMBER; i++)
				{
				g_50_ep_rect.push([  Math.round(parseInt( g_a320x240_EPW_width[i]* g_w_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_height[i]* g_h_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_left[i] * g_w_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_top[i] * g_h_ratio))]);
			}
			ep_rect = g_50_ep_rect;
			// BLC window setting
			$('#BLCWindow').css({
				width:  (ori_EPWindowWidth  *  0.5) * g_w_ratio + (2+2) + 'px',
				height: (ori_EPWindowHeight *  0.5) * g_h_ratio + (2+18+2) + 'px',
				left:   (ori_EPWindowWidth  * 0.25) * g_w_ratio + (5-2) + 'px',
				top:    (ori_EPWindowHeight * 0.25) * g_h_ratio + (20+5-2) +'px'
			})
			break;
		case '25':
			g_vsRatio = 1/4;
			tmpWidth = Width/4+ X_OFFSET;
			evalByAspectRatio("tmpHeight", Height/4, Width/4);
			$(window).unbind("resize");
			
			//ep transfer
			g_mode = '25';
			g_w_ratio = (Width / 4) / ori_EPWindowWidth;
			g_h_ratio = (Height / 4) / ori_EPWindowHeight;

			var arrar_length = g_25_ep_rect.length ;
			for (i = 0; i < arrar_length; i++)
				g_25_ep_rect.pop();

			for (i = 0; i < EP_WINDOW_NUMBER; i++)
			{
				g_25_ep_rect.push([  Math.round(parseInt( g_a320x240_EPW_width[i] * g_w_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_height[i] * g_h_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_left[i] * g_w_ratio)), 
						Math.round(parseInt( g_a320x240_EPW_top[i] * g_h_ratio))]);
			}
			ep_rect = g_25_ep_rect;
			// BLC window setting
			$('#BLCWindow').css({
				width:  (ori_EPWindowWidth  *  0.5) * g_w_ratio + (2+2) + 'px',
				height: (ori_EPWindowHeight *  0.5) * g_h_ratio + (2+18+2) + 'px',
				left:   (ori_EPWindowWidth  * 0.25) * g_w_ratio + (5-2) + 'px',
				top:    (ori_EPWindowHeight * 0.25) * g_h_ratio + (20+5-2) +'px'
			})
			break;
		default:
			alert('Do nothing now');
			break;
	}
	
	//change all ep win
	for (i = 0; i < EP_WINDOW_NUMBER; i++)
	{
		$('#EPWindow' + i).css({
			width: 	Math.round(ep_rect[i][0] + (2+2) )+ 'px',
			height: Math.round(ep_rect[i][1] + (2+18+2) )+ 'px',
			left:  	Math.round(ep_rect[i][2] + (5-2) )+'px',
			top:  	Math.round(ep_rect[i][3] + (20+5-18-2) )+'px'		
		});
	}

	if(bIsWinMSIE)
		$("#"+PLUGIN_ID)[0].Stretch = bStretch;

	if (param == "100")
	{
		if (bOverSize == true)
		{
			$("#"+PLUGIN_ID).attr("height", parseInt(Height)+Y_OFFSET).height(parseInt(Height)+Y_OFFSET);
			$("#"+PLUGIN_ID).attr("width", parseInt(Width)+X_OFFSET).width(parseInt(Width)+X_OFFSET);
		}
		else
		{
			$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
			$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
		}	
	}
	else if (param == "50")
	{	
		if (bOverSize == true)
		{
			  $("#"+PLUGIN_ID).attr("height", Height/2 + Y_OFFSET).height(Height/2 + Y_OFFSET);
			  $("#"+PLUGIN_ID).attr("width", Width/2 + X_OFFSET).width(Width/2 + X_OFFSET);		  
		}
		else
		{
			  $("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
			  $("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);
		}	
	}
	else
	{	
		$("#"+PLUGIN_ID).attr("height", tmpHeight).height(tmpHeight);
		$("#"+PLUGIN_ID).attr("width", tmpWidth).width(tmpWidth);	
	}
	
	$("#EPWinContainer").height($("#"+PLUGIN_ID).height()).width($("#"+PLUGIN_ID).width());	
	if (bOverSize == false)
		$("#showimageBlock").height(tmpHeight).width(tmpWidth).css("overflow","hidden");
	else	
	$("#showimageBlock").height(tmpHeight).width(tmpWidth).css("overflow","auto");
	
}

var g_mode = "Auto"
var g_auto_ep_rect = [];
var g_100_ep_rect = [];
var g_50_ep_rect = [];
var g_25_ep_rect = [];

function EPWinLenTransfer(ep_num, w, h)
{
	switch(g_mode)
	{
	case 'Auto':
		g_auto_ep_rect[ep_num][0] = w;
		g_auto_ep_rect[ep_num][1] = h;
		break;
	case '100':
		g_100_ep_rect[ep_num][0] = w;
		g_100_ep_rect[ep_num][1] = h;
		break;
	case '50':
		g_50_ep_rect[ep_num][0] = w;
		g_50_ep_rect[ep_num][1] = h;
		break;
	case '25':
		g_25_ep_rect[ep_num][0] = w;
		g_25_ep_rect[ep_num][1] = h;
		break;
	default:
		//alert('Do nothing now');
		break;
	}
	
	if (g_auto_ep_rect.length != 0 && g_mode != "Auto")
	{
		g_auto_ep_rect[ep_num][0] = w * $("#showimageBlock").width() / $("#"+PLUGIN_ID).width();
		g_auto_ep_rect[ep_num][1] = h * $("#showimageBlock").height() / $("#"+PLUGIN_ID).height();
	}
	if (g_100_ep_rect.length != 0 && g_mode != "100")
	{
		g_100_ep_rect[ep_num][0] = w * Width / $("#"+PLUGIN_ID).width();
		g_100_ep_rect[ep_num][1] = h * Height / $("#"+PLUGIN_ID).height();
	}
	if (g_50_ep_rect.length != 0 && g_mode != "50")
	{
		g_50_ep_rect[ep_num][0] = w * (Width / 2) / $("#"+PLUGIN_ID).width();
		g_50_ep_rect[ep_num][1] = h * (Height / 2) / $("#"+PLUGIN_ID).height();
	}
	if (g_25_ep_rect.length != 0 && g_mode != "25")
	{
		g_25_ep_rect[ep_num][0] = w * (Width / 4) / $("#"+PLUGIN_ID).width();
		g_25_ep_rect[ep_num][1] = h * (Height / 4) / $("#"+PLUGIN_ID).height();
	}
}

function EPWinPosTransfer(ep_num, l, t)
{
	switch(g_mode)
	{
	case 'Auto':
		g_auto_ep_rect[ep_num][2] = l;
		g_auto_ep_rect[ep_num][3] = t;
		break;
	case '100':
		g_100_ep_rect[ep_num][2] = l;
		g_100_ep_rect[ep_num][3] = t;
		break;
	case '50':
		g_50_ep_rect[ep_num][2] = l;
		g_50_ep_rect[ep_num][3] = t;
		break;
	case '25':
		g_25_ep_rect[ep_num][2] = l;
		g_25_ep_rect[ep_num][3] = t;
		break;
	default:
		//alert('Do nothing now');
		break;
	}
	
	if (g_auto_ep_rect.length != 0 && g_mode != "Auto")
	{
		g_auto_ep_rect[ep_num][2] = l * $("#showimageBlock").width() / $("#"+PLUGIN_ID).width();
		g_auto_ep_rect[ep_num][3] = t * $("#showimageBlock").height() / $("#"+PLUGIN_ID).height();
	}
	if (g_100_ep_rect.length != 0 && g_mode != "100")
	{
		g_100_ep_rect[ep_num][2] = l * Width / $("#"+PLUGIN_ID).width();
		g_100_ep_rect[ep_num][3] = t * Height / $("#"+PLUGIN_ID).height();
	}
	if (g_50_ep_rect.length != 0 && g_mode != "50")
	{
		g_50_ep_rect[ep_num][2] = l * (Width / 2) / $("#"+PLUGIN_ID).width();
		g_50_ep_rect[ep_num][3] = t * (Height / 2) / $("#"+PLUGIN_ID).height();
	}
	if (g_25_ep_rect.length != 0 && g_mode != "25")
	{
		g_25_ep_rect[ep_num][2] = l * (Width / 4) / $("#"+PLUGIN_ID).width();
		g_25_ep_rect[ep_num][3] = t * (Height / 4) / $("#"+PLUGIN_ID).height();
	}
}
