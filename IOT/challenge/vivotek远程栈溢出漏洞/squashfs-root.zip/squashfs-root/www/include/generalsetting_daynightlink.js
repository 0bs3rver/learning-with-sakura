function loadCurrentSetting()
{	
	loadlanguage();
	document.getElementById("content").style.visibility = "visible";
}

function switchToExposureTab()
{
	window.top.$("#exposuretab").click();
}
