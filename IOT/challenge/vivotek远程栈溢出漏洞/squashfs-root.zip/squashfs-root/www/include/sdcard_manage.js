percent_temp = 0;
var smartsd_lifetime_rate = "";
var smartsd_spare_block_rate = "";

function loadCurrentSetting()
{	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info_language&system_info_customlanguage&network_http_port&vadp_module&capability_localstorage_smartsd", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("sd_card_management");
	
	loadlanguage();
}

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
	var hideArray = new Array();
	
	if (ParamUndefinedOrZero("capability_localstorage_smartsd"))
	{
		document.getElementById("SmartSDSpare").style.display = "none";
		document.getElementById("SmartSDLifetime").style.display = "none";
	}
	else
	{
		if( ParamUndefinedOrZero("smartsd_attached"))
		{
			document.getElementById("SmartSDSpare").style.display = "none";
			document.getElementById("SmartSDLifetime").style.display = "none";
		}
	}
	
	
	/*
	hideArray.push("daynightChild");
	hideArray.push("SDCtrlChild");
	
	jQuery.each(hideArray, function(i) { 
		$("#" + hideArray[i]).css("display","none");
	});
	*/
}

function updateSDStatus(param)
{
	if ("status" == param)
	{
		$.ajax({
			url: "/cgi-bin/admin/lsctrl.cgi?cmd=queryStatus&retType=javascript",
			async: false,
			cache: false,
			success: function (data)
			{
				eval(data);
		document.write("<span title=\"symbol\">"+ disk_i0_cond +"</span>");
	}
		});
	}
	else if ("filesystem" == param)
	{
		$.ajax({
			url: "/cgi-bin/admin/getSDfilesystem.cgi",
			async: false,
			cache: false,
			success: function (data)
			{
				document.write("<span title=\"symbol\">"+ data +"</span>");
			}
		});
	}
}

var bFormatSD = false;
function clearVadpParam(idxArray)
{
	var params = "cmd=remove&idx=" + idxArray;
		$.ajax({
			type: "POST",
			url: "/cgi-bin/admin/vadpctrl.cgi",
			data: params, 
			cache: false
		});
}

function isVadpModuleExist()
{
	var SD_PATH="/mnt/auto/CF";
	var bVadpEnable = false;
	var bSaveInSD = false;
	var params = "";

	for (idx = 0; idx < 10; idx++)
	{
		var modulePath = eval("vadp_module_i" + idx + "_path")
		var moduleEnable = eval("vadp_module_i" + idx + "_enable")

		if (modulePath.indexOf(SD_PATH) != -1)
		{
			bSaveInSD = true;

			if (moduleEnable == 1)
			{
				bVadpEnable = true;
			}

			params += idx + ",";
		}
	}

	if (bVadpEnable)
	{
		alert(translator("vadp_module_enabled_please_disable_it"));
		return 1;
	}
	else if (bSaveInSD)
	{
		if (confirm(translator("all_data_will_be_erased_includeing_vadp")))
		{
			bFormatSD = true;
			clearVadpParam(params);
		}
		bSaveInSD = false;
		return 1;
	}

	return 0;
}

function formatsd()
{
	var fstype;
		
	if(disk_i0_cond == "detached")
	{
		bFormatSD = true;
	}
	else if (!isVadpModuleExist())
	{
		if (confirm(translator("all_data_in_sd_will_be_clear_after_format")))
		{
        	if ( document.getElementById("SDFormatList").value == "ext4" )
        	{
        		if(confirm(translator("ext_file_system_not_support_windows")))
				{
		        	bFormatSD = true;
				}
        	}
        	else
        	{
			bFormatSD = true;
		}
	}
	}

	if (bFormatSD)
	{
		bFormatSD = false;
        if ( document.getElementById("SDFormatList").value == "fat32" )
		{
			fstype = "fat32";
		}
		else
		{
			fstype = "ext4";
		}
		document.getElementById("FormatSDBtn").disabled = "disabled";
		$.ajax({
				type: "POST",
				url: "/cgi-bin/admin/formatSD.cgi",
				data: "alerten=1" + "&fstype=" + fstype,
				cache: false
			});
        showFormatSdNotification();
    }
}

function showFormatSdNotification()
{
	var board = document.getElementById("progress_bar");
	var bFormatErr = false;
	
	document.getElementById("notification").style.display = "block";
	
	$.ajax({
		url: "/cgi-bin/admin/formatMsg.cgi",
		async: false,
		cache: false,
		success: function(data){
			if ( !isNaN(data) )
			{
				if (parseInt(data) > percent_temp)
				{
					for (var i =0; i < (parseInt(data) - percent_temp); i++)
					{
						board.value = board.value + "|";
					}
					percent_temp = parseInt(data);
				}	
			}
			else
			{
				alert(translator(data));
				bFormatErr = true;	
			}
			return;
		}
	});
	//console.log("percent_temp="+percent_temp);
	if (percent_temp >= 1000)
	{
		setTimeout("window.location.reload()", 1000);
	}
	else if (bFormatErr == true)
	{
		window.location.reload();
	}
	else
	{
		setTimeout("showFormatSdNotification()", 500);
	}
}

function submitform()
{
	var form = document.localstorage;
    
	if(checkNumRange(form.disk_i0_autocleanup_maxage, 999, 1))
	{
		return -1;
	}
	else
	{
		form.submit();
	}
}
