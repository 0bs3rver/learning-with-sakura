/*

File: AC_QuickTime.js

Abstract: This file contains functions to generate OBJECT and EMBED tags for QuickTime content.

Version: <1.2>

Disclaimer: IMPORTANT:  This Apple software is supplied to you by Apple
Computer, Inc. ("Apple") in consideration of your agreement to the
following terms, and your use, installation, modification or
redistribution of this Apple software constitutes acceptance of these
terms.  If you do not agree with these terms, please do not use,
install, modify or redistribute this Apple software.

In consideration of your agreement to abide by the following terms, and
subject to these terms, Apple grants you a personal, non-exclusive
license, under Apple's copyrights in this original Apple software (the
"Apple Software"), to use, reproduce, modify and redistribute the Apple
Software, with or without modifications, in source and/or binary forms;
provided that if you redistribute the Apple Software in its entirety and
without modifications, you must retain this notice and the following
text and disclaimers in all such redistributions of the Apple Software. 
Neither the name, trademarks, service marks or logos of Apple Computer,
Inc. may be used to endorse or promote products derived from the Apple
Software without specific prior written permission from Apple.  Except
as expressly stated in this notice, no other rights or licenses, express
or implied, are granted by Apple herein, including but not limited to
any patent rights that may be infringed by your derivative works or by
other works in which the Apple Software may be incorporated.

The Apple Software is provided by Apple on an "AS IS" basis.  APPLE
MAKES NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION
THE IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE, REGARDING THE APPLE SOFTWARE OR ITS USE AND
OPERATION ALONE OR IN COMBINATION WITH YOUR PRODUCTS.

IN NO EVENT SHALL APPLE BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE, REPRODUCTION,
MODIFICATION AND/OR DISTRIBUTION OF THE APPLE SOFTWARE, HOWEVER CAUSED
AND WHETHER UNDER THEORY OF CONTRACT, TORT (INCLUDING NEGLIGENCE),
STRICT LIABILITY OR OTHERWISE, EVEN IF APPLE HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

Copyright © 2006-2007 Apple Computer, Inc., All Rights Reserved

*//*
 * This file contains functions to generate OBJECT and EMBED tags for QuickTime content. 
 *//************** LOCALIZABLE GLOBAL VARIABLES ****************/function AC_QuickTimeVersion(){return gQTGeneratorVersion}function _QTComplain(e,t){t=t.replace("%%",e),alert(t)}function _QTIsMSIE(){var e=navigator.userAgent.toLowerCase(),t=/msie/.test(e)&&!/opera/.test(e);return t}function _QTGenerateBehavior(){return objTag='<!--[if IE]><object id="'+gQTBehaviorID+'" classid="clsid:CB927D12-4FF7-4a9e-A169-56E4B8A75598"></object>'+"<![endif]-->"}function _QTPageHasBehaviorObject(e,t){var n=!1,r=document.getElementsByTagName("object");for(var i=0,s;s=r[i];i++)if(s.getAttribute("classid")=="clsid:CB927D12-4FF7-4a9e-A169-56E4B8A75598"){s.getAttribute("id")==gQTBehaviorID&&(n=!1);break}return n}function _QTShouldInsertBehavior(){var e=!1;return gQTEventsEnabled&&_QTIsMSIE()&&!_QTPageHasBehaviorObject()&&(e=!0),e}function _QTAddAttribute(e,t,n){var r;return r=gTagAttrs[e+t],null==r&&(r=gTagAttrs[t]),null!=r?(0==t.indexOf(e)&&null==n&&(n=t.substring(e.length)),null==n&&(n=t)," "+n+'="'+r+'"'):""}function _QTAddObjectAttr(e,t){return 0==e.indexOf("emb#")?"":(0==e.indexOf("obj#")&&null==t&&(t=e.substring(4)),_QTAddAttribute("obj#",e,t))}function _QTAddEmbedAttr(e,t){return 0==e.indexOf("obj#")?"":(0==e.indexOf("emb#")&&null==t&&(t=e.substring(4)),_QTAddAttribute("emb#",e,t))}function _QTAddObjectParam(e,t){var n,r="",i=t?" />":">";return-1==e.indexOf("emb#")&&(n=gTagAttrs["obj#"+e],null==n&&(n=gTagAttrs[e]),0==e.indexOf("obj#")&&(e=e.substring(4)),null!=n&&(r='<param name="'+e+'" value="'+n+'"'+i)),r}function _QTDeleteTagAttrs(){for(var e=0;e<arguments.length;e++){var t=arguments[e];delete gTagAttrs[t],delete gTagAttrs["emb#"+t],delete gTagAttrs["obj#"+t]}}function _QTGenerate(e,t,n){if(n.length<4||0!=n.length%2)return _QTComplain(e,gArgCountErr),"";gTagAttrs=new Object,gTagAttrs.src=n[0],gTagAttrs.width=n[1],gTagAttrs.height=n[2],gTagAttrs.classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B",gTagAttrs.pluginspage="http://www.apple.com/quicktime/download/";var r=n[3];if(null==r||""==r)r="7,3,0,0";gTagAttrs.codebase="http://www.apple.com/qtactivex/qtplugin.cab#version="+r;var i,s;for(var o=4;o<n.length;o+=2)i=n[o].toLowerCase(),s=n[o+1],gTagAttrs[i]=s,"postdomevents"==i&&s.toLowerCase()!="false"&&(gQTEventsEnabled=!0,_QTIsMSIE()&&(gTagAttrs["obj#style"]="behavior:url(#"+gQTBehaviorID+")"));var u="<object "+_QTAddObjectAttr("classid")+_QTAddObjectAttr("width")+_QTAddObjectAttr("height")+_QTAddObjectAttr("codebase")+_QTAddObjectAttr("name")+_QTAddObjectAttr("id")+_QTAddObjectAttr("tabindex")+_QTAddObjectAttr("hspace")+_QTAddObjectAttr("vspace")+_QTAddObjectAttr("border")+_QTAddObjectAttr("align")+_QTAddObjectAttr("class")+_QTAddObjectAttr("title")+_QTAddObjectAttr("accesskey")+_QTAddObjectAttr("noexternaldata")+_QTAddObjectAttr("obj#style")+">"+_QTAddObjectParam("src",t),a="<embed "+_QTAddEmbedAttr("src")+_QTAddEmbedAttr("width")+_QTAddEmbedAttr("height")+_QTAddEmbedAttr("pluginspage")+_QTAddEmbedAttr("name")+_QTAddEmbedAttr("id")+_QTAddEmbedAttr("align")+_QTAddEmbedAttr("tabindex");_QTDeleteTagAttrs("src","width","height","pluginspage","classid","codebase","name","tabindex","hspace","vspace","border","align","noexternaldata","class","title","accesskey","id","style");for(var i in gTagAttrs)s=gTagAttrs[i],null!=s&&(a+=_QTAddEmbedAttr(i),u+=_QTAddObjectParam(i,t));return u+a+"></em"+"bed></ob"+"ject"+">"}function QT_GenerateOBJECTText(){var e=_QTGenerate("QT_GenerateOBJECTText",!1,arguments);return _QTShouldInsertBehavior()&&(e=_QTGenerateBehavior()+e),e}function QT_GenerateOBJECTText_XHTML(){var e=_QTGenerate("QT_GenerateOBJECTText_XHTML",!0,arguments);return _QTShouldInsertBehavior()&&(e=_QTGenerateBehavior()+e),e}function QT_WriteOBJECT(){var e=_QTGenerate("QT_WriteOBJECT",!1,arguments);_QTShouldInsertBehavior()&&document.writeln(_QTGenerateBehavior()),document.writeln(e)}function QT_WriteOBJECT_XHTML(){var e=_QTGenerate("QT_WriteOBJECT_XHTML",!0,arguments);_QTShouldInsertBehavior()&&document.writeln(_QTGenerateBehavior()),document.writeln(e)}function QT_GenerateBehaviorOBJECT(){return _QTGenerateBehavior()}function QT_ReplaceElementContents(){var e=arguments[0],t=[];for(var n=1;n<arguments.length;n++)t.push(arguments[n]);var r=_QTGenerate("QT_ReplaceElementContents",!1,t);r.length>0&&(e.innerHTML=r)}function QT_ReplaceElementContents_XHTML(){var e=arguments[0],t=[];for(var n=1;n<arguments.length;n++)t.push(arguments[n]);var r=_QTGenerate("QT_ReplaceElementContents_XHTML",!0,t);r.length>0&&(e.innerHTML=r)}var gArgCountErr='The "%%" function requires an even number of arguments.\nArguments should be in the form "atttributeName", "attributeValue", ...',gTagAttrs=null,gQTGeneratorVersion=1.2,gQTBehaviorID="qt_event_source",gQTEventsEnabled=!1;