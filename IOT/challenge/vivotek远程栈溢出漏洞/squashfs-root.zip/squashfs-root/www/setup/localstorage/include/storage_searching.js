/**
 * Date.parse with progressive enhancement for ISO 8601 <https://github.com/csnover/js-iso8601>
 * NON-CONFORMANT EDITION.
 * © 2011 Colin Snover <http://zetafleet.com>
 * Released under MIT license.
 */
(function(Date, undefined) {
    var origParse = Date.parse,
        numericKeys = [1, 4, 5, 6, 10, 11];
    Date.parse = function(date) {
        var timestamp, struct, minutesOffset = 0;

        //              1 YYYY                 2 MM        3 DD              4 HH     5 mm        6 ss            7 msec         8 Z 9 ±    10 tzHH    11 tzmm
        if ((struct = /^(\d{4}|[+\-]\d{6})(?:-?(\d{2})(?:-?(\d{2}))?)?(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2})(?:[,\.](\d{1,}))?)?(?:(Z)|([+\-])(\d{2})(?::?(\d{2}))?)?)?$/.exec(date))) {
            // avoid NaN timestamps caused by ?�undefined??values being passed to Date.UTC
            for (var i = 0, k;
                (k = numericKeys[i]); ++i) {
                struct[k] = +struct[k] || 0;
            }

            // allow undefined days and months
            struct[2] = (+struct[2] || 1) - 1;
            struct[3] = +struct[3] || 1;

            // allow arbitrary sub-second precision beyond milliseconds
            struct[7] = struct[7] ? +(struct[7] + "00").substr(0, 3) : 0;

            // timestamps without timezone identifiers should be considered local time
            if ((struct[8] === undefined || struct[8] === '') && (struct[9] === undefined || struct[9] === '')) {
                timestamp = +new Date(struct[1], struct[2], struct[3], struct[4], struct[5], struct[6], struct[7]);
            } else {
                if (struct[8] !== 'Z' && struct[9] !== undefined) {
                    minutesOffset = struct[10] * 60 + struct[11];

                    if (struct[9] === '+') {
                        minutesOffset = 0 - minutesOffset;
                    }
                }

                timestamp = Date.UTC(struct[1], struct[2], struct[3], struct[4], struct[5] + minutesOffset, struct[6], struct[7]);
            }
        } else {
            timestamp = origParse ? origParse(date) : NaN;
        }

        return timestamp;
    };
}(Date));

jQuery.download = function(url, data, method){
    //url and data options required
    if( url && data ){
        //data can be string of parameters or array/object
        data = typeof data == 'string' ? data : jQuery.param(data);
        //split params into form inputs
        var inputs = '';
        jQuery.each(data.split('&'), function(){
            var pair = this.split('=');
            inputs+='<input type="hidden" name="'+ pair[0] +'" value="'+ pair[1] +'" />';
        });
        //send request
        jQuery('<form action="'+ url +'" method="'+ (method||'post') +'">'+inputs+'</form>')
        .appendTo('body').submit().remove();
    };
}

function checkIsWinMSIE()
{
	// This function will check if IE browser 
	
	var rtn = false;
	if (navigator.appName == "Microsoft Internet Explorer" && navigator.platform.match("Win"))
	{
		// Before IE11 ~
		if (navigator.userAgent.match("MSIE") != null)
		{
			rtn = true;
		}
	}
	else if (navigator.appName == "Netscape" && navigator.platform.match("Win"))
	{	
		// New IE (IE11)
		if (navigator.userAgent.match("Trident") != null)
		{
			rtn = true;
		}
	}

	return rtn;
}

// toISOString() not supported under ie8 
if ( !Date.prototype.toISOString ) {         
	(function() {         
		function pad(number) {
			var r = String(number);
			if ( r.length === 1 ) {
				r = '0' + r;
			}
			return r;
		}      
		Date.prototype.toISOString = function() {
			return this.getUTCFullYear()
			+ '-' + pad( this.getUTCMonth() + 1 )
			+ '-' + pad( this.getUTCDate() )
			+ 'T' + pad( this.getUTCHours() )
			+ ':' + pad( this.getUTCMinutes() )
			+ ':' + pad( this.getUTCSeconds() )
			+ '.' + String( (this.getUTCMilliseconds()/1000).toFixed(3) ).slice( 2, 5 )
			+ 'Z';
		};       
	}() );
}

function autoIFrameCreator (parentElement)
{
        // To create the iframe which will be returned
        var iframe = document.createElement("iframe");

        // If no parent element is specified then use body as the parent element
        if(parentElement == null)
        {
                parentElement = document.body;
        }

        // This is necessary in order to initialize the document inside the iframe
        parentElement.appendChild(iframe);
        iframe.doc = null;

        // Depending on browser platform get the iframe's document, this is only
        // available if the iframe has already been appended to an element which
        // has been added to the document
        if(iframe.contentDocument)
        {
                iframe.doc = iframe.contentDocument;            // Firefox, Opera
        }
        else if(iframe.contentWindow)
        {
                iframe.doc = iframe.contentWindow.document;     // Internet Explorer
        }
        else if(iframe.document)
        {
                iframe.doc = iframe.document;                   // Others?
        }

        // Failed in finding the document
        if(iframe.doc == null)
        {
                //throw "Document not found, append the parent element to the DOM before creating the IFrame";
                return null;
        }

        // To create the script inside the iframe's document
        iframe.doc.open();
        iframe.doc.close();

        // Return the iframe, now with an extra property iframe.doc containing the iframe's document
        return iframe;
}

// these add/remove callback register function is copied from common.js, 
// since I want to exchange sequence of detecting attachEvent and addEventListener.
// the reason to do this is becuase ie has strange behavior on attachEvent/addEventListener 
// under different document mode.
function addPluginEvent(obj,evt,fn)
{
	if (window.attachEvent)
		obj.attachEvent('on'+evt,fn);
	else if (window.addEventListener)
		obj.addEventListener(evt,fn,false);
}

function removePluginEvent(obj,evt,fn)
{
	if (window.detachEvent)
		obj.detachEvent('on'+evt,fn);
	else if (window.removeEventListener)
		obj.removeEventListener(evt,fn,false);
}

function compareStormgrVersion(version)
{
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?capability_localstorage_stormgrversion", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);

	return check4bit_verison(capability_localstorage_stormgrversion, version)
}

var localstorage = angular.module('localstorage', ['ui.bootstrap', 'ngGrid']);

// judge_backup_slices: It will be true, if it support bakup type in capability_supporttriggertypes.
// query_backup_slices: It is used to enable the backup judgement, which will auto-transform the trigger type if the media is a backup file
var judge_backup_slices = false;
var query_backup_slices = false;
localstorage.controller('search', function ($scope, $http) {

	$scope.cgiReturnStr = "";
	$.ajax({
		type: "GET",
		cache: false,
		async: false,
		url: "/cgi-bin/admin/getparam.cgi?capability_supporttriggertypes",
		success: function(data){
			$scope.cgiReturnStr = eval(data);
		}
	});

 	$scope.triggertypes = {};
	for (var i=0; i < $scope.cgiReturnStr.split(",").length; i++) 
	{
		var parsedTriggerType = $scope.cgiReturnStr.split(",")[i];
		if (parsedTriggerType == "smartsd")
		{
			continue;
		}
		var obj               = { checked: false, gettext: parsedTriggerType};
		$scope.triggertypes[parsedTriggerType] = obj;
		if (parsedTriggerType == "backup") {
			judge_backup_slices = true;
		}
	}

/*
	$scope.cgiReturnStr = "";
	$.ajax({
		type: "GET",
		cache: false,
		async: false,
		url: "/cgi-bin/admin/getTriggerTypes.cgi",
		success: function(data){
			$scope.cgiReturnStr = eval(data);
		}
	});

 	$scope.triggertypes = {seq: { checked: false, gettext: "periodic" }};
	
	for (var i=0; i < $scope.cgiReturnStr.split(",").length; i++) 
	{
		//search the matching type and add the returned obj
		var obj;
		if ((obj = searchMatchingTriggerType($scope.cgiReturnStr.split(",")[i])) != null) 
		{
			$.extend($scope.triggertypes, obj);
		}
	}
	
	function searchMatchingTriggerType(key)
	{
		var matchingObj;
		switch(key) // the key values are the filename in /etc/conf.d/event/definition
		{
			case 'recordmsg':
				matchingObj = {recnotify: { checked: false, gettext: "recording_notify" }};
				break;
			case 'linkstat':
				matchingObj = {networkfail: { checked: false, gettext: "network_fail" }};
				break;
			case 'boot':
				matchingObj = {boot: { checked: false, gettext: "system_boot" }};
				break;
			case 'vadp':
				matchingObj = {VADP: { checked: false, gettext: "VADP" }};
				break;
			case 'motion':
				matchingObj = {motion: { checked: false, gettext: "motion" }};
				break;
			case 'manualtrigger':
				matchingObj = {vi: { checked: false, gettext: "manual_trigger" }};
				break;
			case 'tampering':
				matchingObj = {tampering: { checked: false, gettext: "tampering" }};
				break;
			case 'di':
				matchingObj = {di: { checked: false, gettext: "di" }};
				break;
			case 'audioalarm':
				matchingObj = {audiodetect: { checked: false, gettext: "audio_detection" }};
				break;
			case 'pir':
				matchingObj = {pir: { checked: false, gettext: "pir" }};
				break;
			case 'temperature':
				matchingObj = {temperature: { checked: false, gettext: "temperature" }};
				break;
			default:
				return null;
		}
		return matchingObj;
	}
*/
	$scope.mediatypes = [
		{ 'name': 'videoclip' },
		{ 'name': 'snapshot' },
		{ 'name': 'text' }
	];

	$scope.mediatype = 'videoclip';

	$scope.CheckboxOnClick = function() {
		var backupchecked = false;
		for (var triggertype in $scope.triggertypes) {
			if ($scope.triggertypes[triggertype].checked == true) {
				if ($scope.triggertypes[triggertype].gettext == "backup") {
						backupchecked = true;

				}
			}

		}
		
		if(backupchecked == true)
		{
			document.getElementById("paging").options[4].selected = 'selected';
			document.getElementById("paging").disabled = true;
		}
		else
		{
			document.getElementById("paging").options[0].selected = 'selected';
			document.getElementById("paging").disabled = false;
		}	
		
      };

	function compose_legacy_query_string (currentPage)
	{
		if (typeof(currentPage) == "undefined") {
			currentPage = 1;
		}

		var query_header = "/cgi-bin/admin/lsctrl.cgi?cmd=search";
		var query_triggertypes_checked = [];
		query_backup_slices = false;
		for (var triggertype in $scope.triggertypes) {
			if ($scope.triggertypes[triggertype].checked == true) {
				if ($scope.triggertypes[triggertype].gettext != "backup") {
					var obj = { "name": triggertype, "item": $scope.triggertypes[triggertype] };
					query_triggertypes_checked.push(obj);
				}
				else {
                                        if (judge_backup_slices == true) {
                                                query_backup_slices = true;
                                        }				
				}
			}
		}

		if(query_backup_slices == true )
		{
					$scope.$parent.pagingOptions.pageSize = 9999;
		}
		else
		{			
			if(document.getElementById("paging").value == 10)
				$scope.$parent.pagingOptions.pageSize = 10;
		}		

		var query_triggertypes = "";
		if (query_triggertypes_checked.length > 0 && query_backup_slices == false) {
			query_triggertypes = "'" + query_triggertypes_checked.map(function(elem){ return elem.name; }).join("'+OR+'") + "'"
			query_triggertypes = "triggerType=" + escape(query_triggertypes);
		}

		var query_start = "'" + $scope.search_begin.getFullYear() + "-" + ("0" + ($scope.search_begin.getMonth()+1)).slice(-2) + "-" + ("0" + $scope.search_begin.getDate()).slice(-2);
		query_start += " " + ("0" + $scope.search_begin.getHours()).slice(-2) + ":";
		query_start += ("0" + $scope.search_begin.getMinutes()).slice(-2) + ":";
		query_start += ("0" + $scope.search_begin.getSeconds()).slice(-2) + "'";

		var query_end = "'" + $scope.search_end.getFullYear() + "-" + ("0" + ($scope.search_end.getMonth()+1)).slice(-2) + "-" + ("0" + $scope.search_end.getDate()).slice(-2);
		query_end += " " + ("0" + $scope.search_end.getHours()).slice(-2) + ":";
		query_end += ("0" + $scope.search_end.getMinutes()).slice(-2) + ":";
		query_end += ("0" + $scope.search_end.getSeconds()).slice(-2) + "'";

		var query_pagesize = "limit=" + $scope.pagingOptions.pageSize;
		var query_offset = "offset=" + (currentPage-1) * $scope.pagingOptions.pageSize;

		query_time = "triggerTime=" + escape(query_start) + "+TO+" + escape(query_end);
		var query_media = "mediaType=" + escape($scope.mediatype) + "";
		var query = query_header + "&" + query_time + "&" + query_triggertypes + "&" + query_media + "&" + query_pagesize + "&" + query_offset;
		return query;
	}

	function send_legacy_query_string (query)
	{
		var result;
		$http.get(query).
			success(function (data, status, headers, config) {
				var x2js = new X2JS();
				result = x2js.xml_str2json(data);
				var stormgr = { 'stormgr': result.stormgr, 'type': 'legacy' };
				$scope.update_legacy_search_result(stormgr);
			}).
			error(function (data, status, headers, config) {
				var x2js = new X2JS();
				result = x2js.xml_str2json(data);
				var stormgr = { 'stormgr': result.stormgr, 'type': 'legacy' };
				$scope.update_legacy_search_result(stormgr);
			});

		return result;
	}

	function update_search_result (result) {
		$scope.$emit('evt_ctrlr_search_sends_results', result);
		$scope.$emit('evt_ctrlr_search_type', $scope.mediatype);
	}

	$scope.update_legacy_search_result = update_search_result;

	function compose_nativeapi_query_string ()
	{
		var query_header = "/cgi-bin/admin/lsctrlrec.cgi?cmd=getSlices";
		var query_triggertypes_checked = [];
		var query_start = $scope.search_begin.toISOString();
		var query_end = $scope.search_end.toISOString();
		query_backup_slices = false;
		for (var triggertype in $scope.triggertypes) {
			if ($scope.triggertypes[triggertype].checked == true) {
				if ($scope.triggertypes[triggertype].gettext != "backup") {
					var obj = { "name": triggertype, "item": $scope.triggertypes[triggertype] };
					query_triggertypes_checked.push(obj);
				}
				else {
					if (judge_backup_slices == true) {
						query_backup_slices = true;
					}
				}
			}
		}

		if(query_backup_slices == true )
		{
					$scope.$parent.pagingOptions.pageSize = 9999;
		}
		else
		{			
			if(document.getElementById("paging").value == 10)
				$scope.$parent.pagingOptions.pageSize = 10;
		}

		var query_triggertypes = "";
		if (query_triggertypes_checked.length > 0 && query_backup_slices == false) {
			query_triggertypes = "&triggerType=" + escape(query_triggertypes_checked.map(function(elem){ return elem.name; }).join(",")) + "";
		}

		var query = query_header + "&recStartTime=" + query_start + "&recEndTime=" + query_end + query_triggertypes;
		return query;
	}

	function send_nativeapi_query_string (query)
	{
		var result;
		$http.get(query).
			success(function (data, status, headers, config) {
				var x2js = new X2JS();
				result = x2js.xml_str2json(data);
				var stormgr = { 'stormgr': result.stormgr, 'type': 'nativeapi' };
				$scope.update_nativeapi_search_result(stormgr);
			}).
			error(function (data, status, headers, config) {
				var x2js = new X2JS();
				result = x2js.xml_str2json(data);
				var stormgr = { 'stormgr': result.stormgr, 'type': 'nativeapi' };
				$scope.update_nativeapi_search_result(stormgr);
			});
	}

	$scope.update_nativeapi_search_result = update_search_result;

	$scope.update_search_callbacks = function () {
		if ($scope.mediatype == 'videoclip') {
			$scope.compose_query_string       = compose_nativeapi_query_string;
			$scope.send_and_update_resultview = send_nativeapi_query_string;
		} else {
			$scope.compose_query_string       = compose_legacy_query_string;
			$scope.send_and_update_resultview = send_legacy_query_string;
		}
	}

	$scope.$on('evt_update_search', function (event, pages) {
		$scope.submit_search_internal(pages);
	});

	$scope.submit_search_internal = function (pages) {
		if($scope.search_begin==null||$scope.search_end==null)
		{
			alert(translator("please_enter_a_valid_date"));
		}
		if($scope.search_begin.getTime()-$scope.search_end.getTime() > 0)
		{
			alert(translator("invalid_end_time"));
		}
		var query = $scope.compose_query_string(pages);
		var result = $scope.send_and_update_resultview (query);
	};

	$scope.submit_search = function (pages) {
		$scope.$parent.camera_timeupdate();
		$scope.$parent.gridOptions.pagingOptions.currentPage = 1;
		$scope.$parent.gridData = [];
		$scope.submit_search_internal(pages);
	}

	$scope.begindateopen = function($event) {
		$event.preventDefault();
		$event.stopPropagation();

		$scope.enddateopened = false;
		$scope.begindateopened = true;
	};

	$scope.enddateopen = function($event) {
		$event.preventDefault();
		$event.stopPropagation();

		$scope.begindateopened = false;
		$scope.enddateopened = true;
	};

	$scope.update_search_picker_by_timerange = function () {
		$scope.search_end = new Date();
		var search_begin_msec = $scope.search_end.getTime() - ($scope.recentsec * $scope.nrecent * 1000);
		$scope.search_begin = new Date(search_begin_msec);
	}

	$scope.update_search_picker_custom = function () {
		var diff = ($scope.search_end.getTime() - $scope.search_begin.getTime()) / 1000;	
		var found_in_recentsec = false;
		var recentsec = [ 60, 3600, 86400, 604800 ];
		for (var i=0; i < recentsec.length; i++) {
			if (diff == recentsec[i])
				found_in_recentsec = true;
		}

		// custom settings
		if (!found_in_recentsec) {
			$scope.recentsec = 0;
		}
	}

	$scope.recentsec = 604800;
	$scope.nrecent = 1;
	$scope.update_search_picker_by_timerange();
	$scope.update_search_callbacks();

});

var embeddedTextBlock = null;
localstorage.controller('player', function ($scope, $window, $sce) {
	$scope.seek = function (element) {
		if (typeof (element.offsetX) == 'undefined')
			return;

		if ($scope.plugin.seeking)
			return;

		$scope.plugin.seeking = true;

		var plugin = $scope.plugin;
		plugin.disconnect();

		var seek_percent = element.offsetX / angular.element('#prog_bar').width();
		var play_length = plugin.playback.endtime - plugin.playback.starttime;
		var seek_to = Math.floor(plugin.playback.starttime + (play_length * seek_percent));

		// The playback length should be larger than 1 sec.
		if ((seek_to + 1) >= plugin.playback.endtime)
		{
			seek_to = (plugin.playback.endtime - 1) - 1;
		}

		var seek_date = new Date(seek_to * 1000);
		var seek_end = new Date(plugin.playback.endtime * 1000);
		plugin.playback.stime = seek_date.toISOString().replace(/T/g, "_").replace(/[-:Z]/g, '');
		plugin.playback.etime = seek_end.toISOString().replace(/T/g, "_").replace(/[-:Z]/g, '');

		printf('going to play ' + plugin.playback.stime + ' ' + seek_percent + '%');

		plugin.instance().Url = ":" + network_rtsp_port + "/mod.sdp?recToken=" + plugin.playback.recToken + "&stime=" + plugin.playback.stime + "&loctime=0&etime=" + plugin.playback.etime;

		plugin.connect($scope.plugin.playback);


	};

	$scope.trickplayover = function (element) {
		if (typeof(element.offsetX) != 'undefined') 
		{
			printf('offsetX ' + event.offsetX);
			printf('width ' + angular.element('#prog_bar').width());
			printf("X: " + (event.offsetX / angular.element('#prog_bar').width() * 100) + "%");
		}
	};

	$scope.plugin = {
		instance: function () { 
			if (typeof (PLUGIN_ID) != "undefined") {	
				if (this.instance_cache == null) {
					this.instance_cache = document.getElementById(PLUGIN_ID);
				}
					
				return this.instance_cache;
			} else {
				return new Object();
			}
		},
		instance_cache: null,
		playing: false,
		connected: false,
		seeking: false,
		playback: { 
			'recToken': '',
			'starttime': 0,
			'endtime': 0,
			'percentage': 0,
			'current': 0,
			'stime': '',
			'etime': '20351231_000000.000'
		},
		_initialized: false,

		ontimestamp: function (p1, timestamp) {
			timestamp -= $scope.camera_timezonemsec / 1000;
			var This = $scope.plugin; This.playback.current = timestamp;
			var total_diff = This.playback.endtime - This.playback.starttime - 1;
			var current_diff = timestamp - This.playback.starttime; current_diff = (current_diff < 0)? 0 : current_diff;
			var percentage = (current_diff / total_diff) * 100;

			This.playback.percentage = Math.ceil(percentage);
			$scope.playback_progress = Math.ceil(percentage);

			// progressbar seems won't be changed automatically when playback_progress is changed.
			// I'm not sure why. Use manual triggered event to make playback progress bar work
			angular.element('#prog_bar').trigger('mouseover');

		},

		onconnectionstatus: function (p1, connstatus, conntype) {
			switch (connstatus) {
				case 1:
					$scope.plugin.connected = true;
					angular.element('#prog_bar').removeClass('progress-striped active');
					$scope.plugin.seeking = false;
					break;
				case 2:
				case 3:
				case 4:
				default:
					$scope.plugin.connected = false;
					angular.element('#prog_bar').addClass('progress-striped active');
					break;

			}
			printf('connstatus ' + connstatus);

		},

		playpause: function () { 
			if (this.connected) {
				if (this.playing) {
					this.instance().RtspPause();
					this.playing = false;
				} else {
					this.instance().RtspPlay();
					this.playing = true;
				}
			} else if (!this.playing){
				this.instance().Connect();
			}
		},

		destroy: function () {
			this.disconnect();
			this.uninit();
			console.log('destroyed');
		},

		disconnect: function () { 
			this.instance().RtspStop();
			this.playing = false;
		},

		backward: function () { 
			$scope.grid.selectprev();
		},

		forward: function () { 
			$scope.grid.selectnext();
		},

		fullscreen: function () { 
			this.instance().SetFullScreen(true);
		},

		init: function () {

			if (this._initialized)
				return;

			// register playback timestamp callback
			var callback = { 'name': 'TimeStamp', 'funcname': this.ontimestamp };
			this.register(null, callback);
			var callback = { 'name': 'ConnectionStatus', 'funcname': this.onconnectionstatus };
			this.register(null, callback);
			this._initialized = true;

		},

		uninit: function () {
			this._initialized = false;
		},

		connect: function (playback) {

			this._connect();

			this.playback.starttime = playback.starttime;
			this.playback.endtime   = playback.endtime;
			this.playback.recToken  = playback.recToken;
			this.playing = true;
		},

		_connect: function (that) {
			var This;
			if (that != null)
				This = that;
			else
				This = this;

			if (This.instance().PluginBeCreated) {
				$scope.playback_progress = 100;
				This.instance().Connect();
			} else {
				setTimeout(function () { This._connect() ; }, 1000);
			}
		},

		register: function (that, callback) {
			var This;
			if (that != null)
				This = that;
			else
				This = this;

			if (This.instance().PluginBeCreated) {
				addPluginEvent(This.instance(), callback.name, callback.funcname);
			} else {
				setTimeout(function () { This.register(This, callback); }, 2000);
			}
		}
	};

	$scope.textlist = { 
		currentshow: { 
			index: 0,
			url: '',
		},

		texts: [],

		forward: function () {
			$scope.grid.selectnext();
		},

		backward: function () {
			$scope.grid.selectprev();
		},
	};

	$scope.shotslist = {
		currentshow: {
			index: 0,
			url: '',
		},
		shots: [],
		forward: function () {
			$scope.grid.selectnext();
		},

		backward: function () {
			$scope.grid.selectprev();
		},
	};

	$scope.$on('evt_player_stop_playing', function (event, mediatype) {
		if (mediatype == "videoclip") {
			try { $scope.plugin.disconnect(); } catch (e) { ; }
		} else if (mediatype == "snapshot") {
			; // do nothing
		} else if (mediatype == "text") {
			; // do nothing
		}
	});

	$scope.$on('evt_player_playback', function (event, playback_item) { 

		var mediatype = playback_item.mediatype;
		
		if (mediatype == "videoclip") {

			if (checkIsWinMSIE()) {
				if ($scope.plugin.playing) {
					$scope.plugin.disconnect();
				}
			}

			if (playback_item.selected.recordingToken == undefined || playback_item.selected.recordingToken == "")
				return;

			/* consider to change this part to an interface for controlling embedded objects */
			var playback = { 
				'recToken': '',
				'starttime': 0, 
				'endtime': 0,
			};
			var d = new Date(Date.parse(playback_item.selected.sliceStart)); playback.starttime = d.getTime()/ 1000;
			d = new Date(Date.parse(playback_item.selected.sliceEnd)); playback.endtime = d.getTime() / 1000;
			playback.recToken = playback_item.selected.recordingToken;

			tackleInjectPluginLayout('showimage_block', parseInt(playback_item.selected.width), parseInt(playback_item.selected.height), playback, $scope.plugin);

			if (checkIsWinMSIE()) {
				$scope.plugin.init();
				$scope.plugin.connect(playback);
			}
			
			$scope.show_mod          = true;
			$scope.show_text         = false;
			$scope.show_snapshots    = false;

		} else if (mediatype == "snapshot") {
			$scope.shotslist.shots = playback_item.items;
			for (var shot in $scope.shotslist.shots) {
				$scope.shotslist.shots[shot].url = '/NCMF' + encodeURIComponent($scope.shotslist.shots[shot].destPath.replace(/.*NCMF\//, ''));
			}
			for (var item in playback_item.items) {
				if (playback_item.items[item] == playback_item.selected)
					$scope.shotslist.currentshow.index = item;
			}
			$scope.shotslist.currentshow.url = 
				$scope.shotslist.shots[$scope.shotslist.currentshow.index].url;
						
			var snapshot_resolution=$scope.shotslist.shots[$scope.shotslist.currentshow.index].resolution.split("x");
			var snapshot_width=parseInt(snapshot_resolution[0]);	
			var snapshot_height=parseInt(snapshot_resolution[1]);				
			if (snapshot_width < snapshot_height) // rotate
			{
				$scope.shotslist.currentshow.height = 520;
				$scope.shotslist.currentshow.width = 520 * (snapshot_width / snapshot_height);
				// fixed the height to be 520
			}
			else if (snapshot_width == snapshot_height) // 1:1
			{
					$scope.shotslist.currentshow.width=520;
					$scope.shotslist.currentshow.height=520;
			}
			else 
			{
				$scope.shotslist.currentshow.width = 520;
				$scope.shotslist.currentshow.height = 520 * (snapshot_height/snapshot_width);
				// fixed the width to be 520
			}				
									
			$scope.show_mod          = false;
			$scope.show_text         = false;
			$scope.show_snapshots    = true;
		} else if (mediatype == "text") {
			/* destroy the older one */
        		if (embeddedTextBlock != null)
        		{
                		if (embeddedTextBlock.parentNode != null)
                		{
                        		embeddedTextBlock.parentNode.removeChild(embeddedTextBlock);
                		}
                		embeddedTextBlock=null;
        		}

			/* load text here */
			$scope.textlist.texts = playback_item.items;
			for (var text in $scope.textlist.texts) {
				$scope.textlist.texts[text].url = '/NCMF' + encodeURIComponent($scope.textlist.texts[text].destPath.replace(/.*NCMF\//, ''));
			}
			for (var item in playback_item.items) {
				if (playback_item.items[item] == playback_item.selected)
					$scope.textlist.currentshow.index = item;
			}
			$scope.textlist.currentshow.url = 
				$scope.textlist.texts[$scope.textlist.currentshow.index].url;

			$.get($scope.textlist.currentshow.url, function(data) {
                        	var canvas = document.getElementById('show_text_block');
                        	var iframe = new autoIFrameCreator(canvas);
                        	embeddedTextBlock=iframe;
                        	iframe.style.width = "100%";
                        	iframe.style.height = "400px";
                        	var div = iframe.doc.createElement("div");
                        	div.innerText = data;
                        	iframe.doc.body.appendChild(div);
                	});

			$scope.show_mod          = false;
			$scope.show_text         = true;
			$scope.show_snapshots    = false;

		}
	});
});


localstorage.controller('totalcontrol', function ($scope, $http, $timeout) { 
	$scope.mediatype = 'videoclip';
	$scope.show_search_panel = true;
	$scope.current_media = '';
	$scope.camera_datetime = new Date();
	$scope.camera_timezonemsec = 0;

	$scope.camera_timeupdate = function () {
		$http.get('/cgi-bin/admin/getparam.cgi?system_date&system_time&system_timezoneindex&system_daylight_enable&system_daylight_dstactualmode')
			.success(function (data, status, headers, config) { 
				eval(data);
				if ((typeof(system_date) != 'undefined') && 
					(typeof(system_time) != 'undefined')) 
				{
					system_date = system_date.replace(/\//g, '-')
					var datetimestring = system_date + 'T' + system_time + '.000Z';
					var datetime = new Date(Date.parse(datetimestring));
					if(system_daylight_enable == "1" && system_daylight_dstactualmode == "3")
					{
						var timezoneoffset = Math.floor(parseInt(system_timezoneindex) / 40 + 1) * 60 * 60 * 1000;
					}
					else
					{
						var timezoneoffset = Math.floor(parseInt(system_timezoneindex) / 40) * 60 * 60 * 1000;
					}
					$scope.camera_timezonemsec = timezoneoffset;
					var vwr_offset = 15 * 1000; // post buffer 15 seconds
					$scope.camera_datetime = new Date(datetime.getTime() - timezoneoffset - vwr_offset);
					printf('camera datetime ' + $scope.camera_datetime.toISOString());
				}
			}).error(function (data, status, headers, config) { });

	};

	$scope.recurrent_camera_timeupdate = function () {
		$scope.camera_timeupdate();
		// update every 1 minute
		setTimeout(function () { $scope.recurrent_camera_timeupdate() ; }, 60000);
	}
	$scope.recurrent_camera_timeupdate();

	$scope.$on('evt_ctrlr_search_sends_results', function (event, arg) { 
		$scope.$broadcast('evt_update_search_result', arg);
	});
	$scope.$on('evt_ctrlr_search_type', function (event, arg) { 
		$scope.$broadcast('evt_update_search_type', arg);
	});
	$scope.$on('evt_search_result_row_select', function (event, selected_items) {
		$scope.$broadcast('evt_player_playback', selected_items);
		$scope.current_media = selected_items.mediatype;
		$scope.show_search_panel = false;
	});

	$scope.close_playback = function () {
		$scope.$broadcast('evt_player_stop_playing', $scope.mediatype);
		$scope.show_search_panel = true;
	};


	$scope.grid = { 
		datacount: function () {
			return $scope.gridData.length;
		},

		currentindex: function () {
			var selectedItem = $scope.gridOptions.selectedItems[0];
			var gridData = $scope.gridData;
			for (var rowIndex =0; rowIndex < gridData.length; rowIndex++) {
				var targetItem = gridData[rowIndex];
				if (selectedItem == targetItem)
					break;
			}

			return rowIndex;
		},


		getitems: function (fn, item_to_compare) {
			var result = [ ] ;
			var array = $scope.gridData;
			for (var item in array) {
					if (fn(array[item], item_to_compare) == true)
					{
					result.push(array[item]);
				}
			}

			return result;
		},

		getchecked: function () {
			return $scope.grid.getitems(function (item) { return item.checked; }, null);
		},

		updateitem: function (update) {
			for (var row in $scope.gridData) {
				if ($scope.gridData[row].label == update.label) {
					$scope.gridData[row] = update;
				}
			}
		},

		removeitem: function (item) {
			for (var row in $scope.gridData) {
				if ($scope.gridData[row].label == item.label) {
					$scope.gridData.splice(row, 1);
				}
			}
		},

		nextindex: function () {
			var curindex = this.currentindex();
			if (curindex < this.datacount())
				return curindex+1;

			return curindex;
		},

		previndex: function () {
			var curindex = this.currentindex();
			if (curindex > 0)
				return curindex-1;

			return curindex;
		},

		selectnext: function () {
			var next = $scope.grid.nextindex();
			printf("selecting " + next);
			$scope.gridOptions.selectRow(next, true);
		},

		selectprev: function () {
			var prev = $scope.grid.previndex();
			printf("selecting " + prev);
			$scope.gridOptions.selectRow(prev, true);
		}
	};


	// gridoptions default
	$scope.totalServerItems = 0;
	$scope.gridData = [ ];
	$scope.colDefs = [ ];
	$scope.currentRowEntity = '';

	$scope.pagingOptions = {
		pageSizes: [ 10, 25, 50, 100, 9999],
		pageSize: 10,
		currentPage: 1,
		showpagesize:10
	};
	
	$scope.pagesizechange = function() {
		$scope.pagingOptions.pageSize = $scope.pagingOptions.showpagesize;
	};

	$scope.gridOptions = {
		data: 'gridData',
		columnDefs: 'colDefs',
		multiSelect: false,
		keepLastSelected: true,
		selectedItems: [ ],
		showFooter: true,
		showFilter: false,
		enableColumnResize: true,
		totalServerItems: 'totalServerItems',
		afterSelectionChange: function (row, event) { 
			if ($scope.currentRowEntity != row.entity) {
				var results = { "mediatype": $scope.mediatype, "selected": row.entity, "items": $scope.gridData };
				$scope.$broadcast('evt_search_result_row_select', results); 
				// ignore double click behavior and lower server loading
				$scope.currentRowEntity = row.entity;
			}
		},
		footerTemplate: '<div ng-show="showFooter"> <br> <div ng-show="enablePaging" style="position:relative; left: 10px"> <select id="paging" style="float: left;height: 27px; width: 100px" ng-model="pagingOptions.showpagesize" ng-change="pagesizechange()"><option ng-repeat="size in pagingOptions.pageSizes"> {{size}}</option></select> </div> <div style="float: right; margin-right: 10px;"> <button type="button" class="ngPagerButton" ng-click="pageToFirst()" ng-disabled="cantPageBackward()" title="{{i18n.ngPagerFirstTitle}}"> <div class="ngPagerFirstTriangle"> <div class="ngPagerFirstBar"> </div> </div> </button> <button class="ngPagerButton" ng-click="pageBackward()" ng-disabled="cantPageBackward()" title="{{i18n.ngPagerPrevTitle}}"> <div class="ngPagerFirstTriangle ngPagerPrevTriangle"> </div> </button> <input class="ngPagerCurrent" min="1" max="{{currentMaxPages}}" type="number" onkeypress="return event.charCode != 13" style="width:50px; height: 24px; margin-top: 1px; padding: 0 4px;" ng-model="pagingOptions.currentPage"/> <span class="ngGridMaxPagesNumber" ng-show="maxPages() > 0">/ {{maxPages()}}</span> <button class="ngPagerButton" ng-click="pageForward()" ng-disabled="cantPageForward()" title="{{i18n.ngPagerNextTitle}}"> <div class="ngPagerLastTriangle ngPagerNextTriangle"> </div> </button> <button type="button" class="ngPagerButton" ng-click="pageToLast()" ng-disabled="cantPageToLast()" title="{{i18n.ngPagerLastTitle}}"> <div class="ngPagerLastTriangle"> <div class="ngPagerLastBar"> </div> </div> </button> </div> </div>',
		enablePaging: true,
		pagingOptions: $scope.pagingOptions
	};
	
	var timeout = null;
	$scope.$watch('pagingOptions.currentPage', function (newPage, oldPage) {	
		printf('newPage ' + newPage + ' oldPage ' + oldPage);
		if ((newPage != oldPage) || newPage == 0) 
		{
			if(timeout)$timeout.cancel(timeout);
			timeout = $timeout(function(){
				printf('step from page ' + oldPage + ' to page ' + newPage);
				$scope.gridData = [];
				$scope.$broadcast('evt_update_search', newPage);
			},1000);
		}
	}, true);

	$scope.$watch('pagingOptions.pageSize', function (newSize, oldSize) {
		if (newSize != oldSize)
		{
			printf('pagesize changed from ' + oldSize + ' to ' + newSize);
			$scope.gridData = [];
			$scope.pagingOptions.currentPage = 1;
			$scope.$broadcast('evt_update_search', 1);
		}
	}, true);
});

localstorage.controller('search_result', function ($scope, $http) {

	// actions for search result
	$scope.download = function () { 
		var checked = $scope.grid.getchecked();

		var download = {
			type: $scope.mediatype,
			items: checked,
		};

		var items_body = "";
		if ($scope.mediatype == 'videoclip') {
			for (var item in download.items) {
				var recordingtoken = download.items[item].recordingToken;
				var start = new Date(Date.parse(download.items[item].sliceStart));
				var end = new Date(Date.parse(download.items[item].sliceEnd));

				if (compareStormgrVersion("1.0.10.4") >= 0)
				{
					start = new Date(start.getTime());
					end = new Date(end.getTime());
				}
				else
				{
					start = new Date(start.getTime() + $scope.camera_timezonemsec);
					end = new Date(end.getTime() + $scope.camera_timezonemsec);
				}

				start = start.toISOString().replace(/T/, ' ').replace(/\.[0-9]*Z/, '');
				end = end.toISOString().replace(/T/, ' ').replace(/\.[0-9]*Z/, '');

				items_body += "type=" + $scope.mediatype;
				items_body += "&recordingname=" + download.items[item].name;
				items_body += "&recordingtoken=" + recordingtoken;
				items_body += "&starttime='" + start + "'";
				items_body += "&endtime='" + end + "'";

				$.download('/cgi-bin/admin/downloadMedias.cgi', items_body);
			}

		} else {
			if(checked.length == 0)
				return;
			var labels = [ ];
			for (var item in download.items) { 
				labels.push(download.items[item].label);
			}

			labels = labels.join(',');
			items_body += "type=" + $scope.mediatype;
			items_body += "&labels=" + labels;

			$.download('/cgi-bin/admin/downloadMedias.cgi', items_body);

		}

	};

	$scope.remove = function () {
		function remove_native (checked) {
			if (checked.islocked == true)
				return;
			var remove_hdr = "/cgi-bin/admin/lsctrlrec.cgi?cmd=truncateRecording";
			var recToken = checked.recordingToken;
			var remove = remove_hdr + "&recToken=" + recToken; 
			remove += "&recStartTime=" + checked.sliceStart;
			remove += "&recEndTime=" + checked.sliceEnd;
			$http.get(remove)
				.success(function (data, status, headers, config) {
					printf('remove slice ' + checked.sliceStart + ' --- ' + checked.sliceEnd);
					$scope.grid.removeitem(checked);
				})
				.error(function (data, status, headers, config) {
					; // do nothing
				});

		};

		function remove_legacy (checked) {
			if (checked.isLocked == true)
				return;
			var remove_hdr = "/cgi-bin/admin/lsctrl.cgi?cmd=delete";
			var remove = remove_hdr + "&label=" + checked.label;
			$http.get(remove)
				.success(function (data, status, headers, config) {
					printf('data ' + data);
					printf('status ' + status);
					printf('headers ' + headers);
					printf('config ' + config);
					printf('remove legacy ' + checked.label);
					$scope.grid.removeitem(checked);
				})
				.error(function (data, status, headers, config) {
					; // do nothing
				});
		};

		function remove (checked, mediatype) {
			if (mediatype == 'videoclip') { 
				remove_native(checked);
			} else { 
				remove_legacy(checked);
			}
		};

		var all_checked = $scope.grid.getchecked();

		for (var checked in all_checked) {
			remove(all_checked[checked], $scope.mediatype);
		}
	};

	$scope.updatelock = function () {
		function update_lock_native (checked) { 
			var query_hdr = "/cgi-bin/admin/lsctrlrec.cgi?cmd=updateSlices";
			var label = checked.label;
			var islocked = (checked.islocked == 1) ? 0 : 1;
			checked.islocked = islocked;
			var query = query_hdr + "&label=" + label + "&isLocked=" + islocked;
			$http.get(query)
				.success (function (data, status, headers, config) {
					$scope.grid.updateitem(checked);
				})
				.error (function (data, status, headers, config) {
					; // do nothing
				});
		};

		function update_lock_legacy (checked) {
			var query_hdr = "/cgi-bin/admin/lsctrl.cgi?cmd=update";
			var label = checked.label;
			var isLocked = (checked.isLocked == 1) ? 0 : 1;
			checked.isLocked = isLocked;
			var query = query_hdr + "&label=" + label + "&isLocked=" + isLocked;
			$http.get(query)
				.success (function (data, status, headers, config) {
					$scope.grid.updateitem(checked);
				})
				.error (function (data, status, headers, config) {
					; // do nothing
				});
		};

		function update_lock (checked, mediatype) {
			if (mediatype == 'videoclip') {
				update_lock_native(checked);
			} else {
				update_lock_legacy(checked);
			}
		};

		var all_checked = $scope.grid.getchecked();

		for (var checked in all_checked) {
			update_lock(all_checked[checked], $scope.mediatype);
		}
	};


	$scope.jpegtoavi = function () { 
		var all_checked = $scope.grid.getchecked();
		var resolution = all_checked[0].resolution;
		var files = [ ];
		for (var checked in all_checked) {
			files.push("'" + all_checked[checked].destPath + "'");
		}
		var fileList = files.join(',');

		var form = document.j2aDownload;
		form.resolution.value = resolution;
		form.fps.value = 1;
		form.list.value = fileList;
		form.submit();
	};

	// trigger of event messages
	$scope.$on('evt_update_search_type', function (event, args) {
		$scope.$parent.mediatype = args;
		if ($scope.$parent.mediatype == 'videoclip') {
			$scope.colDefs = [
				{ 
					field: 'checked', 
					displayName: translator("checked"),
					sortable: false,
					visible: true,
					cellTemplate: '<center><input style="padding-top: 8px" type="checkbox" ng-model="row.entity.checked"</input></center>',
					headerCellTemplate: '<center><input style="padding-top: 8px" type="checkbox" ng-disabled="1"></input></center>',
					width: "4%"  
				},
				{ 
					field: 'isLocked',
					displayName: translator("locked"),
					sortable: true,
					visible: true,
					cellTemplate: '<center><span style="padding-top: 8px" ng-show="(row.entity.islocked == 1)" class="glyphicon glyphicon-lock"></span></center>',
					headerCellTemplate: '<center><span style="padding-top: 8px" class="glyphicon glyphicon-lock"></span></center>', 
					width: "4%"  
				},
				{ 
					field: 'name',
					displayName: translator("name"),
					sortable: true,
					visible: true,
					width: "20%" 
				},
				{ 
					field: 'recordingToken',
					sortable: true,
					visible: false,
				},
				{
					field: 'triggerFilter',
					displayName: translator("trigger_type"),
					sortable: true,
					visible: true,
					width: "15%" 
				},
				{
					field: 'sliceStartDisplay',
					displayName: translator("start_time"),
					sortable: true,
					visible: true,
					width: "25%" 
				},
				{
					field: 'sliceStart',
					sortable: false,
					visible: false,
				},
				{
					field: 'sliceEndDisplay',
					displayName: translator("end_time"),
					sortable: true,
					visible: true,
				},
				{
					field: 'sliceEnd',
					sortable: false,
					visible: false,
				}
			];
		} else {
			$scope.colDefs = [
				{ 
					field: 'checked', 
					displayName: translator("checked"),
					sortable: false,
					visible: true,
					cellTemplate: '<center><input style="padding-top: 8px" type="checkbox" ng-model="row.entity.checked"</input></center>',
					headerCellTemplate: '<center><input style="padding-top: 8px" type="checkbox" ng-disabled="1"></input></center>',
					width: "5%"  
				},
				{ 
					field: 'isLocked',
					displayName: translator("locked"),
					sortable: true,
					visible: true,
					cellTemplate: '<center><span style="padding-top: 8px" ng-show="(row.entity.isLocked == 1)" class="glyphicon glyphicon-lock"></span></center>',
					headerCellTemplate: '<center><span style="padding-top: 8px" class="glyphicon glyphicon-lock"></span></center>', 
					width: "5%"  
				},
				{
					field: 'triggerType',
					displayName: translator("trigger_type"),
					visible: false,
				},
				{
					field: 'triggerTypeDisplay',
					displayName: translator("trigger_type"),
					sortable: true,
					visible: true,
					width: "40%" 
				},
				{
					field: 'triggerTime',
					displayName: translator("trigger_time"),
					sortable: false,
					visible: false,
				},
				{
					field: 'triggerTimeDisplay',
					displayName: translator("trigger_time"),
					sortable: true,
					visible: true,
				},
				{
					field: 'dummy', // keep this field for preventing ng-grid column size overflow
					sortable: false,
					visible: false,
				}
			];
		} 
	});

	function stormgr_legacy_convert_root (stormgr) {
		var root = new Array();
		for (var item in stormgr) {
			if (item.toString().match(/i[0-9]+/)) {
				root.push(stormgr[item]);
			}
		}

		return root;
	}

	function make_readable (time_iso8601) {
		time = Date.parse(time_iso8601);
		var readable = "";
		var diff = ($scope.camera_datetime - time) / 1000;
		var localelist = [ 'en', 'de', 'es', 'fr', 'it', 'ja', 'po', 'zh-CN', 'zh-TW','ru' ];
		var hourago = 60 * 60;
		/*if (diff <= 0) { 
			alert('calendar 1 !!');
			readable = moment(time).locale(localelist[lan]).calendar();
		} else if (diff < hourago) {
			alert("fromNow!!");
			readable = moment(time).locale(localelist[lan]).fromNow();
		} else {
			alert('calendar 2!!');
			readable = moment(time).locale(localelist[lan]).calendar();
		}*/
		readable = moment(time).locale(localelist[lan]).calendar();
		return readable;
	}


	$scope.$on('evt_update_search_result', function (event, results) {
		var triggertypes = angular.element('[ng-controller=search]').scope().triggertypes;
		if (results.type == 'nativeapi') {
			function get_recording_name_and_resolution (item) {
				var query_hdr = "/cgi-bin/admin/lsctrlrec.cgi?cmd=getrecordinginfo";
				var query = query_hdr + "&recToken=" + item.recordingToken;
				$http.get(query)
					.success(function (data, status, headers, config) {
						var x2js = new X2JS();
						results = x2js.xml_str2json(data);
						if (results.stormgr.root.trackNum != 0)
						{
							var recording_name   = results.stormgr.root.source.name;
							var recording_token  = results.stormgr.root.recordingToken;
							var nativeapi_prefix = results.stormgr.root.content.indexOf('NativeAPI-');
							var recording_triggertype = '';
							if (nativeapi_prefix != -1) {
								recording_triggertype = results.stormgr.root.content.slice(nativeapi_prefix + 10);
							}

							var should_filter_by_triggertype = false;
							for (var type in triggertypes) {
								// backup is not a real triggertype of nativeapi
								if (query_backup_slices == true) {
									break;
								}
                                				if (triggertypes[type].gettext != "backup") { 
									if (triggertypes[type].checked == true) {
										should_filter_by_triggertype = true;
										break;
									}
								}
							}

							var slices = $scope.grid.getitems(function (iterator, recording_token) { return iterator.recordingToken == recording_token; }, recording_token);
							for (var slice in slices) {
								slices[slice].name = recording_name;
								slices[slice].triggerType = recording_triggertype;
								if (should_filter_by_triggertype && recording_triggertype != "" && triggertypes[recording_triggertype].checked == false) {
									$scope.grid.removeitem(slices[slice]);
								} else {
									$scope.grid.updateitem(slices[slice]);
								}
							}
						}

						var query_hdr = "/cgi-bin/admin/lsctrlrec.cgi?cmd=getmediaattr";
						var query = query_hdr + "&recToken=" + item.recordingToken + "&recTime=" + item.sliceStart;

						$http.get(query)
							.success(function (data, status, headers, config) {
								var x2js = new X2JS();
								results = x2js.xml_str2json(data);
								if (results.stormgr.root.trackNum != 0)
								{
									var recording_token  = item.recordingToken;
									
									if (results.stormgr.root.retCode != "NoRecording") 
									{
										var maxTrackIndex = 3; //(audio, video, metadata)
										for (var trackIndex = 0; trackIndex < maxTrackIndex; trackIndex++)
										{
											var trackType = eval("results.stormgr.root.recording.i0.trackAttributes.i" + trackIndex + ".trackInformation.trackType");
											if (trackType == "Video") 
											{
												var recording_width  = eval("results.stormgr.root.recording.i0.trackAttributes.i" + trackIndex + ".videoAttributes.width");
												var recording_height = eval("results.stormgr.root.recording.i0.trackAttributes.i" + trackIndex + ".videoAttributes.height");
												break;
											}
										}

										var slices = $scope.grid.getitems(function (iterator, recording_token) { return iterator.recordingToken == recording_token; }, recording_token);
                		                var should_filter_by_triggertype = false;
                		                for (var type in triggertypes) {
                		                	if (triggertypes[type].checked == true) {
                		                   		should_filter_by_triggertype = true;
                		                       	break;
                		                    }
                		                }
										for (var slice in slices) 
										{
											var recording_backup = "0";
											if (item.sliceStart == slices[slice].sliceStart) {
												if (judge_backup_slices == true) {
													recording_backup = results.stormgr.root.recording.i0.backup;
												}

												if (recording_backup == "1") {
													slices[slice].triggerFilter = "backup";
												}
												else {
													slices[slice].triggerFilter = slices[slice].triggerType;
												}
												if (should_filter_by_triggertype && slices[slice].triggerFilter != "" && triggertypes[slices[slice].triggerFilter].checked == false) 
												{
													if (slices[slice].triggerFilter != "backup") 
													{
                		                       		$scope.grid.removeitem(slices[slice]);
                		                       	}
													else
													{
														slices[slice].triggerFilter = translator(slices[slice].triggerType) + " (" + translator(slices[slice].triggerFilter) + ")";
													}
                		                       	}
												else 
												{
													if (slices[slice].triggerFilter == "backup")
													{
														slices[slice].triggerFilter = translator(slices[slice].triggerType) + " (" + translator(slices[slice].triggerFilter) + ")";
													}
													else
													{
													slices[slice].triggerFilter = translator(slices[slice].triggerFilter);
												}
												}
												
											slices[slice].width  = recording_width;
											slices[slice].height = recording_height;
											}											
											$scope.grid.updateitem(slices[slice]);
										}
									}
								}
							}).error(function (data, status, headers, config) {get_recording_name_and_resolution (item)});

					}).error(function (data, status, headers, config) {get_recording_name_and_resolution(item);});

			};
			
			if (typeof(results.stormgr) == 'undefined') {
				$scope.$parent.gridData = [];
				return;
			}

			if (typeof(results.stormgr.root) == 'undefined') {
				$scope.$parent.gridData = [];
				return;
			}
			
			if (typeof(results.stormgr.root.slices) == 'undefined') {
				$scope.$parent.gridData = [];
				return;
			}

			if (typeof(results.stormgr.root.slices.length) == 'undefined') {
				var slices = [ ] ; 
				slices.push(results.stormgr.root.slices);
				results.stormgr.root.slices = slices;
			}

			// do some nasty thing here 
			for (var slice in results.stormgr.root.slices) {
				results.stormgr.root.slices[slice].name = '';
				results.stormgr.root.slices[slice].triggerType = '';
				results.stormgr.root.slices[slice].recording = false;

				if (results.stormgr.root.slices[slice].sliceEnd == "") {
					results.stormgr.root.slices[slice].sliceEnd = $scope.camera_datetime.toISOString();
					results.stormgr.root.slices[slice].recording = true;
				}

				function readable_slicetime (slice) {
					slice.sliceStartDisplay = make_readable(slice.sliceStart);
					slice.sliceEndDisplay = make_readable(slice.sliceEnd);
					if (slice.recording) {
						slice.sliceEndDisplay = "--";
					}

					return slice;
				}

				function raw_slicetime (slice) {
					slice.sliceStartDisplay = slice.sliceStart;
					slice.sliceEndDisplay = slice.sliceEnd;
					return slice;
				}

				var use_readable = true;
				if (use_readable) {
					results.stormgr.root.slices[slice] = readable_slicetime(results.stormgr.root.slices[slice]);
				} else {
					results.stormgr.root.slices[slice] = raw_slicetime(results.stormgr.root.slices[slice]);
				}
			}
			
			// do paging manually. 
			var pagesize = parseInt($scope.$parent.pagingOptions.pageSize);
			var currentpage = $scope.$parent.pagingOptions.currentPage - 1;
			var offset = pagesize * currentpage;
			var gridData = results.stormgr.root.slices.slice(offset, offset + pagesize);

			for (var item in gridData) {
				get_recording_name_and_resolution(gridData[item]);
			}

			$scope.$parent.gridData = gridData;
			$scope.totalServerItems = results.stormgr.root.slices.length;

		} else if (results.type == 'legacy') {
			results.stormgr.root = stormgr_legacy_convert_root(results.stormgr);
			$scope.totalServerItems = parseInt(results.stormgr.counts);

			var should_filter_by_triggertype = false;
			if (judge_backup_slices == true) {
                       		for (var type in triggertypes) {
                      			if (triggertypes[type].checked == true) {
              					should_filter_by_triggertype = true;
                                  		break;
                    			}
                     		}
			}
			
			var iDataIndex = 0;
			for (var item in results.stormgr.root) {
				if (isNaN(item, 10) == true) {
					continue;
				}
				results.stormgr.root[item].triggerTimeDisplay = make_readable(results.stormgr.root[item].triggerTime.replace(/ /, 'T'));
				for (var type in triggertypes) {
					if (type == results.stormgr.root[item].triggerType) {
						if (results.stormgr.root[item].backup == "0") {
							results.stormgr.root[item].triggerTypeDisplay = triggertypes[type].gettext;
						}
						else if (judge_backup_slices == true && results.stormgr.root[item].backup == "1") {
							results.stormgr.root[item].triggerTypeDisplay = triggertypes["backup"].gettext;
						}
						else {
							results.stormgr.root[item].triggerTypeDisplay = triggertypes[type].gettext;
						}
						if (should_filter_by_triggertype == true) {
							if ((triggertypes[results.stormgr.root[item].triggerTypeDisplay].checked == false) && (results.stormgr.root[item].triggerTypeDisplay != "backup")) {
								continue;
							}
						}
						if (results.stormgr.root[item].triggerTypeDisplay == "backup") {
							results.stormgr.root[item].triggerTypeDisplay = translator(triggertypes[type].gettext) + " (" + translator(results.stormgr.root[item].triggerTypeDisplay) + ")";
						}
						else
						{
						results.stormgr.root[item].triggerTypeDisplay = translator(results.stormgr.root[item].triggerTypeDisplay);
						}
						$scope.$parent.gridData[iDataIndex] = results.stormgr.root[item];
						iDataIndex = iDataIndex + 1;
					}
				}
			}
		}
	});


	// I don't want to do this, but I can't find a way to receive
	// evt_update_search_type on page loading 
	$scope.$emit('evt_update_search_type', $scope.$parent.mediatype);
});

function loadCurrentSetting()
{
	$('#InstallerArea').hide();
	
	XMLHttpRequestObject.open("GET", "/cgi-bin/admin/getparam.cgi?system_info_language&system_info_customlanguage&network_http_port&network_https_port", true);
	XMLHttpRequestObject.setRequestHeader("If-Modified-Since","0");
	XMLHttpRequestObject.send(null);
	document.title=translator("content_management");
	loadlanguage();
	langSelect(); 
	loadvaluedone();

	// remove up/down arrow from datepicker
	$('.btn.btn-link').parent().parent().remove();
	$('.form-control.text-center').addClass('input-sm');
	$('.btn.btn-default.text-center.ng-binding').addClass('input-sm');
	
	moment.locale('en', {
    	calendar : {
        lastDay : '[Yesterday at] LT',
        sameDay : '[Today at] LT',
        nextDay : '[Tomorrow at] LT',
        lastWeek : '[last] dddd [at] LT',
        nextWeek : 'dddd [at] LT',
        sameElse : 'L LT'
    	}
	});

	//search for last input filter
	$(document).ready(function() {
		$("input[name='searchFilter']").keydown(function (e) {
			// Allow: backspace, delete, tab, escape, enter
			if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
				 // Allow: Ctrl+A
				(e.keyCode == 65 && e.ctrlKey === true) ||
				 // Allow: Ctrl+C
				(e.keyCode == 67 && e.ctrlKey === true) ||
				 // Allow: Ctrl+X
				(e.keyCode == 88 && e.ctrlKey === true) ||
				 // Allow: home, end, left, right
				(e.keyCode >= 35 && e.keyCode <= 39)) {
					 // let it happen, don't do anything
					 return;
			}
			// Ensure that it is a number and stop the keypress
			if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
				e.preventDefault();
			}
		});
	});	
}

function receivedone()
{
    if( lan >= 100 ) //custom language
       return -1;
}

function loadvaluedone()
{
	document.getElementById("content").style.visibility = "visible";
}

function onExit()
{
	angular.element('[ng-controller=totalcontrol]').scope().close_playback();
}

function Plugin_GenerateOBJECTText (url, width, height, extra_property)
{
	var str_innerHTML = "";
	// The ActiveX plug-in  
	W=width + X_OFFSET;
	H=height + Y_OFFSET;
	STRETCH = true;
	str_innerHTML = "<object id=\"" + PLUGIN_ID + "\" width=" + W + " height=" + H;
	str_innerHTML += "   standby=\"Loading plug-in...\" classid=CLSID:" + CLASS_ID;
	str_innerHTML += "   codebase=\"/" + PLUGIN_NAME + "#version=" + PLUGIN_VER + "\">";
	str_innerHTML += "  <param name=\"Url\" VALUE=\"" + url + "\">";              
	str_innerHTML += "  <param name=\"DarwinConnection\" VALUE=\"true\">";
	str_innerHTML += "  <param name=\"Stretch\" VALUE=\"" + STRETCH + "\">";
	str_innerHTML += "  <param name=\"AutoStartConnection\" VALUE=\"false\">";
	str_innerHTML += "  <param name=\"ReadSettingByParam\" VALUE=\"1\">";
	str_innerHTML += "  <param name=\"ConnectionProtocol\" VALUE=\"3\">";
	str_innerHTML += "  <param name=\"ClientOptions\" VALUE=\"4\">";
	str_innerHTML += "  <param name=\"StreamingBufferTime\" VALUE=\"50\">";
	str_innerHTML += "  <param name=\"PtzURL\" VALUE=\"\">";
	if (window.location.protocol == "https:")
	{
		str_innerHTML += "  <param name=\"HttpPort\" VALUE=\"" + network_https_port + "\">";
	}
	str_innerHTML += translator("this_is_a_plugin_activex");
	str_innerHTML += translator("if_you_see_this_text_your_browser_does_not_support_or_has_disabled_activex");
	str_innerHTML += "</object>";

	return str_innerHTML;
}

function inject_plugin (destBlock, width, height, playback, plugin)
{
	var url = ":" + network_rtsp_port + "/mod.sdp?recToken=" + playback.recToken;
	
	if (Math.ceil(playback.starttime) == playback.starttime)
	{
		playback.starttime = playback.starttime - 1;
	}

	if (Math.ceil(playback.endtime) == playback.endtime)
	{
		playback.endtime = playback.endtime + 1;
	}

	if(playback.starttime == playback.endtime)
	{
		playback.starttime = playback.starttime - 1;
		playback.endtime = playback.endtime + 1;
	}

	printf('playback url ' + playback.url);
	printf('playback starttime ' + playback.starttime);
	printf('playback endtime ' + playback.endtime);
	printf('plugin starttime ' + plugin.starttime);
	printf('plugin endtime ' + plugin.endtime);

	if (playback.starttime) {
		plugin.starttime = playback.starttime;
		var stime = new Date(playback.starttime * 1000); 
		stime = stime.toISOString().replace(/T/g, "_").replace(/[-:Z]/g, '');
		url += "&stime=" + stime;
	}

	if (playback.endtime) {
		plugin.endtime = playback.endtime;
		var etime = new Date(playback.endtime * 1000);
		etime = etime.toISOString().replace(/T/g, "_").replace(/[-:Z]/g, '');
		url += "&etime=" + etime;
	}

	var plugin_dom = document.getElementById(PLUGIN_ID);
	if (plugin_dom != null) {
		plugin_dom.Url = url;
        	$("#"+PLUGIN_ID).attr("height", height).height(height + Y_OFFSET);
        	$("#"+PLUGIN_ID).attr("width", width).width(width + X_OFFSET);
        	$("#showimageBlock").height(height + Y_OFFSET).width(width + X_OFFSET);
		return;
	}

	var str_innerHTML = "";

	if (checkIsWinMSIE()) {
		str_innerHTML = Plugin_GenerateOBJECTText(url, width, height, "");
	} else {
//        str_innerHTML = QT_GenerateOBJECTText_XHTML(url, width, height, "");

		// non-IE is not supported right now.
		str_innerHTML = translator("this_is_a_plugin_activex");
		str_innerHTML += translator("if_you_see_this_text_your_browser_does_not_support_or_has_disabled_activex");
	}

	document.getElementById(destBlock).innerHTML = str_innerHTML;
}
function tackleInjectPluginLayout(destBlock, width, height, playback, scopePlugin)
{
	if (width < height) // rotate
	{
		document.getElementById(destBlock).style.textAlign= "center";
		// fixed the height to be 520
		var total_width = 520;
		var plugin_width = Math.round(width/height*total_width);
		var margin_width = Math.round((total_width-plugin_width)/2);
		var margin_text = String(margin_width) + "px";
		var bar_width_idx = Math.floor((total_width-margin_width*2)/total_width*12) - 4;
		var bar_text = "col-xs-" + String(bar_width_idx);
		document.getElementById("show_back_search").style.marginLeft = margin_text
		document.getElementById("show_play_panel").style.marginLeft = margin_text
		document.getElementById("show_progressbar").setAttribute('class', bar_text);
		inject_plugin(destBlock, plugin_width, 520, playback, scopePlugin);

		//document.getElementById(PLUGIN_ID).StretchFullScreen=false;
	}
	else if (width == height) // 1:1
	{
		document.getElementById("show_back_search").style.marginLeft = "auto";
		document.getElementById("show_play_panel").style.marginLeft = "auto";
		document.getElementById("show_progressbar").setAttribute('class', 'col-xs-8');
		inject_plugin(destBlock, 520, 520, playback, scopePlugin);
		//document.getElementById(PLUGIN_ID).StretchFullScreen=false;	
	}
	else 
	{
		document.getElementById("show_back_search").style.marginLeft = "auto";
		document.getElementById("show_play_panel").style.marginLeft = "auto";
		document.getElementById("show_progressbar").setAttribute('class', 'col-xs-8');

		// fixed the width to be 520
		var total_height = 520;
		var plugin_height = Math.round(height/width*520);
		inject_plugin(destBlock, 520, plugin_height, playback, scopePlugin);

		//document.getElementById(PLUGIN_ID).StretchFullScreen=true;	
	}
}
