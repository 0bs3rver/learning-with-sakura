PRAGMA foreign_keys=ON;

-- table for storing db related information
CREATE TABLE IF NOT EXISTS storage_manager (
	key INTEGER primary key,
	version TEXT,
	pre_version TEXT
);
INSERT INTO storage_manager (version, pre_version) VALUES (6, 6);

-- table for storing timespans
CREATE TABLE IF NOT EXISTS timespan (
	key INTEGER primary key,
	channel INTEGER NOT NULL DEFAULT 1,
	starttime INTEGER NOT NULL DEFAULT 0,
	endtime INTEGER NOT NULL DEFAULT 0,
	vwrstarttime INTEGER NOT NULL DEFAULT 0,
	islocked INTEGER DEFAULT 0,
	token TEXT REFERENCES ONVIF_RECORDING(token) ON UPDATE CASCADE ON DELETE CASCADE
);

-- table for joining records (event and media)
CREATE TABLE IF NOT EXISTS event_media (
	key INTEGER primary key,
	eventidx INTEGER REFERENCES event(key) ON UPDATE CASCADE ON DELETE CASCADE,
	mediaidx INTEGER REFERENCES media(key) ON UPDATE CASCADE ON DELETE CASCADE
);

-- 'event' related tables
CREATE TABLE IF NOT EXISTS event (
	key INTEGER primary key,
	type TEXT NOT NULL,
--	triggertime INTEGER NOT NULL DEFAULT (strftime('%s','now','utc')*1000),
	triggertime TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f')),
	hasaction INTEGER NOT NULL DEFAULT 0,
	dst INTEGER NOT NULL DEFAULT 0,
	timezone INTEGER NOT NULL DEFAULT 320
);

CREATE TABLE IF NOT EXISTS di (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS do (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS pir (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS motion (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	channel INTEGER NOT NULL DEFAULT 0,
	percentage INTEGER NOT NULL,
	triggered INTEGER NOT NULL,
	profile INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tampering (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	percentage INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS temperature (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ir (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ircut (
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS whitelight
(
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audioinsignal
(
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS audioswitch
(
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS visignal
(
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS vosignal
(
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS virestore
(
	key INTEGER primary key,
	source INTEGER NOT NULL DEFAULT 0,
	triggered INTEGER NOT NULL,
	eventkey INTEGER REFERENCES EVENT(key) ON UPDATE CASCADE ON DELETE CASCADE
);

-- 'media' related tables
CREATE TABLE IF NOT EXISTS media (
	key INTEGER primary key,
	streamid INTEGER DEFAULT 0,
	channelid INTEGER DEFAULT 0,
	type TEXT NOT NULL,
	location TEXT NOT NULL,
	triggertype TEXT DEFAULT "seq",
	createtime INTEGER DEFAULT (strftime('%s','now')*1000),
	createtime_utc INTEGER DEFAULT (strftime('%s','now','utc')*1000),
	islocked INTEGER DEFAULT 0,
	dst INTEGER DEFAULT 0,
	tz INTEGER DEFAULT 120,
	backup INTEGER DEFAULT 0,
	seamless INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS snapshot (
	key INTEGER primary key,
	resolution TEXT NOT NULL DEFAULT '800x600',
	mediakey INTEGER REFERENCES MEDIA(key) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS videoclip (
	key INTEGER primary key,
	resolution TEXT NOT NULL DEFAULT '800x600',
	begintime INTEGER NOT NULL DEFAULT (strftime('%s','now')*1000),
	endtime INTEGER NOT NULL,
	begintime_utc INTEGER NOT NULL DEFAULT (strftime('%s','now','utc')*1000),
	endtime_utc INTEGER NOT NULL,
	mediakey INTEGER REFERENCES MEDIA(key) ON UPDATE CASCADE ON DELETE CASCADE,
	recordingToken TEXT REFERENCES ONVIF_RECORDING(token) ON UPDATE CASCADE ON DELETE CASCADE,
	audioTrackKey INTEGER REFERENCES ONVIF_TRACK(token),
	videoTrackKey INTEGER REFERENCES ONVIF_TRACK(token),
	metaTrackKey INTEGER REFERENCES ONVIF_TRACK(token),
	audioSize INTEGER,
	videoSize INTEGER,
	frames INTEGER,
	timespanKey INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS text (
	key INTEGER primary key,
	mediakey INTEGER REFERENCES MEDIA(key) ON UPDATE CASCADE ON DELETE CASCADE
);

-- create table for holding event count
CREATE TABLE eventcount (cnt INTEGER);
INSERT INTO eventcount (cnt) values (0);
CREATE TRIGGER rc1 AFTER INSERT ON event BEGIN UPDATE eventcount SET cnt=cnt+1; END;
CREATE TRIGGER rc2 AFTER DELETE ON event BEGIN UPDATE eventcount SET cnt=cnt-1; END;

-- create indexes (event)
CREATE INDEX IF NOT EXISTS idx_event_triggertime on event (triggertime);
CREATE INDEX IF NOT EXISTS idx_event_type on event (type);
CREATE INDEX IF NOT EXISTS idx_di_key on di (eventkey);
CREATE INDEX IF NOT EXISTS idx_do_key on do (eventkey);
CREATE INDEX IF NOT EXISTS idx_pir_key on pir (eventkey);
CREATE INDEX IF NOT EXISTS idx_motion_key on motion (eventkey);
CREATE INDEX IF NOT EXISTS idx_tampering_key on tampering (eventkey);
CREATE INDEX IF NOT EXISTS idx_temperature_key on temperature (eventkey);
CREATE INDEX IF NOT EXISTS idx_ir_key on ir (eventkey);
CREATE INDEX IF NOT EXISTS idx_ircut_key on ircut (eventkey);
CREATE INDEX IF NOT EXISTS idx_whitelight_key on whitelight (eventkey);
CREATE INDEX IF NOT EXISTS idx_auiodinsignal_key on audioinsignal (eventkey);
CREATE INDEX IF NOT EXISTS idx_audioswitch_key on audioswitch (eventkey);
CREATE INDEX IF NOT EXISTS idx_visignal_key on visignal (eventkey);
CREATE INDEX IF NOT EXISTS idx_vosignal_key on vosignal (eventkey);
CREATE INDEX IF NOT EXISTS idx_virestore_key on virestore (eventkey);

-- create indexs (media)
CREATE INDEX IF NOT EXISTS idx_media_key on media (key);
CREATE INDEX IF NOT EXISTS idx_snapshot on snapshot (mediakey);
CREATE INDEX IF NOT EXISTS idx_videoclip on videoclip (mediakey,begintime,endtime);
CREATE INDEX IF NOT EXISTS idx_videoclip_utc on videoclip (mediakey,begintime_utc,endtime_utc);
CREATE INDEX IF NOT EXISTS idx_systemlop on text (mediakey);

-- create index (media-event)
CREATE INDEX IF NOT EXISTS idx_media_event on event_media (eventidx,mediaidx);
CREATE INDEX IF NOT EXISTS idx_event_media on event_media (mediaidx,eventidx);

-- Genetec Omnicast session
CREATE TABLE IF NOT EXISTS omnicast_session (
	sessionid INTEGER NOT NULL DEFAULT 0,
	channel INTEGER NOT NULL DEFAULT 1,
	starttime INTEGER NOT NULL,
	endtime INTEGER NOT NULL,
	offset INTEGER NOT NULL DEFAULT 0,
	totalcount INTEGER NOT NULL DEFAULT 0
);

-- ONVIF Recording Control
CREATE TABLE IF NOT EXISTS onvif_Recording (
	key INTEGER primary key,
	token TEXT UNIQUE NOT NULL,
	status TEXT NOT NULL DEFAULT 'Unknown',
	earliestRecording INTEGER,
	latestRecording INTEGER,
	source_Id TEXT DEFAULT 'http://www.w3.org/2005/08/addressing/anonymous',
	source_Name TEXT DEFAULT 'recording',
	source_Location TEXT DEFAULT 'Location Description',
	source_Description TEXT DEFAULT 'Source Description',
	source_Address TEXT DEFAULT 'http://www.w3.org/2005/08/addressing/anonymous',
	content TEXT DEFAULT 'Content Description',
	maximumretentiontime TEXT NOT NULL DEFAULT 'PT0S'
);

CREATE TABLE IF NOT EXISTS onvif_Track (
	token INTEGER primary key,
	recordingToken TEXT REFERENCES ONVIF_RECORDING(token) ON UPDATE CASCADE ON DELETE CASCADE,
	type TEXT NOT NULL DEFAULT 'Video',
	dataFrom INTEGER,
	dataTo INTEGER,
	channel INTEGER,
	stream INTEGER,
	codec TEXT,
	audioSamplerate INTEGER,
	description TEXT NOT NULL DEFAULT 'Description',
	srcToken TEXT NOT NULL DEFAULT 'Profile',
	UNIQUE(recordingToken, type, channel, stream, codec, audioSamplerate, srcToken) ON CONFLICT IGNORE
);

-- ONVFI Recording Control History
CREATE TABLE onvif_Recording_Event (
	key INTEGER primary key,
	recordingToken TEXT NOT NULL,
	audioTrackKey INTEGER,
	videoTrackKey INTEGER,
	metaTrackKey INTEGER,
	eventType INTEGER,
	value INTEGER NOT NULL DEFAULT 0,
	time INTEGER NOT NULL DEFAULT (strftime('%s','now', 'utc')*1000),
	endPointKey INTEGER,
	timespanKey INTEGER NOT NULL
);

CREATE TABLE onvif_Recording_Event_Assist (
	key INTEGER primary key,
	recToken TEXT NOT NULL,
	eventType INTEGER,
	endPointKey INTEGER,
	timespanKey INTEGER NOT NULL
);

CREATE TABLE delete_Assist (
	key INTEGER primary key,
	recToken TEXT NOT NULL,
	starttime INTEGER NOT NULL,
	endtime INTEGER NOT NULL,
	count INTEGER NOT NULL DEFAULT 0
);
-- create indexs (onvif_Recording_Event)
CREATE INDEX IF NOT EXISTS idx_edge_event_token on onvif_Recording(token);
