SELECT version FROM storage_manager;
